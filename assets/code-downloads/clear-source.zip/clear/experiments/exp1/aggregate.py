"""Aggregation (0_overall section 10): paired validation, bootstrap CIs, CLEAR vs the strongest
non-oracle baseline and vs its ablation with Holm correction. Regenerates the main table from
the saved trial_metrics.jsonl files alone."""
from __future__ import annotations

import glob
import json
import os
from collections import defaultdict

import numpy as np

from experiments.common.interfaces import TrialRecord, read_trials
from experiments.common.statistics import bootstrap_ci, holm_correction, paired_difference, seed_cluster_ci, validate_paired_runs

HEADLINE = ("task_success", "order_hit", "interaction_regret", "coverage_at_32")
HIGHER_BETTER = {"task_success": True, "order_hit": True, "interaction_regret": False, "coverage_at_32": True}


def _unit_means(records: list[TrialRecord], metric: str, subset) -> dict[tuple, float]:
    """(scene_id, physics_seed) -> mean over training seeds of `metric` (None values skipped)."""
    b: dict[tuple, list[float]] = defaultdict(list)
    for r in records:
        if not subset(r):
            continue
        v = r.task_success if metric == "task_success" else r.extra.get(metric)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            continue
        b[(r.scene_id, r.physics_seed)].append(float(v))
    return {k: float(np.mean(v)) for k, v in b.items()}


def aggregate_runs(cfg: dict, eval_dir: str) -> dict:
    files = sorted(glob.glob(os.path.join(eval_dir, "*_seed*", "trial_metrics.jsonl")))
    if not files:
        raise SystemExit(f"no trial_metrics.jsonl under {eval_dir}; run evaluate first")
    records: list[TrialRecord] = []
    for f in files:
        records.extend(read_trials(f))
    from experiments.exp1.evaluator import ABLATION_METHODS, HEADLINE_METHODS, REFERENCE_METHODS  # role registry
    # Preserve the historical registry order; final display order comes from table_methods.
    order = list(REFERENCE_METHODS + HEADLINE_METHODS + ABLATION_METHODS)
    methods = sorted({r.method for r in records}, key=lambda m: order.index(m) if m in order else 99)
    # every learned method must contribute every declared training seed; the reference oracle
    # runs once. A method missing a seed would otherwise improve by dropping its worst seed.
    n_seeds_expected = len(cfg.get("evaluate", {}).get("training_seeds", [0]))
    expected = {m: (1 if m in REFERENCE_METHODS else n_seeds_expected) for m in methods}
    n_units = validate_paired_runs(records, methods=methods, expected_seeds=expected)  # raises PairingError
    n_boot = int(cfg.get("evaluate", {}).get("n_boot", 10_000))

    solvable = lambda r: bool(r.extra.get("solvable"))
    coverage_ok = lambda r: solvable(r) and r.extra.get("coverage_at_32") is not None
    unsolvable = lambda r: not solvable(r)

    per_method: dict[str, dict] = {}
    for m in methods:
        recs = [r for r in records if r.method == m]
        row: dict = {"n_units": n_units[m], "training_seeds": sorted({r.training_seed for r in recs}),
                     "privileged": bool(recs[0].extra.get("privileged"))}
        learned = m not in REFERENCE_METHODS
        for metric in HEADLINE + ("invalid_sample_rate_at_32",):
            if learned:
                # two-level bootstrap over scenes AND training seeds (spec 6.3): a scene-only CI
                # cannot see across-seed spread. seed_cluster_ci skips None/NaN, which is how
                # coverage eligibility and successful-plan regret are already encoded.
                ci = seed_cluster_ci(recs, metric, m, n_boot=n_boot)
                ci["n"] = ci["n_units"]
                ci["ci_method"] = "seed_cluster_bootstrap"
            else:
                um = _unit_means(recs, metric, coverage_ok if metric in ("coverage_at_32", "invalid_sample_rate_at_32") else solvable)
                ci = bootstrap_ci(list(um.values()), n_boot=n_boot)
            row[metric] = ci
        row["abstain_accuracy"] = bootstrap_ci(list(_unit_means(recs, "abstain_correct", unsolvable).values()), n_boot=n_boot)
        fails: dict[str, int] = defaultdict(int)
        for r in recs:
            if solvable(r) and not r.task_success:
                fails[str(r.failure_type)] += 1
        row["failure_types_solvable"] = dict(fails)
        row["planning_time_s"] = bootstrap_ci([r.planning_time_s for r in recs], n_boot=2000)
        # slices
        for key in ("scene_family", "k_star_bin"):
            sl: dict[str, dict] = {}
            groups = defaultdict(list)
            for r in recs:
                if solvable(r):
                    groups[str(r.extra.get(key))].append(r)
            for g, rs in sorted(groups.items()):
                sl[g] = {mt: bootstrap_ci(list(_unit_means(rs, mt, solvable).values()), n_boot=1000)["mean"]
                         for mt in ("task_success", "order_hit", "interaction_regret")}
                sl[g]["n"] = len({(r.scene_id, r.physics_seed) for r in rs})
            row[f"by_{key}"] = sl
        per_method[m] = row

    # comparisons: CLEAR versus EACH headline baseline (declared family, Holm-corrected), and
    # separately CLEAR versus each ablation. The baseline set is declared up front -- never
    # chosen from test-set performance.
    comparisons: dict[str, dict] = {}
    families = {"headline": [m for m in HEADLINE_METHODS if m != "clear" and m in methods],
                "ablation": [m for m in ABLATION_METHODS if m in methods]}
    if "clear" in methods:
        for fam_name, others in families.items():
            pvals: dict[str, float] = {}
            for other in others:
                for metric in HEADLINE:
                    sub = coverage_ok if metric == "coverage_at_32" else solvable
                    ua = _unit_means([r for r in records if r.method == "clear"], metric, sub)
                    ub = _unit_means([r for r in records if r.method == other], metric, sub)
                    keys = sorted(set(ua) & set(ub))
                    if not keys:
                        continue
                    d = paired_difference([ua[k] for k in keys], [ub[k] for k in keys], n_boot=n_boot)
                    name = f"clear_vs_{other}:{metric}"
                    comparisons[name] = {**d, "higher_is_better": HIGHER_BETTER[metric], "family": fam_name}
                    pvals[name] = d["p_value"]
            for k, v in (holm_correction(pvals) if pvals else {}).items():
                comparisons[k]["p_holm"] = v
    comparisons["_comparison_families"] = families

    requested_table = cfg.get("evaluate", {}).get("table_methods")
    table_methods = ([m for m in requested_table if m in per_method]
                     if requested_table is not None else methods)
    table = _table(per_method, table_methods)
    out = {"eval_dir": eval_dir, "n_records": len(records), "n_units_per_method": n_units, "methods": methods,
           "per_method": per_method, "comparisons": comparisons, "table_markdown": table,
           "scale_note": "debug scale" if "debug" in eval_dir else ""}
    json_path = os.path.join(eval_dir, "aggregate_metrics.json")
    with open(json_path, "w") as f:
        json.dump(out, f, indent=1, default=float)
    table_path = os.path.join(eval_dir, "results_table.md")
    with open(table_path, "w") as f:
        f.write(table + "\n")
    latex_path = os.path.join(eval_dir, "results_table.tex")
    with open(latex_path, "w") as f:
        f.write(_table_latex(per_method, table_methods) + "\n")
    out["json_path"], out["table_path"], out["latex_path"] = json_path, table_path, latex_path
    return out


def _fmt(ci: dict, pct: bool) -> str:
    if ci["n"] == 0 or ci["mean"] != ci["mean"]:
        return "n/a"
    if pct:
        return f"{100 * ci['mean']:.1f} [{100 * ci['ci_lo']:.1f}, {100 * ci['ci_hi']:.1f}]"
    return f"{ci['mean']:.3f} [{ci['ci_lo']:.3f}, {ci['ci_hi']:.3f}]"


def _table(per_method: dict, methods: list[str]) -> str:
    names = {"oracle": "Exact Search Oracle (privileged)", "autoregressive": "Autoregressive Transformer",
             "gumbel_sinkhorn": "Gumbel-Sinkhorn Ordering", "polynet": "PolyNet-style Multi-Strategy AR",
             "clear_mean": "CLEAR-Mean (ablation)", "clear_seq": "CLEAR sequential mover set (ablation)",
             "clear": "CLEAR"}
    lines = ["| Method | Task Success % ↑ | Order Hit % ↑ | Successful-plan Regret ↓ | Order Coverage@32 % ↑ | InvalidSample@32 % ↓ | n (all / coverage) |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for m in methods:
        r = per_method[m]
        lines.append(f"| {names.get(m, m)} | {_fmt(r['task_success'], True)} | {_fmt(r['order_hit'], True)} | "
                     f"{_fmt(r['interaction_regret'], False)} | {_fmt(r['coverage_at_32'], True)} | "
                     f"{_fmt(r['invalid_sample_rate_at_32'], True)} | "
                     f"{r['task_success']['n']} / {r['coverage_at_32']['n']} |")
    lines.append("")
    lines.append("Mean [95% CI]: learned rows use a seed-cluster bootstrap over scenes x training seeds; the oracle "
                 "row a scene bootstrap. "
                 "Task Success and Order Hit use all test scenes; regret uses successful predictions only; "
                 "Order Coverage@32 uses scenes with a complete optimal set of >= 2 orders and is independent "
                 "of target execution. InvalidSample@32 is the fraction of those sampled plans that fail "
                 "end-to-end execution. Oracle coverage is over its enumerated set (privileged).")
    return "\n".join(lines)


def _table_latex(per_method: dict, methods: list[str]) -> str:
    names = {"autoregressive": "Autoregressive", "gumbel_sinkhorn": "Gumbel-Sinkhorn",
             "polynet": "PolyNet-style AR", "clear_mean": "CLEAR-Mean",
             "clear": "CLEAR (ours)"}
    metrics = (("task_success", True, True), ("order_hit", True, True),
               ("interaction_regret", False, False), ("coverage_at_32", True, True),
               ("invalid_sample_rate_at_32", False, True))
    best = {}
    for metric, higher, _ in metrics:
        values = {m: per_method[m][metric]["mean"] for m in methods
                  if per_method[m][metric]["mean"] == per_method[m][metric]["mean"]}
        best[metric] = (max if higher else min)(values.values()) if values else None

    def cell(m, metric, pct):
        r = per_method[m][metric]
        scale = 100 if pct else 1
        digits = 1 if pct else 3
        s = f"{scale*r['mean']:.{digits}f} [{scale*r['ci_lo']:.{digits}f}, {scale*r['ci_hi']:.{digits}f}]"
        return f"\\textbf{{{s}}}" if abs(r["mean"] - best[metric]) < 1e-12 else s

    lines = ["\\begin{table*}[t]", "\\centering", "\\footnotesize",
             "\\setlength{\\tabcolsep}{4pt}", "\\begin{tabular}{lccccc}", "\\hline",
             "Method & Task Success $\\uparrow$ & Order Hit $\\uparrow$ & Regret $\\downarrow$ & "
             "Coverage@32 $\\uparrow$ & Invalid@32 $\\downarrow$ \\\\", "\\hline"]
    for m in methods:
        vals = [cell(m, metric, pct) for metric, _, pct in metrics]
        lines.append(f"{names.get(m,m)} & " + " & ".join(vals) + " \\\\")
    lines += ["\\hline", "\\end{tabular}",
              "\\caption{Results on the fresh 2D-grid test split. Values are mean [95\\% CI]; all metrics except regret are percentages. Intervals use a two-level bootstrap over scenes and training seeds (five seeds). Regret is conditional on successful predictions. Coverage@32 and Invalid@32 use scenes with a complete optimal set containing at least two orders.}",
              "\\label{tab:grid2d_results}", "\\end{table*}"]
    return "\n".join(lines)
