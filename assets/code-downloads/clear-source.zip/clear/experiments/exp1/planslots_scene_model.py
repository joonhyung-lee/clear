"""Plan slots with an explicit post-interaction scene update (candidate C2+, 2D Grid).

For candidate k and interaction r of its plan, a learned update
    s_{r+1} = T_theta(s_r, a_r)          a_r = (object moved so far, its target)
    A_{r+1} = F_theta(s_{r+1})           interaction affordance of the remaining objects
is trained on labels from the Grid's known state transition (GridEnv.apply after each labelled
move, then check_move for every remaining object), and the rank-causal flow of object j reads
the state token s_{rank_j}[j], i.e. the scene as it will be when j is moved.

scene_update = 'aux'   the update + affordance head are trained but the flow still reads the
                       slot tokens (auxiliary-loss control)
scene_update = 'flow'  the flow reads the updated state tokens; at inference the targets are
                       generated in `passes` rounds: pass 1 from the slot tokens, pass p>1 from
                       the states built with the previous pass's targets (teacher forcing in
                       training, self-conditioning at test; no oracle at inference)
Everything else is planslots_model.py (Hungarian 1:1 matching, per-plan targets, prior).
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from experiments.exp1.environment import DIRECTIONS, AgentProfile, GridEnv
from experiments.exp1.planslots_model import GridPlanSlotsModel
from experiments.exp1.shared_model import GridAffordanceFlowModel

ARCHITECTURE = 'clear-planslots-scene-v1'


class GridPlanSlotsSceneModel(GridPlanSlotsModel):
    def __init__(self, canvas_hw, scene_update='flow', aff_weight=1.0, passes=2, **kw):
        super().__init__(canvas_hw, **kw)
        dim = int(kw.get('dim', 128))
        if scene_update not in ('aux', 'flow'):
            raise ValueError("scene_update must be 'aux' or 'flow'")
        self.scene_update, self.aff_weight, self.passes = scene_update, float(aff_weight), int(passes)
        self.act = nn.Linear(3, dim)                                   # [target code (2), moved flag]
        layer = nn.TransformerEncoderLayer(dim, nhead=4, dim_feedforward=2 * dim, dropout=0.0, batch_first=True, norm_first=True)
        self.update = nn.TransformerEncoder(layer, num_layers=1)
        self.post_aff = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, 1))
        self._aff_cache: dict = {}
        self._aux = None

    # -- labels: affordance of the remaining objects after each labelled move -----------------------
    def _post_prefix_affordance(self, ex, order, x1, n):
        key = (id(ex.grid_scene), tuple(order))
        if key in self._aff_cache:
            return self._aff_cache[key]
        scene, agent = ex.grid_scene, ex.public_agent
        env = GridEnv(scene, AgentProfile(agent.agent_id, agent.structure, agent.can_push))
        objs = scene.objects
        lab, msk = np.zeros((n, n), np.float32), np.zeros((n, n), bool)
        for r in range(len(order)):
            moved = set(order[:r])
            for j, obj in enumerate(objs):
                if j in moved:
                    continue
                rr, cc = env.positions[obj.object_id]
                lab[r, j] = float(any(env.check_move(obj.object_id, (rr + dr, cc + dc)).ok for dr, dc in DIRECTIONS.values()))
                msk[r, j] = True
            j = order[r]
            res = env.apply(objs[j].object_id, (int(round(float(x1[j][1]))), int(round(float(x1[j][0])))))  # pose is [col, row]
            if not res.success:
                raise ValueError(f'labelled plan {order} is not executable at step {r}: {res.info}')
        self._aff_cache[key] = (lab, msk)
        return lab, msk

    def make_batch(self, examples, device='cpu', include_targets=True):
        batch = super().make_batch(examples, device, include_targets)
        if include_targets:
            n = batch['object_mask'].shape[1]
            aff = np.zeros((len(examples), self.max_plans, n, n), np.float32)
            aff_mask = np.zeros((len(examples), self.max_plans, n, n), bool)
            for i, ex in enumerate(examples):
                orders = list(getattr(ex, 'valid_orders', []) or []) or list(getattr(ex, 'plan_supervision', {}).keys()) or list(ex.orders)
                orders = sorted({tuple(int(j) for j in o) for o in orders})[:self.max_plans]
                sup = getattr(ex, 'plan_supervision', {}) or {}
                for p, order in enumerate(orders):
                    x1 = sup[order][0] if order in sup else ex.x1
                    lab, msk = self._post_prefix_affordance(ex, order, x1, n)
                    aff[i, p], aff_mask[i, p] = lab, msk
            batch['plan_aff'], batch['plan_aff_mask'] = torch.as_tensor(aff, device=device), torch.as_tensor(aff_mask, device=device)
        return batch

    # -- state update ---------------------------------------------------------------------------------
    def _states(self, tokens, mask, rank, target, n_steps):
        """(M,R,n,d): state after r = 0..R-1 moves of the plan, from tokens + teacher-forced actions."""
        out = []
        for r in range(n_steps):
            moved = (rank >= 0) & (rank < r)
            act_in = torch.cat([target * moved[..., None], moved[..., None].float()], -1)
            out.append(self.update(tokens + self.act(act_in), src_key_padding_mask=~mask))
        return torch.stack(out, 1)

    @staticmethod
    def _gather_state(states, rank):
        idx = rank.clamp(min=0)[:, None, :, None].expand(-1, 1, -1, states.shape[-1])          # (M,1,n,d)
        return states.gather(1, idx)[:, 0]                                                       # (M,n,d)

    # -- training -------------------------------------------------------------------------------------
    def _slot_flow_loss(self, h, batch, pairs, generator):
        if not pairs:
            self._aux = h['objects'].sum() * 0
            return h['objects'].sum() * 0
        bi = torch.tensor([p[0] for p in pairs], device=h['objects'].device)
        ki = torch.tensor([p[1] for p in pairs], device=bi.device)
        pi = torch.tensor([p[2] for p in pairs], device=bi.device)
        tokens, rank = h['modulated'][bi, ki], batch['plans'][bi, pi]
        target, mask = batch['plan_targets'][bi, pi], batch['object_mask'][bi]
        n_steps = int((rank >= 0).sum(1).max().clamp(min=1))
        states = self._states(tokens, mask, rank, target, n_steps)                              # (M,R,n,d)
        logits = self.post_aff(states).squeeze(-1)                                               # (M,R,n)
        lab, msk = batch['plan_aff'][bi, pi, :n_steps], batch['plan_aff_mask'][bi, pi, :n_steps]
        self._aux = (F.binary_cross_entropy_with_logits(logits[msk], lab[msk]) if msk.any() else logits.sum() * 0)
        objects = self._gather_state(states, rank) if self.scene_update == 'flow' else tokens
        return self._flow_mse(h, batch, bi, objects, mask, rank, target, generator)

    def loss(self, batch, generator=None):
        total, parts = super().loss(batch, generator)
        aux = self._aux if self._aux is not None else torch.zeros((), device=batch['object_mask'].device)
        parts['post_affordance'] = float(aux.detach())
        return total + self.aff_weight * aux, parts

    # -- inference: self-conditioned passes ---------------------------------------------------------------
    def sample_targets(self, batch, order, steps=30, generator=None, h=None, draws=1):
        if self.scene_update != 'flow':
            return super().sample_targets(batch, order, steps, generator, h=h, draws=draws)
        h = self.encode(batch) if h is None else h
        k = h.get('slot_of_order', {}).get(tuple(order), int(h['top_slot'][0]))
        tokens = h['modulated'][:, k]                                                            # (1,n,d)
        mask = batch['object_mask']
        rank = torch.full_like(mask, -1, dtype=torch.long)
        if order:
            rank[0, list(order)] = torch.arange(len(order), device=rank.device)
        scale = tokens.new_tensor(self.code_scale())
        objects = tokens
        for p in range(self.passes):
            xy = GridAffordanceFlowModel.sample_targets(self, batch, order, steps, generator, h=dict(h, objects=objects), draws=draws)
            if p == self.passes - 1 or not order:
                return xy
            code = (xy - batch['x0']) / scale                                                     # (draws,n,2)
            m = code.shape[0]
            states = self._states(tokens.expand(m, -1, -1), mask.expand(m, -1), rank.expand(m, -1), code, len(order))
            objects = self._gather_state(states, rank.expand(m, -1))                              # (draws,n,d)
        return xy
