"""CLEAR with K parallel plan codes trained by a set-to-set cover objective (candidate C1', 2D Grid).

Port of the v5 `PlanCodes` head (clear/model/v4/plan_code.py) to the Grid model, replacing the FSQ
posterior/prior variant of `plancode_model.py`, which failed because its scene-conditioned prior could
not recover the posterior's code (outputs/leap2026/WP-A1/README.md). Here there is NO posterior:

  codes      K learned vectors; each FiLM-modulates the encoded object tokens and the shared
             OrderingHead decodes a skeleton per code (selection logit + priority per object)
  cover      every valid minimal plan of the example is matched to its best code (min over codes of
             selection BCE + pairwise rank loss); mean over plans   -> the code set must cover the set
  commit     every winning code is matched to its best plan          -> codes stay distinct/committed
  prior      BCE on which codes won, from the scene + embodiment    -> enumeration order at inference
Inference enumerates codes by prior probability, decodes each deterministically (selection > 0, sorted
by priority) and drops duplicates; no sampler, no schedule. Flow, affordance head, inputs, adaptation
stages and checkpoint format are the paper grid model's, so the paired comparison isolates the head.

Supervision: ALL valid minimal orders of a scene (`Example.plan_supervision`, the oracle's complete
optimal set) instead of the single committed order the paper head sees.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from clear.model.clear import per_example_rank_loss
from experiments.exp1.shared_model import GridAffordanceFlowModel

ARCHITECTURE = 'clear-setcover-v1'


def masked_mean(x, mask):
    w = mask.to(x.dtype)[..., None]
    return (x * w).sum(1) / w.sum(1).clamp_min(1.0)


class GridSetCoverModel(GridAffordanceFlowModel):
    is_plancode = True          # planner API: encode() exposes prior_logits, enumerate_orders()

    def __init__(self, canvas_hw, n_codes=16, max_plans=8, commit_weight=0.5, prior_weight=1.0, **kw):
        super().__init__(canvas_hw, **kw)
        dim = int(kw.get('dim', 128))
        self.K, self.max_plans = int(n_codes), int(max_plans)
        self.commit_weight, self.prior_weight = float(commit_weight), float(prior_weight)
        self.codes = nn.Parameter(torch.randn(self.K, dim) * 0.02)
        self.film = nn.Linear(dim, 2 * dim)
        self.prior = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, self.K))

    # -- batches: attach every valid order ---------------------------------------------
    def make_batch(self, examples, device='cpu', include_targets=True):
        batch = super().make_batch(examples, device, include_targets)
        if include_targets:
            n = batch['object_mask'].shape[1]
            plans = torch.full((len(examples), self.max_plans, n), -1, dtype=torch.long)
            plan_mask = torch.zeros(len(examples), self.max_plans, dtype=torch.bool)
            for i, ex in enumerate(examples):
                orders = list(getattr(ex, 'valid_orders', []) or []) or list(getattr(ex, 'plan_supervision', {}).keys()) or list(ex.orders)
                orders = sorted({tuple(int(j) for j in o) for o in orders})[:self.max_plans]
                for p, order in enumerate(orders):
                    plan_mask[i, p] = True
                    for r, j in enumerate(order):
                        plans[i, p, j] = r
            batch['plans'], batch['plan_mask'] = plans.to(device), plan_mask.to(device)
        return batch

    # -- heads ---------------------------------------------------------------------------
    def _film(self, objects):
        scale, shift = self.film(self.codes).chunk(2, -1)
        return objects[:, None] * (1 + scale[None, :, None]) + shift[None, :, None]        # (b,K,n,d)

    def decode_all(self, h):
        return self.ordering(self._film(h['objects']))                                      # each (b,K,n)

    def _encode(self, batch):
        h = super()._encode(batch)
        pooled = masked_mean(h['objects'], batch['object_mask'])
        h['prior_logits'] = self.prior(torch.cat([pooled, h['embodiment'][:, 0]], -1))
        return h

    def encode(self, batch):
        """Planner view: selection / mu / sigma of the most probable code."""
        h = self._encode(batch)
        sel, mu, sigma = self.decode_all(h)
        k = h.get('rank_logits', h['prior_logits']).argmax(-1)
        idx = torch.arange(sel.shape[0], device=sel.device)
        h['code_index'] = k
        h['selection'], h['mu'], h['sigma'] = sel[idx, k], mu[idx, k], sigma[idx, k]
        return h

    @torch.no_grad()
    def enumerate_orders(self, h, n_objects: int, max_codes: int | None = None):
        """Distinct skeletons of ONE scene in prior order: [(order tuple, code index, prior prob)]."""
        logits = h.get('rank_logits', h['prior_logits'])[0]
        probs = torch.softmax(h['prior_logits'][0], -1)
        ranked = logits.argsort(descending=True)
        if max_codes is not None:
            ranked = ranked[:max_codes]
        sel, mu, _ = self.decode_all(h)
        out, seen = [], set()
        for k in ranked.tolist():
            chosen = (sel[0, k, :n_objects] > 0).nonzero(as_tuple=False).flatten().tolist()
            order = tuple(sorted(chosen, key=lambda j: float(mu[0, k, j])))
            if order not in seen:
                seen.add(order)
                out.append((order, int(k), float(probs[k])))
        return out

    # -- training ---------------------------------------------------------------------------
    def loss(self, batch, generator=None):
        if 'affordance_target' not in batch:
            raise ValueError('affordance labels required; regenerate the training dataset')
        h = self._encode(batch)
        return self._loss_from(h, batch, generator)

    def _loss_from(self, h, batch, generator=None):
        mask, plans, plan_mask = batch['object_mask'], batch['plans'], batch['plan_mask']
        b, n = mask.shape
        K, P = self.K, plans.shape[1]
        sel, mu, sigma = self.decode_all(h)                                                 # (b,K,n)
        h['_decoded'] = (sel, mu, sigma)
        sel_f = sel[:, :, None].expand(b, K, P, n).reshape(-1, n)
        mu_f = mu[:, :, None].expand(b, K, P, n).reshape(-1, n)
        rank_f = plans[:, None].expand(b, K, P, n).reshape(-1, n)
        mask_f = mask[:, None, None].expand(b, K, P, n).reshape(-1, n)
        selected = mask_f & (rank_f >= 0)
        sel_loss = F.binary_cross_entropy_with_logits(sel_f, selected.float(), reduction='none')
        sel_loss = (sel_loss * mask_f).sum(-1) / mask_f.sum(-1).clamp(min=1)
        sentinel = torch.where(selected, rank_f, torch.full_like(rank_f, n))
        valid = selected if getattr(self, 'rank_selected_only', False) else mask_f
        order_loss = per_example_rank_loss(mu_f, sentinel, valid)
        L = (sel_loss + order_loss).view(b, K, P).masked_fill(~plan_mask[:, None, :], float('inf'))
        best_per_plan, winner = L.min(1)                                                    # (b,P)
        cover = best_per_plan.masked_fill(~plan_mask, 0).sum(1) / plan_mask.sum(1).clamp(min=1)
        wins = torch.zeros(b, K, device=sel.device).scatter_add_(1, winner, plan_mask.float()).gt(0).float()   # padded plans add 0
        best_per_code, _ = L.min(2)                                                         # (b,K)
        commit = (best_per_code.masked_fill(wins == 0, 0) * wins).sum(1) / wins.sum(1).clamp(min=1)
        prior = F.binary_cross_entropy_with_logits(h['prior_logits'], wins.detach())
        parts = dict(cover=cover.mean(), commit=commit.mean(), prior=prior)
        parts['flow'] = self.flow_loss(h, batch, generator)
        logits, labels = h['interaction_affordance_logits'], batch['affordance_target']
        parts['affordance'] = (F.binary_cross_entropy_with_logits(logits[mask], labels[mask]) if mask.any() else logits.sum() * 0)
        total = parts['cover'] + self.commit_weight * parts['commit'] + self.prior_weight * parts['prior'] + parts['flow'] + parts['affordance']
        count_weight = getattr(self, 'cardinality_weight', 0.)
        if count_weight:
            # cardinality of the best code per plan vs. the plan's size
            idx = torch.arange(b, device=sel.device)[:, None].expand(b, P)
            best_sel = torch.sigmoid(sel[idx, winner]) * mask[:, None]                      # (b,P,n)
            size = (plans >= 0).sum(-1).to(best_sel.dtype)
            card = ((best_sel.sum(-1) - size) ** 2 * plan_mask).sum() / plan_mask.sum().clamp(min=1)
            parts['cardinality'] = card
            total = total + count_weight * card
        with torch.no_grad():
            parts['code_usage'] = wins.mean(0).gt(0).float().mean()
            parts['kl'] = torch.zeros((), device=sel.device)                                # for log compatibility
        return total, {k: float(v.detach()) for k, v in parts.items()}
