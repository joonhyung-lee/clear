"""Scene generation for the controlled interaction-ordering experiment.

Abstract topology TEMPLATES are enumerated first (family, band count, gaps per band, plug
pattern, distractor count, extra open bands) and split into train/val/test by template
(stratified per family). Only then are the concrete quantities sampled per scene: band rows,
gap columns, start/goal columns, object identities, and optional wall noise. Every generated
scene uses the same abstract agent, is labelled by the exact oracle, and is
REJECTED unless it satisfies its family's predicate (spec 4.2):

  DIRECT             solvable, K* = 0
  SINGLE_GATE        K* = 1, |Pi*| = 1
  CHAIN              K* >= 2, |Pi*| = 1 (forced precedence), set complete
  BRANCH             K* >= 2, |Pi*| >= 2, set complete
  DISTRACTOR         K* >= 1, >= 2 movable objects that appear in no optimal order

Terrain is the legacy wall-band world of clear.data.grid.random_scene / walled_room_scene
(full-width WALL rows with gaps). The queued one-wide-corridor chain of clear.grid.chain_scene
is NOT used: under push semantics an object in a one-wide corridor cannot be turned, so that
layout is unsolvable; stacked plugged gates carry the forced-precedence role instead.
"""
from __future__ import annotations

import itertools
from dataclasses import asdict, dataclass

import numpy as np

from clear.data.capability import WALL

from experiments.exp1.environment import ALL_DIRECTIONS, FIXED_AGENT, FREE, AgentProfile, GridObject, GridScene
from experiments.exp1.oracle import OracleResult, solve

FAMILIES = ("DIRECT", "SINGLE_GATE", "CHAIN", "BRANCH", "DISTRACTOR")


@dataclass(frozen=True)
class Template:
    template_id: str
    family: str
    n_bands: int                             # bands carrying the task structure
    gaps: tuple[int, ...]                    # gaps per structural band
    plugged: tuple[tuple[bool, ...], ...]    # per structural band, per gap
    n_distractors: int
    extra_open_bands: int = 0                # additional fully open bands (route-neutral)
    open_gaps: int = 1                       # gaps in each extra open band

    @property
    def n_plugs(self) -> int:
        return sum(sum(p) for p in self.plugged)

    @property
    def n_objects(self) -> int:
        return self.n_plugs + self.n_distractors

    @property
    def total_bands(self) -> int:
        return self.n_bands + self.extra_open_bands

    def to_dict(self) -> dict:
        return asdict(self)


def _T(family, n_bands, gaps, plugged, nd, extra_open=0, open_gaps=1) -> Template:
    gaps, plugged = tuple(gaps), tuple(tuple(p) for p in plugged)
    if extra_open == 0:
        open_gaps = 1
    pl = "_".join("".join("1" if b else "0" for b in row) for row in plugged)
    tid = f"{family}.b{n_bands}.g{''.join(map(str, gaps))}.p{pl}.d{nd}.x{extra_open}{open_gaps}"
    return Template(tid, family, n_bands, gaps, plugged, nd, extra_open, open_gaps)


def enumerate_templates() -> list[Template]:
    """The finite abstract template pool. Deterministic; the split is a function of this list."""
    T: list[Template] = []
    X = ((0, 1), (1, 1), (1, 2))  # (extra_open_bands, open_gaps) variants
    # DIRECT: every band keeps at least one open gap; objects = plugs on the other gaps + distractors
    for nb in (1, 2):
        for gaps in itertools.product((1, 2), repeat=nb):
            for plug in itertools.product(*[[tuple(c) for c in itertools.product((False, True), repeat=g)
                                             if not all(c)] for g in gaps]):
                for nd in (0, 2, 4):
                    if sum(sum(p) for p in plug) + nd >= 1:
                        T.append(_T("DIRECT", nb, gaps, plug, nd))
    # SINGLE_GATE: one plugged gate, <= 1 distractor
    for nd in (0, 1):
        for xo, og in X:
            T.append(_T("SINGLE_GATE", 1, (1,), ((True,),), nd, xo, og))
    # CHAIN: stacked single plugged gates -> forced precedence (the queued-corridor variant of
    # clear.grid.chain_scene is unsolvable under PUSH semantics and is not used)
    for nb in (2, 3):
        for nd in (0, 1):
            for xo, og in X:
                T.append(_T("CHAIN", nb, (1,) * nb, ((True,),) * nb, nd, xo, og))
    # BRANCH: one alternative gate plus at least one additional required gate. Every accepted
    # scene therefore has K* >= 2 and at least two optimal interaction sequences.
    for nd in (0, 1):
        for xo, og in X:
            T.append(_T("BRANCH", 2, (2, 1), ((True, True), (True,)), nd, xo, og))
            T.append(_T("BRANCH", 2, (1, 2), ((True,), (True, True)), nd, xo, og))
            T.append(_T("BRANCH", 2, (2, 2), ((True, True), (True, True)), nd, xo, og))
    # DISTRACTOR: gate / chain structure plus >= 2 non-contributing movable objects
    for nd in (2, 3, 4):
        for xo, og in X:
            T.append(_T("DISTRACTOR", 1, (1,), ((True,),), nd, xo, og))
            T.append(_T("DISTRACTOR", 2, (1, 1), ((True,), (True,)), nd, xo, og))
    ids = [t.template_id for t in T]
    assert len(ids) == len(set(ids)), "template ids must be unique"
    return T


def split_templates(templates: list[Template], seed: int, fractions: dict[str, float]) -> dict[str, str]:
    """template_id -> split, stratified per family; every split gets >= 1 template per family
    when the family has >= 3 templates."""
    rng = np.random.default_rng(seed)
    out: dict[str, str] = {}
    names = ["train", "val", "test"]
    fr = np.array([fractions.get(n, 0.0) for n in names], dtype=float)
    fr = fr / fr.sum()
    for fam in FAMILIES:
        pool = sorted(t.template_id for t in templates if t.family == fam)
        rng.shuffle(pool)
        n = len(pool)
        counts = np.floor(fr * n).astype(int)
        if n >= 3:
            counts = np.maximum(counts, 1)
        while counts.sum() > n:
            counts[int(np.argmax(counts))] -= 1
        while counts.sum() < n:
            counts[int(np.argmax(fr * n - counts))] += 1
        k = 0
        for name, c in zip(names, counts):
            for tid in pool[k:k + c]:
                out[tid] = name
            k += c
    return out


# --------------------------------------------------------------------------------------
# concrete sampling


class RejectScene(Exception):
    pass


def _band_rows(rng, h: int, n_bands: int) -> list[int]:
    lo, hi = 2, h - 3
    cands = list(range(lo, hi + 1))
    for _ in range(64):
        rng.shuffle(cands)
        rows: list[int] = []
        for r in cands:
            if all(abs(r - x) >= 2 for x in rows):
                rows.append(r)
            if len(rows) == n_bands:
                return sorted(rows)
    raise RejectScene("no band rows")


def _gap_cols(rng, w: int, n_gaps: int, prev: list[int] | None, stagger: bool) -> list[int]:
    cands = list(range(1, w - 1))
    if stagger and prev:
        far = [c for c in cands if all(abs(c - p) >= max(2, w // 3) for p in prev)]
        if len(far) >= n_gaps:
            cands = far
    rng.shuffle(cands)
    cols: list[int] = []
    for c in cands:
        if all(abs(c - x) >= 2 for x in cols):
            cols.append(c)
        if len(cols) == n_gaps:
            return cols
    raise RejectScene("no gap cols")


def _sample_terrain(rng, t: Template, h: int, w: int):
    """-> (terrain, start, goal, structural gap cells per band, all gap cells)."""
    terrain = np.full((h, w), FREE, dtype=np.int64)
    rows = _band_rows(rng, h, t.total_bands)
    # which of the rows carry the structure (the rest are open bands)
    struct_rows = sorted(rng.choice(rows, size=t.n_bands, replace=False).tolist())
    stagger = t.family in ("CHAIN", "DISTRACTOR")
    prev: list[int] = []
    gap_cells: list[list[tuple[int, int]]] = []
    all_gaps: list[tuple[int, int]] = []
    si = 0
    for row in rows:
        terrain[row, :] = WALL
        if row in struct_rows:
            g = t.gaps[si]
            si += 1
            cols = _gap_cols(rng, w, g, prev, stagger)
            gap_cells.append([(row, c) for c in cols])
        else:
            cols = _gap_cols(rng, w, t.open_gaps, prev, False)
        terrain[row, cols] = FREE
        all_gaps += [(row, c) for c in cols]
        prev = cols
    start = (0, int(rng.integers(0, w)))
    goal = (h - 1, int(rng.integers(0, w)))
    return terrain, start, goal, gap_cells, all_gaps


def _room_cells(terrain, exclude: set, gaps: list) -> list[tuple[int, int]]:
    """Free cells strictly inside the rooms: not in a band row, not 4-adjacent to a gap
    (a gap neighbour would change the route structure the template encodes)."""
    h, w = terrain.shape
    near = set()
    for (r, c) in gaps:
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1), (0, 0)):
            near.add((r + dr, c + dc))
    band_rows = {r for r in range(h) if (terrain[r] == WALL).sum() >= w - 2}
    return [(r, c) for r in range(1, h - 1) for c in range(w)
            if terrain[r, c] != WALL and r not in band_rows and (r, c) not in exclude and (r, c) not in near]


def _wall_noise(rng, terrain, p: float, protect: set):
    h, w = terrain.shape
    for r in range(1, h - 1):
        for c in range(w):
            if terrain[r, c] == FREE and (r, c) not in protect and rng.random() < p:
                terrain[r, c] = WALL


def sample_scene(rng: np.random.Generator, t: Template, map_size: int, cfg: dict):
    """One concrete (scene, fixed agent) draw from a template."""
    h = w = int(map_size)
    terrain, start, goal, gap_cells, all_gaps = _sample_terrain(rng, t, h, w)
    plug_cells: list[tuple[int, int]] = []
    for cells, flags in zip(gap_cells, t.plugged):
        for cell, plugged in zip(cells, flags):
            if plugged:
                plug_cells.append(cell)
    # Object dynamics are deliberately constant. Experiment 01 varies topology and order,
    # not physical capability.
    plug_classes = [1] * len(plug_cells)

    # distractors in the rooms
    exclude = set(plug_cells) | {start, goal}
    room = _room_cells(terrain, exclude, all_gaps)
    rng.shuffle(room)
    if len(room) < t.n_distractors:
        raise RejectScene("no room for distractors")
    dcells = room[:t.n_distractors]
    dclasses = [1] * len(dcells)

    noise = float(cfg.get("wall_noise", 0.0))
    if noise > 0:
        protect = set(plug_cells) | set(dcells) | {start, goal} | set(all_gaps)
        _wall_noise(rng, terrain, noise, protect)

    cells = plug_cells + dcells
    classes = plug_classes + dclasses
    ids = list(range(len(cells)))
    rng.shuffle(ids)  # object identity is not tied to role
    objs = []
    for oid, cell, mc in zip(ids, cells, classes):
        objs.append(GridObject(oid, cell, mass_class=mc, pushable_directions=ALL_DIRECTIONS))
    objs.sort(key=lambda o: o.object_id)
    return GridScene(terrain, start, goal, objs), FIXED_AGENT


# --------------------------------------------------------------------------------------
# family predicates


def family_ok(family: str, r: OracleResult) -> bool:
    if family == "DIRECT":
        return r.solvable and r.min_interactions == 0
    if family == "SINGLE_GATE":
        return r.solvable and r.min_interactions == 1 and len(r.optimal_plans) == 1
    if family == "CHAIN":
        return r.solvable and (r.min_interactions or 0) >= 2 and len(r.optimal_plans) == 1 \
            and r.optimal_set_complete
    if family == "BRANCH":
        return r.solvable and (r.min_interactions or 0) >= 2 and len(r.optimal_plans) >= 2 \
            and r.optimal_set_complete
    if family == "DISTRACTOR":
        return r.solvable and (r.min_interactions or 0) >= 1 and len(r.distractors) >= 2
    raise ValueError(family)


@dataclass
class GeneratedScene:
    scene: GridScene
    agent: AgentProfile
    result: OracleResult
    template: Template
    map_size: int
    attempts: int


def generate_scene(rng: np.random.Generator, t: Template, cfg: dict, max_attempts: int = 60) -> GeneratedScene | None:
    # a map of height h fits (h - 5) // 2 + 1 bands two rows apart inside rows [2, h - 3]
    sizes = [int(s) for s in cfg.get("map_sizes", [8]) if (int(s) - 5) // 2 + 1 >= t.total_bands]
    if not sizes:
        return None
    max_orders = int(cfg.get("oracle", {}).get("max_orders", 64))
    for attempt in range(1, max_attempts + 1):
        ms = int(sizes[int(rng.integers(len(sizes)))])
        try:
            scene, agent = sample_scene(rng, t, ms, cfg)
        except RejectScene:
            continue
        result = solve(scene, agent, max_orders=max_orders)
        if family_ok(t.family, result):
            return GeneratedScene(scene, agent, result, t, ms, attempt)
    return None
