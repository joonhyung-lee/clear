"""CLEAR with an enumerable discrete plan-skeleton code (LEAP 2026 architecture candidate C1).

The paper model draws interaction orders from Gaussian latent priorities (mu, sigma) and needs a
validation-chosen joint sampling schedule (`coverage_first`) to reach its Cov@8; with independent
draws the same checkpoints fall from 88.1 to 54.2 Cov@8 (outputs/leap2026/WP-2). This variant
makes the *set of proposals* a property of the model instead of the sampler:

  posterior  q(c | scene, embodiment, plan): encoded object tokens + a learned rank embedding
             -> small transformer -> masked mean -> Linear(dim, 3) -> FSQ(levels)  (no codebook,
             no commitment/KL; index <-> code is a bijection, arXiv 2309.15505)
  prior      p(c | scene, embodiment): MLP on [pooled object tokens ; embodiment token] -> K logits
  ordering   the unchanged OrderingHead applied to object tokens shifted by code_in(c); selection
             logits and priorities therefore encode the whole skeleton (which objects, which order)

Training: the ordering / selection / flow / affordance losses are computed with the posterior code
(teacher forcing); the prior is trained with cross-entropy to the posterior index (stop-gradient).
Inference: codes are enumerated in prior order, each decoded deterministically (selection > 0,
sorted by mu), duplicates removed. Draw d of the coverage loop is the d-th distinct skeleton, the
point prediction is the first. The flow and its rank-causal mask are untouched.

Everything else (inputs, `push_reachability` channel, adaptation stages, checkpoint format) is the
paper grid model, so the paired comparison against `clear-affordance-order-causal-v1` trained
under the same configuration isolates the plan code.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn

from clear.model.affordancenet import AffordanceTransformer
from clear.model.quantizers import FSQ
from experiments.exp1.shared_model import GridAffordanceFlowModel

ARCHITECTURE = 'clear-plancode-fsq-v1'
MAX_RANK = 16


def masked_mean(x, mask):
    w = mask.to(x.dtype)[..., None]
    return (x * w).sum(1) / w.sum(1).clamp_min(1.0)


class GridPlanCodeModel(GridAffordanceFlowModel):
    is_plancode = True

    def __init__(self, canvas_hw, levels=(5, 5, 5), posterior_depth=2, prior_weight=1.0, **kw):
        super().__init__(canvas_hw, **kw)
        dim, heads = int(kw.get('dim', 128)), int(kw.get('heads', 4))
        self.levels = [int(v) for v in levels]
        self.prior_weight = float(prior_weight)
        self.rank_embed = nn.Embedding(MAX_RANK + 2, dim)          # 0 = not selected, r + 1 = rank r
        self.posterior = AffordanceTransformer(dim, depth=int(posterior_depth), heads=heads, dim_head=dim // heads)
        self.to_code = nn.Linear(dim, len(self.levels))
        self.fsq = FSQ(levels=self.levels, dim=len(self.levels))
        self.codebook_size = int(self.fsq.codebook_size)
        self.code_in = nn.Sequential(nn.Linear(len(self.levels), dim), nn.GELU(), nn.Linear(dim, dim))
        self.prior = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, self.codebook_size))

    # -- pieces -----------------------------------------------------------------------
    def _encode(self, batch):
        h = super()._encode(batch)
        pooled = masked_mean(h['objects'], batch['object_mask'])
        h['prior_logits'] = self.prior(torch.cat([pooled, h['embodiment'][:, 0]], -1))
        return h

    def posterior_code(self, h, batch):
        rank, mask = batch['rank'], batch['object_mask']
        n = rank.shape[1]
        selected = mask & (rank >= 0) & (rank < n)
        idx = torch.where(selected, rank.clamp(0, MAX_RANK) + 1, torch.zeros_like(rank))
        tokens = h['objects'] + self.rank_embed(idx)
        blocked = (~mask)[:, None, :].expand(-1, n, -1)
        pooled = masked_mean(self.posterior(tokens, mask=blocked), mask)
        z = self.to_code(pooled)[:, None]
        zq, index = self.fsq(z)
        return zq[:, 0], index.reshape(-1).long()

    def ordering_with_code(self, h, code):
        return self.ordering(h['objects'] + self.code_in(code)[:, None])

    def encode(self, batch):
        """Public view for the planner: selection / mu / sigma under the most probable prior code."""
        h = self._encode(batch)
        index = h['prior_logits'].argmax(-1)
        code = self.fsq.implicit_codebook[index]
        h['code_index'] = index
        h['selection'], h['mu'], h['sigma'] = self.ordering_with_code(h, code)
        return h

    @torch.no_grad()
    def enumerate_orders(self, h, n_objects: int, max_codes: int | None = None):
        """Distinct skeletons in prior order for ONE scene: [(order tuple, code index, prior prob)]."""
        logits = h['prior_logits'][0]
        probs = torch.softmax(logits, -1)
        ranked = logits.argsort(descending=True)
        if max_codes is not None:
            ranked = ranked[:max_codes]
        codes = self.fsq.implicit_codebook.to(logits.device)[ranked]
        objects = h['objects'][0:1].expand(len(ranked), -1, -1)
        selection, mu, _ = self.ordering(objects + self.code_in(codes)[:, None])
        out, seen = [], set()
        for k in range(len(ranked)):
            sel = (selection[k, :n_objects] > 0).nonzero(as_tuple=False).flatten().tolist()
            order = tuple(sorted(sel, key=lambda j: float(mu[k, j])))
            if order not in seen:
                seen.add(order)
                out.append((order, int(ranked[k]), float(probs[ranked[k]])))
        return out

    # -- training -----------------------------------------------------------------------
    def loss(self, batch, generator=None):
        if 'affordance_target' not in batch:
            raise ValueError('affordance labels required; regenerate the training dataset')
        h = self._encode(batch)
        mask = batch['object_mask']
        code, index = self.posterior_code(h, batch)
        selection, mu, sigma = self.ordering_with_code(h, code)
        parts = self.ordering.loss(selection, mu, sigma, batch['rank'], mask, generator,
                                   rank_selected_only=getattr(self, 'rank_selected_only', False))
        parts['flow'] = self.flow_loss(h, batch, generator)
        logits, labels = h['interaction_affordance_logits'], batch['affordance_target']
        parts['affordance'] = (F.binary_cross_entropy_with_logits(logits[mask], labels[mask])
                               if mask.any() else logits.sum() * 0)
        parts['prior'] = F.cross_entropy(h['prior_logits'], index.detach())
        with torch.no_grad():
            parts['code_usage'] = torch.unique(index).numel() / float(self.codebook_size)
        total = (parts['selection'] + parts['order'] + parts['flow'] + self.kl_weight * parts['kl']
                 + parts['affordance'] + self.prior_weight * parts['prior'])
        count_weight = getattr(self, 'cardinality_weight', 0.)
        if count_weight:
            selected = mask & (batch['rank'] >= 0) & (batch['rank'] < mask.shape[1])
            parts['cardinality'] = F.mse_loss((selection.sigmoid() * mask).sum(-1), selected.sum(-1).to(selection.dtype))
            total = total + count_weight * parts['cardinality']
        return total, {k: float(v.detach()) if torch.is_tensor(v) else float(v) for k, v in parts.items()}
