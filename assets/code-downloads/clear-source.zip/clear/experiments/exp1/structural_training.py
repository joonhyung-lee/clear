"""Validation-only, matched-budget adaptation to larger scenes and longer plans."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch
import yaml

from experiments.common.interfaces import write_trials
from experiments.common.manifests import freeze, read_manifests, verify_frozen, write_manifests
from experiments.exp1.dataset import BucketSampler, make_batch, manifest_to_example
from experiments.exp1.evaluator import environment_txt, evaluate_split, make_planner, quick_summary
from experiments.exp1.models import load_checkpoint, save_checkpoint
from experiments.exp1.structural_stress import LEVELS, METHODS, sample_block


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def configure_target_finetune(model):
    """Freeze ordering and its encoders; reuse each architecture's existing target module."""
    prefixes = ('flow.',) if getattr(model, 'is_shared_affordance', False) else ('tgt_', 'to_target.')
    names = []
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith(prefixes))
        if parameter.requires_grad:
            names.append(name)
    if not names:
        raise ValueError('no target parameters found')
    return names


def observation_key(m):
    # Exclude labels, IDs and timing metadata when checking train/validation overlap.
    d = m.to_dict()
    return hashlib.sha256(json.dumps({k: d[k] for k in
        ('environment', 'objects', 'start', 'goal', 'robot')}, sort_keys=True).encode()).hexdigest()


def training_block(args):
    axis, index, seed = args
    rng = np.random.default_rng(seed)
    for _ in range(100):
        block, reason = sample_block(axis, int(rng.integers(2**31)), index)
        if block is not None:
            for m in block:
                m.scene_id = 'adapt_train_' + m.scene_id
                m.base_scene_id = 'adapt_train_' + m.base_scene_id
                m.split = 'structural_adaptation_train'
            return block
    raise RuntimeError(f'failed to generate {axis}/{index}: {reason}')


def generate(a):
    root = Path(a.root)
    root.mkdir(parents=True, exist_ok=False)
    cfg = yaml.safe_load(Path('experiments/exp1/configs/main.yaml').read_text())
    stress_val = Path(a.stress_val)
    verify_frozen(str(stress_val))
    original_val = Path(cfg['data_dir']) / 'val/scene_manifest.jsonl'
    forbidden = {observation_key(m) for path in (stress_val, original_val)
                 for m in read_manifests(str(path))}
    rng = np.random.default_rng(a.generation_seed)
    jobs = [(axis, i, int(rng.integers(2**31))) for axis in LEVELS for i in range(a.blocks)]
    manifests = []
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for i, block in enumerate(pool.map(training_block, jobs)):
            if any(observation_key(m) in forbidden for m in block):
                raise ValueError('training observation overlaps validation')
            manifests.extend(block)
            if (i + 1) % 32 == 0:
                print('generated', len(manifests), flush=True)
    keys = [observation_key(m) for m in manifests]
    if len(set(keys)) != len(keys):
        raise ValueError('duplicate training observation')
    train = root / 'train.jsonl'
    write_manifests(str(train), manifests)
    freeze(str(train))
    design = dict(config=cfg, generation_seed=a.generation_seed, blocks_per_axis=a.blocks,
                  train_scenes=len(manifests), train_sha256=sha(train),
                  stress_val=str(stress_val.resolve()), stress_val_sha256=sha(stress_val),
                  original_val=str(original_val.resolve()), original_val_sha256=sha(original_val),
                  replay_stride=10, stress_step_fraction=.75, batch=64,
                  validation_overlap=0, original_test_read=False)
    (root / 'design.json').write_text(json.dumps(design, indent=2) + '\n')
    print(json.dumps(design, indent=2), flush=True)


def run(a):
    root = Path(a.root)
    design = json.loads((root / 'design.json').read_text())
    cfg = design['config']
    train_path = root / 'train.jsonl'
    if sha(train_path) != design['train_sha256']:
        raise ValueError('training data changed')
    for split in ('stress_val', 'original_val'):
        if sha(design[split]) != design[split + '_sha256']:
            raise ValueError('validation data changed')
    out = root / (a.name or f'{a.method}_seed{a.seed}')
    out.mkdir(parents=True, exist_ok=False)
    source = Path(a.source) if a.source else Path(cfg['runs_dir']) / f'train_{a.method}_seed{a.seed}/checkpoint.pt'
    model, ck = load_checkpoint(str(source))
    if ck['method'] != a.method or ck['training_seed'] != a.seed or 'ablation' in ck:
        raise ValueError('requires matching, unpruned source checkpoint')
    if ((a.reachability and not ck['model_cfg'].get('push_reachability', False))
            or (a.goal_blocked and not ck['model_cfg'].get('goal_blocked', False))):
        if a.targets_only:
            raise ValueError('new reachability inputs require joint training')
        if a.method == 'clear':
            from experiments.exp1.reachability_study import add_reachability
            goal_blocked = a.goal_blocked or ck['model_cfg'].get('goal_blocked', False)
            model = add_reachability(model, ck['model_cfg'], ck['canvas_hw'], goal_blocked=goal_blocked)
            ck['model_cfg']['push_reachability'] = True
            ck['model_cfg']['goal_blocked'] = goal_blocked
        elif a.method in ('autoregressive', 'gumbel_sinkhorn', 'polynet') and not a.goal_blocked:
            # LEAP 2026 WP-1: the same observation channel, grafted the same way (zeroed new
            # input columns), for the order baselines.
            from experiments.exp1.reachability_study import add_reachability_baseline
            model = add_reachability_baseline(model, a.method, ck['model_cfg'], ck['canvas_hw'],
                                              ck.get('method_cfg'))
            ck['model_cfg']['push_reachability'] = True
        else:
            raise ValueError('new reachability inputs require joint CLEAR or order-baseline training')
    if a.selected_order_only:
        if a.method != 'clear' or not getattr(model, 'is_shared_affordance', False):
            raise ValueError('selected-order loss requires shared CLEAR')
        model.rank_selected_only = True
        ck['model_cfg']['rank_selected_only'] = True
    if a.cardinality_weight:
        if a.method != 'clear' or not getattr(model, 'is_shared_affordance', False):
            raise ValueError('cardinality loss requires shared CLEAR')
        model.cardinality_weight = a.cardinality_weight
        ck['model_cfg']['cardinality_weight'] = a.cardinality_weight
    metadata = dict(vars(a), source=str(source.resolve()), source_sha256=sha(source),
                    design_sha256=sha(root / 'design.json'), starting_step=ck['step'],
                    model_cfg=dict(ck['model_cfg']))
    if a.targets_only:
        metadata['trainable_parameters'] = configure_target_finetune(model)
    (out / 'study.json').write_text(json.dumps(metadata, indent=2) + '\n')
    (out / 'environment.txt').write_text(environment_txt())
    checkpoint = source
    if a.steps:
        original_train = Path(cfg['data_dir']) / 'train/scene_manifest.jsonl'
        replay = read_manifests(str(original_train))[::design['replay_stride']]
        stress = read_manifests(str(train_path))
        groups = [[manifest_to_example(m, ck['canvas_hw']) for m in ms] for ms in (replay, stress)]
        if any(e is None for group in groups for e in group):
            raise ValueError('training manifest lacks supervision')
        # Separate data RNG from model/noise RNG: all methods see identical committed plans.
        samplers = [BucketSampler(group, np.random.default_rng(a.seed + i)) for i, group in enumerate(groups)]
        batch_rng = np.random.default_rng(a.seed + 100)
        torch.manual_seed(a.seed)
        model.to(a.device).train()
        if a.method == 'gumbel_sinkhorn':
            model.set_tau(ck['method_cfg'].get('tau_end', .1))
        opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr,
                                weight_decay=cfg['train']['weight_decay'])
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.steps)
        started = time.monotonic()
        batch_counts = [0, 0]
        with (out / 'train_log.jsonl').open('w') as log:
            for step in range(1, a.steps + 1):
                which = int((step - 1) % 4 < round(4 * design['stress_step_fraction']))
                batch_counts[which] += 1
                movers, empty = samplers[which].sample(design['batch'])
                examples = movers + empty
                if getattr(model, 'is_shared_affordance', False):
                    batch = model.make_batch(examples, device=a.device)
                    if a.targets_only:
                        with torch.no_grad():
                            encoded = model.encode(batch)
                        loss = model.flow_loss(encoded, batch)
                        parts = {'flow': float(loss.detach())}
                    else:
                        loss, parts = model(batch)
                else:
                    batch = make_batch(examples, batch_rng, t=0., device=a.device,
                                       push_reachability=bool(getattr(model, 'push_reachability', False)))
                    orders = [e.orders[0] for e in examples]
                    if a.targets_only:
                        loss = model.target_loss(batch, orders)
                        parts = {'target_mse': float(loss.detach())}
                    else:
                        loss, parts = model(batch, orders)
                if not torch.isfinite(loss):
                    raise RuntimeError(f'nonfinite loss at step {step}')
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                opt.step()
                sched.step()
                rec = dict(step=step, loss=float(loss.detach()), **parts)
                log.write(json.dumps(rec) + '\n')
                if step % 100 == 0 or step == a.steps:
                    log.flush()
                    print(a.method, a.seed, rec, 'seconds', round(time.monotonic() - started), flush=True)
        checkpoint = out / 'checkpoint.pt'
        metadata['training_batches'] = dict(replay=batch_counts[0], stress=batch_counts[1])
        if a.targets_only:
            trained = set(metadata['trainable_parameters'])
            if any(not torch.equal(value.detach().cpu(), ck['model'][name])
                   for name, value in model.state_dict().items() if name not in trained):
                raise RuntimeError('a frozen parameter or buffer changed')
            metadata['frozen_state_verified'] = True
        (out / 'study.json').write_text(json.dumps(metadata, indent=2) + '\n')
        save_checkpoint(str(checkpoint), model, a.method, ck['model_cfg'], ck['canvas_hw'],
                        a.seed, ck['step'] + a.steps, extra={'development_study': metadata},
                        method_cfg=ck.get('method_cfg'))
        del model, samplers, groups, opt, sched, replay, stress
        if a.device.startswith('cuda'):
            torch.cuda.empty_cache()
    ecfg = cfg['evaluate']
    planner = make_planner(a.method, str(checkpoint), device=a.device,
        clear_decode=a.clear_decode,
        polynet_point_rule=ecfg['polynet_point_rule'], gs_noise_std_mult=ecfg['gs_noise_std_mult'],
        clear_coverage_selection=ecfg['clear_coverage_selection'],
        clear_flow_steps=ecfg['clear_flow_steps'], clear_target_draws=a.target_draws,
        clear_priority_scale=a.priority_scale, clear_coverage_candidate=a.coverage_candidate)
    splits = {'stress_val': read_manifests(design['stress_val']),
              'original_val': read_manifests(design['original_val'])[::10]}
    if a.method == 'polynet' and a.steps:
        table = {}
        for code in range(planner.model.n_codes):
            planner.model.point_code = code
            scores = []
            for split, manifests in splits.items():
                records, _ = evaluate_split(planner, manifests, cfg['seed'], a.seed,
                    coverage_draws=1, log_every=10**9, stochastic=False)
                scores.append(float(np.mean([r.task_success for r in records])))
            table[code] = dict(stress=scores[0], original=scores[1], mean=float(np.mean(scores)))
        planner.model.point_code = max(table, key=lambda c: table[c]['mean'])
        save_checkpoint(str(checkpoint), planner.model, a.method, ck['model_cfg'], ck['canvas_hw'],
            a.seed, ck['step'] + a.steps, extra={'development_study': metadata}, method_cfg=ck.get('method_cfg'))
        (out / 'point_code.json').write_text(json.dumps(table, indent=2) + '\n')
    for split, manifests in splits.items():
        records, _ = evaluate_split(planner, manifests, cfg['seed'], a.seed, coverage_draws=32, log_every=50)
        write_trials(str(out / f'{split}_trials.jsonl'), records)
        summary = quick_summary(records)
        (out / f'{split}_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
        print(split, json.dumps(summary), flush=True)
    if sha(source) != metadata['source_sha256']:
        raise RuntimeError('source checkpoint changed during study')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['generate', 'run'])
    p.add_argument('--root', required=True)
    p.add_argument('--stress-val', default='runs/exp1_scratch/structural_stress_20260913_a/scene_manifest.jsonl')
    p.add_argument('--blocks', type=int, default=256)
    p.add_argument('--workers', type=int, default=8)
    p.add_argument('--generation-seed', type=int, default=2026091301)
    p.add_argument('--method', choices=METHODS, default='clear')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--steps', type=int, default=3000)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--device', default='cpu')
    p.add_argument('--source')
    p.add_argument('--name')
    p.add_argument('--selected-order-only', action='store_true')
    p.add_argument('--cardinality-weight', type=float, default=0.)
    p.add_argument('--coverage-candidate', choices=['separation2', 'separation2_explore4'])
    p.add_argument('--clear-decode', choices=['mode', 'separation_map'], default='mode')
    p.add_argument('--priority-scale', type=float, default=1.)
    p.add_argument('--target-draws', type=int, default=1)
    p.add_argument('--targets-only', action='store_true')
    p.add_argument('--reachability', action='store_true')
    p.add_argument('--goal-blocked', action='store_true')
    a = p.parse_args()
    if (a.steps < 0 or a.blocks < 1 or a.workers < 1 or not 0 < a.lr < 1
            or not np.isfinite(a.cardinality_weight) or a.cardinality_weight < 0
            or not np.isfinite(a.priority_scale) or a.priority_scale <= 0 or a.target_draws < 1):
        p.error('positive generation settings/lr and nonnegative steps required')
    (generate if a.command == 'generate' else run)(a)


if __name__ == '__main__':
    main()
