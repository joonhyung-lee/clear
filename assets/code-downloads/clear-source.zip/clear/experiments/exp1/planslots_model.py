"""Plan slots (candidate C2, 2D Grid): K slots, each a complete candidate plan
Pi_k = (S_k, rho_k, X_k, q_k) -- selected objects, order, object targets, prior score --
trained by one-to-one (Hungarian) matching against ALL valid minimal plans of the scene,
each with its own target configuration.

What changes w.r.t. the set-cover heads (setcover_model.py, setcover_v2_model.py):
  matching   Hungarian 1:1 between slots and labelled plans on the discrete cost
             (selection BCE + pairwise rank loss). Each slot owns at most one plan, so no
             slot can be the winner of several plans and duplicates are not rewarded.
  flow       the rank-causal flow reads the SLOT-modulated object tokens and is supervised
             with the matched plan's own targets (plan_supervision[order] -> x1_p), so two
             orders of the same objects can produce different targets. At inference the
             enumerated order's slot conditions the flow (sample_targets override).
  prior      BCE on "slot was matched" (enumeration order); unmatched slots receive no
             invalid label (absence from the labelled set is not infeasibility).
  plans      up to K plans per scene (all valid orders when <= K).
No validity head; enumeration is by prior only. Inputs, trunk, affordance head, adaptation
stages and checkpoint format are the paper grid model's.

rank_head=True (LEAP 2026 WP-A9/A10) adds a per-slot quality head that scores the plan each slot
actually decodes (quality-aware ranking, cf. VarifocalNet / Stable-DINO; see
docs/leap2026/PLANSLOTS_STRENGTHENING.md). Its input is the slot's modulated tokens and the
selection-weighted tokens of the objects it picks, detached so the decoders are unchanged; its
label is whether the slot's decoded order is one of the scene's valid orders (negatives are
masked when the stored order list may be truncated at max_plans). Its logits replace the prior
for the point prediction and the enumeration order; the matched-slot prior is still trained.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment

from clear.model.clear import per_example_rank_loss
from experiments.exp1.setcover_model import GridSetCoverModel

ARCHITECTURE = 'clear-planslots-v1'


class GridPlanSlotsModel(GridSetCoverModel):
    def __init__(self, canvas_hw, n_codes=16, max_plans=None, prior_weight=1.0, flow_plans_per_example=2, slot_flow=True,
                 rank_head=False, **kw):
        kw.pop('commit_weight', None)
        self.slot_flow = bool(slot_flow)     # False: 1:1 matching only; flow stays the paper's (unmodulated tokens, committed order's targets)
        super().__init__(canvas_hw, n_codes=n_codes, max_plans=(n_codes if max_plans is None else max_plans),
                         commit_weight=0.0, prior_weight=prior_weight, **kw)
        self.flow_plans_per_example = int(flow_plans_per_example)
        self.use_rank_head = bool(rank_head)
        if self.use_rank_head:
            dim = int(kw.get('dim', 128))
            self.rank_head = nn.Sequential(nn.Linear(3 * dim, dim), nn.GELU(), nn.Linear(dim, 1))

    # -- batches: every valid order with its own targets ------------------------------------
    def make_batch(self, examples, device='cpu', include_targets=True):
        batch = super().make_batch(examples, device, include_targets)
        if include_targets:
            n = batch['object_mask'].shape[1]
            scale = np.asarray(self.code_scale(), np.float32)
            targets = np.zeros((len(examples), self.max_plans, n, 2), np.float32)
            for i, ex in enumerate(examples):
                orders = list(getattr(ex, 'valid_orders', []) or []) or list(getattr(ex, 'plan_supervision', {}).keys()) or list(ex.orders)
                orders = sorted({tuple(int(j) for j in o) for o in orders})[:self.max_plans]   # same order as the parent
                sup = getattr(ex, 'plan_supervision', {}) or {}
                for p, order in enumerate(orders):
                    x1 = sup[order][0] if order in sup else ex.x1
                    for j in order:
                        targets[i, p, j] = (np.asarray(x1[j][:2]) - np.asarray(ex.x0[j][:2])) / scale
            batch['plan_targets'] = torch.as_tensor(targets, device=device)
        return batch

    # -- slot representations -------------------------------------------------------------------
    def _encode(self, batch):
        h = super()._encode(batch)                       # objects, embodiment, scene, key_mask, prior_logits
        h['modulated'] = self._film(h['objects'])        # (b,K,n,d): slot-modulated object tokens
        if self.use_rank_head:
            h['rank_logits'] = self._rank_logits(h, batch['object_mask'])
        return h

    def _rank_logits(self, h, mask):
        """Per-slot quality logit from the slot's own decode; inputs detached (ranking only)."""
        tokens = h['modulated'].detach()
        sel, _, _ = self.decode_all(dict(h, modulated=tokens))
        m = mask[:, None, :, None].float()
        w = torch.sigmoid(sel.detach())[..., None] * m
        slot_mean = (tokens * m).sum(2) / m.sum(2).clamp(min=1)
        chosen = (tokens * w).sum(2) / w.sum(2).clamp(min=1e-6)
        emb = h['embodiment'][:, :1].detach().expand(-1, tokens.shape[1], -1)
        return self.rank_head(torch.cat([slot_mean, chosen, emb], -1)).squeeze(-1)

    @staticmethod
    def decoded_ranks(sel, mu, mask):
        """Rank of every object in each slot's deterministic decode (-1 = not selected), (b,K,n)."""
        chosen = (sel > 0) & mask[:, None, :]
        key = torch.where(chosen, mu, torch.full_like(mu, float('inf')))
        order = key.argsort(dim=-1, stable=True)
        rank = torch.empty_like(order).scatter_(-1, order, torch.arange(order.shape[-1], device=order.device).expand_as(order))
        return torch.where(chosen, rank, torch.full_like(rank, -1))

    def decode_all(self, h):
        return self.ordering(h['modulated'])

    def encode(self, batch):
        h = super().encode(batch)                        # selection/mu/sigma of the top-prior slot
        h['top_slot'] = h['code_index']
        return h

    @torch.no_grad()
    def enumerate_orders(self, h, n_objects, max_codes=None):
        out = super().enumerate_orders(h, n_objects, max_codes)
        h['slot_of_order'] = {order: k for order, k, _ in out}
        return out

    def sample_targets(self, batch, order, steps=30, generator=None, h=None, draws=1):
        """The flow is conditioned on the slot that produced `order` (top slot for sampled orders)."""
        h = self.encode(batch) if h is None else h
        if not self.slot_flow:
            return super().sample_targets(batch, order, steps, generator, h=h, draws=draws)
        k = h.get('slot_of_order', {}).get(tuple(order), int(h['top_slot'][0]))
        h_slot = dict(h, objects=h['modulated'][:, k])
        return super().sample_targets(batch, order, steps, generator, h=h_slot, draws=draws)

    # -- training -------------------------------------------------------------------------------
    def _slot_flow_loss(self, h, batch, pairs, generator):
        """Flow loss over matched (example, slot, plan) triples with each plan's own targets."""
        if not pairs:
            return h['objects'].sum() * 0
        bi = torch.tensor([p[0] for p in pairs], device=h['objects'].device)
        ki = torch.tensor([p[1] for p in pairs], device=bi.device)
        pi = torch.tensor([p[2] for p in pairs], device=bi.device)
        objects = h['modulated'][bi, ki]                                          # (M,n,d)
        rank = batch['plans'][bi, pi]                                             # (M,n)
        target = batch['plan_targets'][bi, pi]                                    # (M,n,2)
        mask = batch['object_mask'][bi]
        return self._flow_mse(h, batch, bi, objects, mask, rank, target, generator)

    def _flow_mse(self, h, batch, bi, objects, mask, rank, target, generator):
        n = rank.shape[1]
        selected = mask & (rank >= 0) & (rank < n)
        if not selected.any():
            return h['objects'].sum() * 0
        noise = torch.randn(target.shape, device=target.device, generator=generator) * self.flow.noise_std
        t = torch.rand(target.shape[0], device=target.device, generator=generator)
        target = torch.where(selected[:, :, None], target, torch.zeros_like(target))
        mixed = (1 - t[:, None, None]) * noise + t[:, None, None] * target
        sub = {key: (v[bi] if torch.is_tensor(v) and v.shape[0] == batch['object_mask'].shape[0] else v) for key, v in h.items()
               if key not in ('modulated', 'slot_of_order')}
        velocity = self.flow(objects, sub['embodiment'], sub['scene'], mixed, t, rank, selected,
                             key_mask=self.flow_key_mask(sub, mask))
        return F.mse_loss(velocity[selected], (target - noise)[selected])

    def loss(self, batch, generator=None):
        if 'affordance_target' not in batch:
            raise ValueError('affordance labels required; regenerate the training dataset')
        h = self._encode(batch)
        mask, plans, plan_mask = batch['object_mask'], batch['plans'], batch['plan_mask']
        b, n = mask.shape
        K, P = self.K, plans.shape[1]
        sel, mu, sigma = self.decode_all(h)                                                 # (b,K,n)
        sel_f = sel[:, :, None].expand(b, K, P, n).reshape(-1, n)
        mu_f = mu[:, :, None].expand(b, K, P, n).reshape(-1, n)
        rank_f = plans[:, None].expand(b, K, P, n).reshape(-1, n)
        mask_f = mask[:, None, None].expand(b, K, P, n).reshape(-1, n)
        selected = mask_f & (rank_f >= 0)
        sel_loss = F.binary_cross_entropy_with_logits(sel_f, selected.float(), reduction='none')
        sel_loss = (sel_loss * mask_f).sum(-1) / mask_f.sum(-1).clamp(min=1)
        sentinel = torch.where(selected, rank_f, torch.full_like(rank_f, n))
        valid = selected if getattr(self, 'rank_selected_only', False) else mask_f
        L = (sel_loss + per_example_rank_loss(mu_f, sentinel, valid)).view(b, K, P)         # (b,K,P)
        # Hungarian 1:1 matching per example on the detached discrete cost
        cost = L.detach().cpu().numpy()
        pm = plan_mask.cpu().numpy()
        matched = torch.zeros(b, K, device=sel.device)
        pairs, terms = [], []
        gen = generator if (generator is not None and generator.device.type == 'cpu') else None
        for i in range(b):
            cols = np.flatnonzero(pm[i])
            if len(cols) == 0:
                continue
            rows, sel_cols = linear_sum_assignment(cost[i][:, cols])
            ex_pairs = [(i, int(k), int(cols[c])) for k, c in zip(rows, sel_cols)]
            for _, k, p in ex_pairs:
                matched[i, k] = 1.0
                terms.append(L[i, k, p])
            if len(ex_pairs) > self.flow_plans_per_example:
                idx = torch.randperm(len(ex_pairs), generator=gen)[:self.flow_plans_per_example].tolist()
                ex_pairs = [ex_pairs[j] for j in idx]
            pairs.extend(ex_pairs)
        match_loss = torch.stack(terms).mean() if terms else L.sum() * 0
        prior = F.binary_cross_entropy_with_logits(h['prior_logits'], matched)
        parts = dict(cover=match_loss, prior=prior,
                     flow=(self._slot_flow_loss(h, batch, pairs, generator) if self.slot_flow else self.flow_loss(h, batch, generator)))
        logits, labels = h['interaction_affordance_logits'], batch['affordance_target']
        parts['affordance'] = (F.binary_cross_entropy_with_logits(logits[mask], labels[mask]) if mask.any() else logits.sum() * 0)
        total = parts['cover'] + self.prior_weight * parts['prior'] + parts['flow'] + parts['affordance']
        if self.use_rank_head:
            with torch.no_grad():
                ranks = self.decoded_ranks(sel, mu, mask)                                        # (b,K,n)
                same = ((ranks[:, :, None] == plans[:, None]) | ~mask[:, None, None]).all(-1)    # (b,K,P)
                valid = (same & plan_mask[:, None]).any(-1).float()
                complete = plan_mask.sum(1) < self.max_plans                                     # list not truncated
                label_mask = complete[:, None] | valid.bool()
            r = F.binary_cross_entropy_with_logits(h['rank_logits'], valid, reduction='none')
            parts['rank'] = (r * label_mask).sum() / label_mask.sum().clamp(min=1)
            total = total + parts['rank']
            parts['rank_valid_rate'] = valid.mean()
        with torch.no_grad():
            parts['code_usage'] = matched.mean(0).gt(0).float().mean()
            parts['commit'] = torch.zeros((), device=sel.device)
            parts['kl'] = torch.zeros((), device=sel.device)
        return total, {k: float(v.detach()) for k, v in parts.items()}
