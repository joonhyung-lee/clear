"""Paired validation-only development study; never reads the test manifest.

Compare original, equally fine-tuned control, and observation-conditioned CLEAR.
The two fine-tuned arms use identical batches, noise seeds, and optimizer budgets.
This is an ablation, not a replacement for the frozen four-method paper comparison.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
import yaml

from experiments.common.interfaces import write_trials
from experiments.common.manifests import read_manifests
from experiments.exp1.dataset import BucketSampler, manifest_to_example
from experiments.exp1.evaluator import environment_txt, evaluate_split, make_planner, quick_summary
from experiments.exp1.models import build_clear, load_checkpoint, save_checkpoint
from experiments.exp1.shared_model import OBJECT_DIM


def add_reachability(model, cfg, canvas, goal_blocked=False):
    """Zero new input columns so the initial model is functionally identical."""
    candidate = build_clear(dict(cfg, push_reachability=True, goal_blocked=goal_blocked), canvas)
    old_dim = OBJECT_DIM + 4 * bool(cfg.get('push_reachability')) + bool(cfg.get('goal_blocked'))
    added = OBJECT_DIM + 4 + bool(goal_blocked) - old_dim
    if added < 0:
        raise ValueError('warm start may only add observation features')
    state = model.state_dict()
    for key in ('encoder.object_in.0.weight', 'interaction_affordance.edge.0.weight'):
        weight = state[key]
        state[key] = torch.cat([weight[:, :old_dim], weight.new_zeros(weight.shape[0], added),
                                weight[:, old_dim:]], dim=1)
    candidate.load_state_dict(state)
    return candidate


def add_reachability_baseline(model, method, cfg, canvas, method_cfg=None):
    """Order-baseline counterpart of `add_reachability` (LEAP 2026 WP-1): rebuild the
    autoregressive / Gumbel-Sinkhorn / PolyNet model with the 4-D `push_reachability`
    channel and zero the four new input columns of both object tokenizers, so the warm-started
    model is functionally identical to its source until adaptation updates them."""
    from experiments.exp1.models import build
    if cfg.get('push_reachability'):
        raise ValueError('source already receives push_reachability')
    candidate = build(method, dict(cfg, push_reachability=True), canvas, method_cfg)
    state = model.state_dict()
    for key in ('to_object_tokens.weight', 'tgt_object_tokens.weight'):
        weight = state[key]
        state[key] = torch.cat([weight, weight.new_zeros(weight.shape[0], 4)], dim=1)
    candidate.load_state_dict(state)
    return candidate


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--arm', choices=['original', 'control', 'reachability',
                                     'autoregressive', 'gumbel_sinkhorn', 'polynet'], required=True)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--steps', type=int, default=3000)
    p.add_argument('--lr', type=float, default=3e-5)
    p.add_argument('--val-stride', type=int, default=10)
    p.add_argument('--device', default='cpu')
    p.add_argument('--config', default='experiments/exp1/configs/main.yaml')
    p.add_argument('--output', required=True, help='new, exclusive study directory')
    p.add_argument('--evaluate-only', action='store_true', help='rescore a saved arm in eval_independent/')
    a = p.parse_args()
    if a.steps < 1 or a.val_stride < 1 or not 0 < a.lr < 1:
        p.error('steps and val-stride must be positive; lr must be in (0, 1)')
    cfg = yaml.safe_load(Path(a.config).read_text())
    method = 'clear' if a.arm in ('original', 'control', 'reachability') else a.arm
    fine_tune = a.arm in ('control', 'reachability')
    source = Path(cfg['runs_dir']) / f'train_{method}_seed{a.seed}/checkpoint.pt'
    out = Path(a.output) / f'{a.arm}_seed{a.seed}'
    if a.evaluate_only:
        if fine_tune:
            source = out / 'checkpoint.pt'
        out = out / 'eval_independent'
    out.mkdir(parents=True, exist_ok=False)
    model, ck = load_checkpoint(str(source))
    if not a.evaluate_only and ck['model_cfg'].get('push_reachability', False):
        raise ValueError('study requires an original checkpoint without reachability features')
    model_cfg = dict(ck['model_cfg'])
    if a.arm == 'reachability' and not a.evaluate_only:
        model = add_reachability(model, model_cfg, ck['canvas_hw'])
        model_cfg['push_reachability'] = True
    val_path = Path(cfg['data_dir']) / 'val/scene_manifest.jsonl'
    metadata = dict(vars(a), source=str(source.resolve()),
                    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                    val_sha256=hashlib.sha256(val_path.read_bytes()).hexdigest(),
                    model_cfg=model_cfg, batch=cfg['train']['batch'],
                    weight_decay=cfg['train']['weight_decay'])
    (out / 'study.json').write_text(json.dumps(metadata, indent=2) + '\n')
    (out / 'environment.txt').write_text(environment_txt())
    checkpoint = source
    if fine_tune and not a.evaluate_only:
        train_path = Path(cfg['data_dir']) / 'train/scene_manifest.jsonl'
        metadata['train_sha256'] = hashlib.sha256(train_path.read_bytes()).hexdigest()
        (out / 'study.json').write_text(json.dumps(metadata, indent=2) + '\n')
        examples = [manifest_to_example(m, ck['canvas_hw']) for m in read_manifests(str(train_path))]
        sampler = BucketSampler([e for e in examples if e is not None], np.random.default_rng(a.seed))
        torch.manual_seed(a.seed)
        model.to(a.device).train()
        opt = torch.optim.AdamW(model.parameters(), lr=a.lr,
                                weight_decay=cfg['train']['weight_decay'])
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.steps)
        with (out / 'train_log.jsonl').open('w') as log:
            for step in range(1, a.steps + 1):
                movers, empty = sampler.sample(cfg['train']['batch'])
                loss, parts = model(model.make_batch(movers + empty, device=a.device))
                if not torch.isfinite(loss):
                    raise RuntimeError(f'nonfinite loss at step {step}')
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                opt.step()
                sched.step()
                rec = dict(step=step, loss=float(loss.detach()), **parts)
                log.write(json.dumps(rec) + '\n')
                if step % 100 == 0 or step == a.steps:
                    print(a.arm, a.seed, rec, flush=True)
        checkpoint = out / 'checkpoint.pt'
        save_checkpoint(str(checkpoint), model, 'clear', model_cfg, ck['canvas_hw'],
                        a.seed, ck['step'] + a.steps, extra={'development_study': metadata})
        del examples, sampler, opt, sched, model
        if str(a.device).startswith('cuda'):
            torch.cuda.empty_cache()
    ecfg = cfg['evaluate']
    planner = make_planner(method, str(checkpoint), device=a.device,
                           polynet_point_rule=ecfg['polynet_point_rule'],
                           gs_noise_std_mult=ecfg['gs_noise_std_mult'],
                           clear_coverage_selection=ecfg['clear_coverage_selection'],
                           clear_flow_steps=ecfg['clear_flow_steps'],
                           clear_target_draws=ecfg['clear_target_draws'])
    manifests = read_manifests(str(val_path))[::a.val_stride]
    (out / 'val_scene_ids.json').write_text(json.dumps([m.scene_id for m in manifests]) + '\n')
    records, _ = evaluate_split(planner, manifests, cfg['seed'], a.seed,
                                 coverage_draws=32, log_every=50)
    write_trials(str(out / 'trial_metrics.jsonl'), records)
    summary = quick_summary(records)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
