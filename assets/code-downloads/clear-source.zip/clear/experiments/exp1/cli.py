"""Command contract for Experiment 01 (spec section 13). Each function takes argv and returns
an exit code; scripts/*.py dispatch here:

  python -m scripts.generate_dataset  --experiment grid2d --config experiments/exp1/configs/debug.yaml
  python -m scripts.label_with_oracle --experiment grid2d --config ... --split all
  python -m scripts.train             --experiment grid2d --config ... --method clear --seed 0
  python -m scripts.evaluate          --experiment grid2d --config ... --method all --split test
  python -m scripts.aggregate         --experiment grid2d --config ...
  python -m scripts.render_qualitative --experiment grid2d --config ...

Layout: data -> <data_dir>/<split>/scene_manifest.jsonl (+ .sha256 for the frozen test split);
runs -> <runs_dir>/train_<method>_seed<k>/ and <runs_dir>/eval_<split>/<method>_seed<k>/.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import numpy as np
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEFAULT_CONFIG = os.path.join(ROOT, "experiments", "exp1", "configs", "main.yaml")


def _load_config(path: str | None) -> tuple[dict, str]:
    path = path or DEFAULT_CONFIG
    path = os.path.join(ROOT, path) if not os.path.isabs(path) else path
    with open(path) as f:
        text = f.read()
    cfg = yaml.safe_load(text)
    cfg["_path"] = path
    cfg["_text"] = text
    return cfg, text


def _abs(cfg: dict, key: str) -> str:
    p = cfg[key]
    return p if os.path.isabs(p) else os.path.join(ROOT, p)


def _manifest_path(cfg: dict, split: str) -> str:
    return os.path.join(_abs(cfg, "data_dir"), split, "scene_manifest.jsonl")


def _threads() -> None:
    import torch
    n = int(os.environ.get("OMP_NUM_THREADS", "10"))
    torch.set_num_threads(n)


def _base_parser(prog: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog=f"python -m scripts.{prog} --experiment grid2d")
    p.add_argument("--config", default=None, help="experiments/exp1/configs/{main,debug}.yaml")
    p.add_argument("--seed", type=int, default=None, help="overrides config seed")
    return p


# --------------------------------------------------------------------------------------


def _split_base(split: str) -> tuple[str, int]:
    """Resolve numbered scene variants to their canonical template pool and quotas.

    ``val2`` is reserved for a fresh validation check after the original validation set has
    accumulated design decisions. ``test2``, ``test3``, ... remain fresh held-out scene draws
    from the TEST template pool; no variant changes the template-level train/val/test split.
    """
    for base in ("train", "val", "test"):
        suffix = split[len(base):] if split.startswith(base) else ""
        if suffix.isdigit():
            return base, int(suffix)
    return split, 0


def generate_dataset(argv: list[str]) -> int:
    p = _base_parser("generate_dataset")
    p.add_argument("--splits", default="train,val,test")
    a = p.parse_args(argv)
    cfg, _ = _load_config(a.config)
    seed = int(cfg["seed"] if a.seed is None else a.seed)
    from experiments.common.manifests import check_unique_ids, write_manifests
    from experiments.exp1.dataset import scene_to_manifest
    from experiments.exp1.generator import FAMILIES, enumerate_templates, generate_scene, split_templates
    from experiments.exp1.metrics import k_star_bin

    templates = enumerate_templates()
    tsplit = split_templates(templates, seed, cfg["template_split"])
    data_dir = _abs(cfg, "data_dir")
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "templates.json"), "w") as f:
        json.dump({"seed": seed, "split": tsplit, "templates": [t.to_dict() for t in templates]}, f, indent=1)
    stats: dict = {}
    for si, split in enumerate(a.splits.split(",")):
        base, variant = _split_base(split)
        # the canonical splits keep their historical seeds (train 0, val 1, test 2); a testN
        # variant gets its own stream so its scenes differ from test's
        canon = {"train": 0, "val": 1, "test": 2}.get(base, si)
        rng = np.random.default_rng(seed * 100 + canon + 1000 * variant)
        quotas = cfg["scenes_per_family"][base]
        manifests = []
        st = {"attempts": 0, "failed_templates": 0, "k_star_bins": {}, "families": {}}
        idx = 0
        t0 = time.perf_counter()
        for fam in FAMILIES:
            pool = [t for t in templates if t.family == fam and tsplit[t.template_id] == base]
            if not pool:
                print(f"[{split}] no {fam} templates in this split; skipping", file=sys.stderr)
                continue
            n_target = int(quotas if isinstance(quotas, int) else quotas.get(fam, 0))
            made = 0
            while made < n_target:
                t = pool[int(rng.integers(len(pool)))]
                g = generate_scene(rng, t, cfg, max_attempts=int(cfg.get("max_attempts_per_scene", 60)))
                if g is None:
                    st["failed_templates"] += 1
                    if st["failed_templates"] > 20 * max(1, n_target):
                        raise SystemExit(f"[{split}] {fam}: too many rejected templates")
                    continue
                st["attempts"] += g.attempts
                base_id = f"g2d_{split}_{idx:06d}"
                manifests.append(scene_to_manifest(
                    g.scene, g.agent, scene_id=base_id, family=fam,
                    generation_seed=int(rng.integers(2**31 - 1)), split=split,
                    base_scene_id=base_id, template_id=t.template_id,
                    extra={"k_star_bin_at_generation": k_star_bin(g.result.min_interactions)}))
                b = k_star_bin(g.result.min_interactions)
                st["k_star_bins"][b] = st["k_star_bins"].get(b, 0) + 1
                idx += 1
                made += 1
            st["families"][fam] = made
        check_unique_ids(manifests)
        path = _manifest_path(cfg, split)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path + ".sha256"):
            raise SystemExit(f"{path} is frozen; refusing to regenerate the test split")
        write_manifests(path, manifests)
        st["n_manifests"] = len(manifests)
        st["time_s"] = round(time.perf_counter() - t0, 2)
        stats[split] = st
        print(f"[{split}] wrote {len(manifests)} manifests -> {path}  ({st['time_s']}s) families={st['families']} K*bins={st['k_star_bins']}")
    with open(os.path.join(data_dir, "generation_stats.json"), "w") as f:
        json.dump(stats, f, indent=1)
    return 0


def label_with_oracle(argv: list[str]) -> int:
    p = _base_parser("label_with_oracle")
    p.add_argument("--split", default="all")
    p.add_argument("--no-freeze", action="store_true", help="do not freeze the test manifest after labelling")
    a = p.parse_args(argv)
    cfg, _ = _load_config(a.config)
    from experiments.common.manifests import OracleLabel, freeze, read_manifests, verify_frozen, write_manifests
    from experiments.exp1.dataset import agent_from_manifest, scene_from_manifest
    from experiments.exp1.oracle import solve

    splits = ["train", "val", "test"] if a.split == "all" else a.split.split(",")
    max_orders = int(cfg.get("oracle", {}).get("max_orders", 64))
    for split in splits:
        path = _manifest_path(cfg, split)
        if not os.path.exists(path):
            raise SystemExit(f"missing {path}; run generate_dataset first")
        if os.path.exists(path + ".sha256"):
            verify_frozen(path)
            print(f"[{split}] frozen manifest verified; labels left untouched")
            continue
        ms = read_manifests(path)
        t0 = time.perf_counter()
        n_uns = 0
        incomplete = 0
        for m in ms:
            r = solve(scene_from_manifest(m), agent_from_manifest(m), max_orders=max_orders)
            m.oracle = OracleLabel(**r.to_label_dict())
            n_uns += int(not r.solvable)
            incomplete += int(not r.optimal_set_complete)
        write_manifests(path, ms)
        msg = f"[{split}] labelled {len(ms)} scenes ({n_uns} unsolvable, {incomplete} capped sets) in {time.perf_counter() - t0:.1f}s"
        if _split_base(split)[0] == "test" and not a.no_freeze:
            d = freeze(path)
            msg += f"; frozen sha256 {d[:12]}"
        print(msg)
    return 0


# --------------------------------------------------------------------------------------


def train(argv: list[str]) -> int:
    p = _base_parser("train")
    p.add_argument("--method", required=True,
                   choices=["clear", "clear_seq", "autoregressive", "gumbel_sinkhorn", "polynet"])
    p.add_argument("--steps", type=int, default=None)
    p.add_argument("--device", default="cpu", help='"cpu" (default) or e.g. "cuda:0"; the model is '
                                                  "device-agnostic and checkpoints always load back on CPU")
    p.add_argument("--wandb-project", default=os.environ.get("WANDB_PROJECT"),
                   help="mirror train_log.jsonl to this Weights & Biases project; "
                        "unset (the default) disables wandb entirely")
    p.add_argument("--wandb-group", default=os.environ.get("WANDB_GROUP"),
                   help="wandb group, e.g. the config name so one experiment's seeds group together")
    p.add_argument("--wandb-name", default=None, help="wandb run name; default <method>_seed<k>")
    a = p.parse_args(argv)
    cfg, cfg_text = _load_config(a.config)
    _threads()
    import torch
    from experiments.common.manifests import read_manifests
    from experiments.exp1.dataset import BucketSampler, make_batch, manifest_to_example
    from experiments.exp1.evaluator import environment_txt
    from experiments.exp1.models import build, clear_empty_plan_loss, clear_seq_empty_plan_loss, save_checkpoint

    seed = int(cfg["seed"] if a.seed is None else a.seed)
    tcfg = dict(cfg["train"])
    steps = int(a.steps or tcfg["steps"])
    canvas = tuple(cfg["canvas_hw"])
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)

    def load(split):
        path = _manifest_path(cfg, split)
        if not os.path.exists(path):
            raise SystemExit(f"missing {path}; run generate_dataset + label_with_oracle first")
        ex = [manifest_to_example(m, canvas) for m in read_manifests(path)]
        ex = [e for e in ex if e is not None]
        if not ex:
            raise SystemExit(f"{split} has no labelled examples; run label_with_oracle")
        return ex

    train_ex, val_ex = load("train"), load("val")
    sampler = BucketSampler(train_ex, rng)
    dev = a.device
    method_cfg = dict(cfg.get(a.method, {}) or {})      # e.g. the gumbel_sinkhorn: / polynet: blocks
    model = build(a.method, cfg["model"], canvas, method_cfg).to(dev)
    n_params = sum(p.numel() for p in model.parameters())
    opt = torch.optim.AdamW(model.parameters(), lr=float(tcfg.get("lr", 3e-4)), weight_decay=float(tcfg.get("weight_decay", 1e-4)))
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    run_dir = os.path.join(_abs(cfg, "runs_dir"), f"train_{a.method}_seed{seed}")
    os.makedirs(run_dir, exist_ok=True)
    with open(os.path.join(run_dir, "config.yaml"), "w") as f:
        f.write(cfg_text)
    with open(os.path.join(run_dir, "environment.txt"), "w") as f:
        f.write(environment_txt())
    log_path = os.path.join(run_dir, "train_log.jsonl")
    log = open(log_path, "w")
    wb = None
    if a.wandb_project:
        import wandb
        wb = wandb.init(project=a.wandb_project, group=a.wandb_group,
                        name=a.wandb_name or f"{a.method}_seed{seed}", dir=run_dir,
                        config={"experiment": "exp1", "method": a.method, "seed": seed,
                                "steps": steps, "device": dev, "n_params": n_params,
                                "config_path": cfg["_path"], "config_name": cfg.get("name"),
                                "architecture": cfg["model"].get("architecture", "legacy-grid-v2"),
                                "canvas_hw": list(canvas), "model": cfg["model"], "train": tcfg,
                                "method_cfg": method_cfg, "n_train": len(train_ex), "n_val": len(val_ex)})
    print(f"train {a.method} seed={seed} device={dev} steps={steps} params={n_params} train_ex={len(train_ex)} val_ex={len(val_ex)} buckets={sampler.sizes}")

    def step_loss(movers, empty):
        if getattr(model, 'is_shared_affordance', False):
            return model(model.make_batch(movers + empty, device=dev, include_targets=True))
        parts = {}
        loss = torch.zeros((), device=dev)
        if a.method in ("clear", "clear_seq"):
            empty_loss = clear_seq_empty_plan_loss if a.method == "clear_seq" else clear_empty_plan_loss
            if movers:
                l1, parts = model(make_batch(movers, rng, device=dev))
                loss = loss + l1 * (len(movers) / (len(movers) + len(empty)))
            if empty:
                l2 = empty_loss(model, make_batch(empty, rng, device=dev))
                parts["empty_mover_bce"] = l2.item()
                loss = loss + l2 * (len(empty) / (len(movers) + len(empty)))
        else:
            exs = movers + empty
            batch = make_batch(exs, rng, t=0.0, device=dev,
                               push_reachability=bool(getattr(model, 'push_reachability', False)))
            orders = [e.orders[0] for e in exs]
            loss, parts = model(batch, orders)
        return loss, parts

    @torch.no_grad()
    def val_loss():
        model.eval()
        vs = BucketSampler(val_ex, np.random.default_rng(0))
        tot = 0.0
        for _ in range(4):
            mv, em = vs.sample(int(tcfg.get("batch", 32)))
            l, _ = step_loss(mv, em)
            tot += float(l)
        model.train()
        return tot / 4

    model.train()
    t0 = time.perf_counter()
    first = None
    tau_sched = None
    if a.method == "gumbel_sinkhorn":
        t0_, t1_ = float(method_cfg.get("tau_start", 1.0)), float(method_cfg.get("tau_end", 0.1))
        # geometric interpolation tau_start -> tau_end over the run; recorded in the checkpoint
        tau_sched = lambda k: t0_ * (t1_ / t0_) ** ((k - 1) / max(steps - 1, 1))
    for step in range(1, steps + 1):
        if tau_sched is not None:
            model.set_tau(tau_sched(step))
        movers, empty = sampler.sample(int(tcfg.get("batch", 32)))
        loss, parts = step_loss(movers, empty)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if first is None:
            first = float(loss.detach())
        rec = {"step": step, "loss": float(loss.detach()), **{k: float(v) for k, v in parts.items()}}
        if step % int(tcfg.get("eval_every", 100)) == 0 or step == steps:
            rec["val_loss"] = val_loss()
        log.write(json.dumps(rec) + "\n")
        if wb is not None:
            wb.log(rec, step=step)
        if step % int(tcfg.get("log_every", 50)) == 0 or step == steps:
            print(f"step {step:6d} loss {float(loss.detach()):.4f} " + " ".join(f"{k} {v:.4f}" for k, v in parts.items())
                  + (f" | val {rec['val_loss']:.4f}" if "val_loss" in rec else "") + f" | {time.perf_counter() - t0:.0f}s", flush=True)
    log.close()
    ck = os.path.join(run_dir, "checkpoint.pt")
    save_checkpoint(ck, model, a.method, cfg["model"], canvas, seed, steps,
                    extra={"first_loss": first, "last_loss": float(loss.detach()), "config": cfg["_path"]},
                    method_cfg=method_cfg)
    if a.method == "polynet":
        _select_polynet_code(cfg, ck, a.method, seed, dev, run_dir)
    with open(os.path.join(run_dir, "checkpoint_or_version.txt"), "w") as f:
        f.write(ck + "\n")
    print(f"saved {ck}  first_loss={first:.4f} last_loss={float(loss.detach()):.4f}")
    if wb is not None:
        wb.summary.update({"first_loss": first, "last_loss": float(loss.detach()), "checkpoint": ck})
        wb.finish()
    return 0


def _select_polynet_code(cfg, ck_path: str, method: str, training_seed: int, device: str, run_dir: str) -> None:
    """PolyNet-style point rule: one fixed strategy code per training seed, chosen on
    VALIDATION Task Success (tie-break Order Hit) and frozen into the checkpoint before any
    test evaluation. Uses the real evaluator path with deterministic coverage so no draws
    are spent; the per-code table is written next to the checkpoint."""
    import torch
    from experiments.common.manifests import read_manifests
    from experiments.exp1.evaluator import evaluate_split, make_planner
    from experiments.exp1.models import save_checkpoint
    planner = make_planner(method, ck_path, device=device)
    manifests = read_manifests(_manifest_path(cfg, "val"))
    table = {}
    for code in range(int(planner.model.n_codes)):
        planner.model.point_code = code
        recs, _ = evaluate_split(planner, manifests, int(cfg["seed"]), training_seed,
                                 coverage_draws=1, log_every=10**9, stochastic=False)
        ts = float(np.mean([r.task_success for r in recs]))
        oh = float(np.mean([float(r.extra.get("order_hit", 0.0)) for r in recs]))
        table[code] = {"val_task_success": ts, "val_order_hit": oh, "n": len(recs)}
        print(f"  polynet code {code}: val task_success {ts:.4f} order_hit {oh:.4f}", flush=True)
    best = max(table, key=lambda c: (table[c]["val_task_success"], table[c]["val_order_hit"]))
    planner.model.point_code = int(best)
    ck = torch.load(ck_path, map_location="cpu", weights_only=False)
    save_checkpoint(ck_path, planner.model, method, ck["model_cfg"], ck["canvas_hw"], training_seed,
                    int(ck["step"]), extra={k: v for k, v in ck.items()
                                            if k not in ("model", "method", "model_cfg", "method_cfg",
                                                         "canvas_hw", "training_seed", "step", "point_code",
                                                         "n_params", "n_params_decoder")},
                    method_cfg=ck.get("method_cfg"))
    with open(os.path.join(run_dir, "point_code.json"), "w") as f:
        json.dump({"selected": int(best), "rule": "argmax val task_success, tie-break order_hit",
                   "per_code": table}, f, indent=2)
    print(f"  polynet point_code = {best} (frozen in checkpoint)", flush=True)


# --------------------------------------------------------------------------------------


def _eval_dir(cfg, split):
    return os.path.join(_abs(cfg, "runs_dir"), f"eval_{split}")


def evaluate(argv: list[str]) -> int:
    p = _base_parser("evaluate")
    p.add_argument("--method", default="all", help="all | comma list; see evaluator.ALL_METHODS")
    p.add_argument("--split", default="test")
    p.add_argument("--training-seeds", default=None, help="comma list; default from config")
    p.add_argument("--limit", type=int, default=None, help="evaluate only the first N manifests (debugging)")
    p.add_argument("--only-coverage-scenes", action="store_true",
                   help="evaluate only the scenes Coverage@32 applies to (complete optimal set "
                        "with >= 2 orders). Task Success and Order Hit from such a run describe "
                        "that subset, not the whole split; use it for coverage-budget work.")
    p.add_argument("--device", default="cpu", help='"cpu" (default) or e.g. "cuda:0" for the '
                                                  "learned planners; the oracle is unaffected")
    p.add_argument("--clear-decode", default=None, choices=["mode", "sample", "separation_map"],
                   help="CLEAR's point estimate: calibrated-size mode (default), priority-separation "
                        "MAP subset, or one Bernoulli draw. Coverage@32 remains stochastic.")
    p.add_argument('--clear-priority-scale', type=float, default=None,
                   help='Validation-calibrated Gaussian priority scale; defaults to config or 1.')
    p.add_argument('--clear-coverage-candidate', default=None,
                   help='Validation-selected coverage sampler candidate; defaults to the frozen rule.')
    p.add_argument("--clear-coverage-selection", default=None,
                   choices=["independent", "cardinality", "coverage_first"],
                   help="CLEAR coverage draws: the historical independent Bernoulli mover set "
                        "or the same distribution conditioned on k=round(sum p), or the frozen "
                        "coverage-first priority/Sobol schedule. None uses simulator or oracle "
                        "information. Default comes from "
                        "evaluate.clear_coverage_selection, falling back to independent.")
    p.add_argument("--polynet-point-rule", default=None, choices=["ckpt", "likelihood"],
                   help="PolyNet-style point prediction: the checkpoint's frozen code (default, "
                        "= test3) or PolyNet's decode-every-code-keep-the-most-likely rule. "
                        "Default may be frozen in the evaluate config block.")
    p.add_argument("--gs-noise-std-mult", type=float, default=None,
                   help="Gumbel-Sinkhorn coverage draws: noise = this x std(log_alpha) per scene; "
                        "0 (= test3) keeps the checkpoint's fixed noise_factor. Default may be "
                        "frozen in the evaluate config block.")
    p.add_argument("--clear-flow-steps", type=int, default=None,
                   help="Euler steps for CLEAR's target flow (shared affordance architecture "
                        "only). Default comes from evaluate.clear_flow_steps, falling back to 30.")
    p.add_argument("--clear-target-draws", type=int, default=None,
                   help="CLEAR's point estimate takes the modal target cell over this many flow "
                        "draws (1 = the single draw used originally). Coverage draws always use "
                        "one draw each. Default comes from evaluate.clear_target_draws.")
    p.add_argument("--run-suffix", default="",
                   help="appended to every run directory name (validation sweeps of the knobs above; "
                        "leave empty for a paired test run so aggregate can pair the directories)")
    a = p.parse_args(argv)
    cfg, cfg_text = _load_config(a.config)
    _threads()
    from experiments.common.manifests import read_manifests, verify_frozen
    from experiments.exp1.evaluator import ALL_METHODS, evaluate_split, make_planner, write_run_dir

    ecfg = dict(cfg.get("evaluate", {}))
    clear_decode = a.clear_decode or ecfg.get('clear_decode', 'mode')
    clear_priority_scale = (a.clear_priority_scale if a.clear_priority_scale is not None
                            else float(ecfg.get('clear_priority_scale', 1.)))
    clear_coverage_candidate = a.clear_coverage_candidate or ecfg.get('clear_coverage_candidate')
    clear_coverage_selection = (a.clear_coverage_selection
                                or ecfg.get("clear_coverage_selection", "independent"))
    polynet_point_rule = a.polynet_point_rule or ecfg.get("polynet_point_rule", "ckpt")
    gs_noise_std_mult = (a.gs_noise_std_mult if a.gs_noise_std_mult is not None
                         else float(ecfg.get("gs_noise_std_mult", 0.0)))
    clear_flow_steps = int(a.clear_flow_steps if a.clear_flow_steps is not None
                           else ecfg.get("clear_flow_steps", 30))
    clear_target_draws = int(a.clear_target_draws if a.clear_target_draws is not None
                             else ecfg.get("clear_target_draws", 1))
    methods = list(ecfg.get("methods", ALL_METHODS)) if a.method == "all" else a.method.split(",")
    for m in methods:
        if m not in ALL_METHODS:
            raise SystemExit(f"unknown method {m}; choose from {ALL_METHODS}")
    path = _manifest_path(cfg, a.split)
    if not os.path.exists(path):
        raise SystemExit(f"missing {path}; run generate_dataset + label_with_oracle first")
    verify_frozen(path)
    manifests = read_manifests(path)
    if a.only_coverage_scenes:
        from experiments.exp1.metrics import coverage_applicable
        manifests = [m for m in manifests if m.oracle is not None
                     and coverage_applicable([tuple(o) for o in m.oracle.valid_orders],
                                             m.oracle.optimal_set_complete)]
        print(f"restricted to {len(manifests)} coverage-eligible scenes")
    if a.limit:
        manifests = manifests[:a.limit]
    if any(m.oracle is None for m in manifests):
        raise SystemExit("unlabelled manifests; run label_with_oracle")
    seed = int(cfg["seed"] if a.seed is None else a.seed)
    tseeds = [int(s) for s in (a.training_seeds.split(",") if a.training_seeds else ecfg.get("training_seeds", [0]))]
    draws = int(ecfg.get("coverage_draws", 32))
    for method in methods:
        seeds = [0] if method == "oracle" else tseeds
        for ts in seeds:
            if method == "oracle":
                planner = make_planner("oracle", max_orders=int(cfg.get("oracle", {}).get("max_orders", 64)))
                version = "experiments.exp1.oracle.solve (privileged)"
            else:
                train_method = "clear" if method == "clear_mean" else method
                ck = os.path.join(_abs(cfg, "runs_dir"), f"train_{train_method}_seed{ts}", "checkpoint.pt")
                if not os.path.exists(ck):
                    raise SystemExit(f"missing checkpoint {ck}; run train --method {train_method} --seed {ts}")
                planner = make_planner(method, ck, device=a.device, clear_decode=clear_decode,
                                       clear_priority_scale=clear_priority_scale,
                                       clear_coverage_candidate=clear_coverage_candidate,
                                       polynet_point_rule=polynet_point_rule,
                                       gs_noise_std_mult=gs_noise_std_mult,
                                       clear_coverage_selection=clear_coverage_selection,
                                       clear_flow_steps=clear_flow_steps,
                                       clear_target_draws=clear_target_draws)
                version = ck
                if method in ("clear", "clear_mean"):
                    version += (f" | clear_flow_steps={clear_flow_steps}"
                                f" | clear_target_draws={clear_target_draws}")
                if method == "clear":
                    version += f" | clear_coverage_selection={clear_coverage_selection}"
                    version += (f' | clear_decode={clear_decode} | clear_priority_scale={clear_priority_scale}'
                                f' | clear_coverage_candidate={clear_coverage_candidate}')
                if method == "polynet":
                    version += f" | polynet_point_rule={polynet_point_rule}"
                if method == "gumbel_sinkhorn":
                    version += f" | gs_noise_std_mult={gs_noise_std_mult:g}"
            print(f"evaluate {method} training_seed={ts} on {len(manifests)} {a.split} scenes"
                  f"{'' if method == 'oracle' else f' [{a.device}]'}", flush=True)
            records, _ = evaluate_split(planner, manifests, seed, ts, coverage_draws=draws,
                                        log_every=int(ecfg.get("log_every", 25)))
            run_dir = os.path.join(_eval_dir(cfg, a.split), f"{method}_seed{ts}{a.run_suffix}")
            write_run_dir(run_dir, cfg_text, path, records, version)
            with open(os.path.join(run_dir, "aggregate_metrics.json")) as f:
                s = json.load(f)
            print(f"  -> {run_dir}: success {s['task_success']} order_hit {s['order_hit']} "
                  f"successful_regret {s['interaction_regret']} order_coverage {s['coverage_at_32']} "
                  f"(n_cov={s['n_coverage_scenes']})")
    return 0


def aggregate(argv: list[str]) -> int:
    p = _base_parser("aggregate")
    p.add_argument("--split", default="test")
    a = p.parse_args(argv)
    cfg, _ = _load_config(a.config)
    from experiments.exp1.aggregate import aggregate_runs
    out = aggregate_runs(cfg, _eval_dir(cfg, a.split))
    print(out["table_markdown"])
    print(f"wrote {out['json_path']} and {out['table_path']}")
    return 0


def render_qualitative(argv: list[str]) -> int:
    p = _base_parser("render_qualitative")
    p.add_argument("--split", default="test")
    p.add_argument("--method", default="clear")
    p.add_argument("--training-seed", type=int, default=0)
    p.add_argument("--device", default="cpu", help="must match the device `evaluate` ran on: the "
                                                  "panels re-predict with the logged rng seed, and "
                                                  "CPU and GPU arithmetic diverge on the same seed")
    a = p.parse_args(argv)
    cfg, _ = _load_config(a.config)
    _threads()
    from experiments.common.interfaces import read_trials
    from experiments.common.manifests import read_manifests, verify_frozen
    from experiments.exp1.evaluator import make_planner, scene_seed
    from experiments.exp1.dataset import agent_from_manifest, scene_from_manifest
    from experiments.exp1.environment import Observation
    from experiments.exp1.render import render_figure, select_qualitative

    path = _manifest_path(cfg, a.split)
    verify_frozen(path)
    manifests = read_manifests(path)
    run_dir = os.path.join(_eval_dir(cfg, a.split), f"{a.method}_seed{a.training_seed}")
    tpath = os.path.join(run_dir, "trial_metrics.jsonl")
    if not os.path.exists(tpath):
        raise SystemExit(f"missing {tpath}; run evaluate first")
    recs = {r.scene_id: r for r in read_trials(tpath)}
    picks = select_qualitative(manifests, recs)
    if not picks:
        raise SystemExit("no scene matched the selection rules")
    # re-predict with the logged rng seed so the panel shows exactly the recorded plan
    if a.method == "oracle":
        planner = make_planner("oracle", max_orders=int(cfg.get("oracle", {}).get("max_orders", 64)))
    else:
        train_method = "clear" if a.method == "clear_mean" else a.method
        # the same frozen inference rules `evaluate` ran under, or the re-prediction below
        # silently draws different targets from the ones the trial records hold
        ecfg = dict(cfg.get("evaluate", {}))
        planner = make_planner(a.method, os.path.join(_abs(cfg, "runs_dir"), f"train_{train_method}_seed{a.training_seed}", "checkpoint.pt"),
                               device=a.device,
                               clear_decode=ecfg.get('clear_decode', 'mode'),
                               clear_priority_scale=float(ecfg.get('clear_priority_scale', 1.)),
                               clear_coverage_candidate=ecfg.get('clear_coverage_candidate'),
                               polynet_point_rule=ecfg.get("polynet_point_rule", "ckpt"),
                               gs_noise_std_mult=float(ecfg.get("gs_noise_std_mult", 0.0)),
                               clear_coverage_selection=ecfg.get("clear_coverage_selection", "independent"),
                               clear_flow_steps=int(ecfg.get("clear_flow_steps", 30)),
                               clear_target_draws=int(ecfg.get("clear_target_draws", 1)))
    items = []
    for rule, m in picks:
        rec = recs.get(m.scene_id)
        scene, agent = scene_from_manifest(m), agent_from_manifest(m)
        planner.reset(int(rec.extra["rng_seed"]) if rec else scene_seed(int(cfg["seed"]), 0))
        pred = planner.predict(Observation(scene, agent.public(), m.scene_id),
                               agent if planner.privileged else agent.public())
        if rec is not None and list(pred.object_ids) != list(rec.predicted_order):
            print(f"warning: re-predicted order {pred.object_ids} != recorded {rec.predicted_order} for {m.scene_id}", file=sys.stderr)
        items.append((rule, m, rec, list(pred.object_ids), list(pred.target_configurations)))
    out = render_figure(items, os.path.join(_eval_dir(cfg, a.split), "figures", f"qualitative_{a.method}.png"), a.method)
    with open(os.path.join(_eval_dir(cfg, a.split), "figures", f"qualitative_{a.method}_selection.json"), "w") as f:
        json.dump([{"rule": r, "scene_id": m.scene_id, "family": m.scene_family} for r, m in picks], f, indent=1)
    print(f"wrote {out}  ({', '.join(r for r, _ in picks)})")
    return 0
