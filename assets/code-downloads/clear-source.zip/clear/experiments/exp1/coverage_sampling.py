"""Frozen model-only Coverage@32 sampler for Experiment 01.

The rule was developed on val2 and is applied only to CLEAR's coverage draws. Point decoding,
training, checkpoints, and target generation are unchanged.
"""
from experiments.exp1.sampling_dev import sample_orders

FINAL_RULE = "coverage_first"
FINAL_CANDIDATE = "separation2_explore4"
FINAL_DRAWS = 32


def sample_final_orders(p, mu, sigma, scene_id: str, training_seed: int, draws: int = FINAL_DRAWS,
                        candidate: str | None = None):
    if draws != FINAL_DRAWS:
        raise ValueError(f"{FINAL_RULE} is frozen for exactly {FINAL_DRAWS} draws, got {draws}")
    return sample_orders(p, mu, sigma, scene_id, training_seed, candidate or FINAL_CANDIDATE)
