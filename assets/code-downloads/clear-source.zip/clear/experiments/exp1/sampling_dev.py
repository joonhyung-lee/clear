"""Model-only development samplers; no scene geometry, oracle, or execution feedback.

Cardinality exploration mixes the predicted count with its immediate neighbours. Subset
reweighting penalizes overlapping Gaussian priority predictions. Scrambled Sobol points
spread exactly 32 proposals across the categorical subset CDF and Gaussian priorities.
These are inference ablations, not changes to CLEAR's architecture or training.
"""
import math
from itertools import combinations
import numpy as np
import torch
from experiments.exp1.evaluator import stable_seed

CANDIDATES = {
    'stratified': (0., 0.),
    'separation1': (0., 1.),
    'separation2': (0., 2.),
    'explore4': (.125, 0.),
    'separation1_explore4': (.125, 1.),
    'separation2_explore4': (.125, 2.),
    'separation1_explore8': (.25, 1.),
    'separation2_explore8': (.25, 2.),
}


def subset_distribution(p, mu, sigma, exploration, separation):
    p=np.clip(np.asarray(p,dtype=float),1e-6,1-1e-6)
    mu=np.asarray(mu);sigma=np.asarray(sigma);n=len(p);k=round(float(p.sum()))
    neighbours=[j for j in (k-1,k+1) if 0<=j<=n]
    counts={k:1.-exploration if neighbours else 1.}
    if neighbours and exploration:
        counts.update({j:exploration/len(neighbours) for j in neighbours})
    odds=np.log(p)-np.log1p(-p);subsets=[];weights=[]
    for size,prior in sorted(counts.items()):
        sets=list(combinations(range(n),size));logs=[]
        for subset in sets:
            score=float(odds[list(subset)].sum())
            for i,j in combinations(subset,2):
                gap=abs(mu[i]-mu[j])/math.sqrt(sigma[i]**2+sigma[j]**2)
                score+=separation*math.log(max(math.erf(gap/math.sqrt(2)),1e-6))
            logs.append(score)
        logs=np.asarray(logs);w=np.exp(logs-logs.max());w/=w.sum()
        subsets.extend(sets);weights.extend(prior*w)
    return subsets,np.asarray(weights)


def sample_orders(p,mu,sigma,scene_id,training_seed,candidate):
    exploration,separation=CANDIDATES[candidate]
    subsets,weights=subset_distribution(p,mu,sigma,exploration,separation)
    n=len(p)
    engine=torch.quasirandom.SobolEngine(n+1,scramble=True,
        seed=stable_seed(scene_id,'clear_sampling_dev',training_seed))
    points=engine.draw(32,dtype=torch.float64).clamp(1e-12,1-1e-12)
    noise=(math.sqrt(2)*torch.erfinv(2*points[:,1:]-1)).numpy()
    cdf=np.cumsum(weights);cdf[-1]=1.
    indices=np.searchsorted(cdf,points[:,0].numpy(),side='right')
    priorities=np.asarray(mu)[None,:]+np.asarray(sigma)[None,:]*noise
    return [tuple(sorted(subsets[int(index)],key=lambda j:priorities[d,j]))
            for d,index in enumerate(indices)]
