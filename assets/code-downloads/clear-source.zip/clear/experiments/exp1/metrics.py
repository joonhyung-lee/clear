"""The four headline metrics of spec section 7 as pure functions (unit-tested in
tests/experiments/test_grid2d_metrics.py with hand-constructed examples).

  TaskSuccess        all predicted interactions executable and the goal reachable afterwards
                     (the evaluator's `execute_plan` verdict). Unsolvable scenes are excluded
                     from the headline and reported as abstention accuracy in diagnostics.
  OrderHit           rho_hat in Pi_star. With an INCOMPLETE oracle set, absence is not an
                     error: fall back to plan validity + K == K_star.
  InteractionRegret  K(P_hat) - K_star on successful plans only.
  OrderCoverage@M    |{sampled orders} intersect Pi_star| / |Pi_star| on scenes whose optimal
                     set is complete with >= 2 orders. Target prediction and execution do not
                     affect this ordering metric.
  InvalidSampleRate@M (diagnostic) fraction of the M samples whose plan failed execution.
"""
from __future__ import annotations

from typing import Iterable, Sequence


def task_success(plan_valid: bool, goal_reached: bool) -> int:
    return int(bool(plan_valid) and bool(goal_reached))


def order_hit(pred_order: Sequence[int], valid_orders: Iterable[Sequence[int]],
              optimal_set_complete: bool, plan_valid: bool, k_star: int | None) -> int | None:
    """None on unsolvable scenes (no Pi_star)."""
    if k_star is None:
        return None
    pred = tuple(int(i) for i in pred_order)
    valid = {tuple(int(i) for i in o) for o in valid_orders}
    if pred in valid:
        return 1
    if optimal_set_complete:
        return 0
    return int(bool(plan_valid) and len(pred) == int(k_star))


def interaction_regret(k_pred: int, k_star: int | None, plan_success: bool = True) -> int | None:
    if k_star is None or not plan_success:
        return None
    return int(k_pred) - int(k_star)


def coverage_applicable(valid_orders: Iterable[Sequence[int]], optimal_set_complete: bool) -> bool:
    return bool(optimal_set_complete) and len(list(valid_orders)) >= 2


def coverage(sampled_orders: Iterable[Sequence[int]], valid_orders: Iterable[Sequence[int]]) -> float:
    valid = {tuple(int(i) for i in o) for o in valid_orders}
    if not valid:
        return float("nan")
    got = {tuple(int(i) for i in o) for o in sampled_orders}
    return len(got & valid) / len(valid)


def invalid_sample_rate(sampled_valid: Sequence[bool]) -> float:
    n = len(sampled_valid)
    return float("nan") if n == 0 else 1.0 - sum(bool(v) for v in sampled_valid) / n


def k_star_bin(k: int | None) -> str:
    """K* bins are [0, 1, 2, 3_plus] (spec 4.1). A separate `4_plus` bin was dropped because
    the template pool's plug count bounds K*: on the previous, embodiment-aware generator it
    held 5 / 1 / 2 scenes of the 50k / 5k / 10k splits, and a slice with n = 2 in test is not
    a measurement. K* >= 3 is merged into one bin, never dropped, so the bound does not have
    to be re-derived when the template pool changes -- but `3_plus` occupancy under THIS
    generator is unmeasured; check generation_stats.json before quoting that slice."""
    if k is None:
        return "unsolvable"
    return str(k) if k < 3 else "3_plus"


def distractor_bin(n: int) -> str:
    return "0" if n == 0 else ("2" if n <= 3 else "4_plus")


def multiplicity_bin(n_orders: int) -> str:
    return "1" if n_orders <= 1 else ("2" if n_orders == 2 else "3_plus")
