"""Optimistic reachability abstraction of a Grid plan skeleton (LEAP 2026, WP-R).

Abstract state: the set of cells the body can reach from its start, given the current occupancy and
its traversability. Abstract action "clear object i": remove i from the occupancy (an optimistic,
angelic description of pushing it anywhere -- Marthi, Russell & Wolfe 2007). Reachability is
monotone in occupancy (fewer obstacles never shrink the reachable set), so if a skeleton fails in
this abstraction -- an object is not accessible to the body even with all its predecessors gone, or
the goal is unreachable even with every selected object gone -- then no choice of continuous push
targets can make it succeed. The check is therefore a sound filter: it never rejects a skeleton that
has a feasible refinement. Capability enters only through the body: which cells it can traverse,
which push directions it has and which masses it can move (GridEnv's own rules).
"""
from __future__ import annotations

import dataclasses

from experiments.exp1.environment import GridEnv, flood_fill


def _without(scene, removed):
    return dataclasses.replace(scene, objects=[o for o in scene.objects if o.object_id not in removed])


def access_ok(scene, agent, object_id, removed=()):
    """Some push direction of `object_id` has an interaction cell the body can reach, with `removed` gone."""
    env = GridEnv(_without(scene, set(removed)), agent)
    obj = env.scene.by_id(object_id)
    if not env.agent_profile.can_move(obj):
        return False
    cur, others = env.positions[object_id], env.occupied(exclude=object_id)
    reach = env.agent_reachable()
    return any(ic in reach for d in obj.pushable_directions if d in env.agent_profile.can_push
               for ic in env._interaction_cells(obj, cur, d, others))


def goal_ok(scene, agent, removed=()):
    """The goal is reachable by the body once the objects in `removed` are gone."""
    env = GridEnv(_without(scene, set(removed)), agent)
    return scene.goal in flood_fill(scene.terrain, env.occupied(), env.agent)


def optimistic_feasible(scene, agent, order):
    """False only if the skeleton cannot succeed for ANY continuous refinement (sound rejection)."""
    order = list(order)
    for t, oid in enumerate(order):
        if not access_ok(scene, agent, oid, order[:t]):
            return False
    return goal_ok(scene, agent, order)


def object_predicates(scene, agent):
    """Per-object abstract predicates [accessible, necessary, sufficient, goal_reachable_now] (one row per object, in
    scene order), from the same optimistic abstraction. necessary: the goal stays unreachable with every OTHER object
    removed (i is in every solution); sufficient: removing i alone opens the goal."""
    ids = [o.object_id for o in scene.objects]
    g = float(goal_ok(scene, agent))
    rows = []
    for oid in ids:
        others = [j for j in ids if j != oid]
        rows.append([float(access_ok(scene, agent, oid)), float(not goal_ok(scene, agent, others)),
                     float(goal_ok(scene, agent, [oid])), g])
    return rows


_PREDICATE_CACHE: dict = {}


def cached_object_predicates(scene, agent):
    """object_predicates memoised on the scene content and the body (training revisits every scene many times)."""
    key = (scene.terrain.tobytes(), scene.terrain.shape, scene.start, scene.goal, agent.can_push, agent.structure,
           tuple((o.object_id, o.cell, tuple(map(tuple, o.footprint)), o.pushable_directions) for o in scene.objects))
    if key not in _PREDICATE_CACHE:
        _PREDICATE_CACHE[key] = object_predicates(scene, agent)
    return _PREDICATE_CACHE[key]
