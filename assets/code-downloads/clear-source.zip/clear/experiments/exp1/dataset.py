"""Manifests <-> GridScene, and manifests -> pamo `Example`s for training (spec 4, 11).

Canonical manifest (0_overall section 5) via experiments.common.manifests.SceneManifest:
  environment.grid          list[str] ASCII rows ('#' wall, '.' free) of the scene's own size
  objects[].initial_configuration = [row, col]; .mass = kg carrier of the mass class;
  objects[].extra = {mass_class, footprint, pushable_directions}
  robot.embodiment_id is always `fixed_grid_agent`; extra.agent stores the constant simulator
  adapter. It is not an experimental variable.
  oracle                    OracleLabel from oracle.OracleResult.to_label_dict()

Training examples reuse clear.data.data.Example / collate unchanged. Scenes of different map
sizes are padded with WALL into one `canvas_hw` so a single PAMO (fixed grid_hw) sees all of
them; coordinates are canvas coordinates (scene at the canvas origin, so no offset).
"""
from __future__ import annotations

import hashlib
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable

import numpy as np

from clear.data.capability import WALL
from clear.data.data import Example, collate
from clear.data.grid import Scene, cell_path

from experiments.common.manifests import OracleLabel, RobotSpec, SceneManifest, SceneObject
from experiments.exp1.environment import DEFAULT_EXTENT, DIRECTIONS, FREE, AgentProfile, GridObject, GridScene, Observation, PublicAgent, flood_fill
from experiments.exp1.oracle import OraclePlan, OracleResult

EXPERIMENT = "grid2d"
SPLITS = ("train", "val", "test")


# --------------------------------------------------------------------------------------
# manifest <-> scene


def grid_to_rows(terrain: np.ndarray) -> list[str]:
    return ["".join("#" if int(v) == WALL else "." for v in row) for row in np.asarray(terrain)]


def rows_to_grid(rows: list[str]) -> np.ndarray:
    return np.array([[WALL if ch == "#" else FREE for ch in r] for r in rows], dtype=np.int64)


def scene_to_manifest(scene: GridScene, agent: AgentProfile, *, scene_id: str, family: str,
                      generation_seed: int, split: str, base_scene_id: str, template_id: str,
                      oracle: OracleResult | None = None, extra: dict | None = None) -> SceneManifest:
    objs = [
        SceneObject(
            object_id=int(o.object_id), asset_id=f"box_m{o.mass_class}",
            initial_configuration=[float(o.cell[0]), float(o.cell[1])], mass=float(o.mass),
            geometry=[float(len(o.footprint)), float(o.extent)], friction=0.5,
            extra={"mass_class": int(o.mass_class), "footprint": [list(f) for f in o.footprint],
                   "pushable_directions": list(o.pushable_directions)},
        )
        for o in scene.objects
    ]
    h, w = scene.shape
    m = SceneManifest(
        scene_id=scene_id, scene_family=family, generation_seed=int(generation_seed),
        environment={"grid": grid_to_rows(scene.terrain), "height": int(h), "width": int(w),
                     "terrain": []},
        objects=objs, start=[float(scene.start[0]), float(scene.start[1])],
        goal={"cell": [int(scene.goal[0]), int(scene.goal[1])]},
        robot=RobotSpec(agent.agent_id, None, agent.structure.hash()),
        oracle=None if oracle is None else OracleLabel(**oracle.to_label_dict()),
        split=split, base_scene_id=base_scene_id,
        extra={"agent": agent.to_dict(), "template_id": template_id,
               "map_size": int(max(h, w)), "num_objects": len(objs), **(extra or {})},
    )
    return m


def scene_from_manifest(m: SceneManifest) -> GridScene:
    terrain = rows_to_grid(m.environment["grid"])
    objs = [
        GridObject(int(o.object_id), (int(o.initial_configuration[0]), int(o.initial_configuration[1])),
                   footprint=tuple(tuple(f) for f in o.extra.get("footprint", [[0, 0]])),
                   mass_class=int(o.extra.get("mass_class", 1)),
                   pushable_directions=tuple(o.extra.get("pushable_directions", ("N", "E", "S", "W"))),
                   extent=float(o.geometry[1]) if len(o.geometry) > 1 else DEFAULT_EXTENT)
        for o in m.objects
    ]
    return GridScene(terrain, (int(m.start[0]), int(m.start[1])), tuple(int(v) for v in m.goal["cell"]), objs)


def agent_from_manifest(m: SceneManifest) -> AgentProfile:
    return AgentProfile.from_dict(m.extra["agent"])


def label_plans(m: SceneManifest) -> list[OraclePlan]:
    if m.oracle is None:
        return []
    return [OraclePlan.from_dict(p) for p in m.oracle.extra.get("optimal_plans", [])]


def observation_from_manifest(m: SceneManifest) -> Observation:
    agent = agent_from_manifest(m)
    return Observation(scene_from_manifest(m), agent.public(), m.scene_id)


def manifest_digest(m: SceneManifest) -> str:
    return hashlib.sha256(m.canonical_json().encode()).hexdigest()[:12]


# --------------------------------------------------------------------------------------
# scene -> pamo Example


def pad_terrain(terrain: np.ndarray, canvas_hw: tuple[int, int]) -> np.ndarray:
    h, w = terrain.shape
    H, W = canvas_hw
    if h > H or w > W:
        raise ValueError(f"scene {h}x{w} does not fit canvas {H}x{W}")
    out = np.full((H, W), WALL, dtype=np.int64)
    out[:h, :w] = terrain
    return out


def _grid_tensor(scene: GridScene, canvas_hw) -> np.ndarray:
    padded = pad_terrain(scene.terrain, canvas_hw)
    return Scene(terrain=padded, start=scene.start, goal=scene.goal, objects=[]).tensor(), padded


def _pose(cell) -> np.ndarray:
    return np.array([cell[1], cell[0], 0.0], dtype=np.float32)


def scene_to_example(scene: GridScene, agent: AgentProfile | PublicAgent, canvas_hw,
                     plans: list[OraclePlan] | None = None, solvable: bool = True,
                     movable: np.ndarray | None = None, emb_name: str | None = None) -> Example:
    """Build the pamo Example. `plans` (oracle) supply orders + canonical targets; with no
    plans (inference, K*=0, unsolvable) orders = [()] and every target is the current pose.
    `movable` is the LABEL-side mover mask used by the loss; the model never sees it
    (drop_obj=('can_move',)) -- pass None at inference."""
    grid, padded = _grid_tensor(scene, canvas_hw)
    n = len(scene.objects)
    x0 = np.stack([_pose(o.cell) for o in scene.objects]) if n else np.zeros((0, 3), np.float32)
    x1 = x0.copy()
    orders: list[tuple[int, ...]] = [()]
    paths: dict[int, list] = {}
    supervision: dict[tuple[int, ...], tuple[np.ndarray, dict[int, list]]] = {}
    n_moved = 0
    idx_of = {o.object_id: k for k, o in enumerate(scene.objects)}
    if plans:
        orders = [tuple(idx_of[i] for i in p.order) for p in plans]
        n_moved = len(plans[0].order)
        for p in plans:
            order = tuple(idx_of[i] for i in p.order)
            px1 = x0.copy()
            ppaths: dict[int, list] = {}
            for oid, tgt in zip(p.order, p.targets):
                k = idx_of[oid]
                px1[k] = _pose(tgt)
                try:
                    ppaths[k] = cell_path(padded, scene.objects[k].cell, tgt)
                except KeyError:
                    ppaths[k] = [scene.objects[k].cell, tgt]
            supervision[order] = (px1, ppaths)
        x1, paths = supervision[orders[0]]
    if movable is None:
        movable = np.ones(n, dtype=bool)
    occ_all = set()
    for o in scene.objects:
        occ_all.update(o.cells())
    reach0 = flood_fill(scene.terrain, occ_all, scene.start)
    reachable0 = np.array([any((r + dr, c + dc) in reach0 for r, c in o.cells() for dr, dc in
                               ((-1, 0), (1, 0), (0, -1), (0, 1))) for o in scene.objects], dtype=bool)
    ex = Example(
        grid=grid, x0=x0, x1=x1,
        mass=np.array([o.mass for o in scene.objects], dtype=np.float32),
        extent=np.array([o.extent for o in scene.objects], dtype=np.float32),
        movable=np.asarray(movable, dtype=bool), reachable0=reachable0,
        orders=orders, emb_feat=np.array(agent.structure.vector(), dtype=np.float32),
        emb_name=emb_name or agent.agent_id, n_moved=n_moved, paths=paths,
        robot_paths=None, height=None, obj_extra=None, emb=None,
    )
    ex.plan_supervision = supervision  # type: ignore[attr-defined]
    ex.grid_scene = scene
    ex.public_agent = agent.public() if isinstance(agent, AgentProfile) else agent
    return ex


def manifest_to_example(m: SceneManifest, canvas_hw) -> Example | None:
    """Labelled training example (None without an oracle label)."""
    if m.oracle is None:
        return None
    scene = scene_from_manifest(m)
    agent = agent_from_manifest(m)
    plans = label_plans(m) if m.oracle.solvable else []
    movable = np.ones(len(scene.objects), dtype=bool)
    ex = scene_to_example(scene, agent, canvas_hw, plans=plans, solvable=m.oracle.solvable, movable=movable)
    ex.scene_id = m.scene_id  # type: ignore[attr-defined]
    # every optimal order of the oracle label (object INDICES), for set-cover supervision of the ordering
    idx_of = {o.object_id: k for k, o in enumerate(scene.objects)}
    ex.valid_orders = [tuple(idx_of[i] for i in o) for o in (m.oracle.valid_orders or []) if all(i in idx_of for i in o)]  # type: ignore[attr-defined]
    return ex


def observation_to_example(obs: Observation, canvas_hw) -> Example:
    return scene_to_example(obs.scene, obs.agent, canvas_hw)


# --------------------------------------------------------------------------------------
# batching


def commit_order(ex: Example, order: tuple[int, ...]) -> Example:
    """A view of `ex` committed to ONE plan: orders = [order], movable = 'in this plan'. With
    this, clear.collate builds ranks with the sentinel for every object outside the plan and a
    slot schedule with exactly K slots -- the same convention PAMO.sample uses at inference
    when the mover set comes from the mover head (see REPORT decisions)."""
    inplan = np.zeros(len(ex.x0), dtype=bool)
    for i in order:
        inplan[i] = True
    supervision = getattr(ex, "plan_supervision", {})
    x1, paths = supervision.get(tuple(order), (ex.x1, ex.paths))
    committed = Example(grid=ex.grid, x0=ex.x0, x1=x1, mass=ex.mass, extent=ex.extent,
                   movable=inplan, reachable0=ex.reachable0, orders=[tuple(order)],
                   emb_feat=ex.emb_feat, emb_name=ex.emb_name, n_moved=len(order), paths=paths,
                   robot_paths=None, height=None, obj_extra=None, emb=None)
    if hasattr(ex, 'grid_scene'):
        committed.grid_scene, committed.public_agent = ex.grid_scene, ex.public_agent
    if supervision:
        committed.plan_supervision = supervision   # every valid order's targets (set-cover heads read them; others ignore)
    if hasattr(ex, 'valid_orders'):
        committed.valid_orders = ex.valid_orders
    return committed


class BucketSampler:
    """Groups examples by object count (clear.collate stacks (N, 3) arrays) and by whether the
    committed plan is empty (PAMO.forward needs >= 1 mover; empty plans feed the mover head
    only). Scene-balanced: one plan is drawn uniformly per scene per step."""

    def __init__(self, examples: list[Example], rng: np.random.Generator):
        self.rng = rng
        self.buckets: dict[int, list[Example]] = defaultdict(list)
        for ex in examples:
            self.buckets[len(ex.x0)].append(ex)
        self.sizes = {n: len(v) for n, v in self.buckets.items()}
        self.total = sum(self.sizes.values())

    def sample(self, batch_size: int) -> tuple[list[Example], list[Example]]:
        """-> (committed examples with >= 1 mover, committed examples with an empty plan)."""
        ns = list(self.buckets)
        p = np.array([self.sizes[n] for n in ns], dtype=float)
        n = ns[int(self.rng.choice(len(ns), p=p / p.sum()))]
        pool = self.buckets[n]
        idx = self.rng.integers(len(pool), size=batch_size)
        movers, empty = [], []
        for i in idx:
            ex = pool[i]
            order = ex.orders[int(self.rng.integers(len(ex.orders)))]
            c = commit_order(ex, order)
            (movers if len(order) else empty).append(c)
        return movers, empty


def push_reachability_rows(ex: Example) -> np.ndarray:
    """(n, 4) observation-only first-push access per direction: can the public agent stand
    behind object i and push it in direction d with every object at its initial cell. This is
    the SAME feature as the `push_reachability` columns of the CLEAR grid adapter
    (experiments/exp1/shared_model.py collate), exposed to the order baselines under the same
    name so that every learned method receives the same observation (LEAP 2026 WP-1). It is
    not a feasibility mask: no rollout, no oracle label."""
    scene, agent = ex.grid_scene, ex.public_agent
    blocked = {cell for obj in scene.objects for cell in obj.cells()}
    reach = flood_fill(scene.terrain, blocked, scene.start)
    rows = np.zeros((len(scene.objects), 4), dtype=np.float32)
    for i, obj in enumerate(scene.objects):
        rows[i] = [float(d in obj.pushable_directions and d in agent.can_push and
                         any((rr - dr, cc - dc) in reach for rr, cc in obj.cells()))
                   for d, (dr, dc) in DIRECTIONS.items()]
    return rows


def make_batch(examples: list[Example], rng: np.random.Generator, t=None, device="cpu",
               push_reachability: bool = False) -> dict:
    """Legacy (non-shared) batch. `push_reachability=False` is byte-identical to before the
    flag existed; True adds `batch["push_reachability"]` (b, n, 4) for models built with the
    channel (baselines/autoregressive_order/model.py and its subclasses)."""
    batch = collate(examples, rng, device=device, t=t)
    if push_reachability:
        import torch
        rows = np.stack([push_reachability_rows(ex) for ex in examples])
        batch["push_reachability"] = torch.as_tensor(rows, device=device)
    return batch
