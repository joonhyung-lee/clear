"""Evaluate paper Grid checkpoints, including the frozen ordering ablations."""
import argparse
import json
from pathlib import Path

import torch

from experiments.common.interfaces import write_trials
from experiments.common.manifests import read_manifests
from experiments.exp1.evaluator import Instrument, evaluate_split, make_planner, quick_summary
from experiments.exp1.ordering_ablation import OrderingPlanner
from experiments.exp1.structural_confirmation import verify_release


def verify_release_allowing_code_drift(release) -> list[str]:
    """LEAP 2026: checkpoints and split hashes are still enforced; source files that drifted
    from the release freeze are returned (and recorded in summary.json) instead of aborting."""
    from experiments.exp1.structural_training import sha
    drift = [path for path, digest in release['code_sha256'].items() if sha(path) != digest]
    verify_release(dict(release, code_sha256={}))
    return drift


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--method', choices=['clear', 'clear_ro', 'clear_ho', 'autoregressive', 'gumbel_sinkhorn', 'polynet'], default='clear')
    p.add_argument('--seed', type=int, choices=range(5), default=0)
    p.add_argument('--split', choices=['structural', 'original_fresh', 'original_remaining'], default='structural')
    p.add_argument('--device', default='cpu')
    p.add_argument('--limit', type=int, help='Prefix check only; not a paper aggregate')
    p.add_argument('--out', type=Path, required=True)
    # LEAP 2026 additions (all off by default; defaults are byte-identical to the release run)
    p.add_argument('--instrument', action='store_true',
                   help='WP-0: write <out>/candidates.jsonl (one row per verifier call) and add per-scene fields')
    p.add_argument('--allow-code-drift', action='store_true',
                   help='record instead of refuse source files changed since the release freeze')
    p.add_argument('--clear-coverage-selection', choices=['independent', 'cardinality', 'coverage_first', 'enumerate'],
                   help='WP-2: override the CLEAR inference-time coverage sampler (recorded in summary.json)')
    p.add_argument('--clear-decode', choices=['mode', 'separation_map', 'plancode'],
                   help='override the CLEAR point-prediction decode rule (recorded in summary.json)')
    p.add_argument('--clear-abstraction', action='store_true',
                   help='WP-R: stable-reorder CLEAR candidates by the optimistic reachability abstraction (recorded)')
    p.add_argument('--checkpoint', type=Path,
                   help='WP-1/WP-5: evaluate this checkpoint (same method, same inference settings) '
                        'instead of the release checkpoint; its sha256 is recorded in summary.json')
    a = p.parse_args()
    release = json.loads(Path('experiments/exp1/configs/paper.json').read_text())
    code_drift = verify_release_allowing_code_drift(release) if a.allow_code_drift else (verify_release(release) or [])
    torch.set_num_threads(2)
    arm = release['arms']['clear' if a.method in ('clear_ro', 'clear_ho') else a.method]
    inference = dict(arm['inference'])
    if a.clear_coverage_selection and arm['method'] == 'clear':
        inference['clear_coverage_selection'] = a.clear_coverage_selection
    if a.clear_decode and arm['method'] == 'clear':
        inference['clear_decode'] = a.clear_decode
    if a.clear_abstraction and arm['method'] == 'clear':
        inference['clear_abstraction'] = True
    checkpoint_path = str(a.checkpoint) if a.checkpoint else arm['checkpoints'][str(a.seed)]['path']
    planner = make_planner(arm['method'], checkpoint_path, device=a.device, **inference)
    if a.method in ('clear_ro', 'clear_ho'):
        planner.__class__ = OrderingPlanner
        planner.condition = 'random' if a.method == 'clear_ro' else 'heuristic'
        planner.training_seed = a.seed
    rows = read_manifests(release['splits'][a.split]['path'])
    if a.limit:
        rows = rows[:a.limit]
    a.out.mkdir(parents=True, exist_ok=False)
    # The frozen coverage sampler constructs 32 proposals jointly; report its first 8.
    instrument = Instrument() if a.instrument else None
    records, _ = evaluate_split(planner, rows, release['evaluation_seed'], a.seed, coverage_draws=32, log_every=100,
                                instrument=instrument)
    write_trials(str(a.out/'trials.jsonl'), records)
    summary = quick_summary(records)
    summary.update(method=a.method, split=a.split, training_seed=a.seed, prefix_only=bool(a.limit), generated_draws=32, reported_prefix=8)
    if a.instrument:
        with (a.out/'candidates.jsonl').open('w') as f:
            for row in instrument.rows:
                f.write(json.dumps(row) + '\n')
        summary.update(instrumented=True, candidate_rows=len(instrument.rows))
    if a.allow_code_drift or a.clear_coverage_selection or a.clear_decode or a.checkpoint:
        from experiments.exp1.structural_training import sha
        summary.update(code_drift=code_drift, inference=inference, checkpoint=checkpoint_path,
                       checkpoint_sha256=sha(checkpoint_path))
    for key in ('coverage_at_8', 'invalid_sample_rate_at_8'):
        values = [r.extra[key] for r in records if r.extra.get(key) is not None]
        summary[key] = sum(values)/len(values) if values else None
    (a.out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
