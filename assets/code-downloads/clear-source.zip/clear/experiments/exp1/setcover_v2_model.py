"""Set-cover plan codes, v2 (candidate C1''): scene-conditioned codes that attend to each other before
decoding, and a learned validity head that re-ranks the enumeration.

Diagnosis of v1 (outputs/leap2026/WP-A1/README.md, C1' section): the 16 codes are static vectors decoded
independently, so 7 of 16 collapse onto duplicates (8.9 distinct skeletons) and the prior only knows which
codes *won* a plan, not whether the decoded skeleton is valid, so 36 % of the first eight enumerated
skeletons are invalid and the top code is a weaker point prediction than the paper head (93.7 vs 96.9).

v2 keeps the losses of v1 (cover / commit / prior / flow / affordance) and changes two things:
  codes     q_k = code_k + proj(scene, embodiment)  ->  one self-attention layer over the K queries
            (DETR-style query interaction, Carion et al. 2020: queries that see each other stop
            predicting the same object)  -> FiLM of the object tokens per code, shared ordering head.
  validity  per code, a logit for "the deterministic decode of this code is one of the labelled valid
            orders" (exact skeleton match, computed from the same forward pass, no oracle at inference);
            enumeration and the top-1 code are ranked by log p_prior(k) + log sigmoid(validity_k).
Inputs, flow, adaptation stages and checkpoint format are unchanged, so the comparison with v1 and with the
paper head stays paired.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn

from experiments.exp1.setcover_model import GridSetCoverModel, masked_mean

ARCHITECTURE = 'clear-setcover-v2'


class GridSetCoverV2Model(GridSetCoverModel):
    def __init__(self, canvas_hw, validity_weight=1.0, code_layers=1, **kw):
        super().__init__(canvas_hw, **kw)
        dim = int(kw.get('dim', 128))
        self.validity_weight = float(validity_weight)
        self.scene_proj = nn.Linear(2 * dim, dim)
        layer = nn.TransformerEncoderLayer(dim, nhead=4, dim_feedforward=2 * dim, dropout=0.0, batch_first=True, norm_first=True)
        # code_layers=0: static codes exactly as v1 (no scene context, no query interaction) -> isolates the validity head
        self.code_layers = int(code_layers)
        self.code_ctx = nn.TransformerEncoder(layer, num_layers=self.code_layers) if self.code_layers > 0 else nn.Identity()
        self.validity = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, 1))

    # -- scene-conditioned, mutually aware codes --------------------------------------------
    def _film(self, objects, codes_b=None):
        if codes_b is None:                                    # v1 call signature (static codes)
            return super()._film(objects)
        scale, shift = self.film(codes_b).chunk(2, -1)         # (b,K,d)
        return objects[:, None] * (1 + scale[:, :, None]) + shift[:, :, None]

    def decode_all(self, h):
        return self.ordering(h['modulated'])                   # each (b,K,n)

    def _encode(self, batch):
        h = super()._encode(batch)                             # objects, embodiment, prior_logits
        mask = batch['object_mask']
        ctx = self.scene_proj(torch.cat([masked_mean(h['objects'], mask), h['embodiment'][:, 0]], -1))
        codes = (self.code_ctx(self.codes[None] + ctx[:, None]) if self.code_layers > 0
                 else self.codes[None].expand(mask.shape[0], -1, -1))                             # (b,K,d)
        mod = self._film(h['objects'], codes)                                                    # (b,K,n,d)
        pooled_k = (mod * mask[:, None, :, None]).sum(2) / mask.sum(1).clamp(min=1)[:, None, None]
        h['codes'], h['modulated'] = codes, mod
        h['validity_logits'] = self.validity(torch.cat([pooled_k, codes], -1)).squeeze(-1)      # (b,K)
        h['rank_logits'] = torch.log_softmax(h['prior_logits'], -1) + F.logsigmoid(h['validity_logits'])
        return h

    # -- training --------------------------------------------------------------------------------
    @staticmethod
    def decoded_ranks(sel, mu, mask):
        """Deterministic decode of every code as a rank vector (b,K,n): -1 = not selected."""
        chosen = (sel > 0) & mask[:, None]
        order = mu.masked_fill(~chosen, float('inf')).argsort(-1)
        rank = torch.empty_like(order)
        rank.scatter_(-1, order, torch.arange(order.shape[-1], device=order.device).expand_as(order))
        return torch.where(chosen, rank, torch.full_like(rank, -1))

    def loss(self, batch, generator=None):
        h = self._encode(batch)
        total, parts = self._loss_from(h, batch, generator)
        sel, mu, _ = h['_decoded']
        mask, plans, plan_mask = batch['object_mask'], batch['plans'], batch['plan_mask']
        with torch.no_grad():
            pred = self.decoded_ranks(sel, mu, mask)                                             # (b,K,n)
            eq = (pred[:, :, None] == plans[:, None]) | ~mask[:, None, None]                     # (b,K,P,n)
            label = (eq.all(-1) & plan_mask[:, None]).any(-1).float()                            # (b,K)
        validity = F.binary_cross_entropy_with_logits(h['validity_logits'], label)
        parts['validity'] = float(validity.detach())
        parts['valid_codes'] = float(label.mean())
        with torch.no_grad():                                                                    # top-ranked code valid?
            top = h['rank_logits'].argmax(-1)
            parts['top1_valid'] = float(label.gather(1, top[:, None]).mean())
        return total + self.validity_weight * validity, parts
