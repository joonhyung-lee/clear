"""Discrete grid environment for the controlled ordering experiment.

Experiment 01 deliberately uses one fixed abstract agent. Robot type and embodiment
variation are not experimental factors here; they are evaluated in Experiment 03. The
constant six-dimensional descriptor exists only to keep the shared CLEAR architecture and
checkpoint format unchanged across experiments.

Feasibility of `move(object_id, target_cell)`, implemented by `GridEnv`:
  1. the agent can reach a valid interaction cell adjacent to the object (the cell behind the
     object w.r.t. the first push step, through free cells only);
  2. a collision-free discrete object path exists to target_cell, with the footprint clear of
     walls and other objects at every step;
  3. the target footprint is free.
After the interaction the object occupies the target footprint and the agent stands on the
interaction-completion cell (the cell the object vacated on its last step). Agent-only motion
is free and never counts toward K(P). Each object may be interacted with at most once per plan
(PlanPrediction forbids duplicate object ids).
"""
from __future__ import annotations

import hashlib
import json
from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Iterable

import numpy as np

from clear.data.capability import FLAT, WALL, Embodiment
from clear.data.grid import Obj, Scene

from experiments.common.interfaces import ExecutionResult, FailureType

FREE = FLAT  # 0 -- same class codes as pamo so Scene.tensor() and bfs helpers apply unchanged
# WALL = 2 (imported)

DIRECTIONS: dict[str, tuple[int, int]] = {"N": (-1, 0), "E": (0, 1), "S": (1, 0), "W": (0, -1)}
ALL_DIRECTIONS: tuple[str, ...] = ("N", "E", "S", "W")
OPPOSITE = {"N": "S", "S": "N", "E": "W", "W": "E"}

# mass_class -> mass in kg handed to the legacy `Obj.mass` (so `Embodiment.can_move` and every
# existing scorer see a consistent number). Classes are what the spec talks about; kg is the
# legacy carrier.
MASS_CLASS_KG: dict[int, float] = {1: 1.0, 2: 4.0, 3: 12.0, 4: 40.0}
MASS_CLASSES: tuple[int, ...] = (1, 2, 3, 4)
DEFAULT_EXTENT = 0.5  # cells; every object is a single cell here, extent is cosmetic/legacy


def _norm_dirs(dirs: Iterable[str]) -> tuple[str, ...]:
    out = tuple(d for d in ALL_DIRECTIONS if d in set(dirs))
    if not out:
        raise ValueError("an object/agent needs at least one push direction")
    return out


@dataclass
class GridObject:
    object_id: int
    cell: tuple[int, int]
    footprint: tuple[tuple[int, int], ...] = ((0, 0),)  # offsets (dr, dc) from `cell`
    mass_class: int = 1
    pushable_directions: tuple[str, ...] = ALL_DIRECTIONS
    extent: float = DEFAULT_EXTENT

    def __post_init__(self) -> None:
        self.cell = (int(self.cell[0]), int(self.cell[1]))
        self.footprint = tuple((int(a), int(b)) for a, b in self.footprint)
        if (0, 0) not in self.footprint:
            raise ValueError("footprint must contain the anchor offset (0, 0)")
        self.pushable_directions = _norm_dirs(self.pushable_directions)
        if self.mass_class not in MASS_CLASS_KG:
            raise ValueError(f"unknown mass_class {self.mass_class}")

    @property
    def mass(self) -> float:
        return MASS_CLASS_KG[self.mass_class]

    def cells(self, at: tuple[int, int] | None = None) -> list[tuple[int, int]]:
        r, c = self.cell if at is None else at
        return [(r + dr, c + dc) for dr, dc in self.footprint]

    def to_pamo_obj(self) -> Obj:
        return Obj(cell=self.cell, mass=self.mass, extent=self.extent, theta=0.0)

    def to_dict(self) -> dict:
        return {
            "object_id": int(self.object_id), "cell": list(self.cell),
            "footprint": [list(f) for f in self.footprint], "mass_class": int(self.mass_class),
            "pushable_directions": list(self.pushable_directions), "extent": float(self.extent),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "GridObject":
        return cls(object_id=int(d["object_id"]), cell=tuple(d["cell"]),
                   footprint=tuple(tuple(f) for f in d.get("footprint", [[0, 0]])),
                   mass_class=int(d.get("mass_class", 1)),
                   pushable_directions=tuple(d.get("pushable_directions", ALL_DIRECTIONS)),
                   extent=float(d.get("extent", DEFAULT_EXTENT)))


# --------------------------------------------------------------------------------------
# fixed abstract agent


@dataclass(frozen=True)
class StructuralDescriptor:
    """Constant compatibility descriptor for the shared 6-D CapabilityEncoder."""

    body_width_cells: int = 1
    n_arms: int = 0
    actuator_torque: float = 0.5   # normalised, ~[0, 1]
    contact_area: float = 0.5      # normalised pusher/contact area, ~[0, 1]
    base_height: float = 0.5       # metres
    legged: bool = True

    def vector(self) -> list[float]:
        return [
            float(self.body_width_cells) / 2.0,
            float(self.n_arms) / 2.0,
            float(self.actuator_torque),
            float(self.contact_area),
            float(self.base_height),
            float(self.legged),
        ]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "StructuralDescriptor":
        return cls(**{k: d[k] for k in ("body_width_cells", "n_arms", "actuator_torque",
                                         "contact_area", "base_height", "legged")})

    def hash(self) -> str:
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]


STRUCTURE_DIM = 6

PUSH_CLASS_THRESHOLDS: tuple[float, ...] = (0.35, 0.9, 2.0)  # capacity below t_k -> class k+1


def push_capacity(s: StructuralDescriptor) -> float:
    return float(s.actuator_torque) * (1.0 + 0.5 * s.n_arms) * (1.0 + 0.25 * s.contact_area)


def derive_push_class(s: StructuralDescriptor) -> int:
    """Legacy adapter used only to configure the fixed agent's simulator limits."""
    cap = push_capacity(s)
    for k, t in enumerate(PUSH_CLASS_THRESHOLDS):
        if cap < t:
            return k + 1
    return len(PUSH_CLASS_THRESHOLDS) + 1


@dataclass(frozen=True)
class AgentProfile:
    agent_id: str
    structure: StructuralDescriptor
    can_push: tuple[str, ...] = ALL_DIRECTIONS

    @property
    def body_width_cells(self) -> int:
        return self.structure.body_width_cells

    @property
    def max_push_mass_class(self) -> int:
        return derive_push_class(self.structure)

    def can_move(self, obj: GridObject) -> bool:
        return obj.mass_class <= self.max_push_mass_class

    def public(self) -> "PublicAgent":
        return PublicAgent(self.agent_id, self.structure, _norm_dirs(self.can_push))

    def to_pamo_embodiment(self) -> Embodiment:
        """Legacy `Embodiment` whose mass gate reproduces the derived class limit exactly."""
        max_mass = MASS_CLASS_KG[self.max_push_mass_class] + 1e-6
        return Embodiment(self.agent_id, frozenset({FLAT}), max_mass=max_mass,
                          max_extent=10.0, n_arms=self.structure.n_arms, clearance=0.0)

    def to_dict(self) -> dict:
        return {"agent_id": self.agent_id, "structure": self.structure.to_dict(),
                "can_push": list(self.can_push)}

    @classmethod
    def from_dict(cls, d: dict) -> "AgentProfile":
        return cls(d["agent_id"], StructuralDescriptor.from_dict(d["structure"]),
                   tuple(d.get("can_push", ALL_DIRECTIONS)))


@dataclass(frozen=True)
class PublicAgent:
    """Non-privileged view of the single fixed agent."""

    agent_id: str
    structure: StructuralDescriptor
    can_push: tuple[str, ...] = ALL_DIRECTIONS


# One constant, maximally permissive profile. All generated objects use mass class 1 and all
# directions, so neither mass nor this descriptor changes feasibility across scenes.
FIXED_AGENT = AgentProfile(
    "fixed_grid_agent", StructuralDescriptor(1, 2, 1.0, 1.0, 0.5, False), ALL_DIRECTIONS)
assert FIXED_AGENT.max_push_mass_class == max(MASS_CLASSES)


# --------------------------------------------------------------------------------------
# scene


@dataclass
class GridScene:
    terrain: np.ndarray  # (H, W) int, FREE / WALL
    start: tuple[int, int]
    goal: tuple[int, int]
    objects: list[GridObject] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.terrain = np.asarray(self.terrain, dtype=np.int64)
        self.start = (int(self.start[0]), int(self.start[1]))
        self.goal = (int(self.goal[0]), int(self.goal[1]))
        ids = [o.object_id for o in self.objects]
        if len(set(ids)) != len(ids):
            raise ValueError(f"duplicate object ids {ids}")

    @property
    def shape(self) -> tuple[int, int]:
        return tuple(int(v) for v in self.terrain.shape)  # type: ignore[return-value]

    def in_bounds(self, cell) -> bool:
        r, c = cell
        h, w = self.terrain.shape
        return 0 <= r < h and 0 <= c < w

    def is_wall(self, cell) -> bool:
        return (not self.in_bounds(cell)) or int(self.terrain[cell]) == WALL

    def by_id(self, object_id: int) -> GridObject:
        for o in self.objects:
            if o.object_id == object_id:
                return o
        raise KeyError(object_id)

    def copy(self) -> "GridScene":
        return GridScene(self.terrain.copy(), self.start, self.goal,
                         [GridObject.from_dict(o.to_dict()) for o in self.objects])

    def to_pamo_scene(self) -> Scene:
        return Scene(terrain=self.terrain.copy(), start=self.start, goal=self.goal,
                     objects=[o.to_pamo_obj() for o in self.objects])

    def grid_rows(self) -> list[str]:
        """ASCII rows: '#' wall, '.' free, 'S', 'G', digits for object ids (first 10)."""
        h, w = self.terrain.shape
        rows = [["#" if int(self.terrain[r, c]) == WALL else "." for c in range(w)] for r in range(h)]
        for o in self.objects:
            for rr, cc in o.cells():
                rows[rr][cc] = str(o.object_id % 10)
        rows[self.start[0]][self.start[1]] = "S"
        rows[self.goal[0]][self.goal[1]] = "G"
        return ["".join(r) for r in rows]


def scene_from_ascii(text: str, mass_class: dict[int, int] | None = None,
                     pushable: dict[int, Iterable[str]] | None = None) -> GridScene:
    """Hand-drawn scene: '#' wall, '.' free, 'S' start, 'G' goal, digit = object id."""
    rows = [r.strip() for r in text.strip().splitlines() if r.strip()]
    h, w = len(rows), max(len(r) for r in rows)
    terrain = np.full((h, w), FREE, dtype=np.int64)
    start = goal = None
    objs: dict[int, GridObject] = {}
    mass_class = mass_class or {}
    pushable = pushable or {}
    for r, row in enumerate(rows):
        for c, ch in enumerate(row.ljust(w, "#")):
            if ch == "#":
                terrain[r, c] = WALL
            elif ch == "S":
                start = (r, c)
            elif ch == "G":
                goal = (r, c)
            elif ch.isdigit():
                i = int(ch)
                objs[i] = GridObject(i, (r, c), mass_class=mass_class.get(i, 1),
                                     pushable_directions=tuple(pushable.get(i, ALL_DIRECTIONS)))
    if start is None or goal is None:
        raise ValueError("scene needs S and G")
    return GridScene(terrain, start, goal, [objs[i] for i in sorted(objs)])


# --------------------------------------------------------------------------------------
# observation handed to planners


@dataclass
class Observation:
    """Everything a planner may read. No oracle labels."""

    scene: GridScene
    agent: PublicAgent
    scene_id: str = ""


# --------------------------------------------------------------------------------------
# the discrete simulator / plan validator


def flood_fill(terrain: np.ndarray, blocked: set, src: tuple[int, int]) -> set:
    """4-connected cells reachable from src through non-wall, non-blocked cells (src included
    even if listed in `blocked`)."""
    h, w = terrain.shape
    if not (0 <= src[0] < h and 0 <= src[1] < w) or int(terrain[src]) == WALL:
        return set()
    seen = {src}
    q = deque([src])
    while q:
        r, c = q.popleft()
        for dr, dc in DIRECTIONS.values():
            n = (r + dr, c + dc)
            if 0 <= n[0] < h and 0 <= n[1] < w and n not in seen and int(terrain[n]) != WALL \
                    and n not in blocked:
                seen.add(n)
                q.append(n)
    return seen


def bfs_path(terrain: np.ndarray, blocked: set, src: tuple[int, int], dst: tuple[int, int]):
    """Shortest 4-connected path src -> dst (inclusive) through free, non-blocked cells;
    None if unreachable."""
    if src == dst:
        return [src]
    h, w = terrain.shape
    prev = {src: None}
    q = deque([src])
    while q:
        cur = q.popleft()
        if cur == dst:
            out = []
            while cur is not None:
                out.append(cur)
                cur = prev[cur]
            return out[::-1]
        r, c = cur
        for dr, dc in DIRECTIONS.values():
            n = (r + dr, c + dc)
            if 0 <= n[0] < h and 0 <= n[1] < w and n not in prev and int(terrain[n]) != WALL \
                    and n not in blocked:
                prev[n] = cur
                q.append(n)
    return None


@dataclass
class MoveResult:
    ok: bool
    failure: str | None = None
    object_path: list | None = None       # anchor cells, inclusive
    interaction_cell: tuple | None = None
    completion_cell: tuple | None = None
    agent_walk: list | None = None        # agent cells to the interaction cell, inclusive
    reason: str = ""


class GridEnv:
    """Stateful discrete world: object positions, agent cell, executed interactions."""

    def __init__(self, scene: GridScene, agent: AgentProfile):
        if agent.body_width_cells != 1:
            raise NotImplementedError("body_width_cells > 1 is deferred (see REPORT decisions)")
        self.scene = scene
        self.agent_profile = agent
        self.emb = agent  # legacy name used by the shared oracle's lightweight state clone
        self.reset()

    # -- state ------------------------------------------------------------------------
    def reset(self) -> None:
        self.positions: dict[int, tuple[int, int]] = {o.object_id: o.cell for o in self.scene.objects}
        self.agent: tuple[int, int] = self.scene.start
        self.executed: list[int] = []
        self.agent_trace: list[tuple[int, int]] = [self.scene.start]
        self.agent_path_length: int = 0

    def occupied(self, exclude: int | None = None) -> set:
        occ = set()
        for o in self.scene.objects:
            if o.object_id == exclude:
                continue
            occ.update(o.cells(self.positions[o.object_id]))
        return occ

    def agent_reachable(self) -> set:
        return flood_fill(self.scene.terrain, self.occupied(), self.agent)

    def goal_reachable(self) -> bool:
        return self.scene.goal in self.agent_reachable()

    def state_dict(self) -> dict:
        return {"agent": list(self.agent),
                "objects": {str(k): list(v) for k, v in self.positions.items()}}

    # -- feasibility (spec 3.2) ------------------------------------------------------
    def _footprint_free(self, obj: GridObject, at: tuple[int, int], others: set) -> bool:
        for cell in obj.cells(at):
            if self.scene.is_wall(cell) or cell in others:
                return False
        return True

    def _interaction_cells(self, obj: GridObject, at: tuple[int, int], d: str, others: set) -> list:
        """Cells the agent can stand on to push the footprint at `at` in direction d."""
        dr, dc = DIRECTIONS[d]
        fp = set(obj.cells(at))
        out = []
        for (r, c) in fp:
            behind = (r - dr, c - dc)
            if behind in fp or self.scene.is_wall(behind) or behind in others:
                continue
            out.append(behind)
        return out

    def _push_context(self, object_id: int):
        """Shared preamble of check_move / enumerate_targets. -> (obj, cur, others, dirs,
        first_ok, failure_or_None)."""
        try:
            obj = self.scene.by_id(object_id)
        except KeyError:
            return None, None, None, None, None, MoveResult(False, FailureType.WRONG_OBJECT_SELECTION.value,
                                                              reason="unknown object")
        if object_id in self.executed:
            return obj, None, None, None, None, MoveResult(False, FailureType.INVALID_ORDER.value,
                                                             reason="object already moved")
        # Fixed-agent guard. It is constant and inactive for every generated scene.
        if not self.agent_profile.can_move(obj):
            return obj, None, None, None, None, MoveResult(False, FailureType.WRONG_OBJECT_SELECTION.value,
                                                             reason="exceeds push limit")
        cur = self.positions[object_id]
        others = self.occupied(exclude=object_id)
        dirs = [d for d in obj.pushable_directions if d in self.agent_profile.can_push]
        if not dirs:
            return obj, cur, others, dirs, {}, MoveResult(False, FailureType.WRONG_OBJECT_SELECTION.value,
                                                         reason="no common push direction")
        # rule 1: which first-step directions have an agent-reachable interaction cell
        reach = self.agent_reachable()
        first_ok: dict[str, tuple] = {}
        for d in dirs:
            for ic in self._interaction_cells(obj, cur, d, others):
                if ic in reach:
                    first_ok[d] = ic
                    break
        return obj, cur, others, dirs, first_ok, None

    def _object_bfs(self, obj, cur, others, dirs, first_ok, stop_at=None):
        """BFS over anchor positions (rule 3). First step restricted to directions in
        first_ok. -> (prev, first_dir, last_dir); stops early when `stop_at` is reached."""
        prev: dict[tuple, tuple | None] = {cur: None}
        first_dir: dict[tuple, str] = {}
        last_dir: dict[tuple, str] = {}
        q = deque([cur])
        while q:
            at = q.popleft()
            if stop_at is not None and at == stop_at:
                break
            for d in dirs:
                if at == cur and d not in first_ok:
                    continue
                dr, dc = DIRECTIONS[d]
                nxt = (at[0] + dr, at[1] + dc)
                if nxt in prev or not self._footprint_free(obj, nxt, others):
                    continue
                prev[nxt] = at
                first_dir[nxt] = first_dir.get(at, d)
                last_dir[nxt] = d
                q.append(nxt)
        return prev, first_dir, last_dir

    @staticmethod
    def _unwind(prev, target):
        path = []
        at = target
        while at is not None:
            path.append(at)
            at = prev[at]
        path.reverse()
        return path

    def enumerate_targets(self, object_id: int) -> dict:
        """Every feasible target for `move(object_id, .)` from the current state ->
        {target: (object_path, interaction_cell, completion_cell)}. Empty when infeasible."""
        obj, cur, others, dirs, first_ok, fail = self._push_context(object_id)
        if fail is not None or not first_ok:
            return {}
        prev, first_dir, last_dir = self._object_bfs(obj, cur, others, dirs, first_ok)
        out = {}
        for tgt in prev:
            if tgt == cur:
                continue
            path = self._unwind(prev, tgt)
            out[tgt] = (path, first_ok[first_dir[tgt]], path[-2])
        return out

    def check_move(self, object_id: int, target: tuple[int, int]) -> MoveResult:
        target = (int(target[0]), int(target[1]))
        obj, cur, others, dirs, first_ok, fail = self._push_context(object_id)
        if fail is not None:
            return fail
        # rule 4: target footprint free
        if target == cur:
            return MoveResult(False, FailureType.UNREACHABLE_TARGET.value, reason="zero displacement")
        if not self._footprint_free(obj, target, others):
            return MoveResult(False, FailureType.UNREACHABLE_TARGET.value, reason="target footprint not free")
        prev, first_dir, last_dir = self._object_bfs(obj, cur, others, dirs, first_ok, stop_at=target)
        if target not in prev:
            # distinguish "no geometric path at all" from "path exists but agent cannot get behind"
            prev_any, _, _ = self._object_bfs(obj, cur, others, dirs, {d: None for d in dirs}, stop_at=target)
            if target in prev_any:
                return MoveResult(False, FailureType.INVALID_ORDER.value,
                                  reason="no agent-reachable interaction cell for any feasible push")
            return MoveResult(False, FailureType.UNREACHABLE_TARGET.value,
                              reason="no collision-free object path to target")
        path = self._unwind(prev, target)
        ic = first_ok[first_dir[target]]
        walk = bfs_path(self.scene.terrain, self.occupied(), self.agent, ic)
        return MoveResult(True, None, path, ic, path[-2], walk)

    # -- transition -------------------------------------------------------------------
    def apply(self, object_id: int, target: tuple[int, int]) -> ExecutionResult:
        before = self.state_dict()
        res = self.check_move(object_id, target)
        if not res.ok:
            return ExecutionResult(False, res.failure, before["objects"], before["objects"],
                                   {"agent": before["agent"]}, {"agent": before["agent"]},
                                   info={"reason": res.reason, "object_id": int(object_id)})
        # agent walks to the interaction cell, then steps into every cell the object vacates;
        # after the last push it stands on object_path[-2] == the completion cell
        self.agent_trace.extend(res.agent_walk[1:])
        self.agent_path_length += len(res.agent_walk) - 1
        push_len = len(res.object_path) - 1
        self.agent_trace.extend(res.object_path[:-1])
        self.agent_path_length += push_len
        self.positions[object_id] = (int(target[0]), int(target[1]))
        self.agent = res.completion_cell
        self.executed.append(int(object_id))
        after = self.state_dict()
        return ExecutionResult(True, None, before["objects"], after["objects"],
                               {"agent": before["agent"]}, {"agent": after["agent"]},
                               info={"object_path": [list(c) for c in res.object_path],
                                     "interaction_cell": list(res.interaction_cell),
                                     "push_length": push_len, "object_id": int(object_id)})

    def walk_to_goal(self) -> bool:
        """Append the final walk if the goal is reachable. -> success."""
        path = bfs_path(self.scene.terrain, self.occupied(), self.agent, self.scene.goal)
        if path is None:
            return False
        self.agent_trace.extend(path[1:])
        self.agent_path_length += len(path) - 1
        self.agent = self.scene.goal
        return True


@dataclass
class PlanOutcome:
    success: bool
    failure_type: str | None
    executed_order: list[int]
    steps: list[ExecutionResult]
    agent_path_length: int
    agent_trace: list
    final_positions: dict


def execute_plan(scene: GridScene, agent: AgentProfile, object_ids: list[int],
                 targets: list) -> PlanOutcome:
    """Validate and execute a plan WITHOUT any oracle correction (spec section 8). Stops at the
    first infeasible interaction. Success iff every interaction executed and the goal is
    reachable afterwards. Exactly one failure type on failure."""
    env = GridEnv(scene, agent)
    steps: list[ExecutionResult] = []
    failure: str | None = None
    if len(object_ids) != len(targets):
        raise ValueError("object_ids / targets misaligned")
    for oid, tgt in zip(object_ids, targets):
        res = env.apply(int(oid), (int(tgt[0]), int(tgt[1])))
        steps.append(res)
        if not res.success:
            failure = res.failure_type
            break
    if failure is None:
        if env.walk_to_goal():
            return PlanOutcome(True, None, list(env.executed), steps, env.agent_path_length,
                               list(env.agent_trace), dict(env.positions))
        failure = FailureType.NO_PLAN.value if not object_ids else FailureType.GOAL_NOT_REACHED.value
    return PlanOutcome(False, failure, list(env.executed), steps, env.agent_path_length,
                       list(env.agent_trace), dict(env.positions))


def goal_open(scene: GridScene) -> bool:
    """Is the goal reachable from start with every object in place (K = 0 test)."""
    occ = set()
    for o in scene.objects:
        occ.update(o.cells())
    return scene.goal in flood_fill(scene.terrain, occ, scene.start)
