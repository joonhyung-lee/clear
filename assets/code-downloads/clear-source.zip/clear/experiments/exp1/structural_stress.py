"""Frozen-checkpoint structural stress pilot: paired distractor and gate-depth conditions."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import numpy as np
import yaml

from experiments.common.interfaces import read_trials, write_trials
from experiments.common.manifests import freeze, read_manifests, verify_frozen, write_manifests
from experiments.common.statistics import seed_cluster_ci, validate_paired_runs
from experiments.exp1.dataset import scene_to_manifest
from experiments.exp1.evaluator import environment_txt, evaluate_split, make_planner, quick_summary
from experiments.exp1.generator import RejectScene, Template, sample_scene
from experiments.exp1.oracle import solve

LEVELS = {'distractors': (0, 4, 8), 'depth': (2, 3, 4)}
METHODS = ('autoregressive', 'gumbel_sinkhorn', 'polynet', 'clear')
METRICS = ('task_success', 'order_hit', 'interaction_regret', 'coverage_at_32', 'invalid_sample_rate_at_32')


def template_for(axis, level):
    if axis not in LEVELS or level not in LEVELS[axis]:
        raise ValueError('unknown stress condition')
    gaps = (2, 1) if axis == 'distractors' else (2,) * level
    nd = level if axis == 'distractors' else 8 - 2 * level
    return Template(f'stress_{axis}_{level}', 'BRANCH', len(gaps), gaps,
                    tuple((True,) * g for g in gaps), nd)


def sample_block(axis, scene_seed, index):
    """One shared layout seed across levels; reject the entire block if labels are uncertified."""
    manifests = []
    for level in LEVELS[axis]:
        template = template_for(axis, level)
        try:
            scene, agent = sample_scene(np.random.default_rng(scene_seed), template, 32, {'wall_noise': 0})
        except RejectScene:
            return None, 'geometry'
        result = solve(scene, agent, max_orders=64, k_max=template.n_bands)
        if not result.solvable or result.min_interactions != template.n_bands:
            return None, 'unrealized_required_depth'
        if not result.optimal_set_complete:
            return None, 'incomplete_order_set'
        if len(result.optimal_plans) != int(np.prod(template.gaps)):
            return None, 'unexpected_order_count'
        if len(result.distractors) != template.n_distractors:
            return None, 'unexpected_distractor_count'
        group = f'stress_{axis}_{index:04d}'
        manifests.append(scene_to_manifest(scene, agent, scene_id=f'{group}_level{level}',
            family='BRANCH', generation_seed=scene_seed, split='structural_stress_val',
            base_scene_id=group, template_id=template.template_id, oracle=result,
            extra=dict(stress_axis=axis, stress_level=level, required_depth=template.n_bands,
                       n_distractors=template.n_distractors)))
    return manifests, None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['generate', 'evaluate', 'summarize'])
    p.add_argument('--root', required=True)
    p.add_argument('--scenes-per-level', type=int, default=12)
    p.add_argument('--generation-seed', type=int, default=20260913)
    p.add_argument('--method', choices=METHODS)
    p.add_argument('--seed', type=int, default=0, choices=[0, 1])
    p.add_argument('--device', default='cpu')
    a = p.parse_args()
    if a.scenes_per_level < 1 or (a.command == 'evaluate' and a.method is None):
        p.error('positive scene count and an evaluation method are required')
    root = Path(a.root)
    path = root / 'scene_manifest.jsonl'
    if a.command == 'generate':
        root.mkdir(parents=True, exist_ok=False)
        cfg = yaml.safe_load(Path('experiments/exp1/configs/main.yaml').read_text())
        checkpoints = {}
        for method in METHODS:
            for seed in (0, 1):
                source = Path(cfg['runs_dir']) / f'train_{method}_seed{seed}/checkpoint.pt'
                checkpoints[f'{method}_seed{seed}'] = dict(path=str(source.resolve()),
                    sha256=hashlib.sha256(source.read_bytes()).hexdigest())
        design = dict(levels=LEVELS, scenes_per_level=a.scenes_per_level,
                      generation_seed=a.generation_seed, map_size=32, wall_noise=0,
                      config=cfg, checkpoints=checkpoints, training_seeds=[0, 1])
        (root / 'design.json').write_text(json.dumps(design, indent=2) + '\n')
        rng = np.random.default_rng(a.generation_seed)
        manifests, rejected = [], Counter()
        for axis in LEVELS:
            for index in range(a.scenes_per_level):
                for _ in range(100):
                    block, reason = sample_block(axis, int(rng.integers(2**31)), index)
                    if block is not None:
                        manifests.extend(block)
                        print(axis, index + 1, '/', a.scenes_per_level, flush=True)
                        break
                    rejected[f'{axis}:{reason}'] += 1
                else:
                    raise RuntimeError(f'failed to generate certified {axis} block {index}: {rejected}')
        write_manifests(str(path), manifests)
        digest = freeze(str(path))
        (root / 'generation.json').write_text(json.dumps(dict(n_scenes=len(manifests),
            rejected_blocks=dict(rejected), sha256=digest, coverage_excluded=0), indent=2) + '\n')
        return
    design = json.loads((root / 'design.json').read_text())
    verify_frozen(str(path))
    if a.command == 'summarize':
        records = [r for method in METHODS for seed in design['training_seeds']
                   for r in read_trials(str(root / 'eval' / f'{method}_seed{seed}' / 'trial_metrics.jsonl'))]
        validate_paired_runs(records, methods=list(METHODS), expected_seeds={m: 2 for m in METHODS})
        summary = {}
        table = ['| Axis | Level | Method | Task Success | Order Hit | Regret | Coverage@32 | Invalid@32 |',
                 '|---|---:|---|---:|---:|---:|---:|---:|']
        for axis, levels in design['levels'].items():
            for level in levels:
                group = [r for r in records if r.extra['stress_axis'] == axis and r.extra['stress_level'] == level]
                summary[f'{axis}_{level}'] = {}
                for method in METHODS:
                    row, cells = {}, []
                    for metric in METRICS:
                        ci = seed_cluster_ci(group, metric, method, n_boot=2000)
                        row[metric] = {k: (v if np.isfinite(v) else None) for k, v in ci.items()}
                        scale = 1 if metric == 'interaction_regret' else 100
                        cells.append(f"{scale * ci['mean']:.2f} [{scale * ci['ci_lo']:.2f}, "
                                     f"{scale * ci['ci_hi']:.2f}]" if ci['n_units'] else 'n/a')
                    summary[f'{axis}_{level}'][method] = row
                    table.append(f'| {axis} | {level} | {method} | ' + ' | '.join(cells) + ' |')
        (root / 'summary_with_ci.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
        (root / 'results_table.md').write_text('\n'.join(table) + '\n')
        print('\n'.join(table), flush=True)
        return
    source = design['checkpoints'][f'{a.method}_seed{a.seed}']
    if hashlib.sha256(Path(source['path']).read_bytes()).hexdigest() != source['sha256']:
        raise ValueError('source checkpoint changed after the stress design was frozen')
    out = root / 'eval' / f'{a.method}_seed{a.seed}'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'environment.txt').write_text(environment_txt())
    cfg = design['config']
    ecfg = cfg['evaluate']
    planner = make_planner(a.method, source['path'], device=a.device,
        polynet_point_rule=ecfg['polynet_point_rule'], gs_noise_std_mult=ecfg['gs_noise_std_mult'],
        clear_coverage_selection=ecfg['clear_coverage_selection'],
        clear_flow_steps=ecfg['clear_flow_steps'], clear_target_draws=ecfg['clear_target_draws'])
    manifests = read_manifests(str(path))
    records, _ = evaluate_split(planner, manifests, cfg['seed'], a.seed, coverage_draws=32, log_every=12)
    for record, manifest in zip(records, manifests):
        record.extra.update(stress_axis=manifest.extra['stress_axis'],
                            stress_level=manifest.extra['stress_level'], base_scene_id=manifest.base_scene_id)
    write_trials(str(out / 'trial_metrics.jsonl'), records)
    summary = {f'{axis}_{level}': quick_summary([r for r in records
        if r.extra['stress_axis'] == axis and r.extra['stress_level'] == level])
        for axis, levels in LEVELS.items() for level in levels}
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert hashlib.sha256(Path(source['path']).read_bytes()).hexdigest() == source['sha256']
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
