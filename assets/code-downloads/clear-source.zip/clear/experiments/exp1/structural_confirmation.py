"""Evaluate a frozen structural-adaptation release; never select or modify a checkpoint."""
import argparse
import json
from pathlib import Path

from experiments.common.interfaces import write_trials
from experiments.common.manifests import read_manifests
from experiments.exp1.evaluator import environment_txt, evaluate_split, quick_summary, make_planner
from experiments.exp1.structural_training import sha


def verify_release(release):
    for path, digest in release['code_sha256'].items():
        if sha(path) != digest:
            raise ValueError('code changed after release freeze: ' + path)
    for item in release['splits'].values():
        if sha(item['path']) != item['sha256']:
            raise ValueError('confirmation data changed: ' + item['path'])
    for arm in release['arms'].values():
        for item in arm['checkpoints'].values():
            if sha(item['path']) != item['sha256']:
                raise ValueError('checkpoint changed: ' + item['path'])


def run(release_path, arm_name, seed, split, device):
    release = json.loads(Path(release_path).read_text())
    verify_release(release)
    arm = release['arms'][arm_name]
    checkpoint = arm['checkpoints'][str(seed)]
    data = release['splits'][split]
    out = Path(release['output_root']) / split / f'{arm_name}_seed{seed}'
    out.mkdir(parents=True, exist_ok=False)
    identity = dict(release=str(release_path), release_sha256=sha(release_path),
                    arm=arm_name, seed=seed, split=split, checkpoint=checkpoint,
                    inference=arm['inference'], device=device)
    (out / 'run.json').write_text(json.dumps(identity, indent=2) + '\n')
    (out / 'environment.txt').write_text(environment_txt())
    manifests = read_manifests(data['path'])
    if len(manifests) != data['n_scenes'] or len({m.scene_id for m in manifests}) != len(manifests):
        raise ValueError('wrong scene count or duplicate IDs')
    planner = make_planner(arm['method'], checkpoint['path'], device=device, **arm['inference'])
    records, _ = evaluate_split(planner, manifests, release['evaluation_seed'], seed,
                                coverage_draws=32, log_every=100)
    for record, manifest in zip(records, manifests):
        record.extra.update(base_scene_id=manifest.base_scene_id, release_arm=arm_name)
        for key in ('stress_axis', 'stress_level'):
            if key in manifest.extra:
                record.extra[key] = manifest.extra[key]
    verify_release(release)
    if sha(release_path) != identity['release_sha256']:
        raise ValueError('release manifest changed during evaluation')
    write_trials(str(out / 'trial_metrics.jsonl'), records)
    summary = quick_summary(records)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--release', required=True)
    p.add_argument('--arm', required=True)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--split', required=True)
    p.add_argument('--device', default='cpu')
    a = p.parse_args()
    run(a.release, a.arm, a.seed, a.split, a.device)
