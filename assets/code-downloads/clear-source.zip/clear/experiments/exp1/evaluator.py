"""Planners (spec section 6) and the shared evaluator (spec section 8) for Experiment 01.

Every method is an `experiments.common.interfaces.Planner`. The evaluator owns execution
(`environment.execute_plan`, no oracle correction of predicted targets) and metrics. Every
scene uses the same fixed abstract agent; the public/full split is retained only to keep the
shared planner interface and oracle privilege boundary intact.

  oracle          grid2d.oracle.solve on the true scene; returns the shortest-path optimal plan
                  and (in scores) the full enumerated optimal set. privileged=True.
  clear           PAMO checkpoint: configurable mover-set sampler plus one latent priority per
                  selected object (u = mu + sigma*eps), order = argsort u, targets from the
                  rank-causal flow (30 Euler steps).
  clear_mean      same checkpoint, u = mu at inference (inference-only ablation).
  autoregressive  greedy decode of object ids with STOP + regressed target cells.
"""
from __future__ import annotations

import collections
import json
import os
import platform
import subprocess
import sys
import hashlib
import time
from itertools import combinations
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import torch

from experiments.common.interfaces import FailureType, PlanPrediction, Planner, TrialRecord, stopwatch
from experiments.common.manifests import SceneManifest

from experiments.exp1 import metrics as M
from experiments.exp1.dataset import EXPERIMENT, agent_from_manifest, make_batch, observation_to_example, scene_from_manifest
from experiments.exp1.environment import WALL, AgentProfile, Observation, PublicAgent, execute_plan
from experiments.exp1.models import load_checkpoint
from experiments.exp1.oracle import solve

# One registry, by role (exp_v2/01_grid2d_baseline_extension_instruction.md section 7). CLI,
# aggregation and tests import these instead of keeping their own lists.
REFERENCE_METHODS = ("oracle",)                                           # labeler / privileged ceiling
HEADLINE_METHODS = ("autoregressive", "gumbel_sinkhorn", "polynet", "clear")  # the locked comparison
ABLATION_METHODS = ("clear_mean", "clear_seq")                             # separate statistical family
LEARNED_METHODS = HEADLINE_METHODS + ABLATION_METHODS
ALL_METHODS = REFERENCE_METHODS + LEARNED_METHODS
# every learned method that has a distribution to draw from gets exactly 32 coverage draws;
# CLEAR-Mean is deterministic by definition and repeats its one plan
STOCHASTIC_METHODS = tuple(m for m in LEARNED_METHODS if m != "clear_mean")
# Budgets reported alongside Coverage@32. The eligible scenes hold only 2 or 4 optimal orders,
# so 32 draws is 8-16x the number of distinct orders there are to find; the curve shows where
# each sampler saturates instead of asserting that 32 is the right budget.
COVERAGE_BUDGETS = (1, 2, 4, 8, 16, 32)
METHODS = ALL_METHODS  # legacy name


# --------------------------------------------------------------------------------------
# planners


class OraclePlanner(Planner):
    name = "oracle"
    privileged = True

    def __init__(self, max_orders: int = 64):
        self.max_orders = max_orders

    def reset(self, seed: int) -> None:  # deterministic
        pass

    def predict(self, observation: Observation, agent: AgentProfile) -> PlanPrediction:
        if not isinstance(agent, AgentProfile):
            raise TypeError("the oracle needs the full fixed-agent simulator profile")
        t0 = time.perf_counter()
        r = solve(observation.scene, agent, max_orders=self.max_orders)
        dt = time.perf_counter() - t0
        if not r.solvable:
            return PlanPrediction.empty(dt, abstain=True, k_star=None, all_optimal_orders=[],
                                        optimal_set_complete=r.optimal_set_complete)
        p = r.optimal_plans[0]
        return PlanPrediction(list(p.order), [tuple(t) for t in p.targets],
                             scores={"k_star": r.min_interactions, "all_optimal_orders": [list(o) for o in r.optimal_orders],
                                     "optimal_set_complete": r.optimal_set_complete},
                             planning_time_s=dt)


class _LearnedPlanner(Planner):
    def __init__(self, checkpoint: str, device: str = "cpu"):
        self.model, self.ckpt = load_checkpoint(checkpoint)
        self.canvas_hw = tuple(self.ckpt["canvas_hw"])
        self.device = device
        # `_batch` puts the batch on `device`, so the weights have to follow -- passing
        # device="cuda:N" used to crash with a mat1/other device mismatch. The sampler's
        # generator must sit on the same device as the noise it draws.
        self.model.to(device)
        self.checkpoint_path = checkpoint
        self.gen = torch.Generator(device=device).manual_seed(0)
        self.rng = np.random.default_rng(0)
        self.last_seed = 0

    # shared target post-processing for EVERY learned planner (fairness contract: same
    # target post-processing across methods). Observation only -- see _snap.
    snap_targets = True
    sampling = False        # the coverage loop flips this to draw from the distribution
    draw_index = 0

    def _finish_targets(self, xy, order, scene):
        targets = self._cells(xy, order, scene)
        if self.snap_targets:
            occ = {o.cell for o in scene.objects}
            targets = [self._snap(t, scene.objects[j].cell, scene, occ - {scene.objects[j].cell})
                       for t, j in zip(targets, order)]
        return targets

    def reset(self, seed: int) -> None:
        self.gen = torch.Generator(device=self.device).manual_seed(int(seed))
        self.rng = np.random.default_rng(int(seed))
        self.last_seed = int(seed)

    def _batch(self, observation: Observation):
        ex = observation_to_example(observation, self.canvas_hw)
        if getattr(self.model, 'is_shared_affordance', False):
            return self.model.make_batch([ex], device=self.device, include_targets=False)
        return make_batch([ex], self.rng, t=0.0, device=self.device,
                          push_reachability=bool(getattr(self.model, 'push_reachability', False)))

    @staticmethod
    def _cells(xy, idx, scene):
        h, w = scene.shape
        out = []
        for j in idx:
            c = int(np.clip(round(float(xy[j, 0])), 0, w - 1))
            r = int(np.clip(round(float(xy[j, 1])), 0, h - 1))
            out.append((r, c))
        return out

    @staticmethod
    def _snap(cell, cur, scene, occupied):
        """Move a predicted target off a wall, off another object, and off the object's own
        cell, to the nearest cell that is none of those.

        Observation only: the terrain and the object positions are both in the Observation the
        planner already receives. It does NOT check whether the push is executable -- that
        needs the agent's reachability, i.e. the simulator -- so this repairs the 0.7 % of
        targets that land on a wall and the 0.3 % on an occupied cell, not the 3.1 % that fail
        for want of an interaction cell.
        """
        h, w = scene.shape
        if cell != cur and int(scene.terrain[cell]) != WALL and cell not in occupied:
            return cell
        best, bd = None, None
        for r in range(h):
            for c in range(w):
                if (r, c) == cur or int(scene.terrain[r, c]) == WALL or (r, c) in occupied:
                    continue
                d = abs(r - cell[0]) + abs(c - cell[1])
                if bd is None or d < bd:
                    best, bd = (r, c), d
        return best if best is not None else cell


class ClearPlanner(_LearnedPlanner):
    """CLEAR. The learned priority field is a DISTRIBUTION over interaction orders, so the
    single prediction and the coverage draws are two different questions asked of it.

    `predict` returns the point estimate: the mover set is the `k` highest-probability objects
    with `k = round(sum p)` -- the model's own expected mover count -- ordered by `mu`. Drawing
    the mover set with `torch.bernoulli(p)` instead (and thresholding at p > 0.5, as CLEAR-Mean
    does) both produce wrong-SIZED sets, which is where the single-prediction metrics were
    lost: on validation, BRANCH Order Hit is 0.382 for the Bernoulli draw and 0.258 for the
    0.5 threshold against 0.862 for the calibrated size. Only the size changes; nothing here
    consults the environment, the oracle, or any label, and the rule was chosen on validation.

    `sampling = True` restores the stochastic draw. The coverage loop sets it, because
    Coverage@32 asks what the distribution covers, not what its mode is.
    """

    name = "clear"
    mean = False
    sampling = False
    vote_draws = 32          # 0 disables the vote and uses top-k directly
    flow_steps = 30          # Euler steps for the target flow; refrozen on val
    target_draws = 1         # >1 takes the modal target cell over that many flow draws
    coverage_mover_rule = "independent"
    coverage_order = None

    def _priority_outputs(self, batch):
        if getattr(self.model, 'is_shared_affordance', False):
            h = self.model.encode(batch)
            n = int(batch['object_mask'][0].sum())
            return h['mu'][:, :n], h['sigma'][:, :n] * getattr(self, 'priority_sigma_scale', 1.), h['selection'][:, :n], h
        model = self.model
        feat = model.object_features(batch, batch['x0'], torch.zeros_like(batch['s']), 0.0, batch['movable'])
        mu, sigma, logit = model.priority_head(batch['grid'], feat, model._cap(batch), return_mover=True)
        return mu, sigma * getattr(self, 'priority_sigma_scale', 1.), logit, None

    def _priority_noise(self, model, reference):
        if getattr(model, 'is_shared_affordance', False):
            return torch.randn(reference.shape, device=reference.device, generator=self.gen)
        return model.priority_head.sample_noise(reference, generator=self.gen)

    abstraction = False     # WP-R: stable-reorder candidates by the optimistic reachability abstraction

    def _abstraction_reorder(self, observation: Observation, orders, key=lambda o: o):
        """Skeletons that fail the sound optimistic abstraction (experiments/exp1/abstraction.py) go behind the
        passing ones; relative order is otherwise unchanged. Public observation and the body's own capability only."""
        from experiments.exp1.abstraction import optimistic_feasible
        scene, a = observation.scene, observation.agent
        agent = AgentProfile(a.agent_id, a.structure, tuple(a.can_push))
        cache = {}
        def ok(o):
            k = tuple(key(o))
            if k not in cache:
                cache[k] = optimistic_feasible(scene, agent, [scene.objects[j].object_id for j in k])
            return cache[k]
        flags = [ok(o) for o in orders]
        return [o for o, f in zip(orders, flags) if f] + [o for o, f in zip(orders, flags) if not f]

    @torch.no_grad()
    def prepare_coverage_orders(self, observation: Observation, training_seed: int,
                                coverage_draws: int) -> list[tuple] | None:
        """Build the frozen joint 32-draw schedule without oracle or execution feedback."""
        if self.coverage_mover_rule != "coverage_first":
            return None
        if self.abstraction:
            self._observation = observation
            self.abstraction = False
            try:
                schedule = self.prepare_coverage_orders(observation, training_seed, coverage_draws)
            finally:
                self.abstraction = True
            return self._abstraction_reorder(observation, schedule)
        from experiments.exp1.coverage_sampling import sample_final_orders
        batch = self._batch(observation)
        model = self.model
        mu, sigma, logit, _ = self._priority_outputs(batch)
        return sample_final_orders(torch.sigmoid(logit)[0].cpu().tolist(),
                                   mu[0].cpu().tolist(), sigma[0].cpu().tolist(),
                                   observation.scene_id, training_seed, coverage_draws,
                                   candidate=getattr(self, 'coverage_candidate', None))

    @staticmethod
    def _conditional_movers(prob, k: int, generator) -> tuple[int, ...]:
        """Sample the independent Bernoulli mover head conditioned on exactly ``k`` movers.

        For a subset A with |A|=k, p(A | |A|=k) is proportional to the product of the
        Bernoulli odds p_i/(1-p_i) over i in A. Grid2d has at most 12 objects, so enumerating
        the at-most C(12, 6)=924 subsets is exact and negligible beside flow sampling. This is
        observation/model-only decoding: no simulator outcome or oracle label is consulted.
        """
        n = int(prob.numel())
        k = min(max(int(k), 0), n)
        if k == 0:
            return ()
        if k == n:
            return tuple(range(n))
        sets = list(combinations(range(n), k))
        index = torch.tensor(sets, dtype=torch.long, device=prob.device)
        p = prob.clamp(1e-6, 1.0 - 1e-6)
        log_odds = torch.log(p) - torch.log1p(-p)
        log_weight = log_odds[index].sum(dim=-1)
        choice = int(torch.multinomial(torch.softmax(log_weight, dim=0), 1,
                                       generator=generator).item())
        return sets[choice]

    def _order(self, batch, model, mu, sigma, prob) -> tuple:
        """The mover set and its ordering. Subclasses override the set; CLEAR-Mean overrides
        both. `sampling` is set by the coverage loop and must stay stochastic there."""
        if self.sampling:
            if self.coverage_mover_rule == "coverage_first":
                if self.coverage_order is None:
                    raise RuntimeError("coverage_first requires a prepared 32-draw order schedule")
                return self.coverage_order
            if self.coverage_mover_rule == "cardinality":
                movers = self._conditional_movers(prob, round(float(prob.sum())), self.gen)
            elif self.coverage_mover_rule == "independent":
                sel = torch.bernoulli(prob, generator=self.gen).to(dtype=torch.bool)
                movers = tuple(sel.nonzero(as_tuple=False).flatten().tolist())
            else:
                raise ValueError(f"unknown CLEAR coverage mover rule {self.coverage_mover_rule!r}")
            u = mu[0] + sigma[0] * self._priority_noise(model, mu[0])
            return tuple(sorted(movers, key=lambda j: float(u[j])))
        return self._mode_order(model, prob, mu[0], sigma[0])

    def _mode_order(self, model, prob, mu, sigma) -> tuple:
        """Point estimate of the order: the `k = round(sum p)` most probable movers, then the
        most frequent ordering of exactly that many, taken over `vote_draws` priority-head
        draws. Falls back to ordering the top-k by `mu` when no draw has the right size.

        The draws use only the priority head, so they cost far less than the single flow
        sample that produces the targets; on validation the vote is worth +0.5 pt of Order Hit
        and +0.44 pt of Task Success over plain top-k.
        """
        if getattr(self, 'decode_rule', 'mode') == 'separation_map':
            from experiments.exp1.sampling_dev import subset_distribution
            arrays = [x.detach().cpu().numpy() for x in (prob, mu, sigma)]
            subsets, weights = subset_distribution(*arrays, exploration=0., separation=2.)
            return tuple(sorted(subsets[int(weights.argmax())], key=lambda j: float(mu[j])))
        k = int(round(float(prob.sum())))
        if k <= 0:
            return ()
        topk = torch.topk(prob, k).indices.tolist()
        fallback = tuple(sorted(topk, key=lambda j: float(mu[j])))
        if not self.vote_draws or k == 1:
            return fallback
        counts: dict[tuple, int] = {}
        for _ in range(self.vote_draws):
            sel = torch.bernoulli(prob, generator=self.gen).to(dtype=torch.bool)
            mv = sel.nonzero(as_tuple=False).flatten().tolist()
            if len(mv) != k:
                continue
            u = mu + sigma * self._priority_noise(model, mu)
            key = tuple(sorted(mv, key=lambda j: float(u[j])))
            counts[key] = counts.get(key, 0) + 1
        if not counts:
            return fallback
        # ties broken by total mover probability, so the result does not depend on dict order
        return max(counts.items(), key=lambda kv: (kv[1], sum(float(prob[j]) for j in kv[0])))[0]

    @torch.no_grad()
    def predict(self, observation: Observation, agent: PublicAgent) -> PlanPrediction:
        if isinstance(agent, AgentProfile):
            raise TypeError("a learned planner must not receive the privileged simulator profile")
        t0 = time.perf_counter()
        self._observation = observation
        batch = self._batch(observation)
        model = self.model
        mu, sigma, logit, h = self._priority_outputs(batch)
        prob = torch.sigmoid(logit)[0]
        order = self._order(batch, model, mu, sigma, prob)
        targets: list = []
        if order:
            if getattr(model, 'is_shared_affordance', False):
                flow_gen = torch.Generator(device=self.device).manual_seed(self.last_seed) if self.mean else self.gen
                draws = 1 if self.sampling else int(self.target_draws)
                xy = model.sample_targets(batch, order, steps=int(self.flow_steps),
                                          generator=flow_gen, h=h, draws=draws)
                if draws > 1:
                    # Modal target cell over the draws. The flow's error is a fraction of a
                    # cell, so a single draw lands one cell off far more often than the mode
                    # does; the vote uses only the model's own distribution. Coverage draws
                    # keep one draw each -- there the point of a draw is that it differs.
                    cand = [self._finish_targets(xy[d].cpu().numpy(), order, observation.scene)
                            for d in range(xy.shape[0])]
                    votes = [collections.Counter(c[i] for c in cand) for i in range(len(order))]
                    return PlanPrediction(
                        [observation.scene.objects[j].object_id for j in order],
                        [v.most_common(1)[0][0] for v in votes],
                        scores={"mover_prob": [round(float(p), 4) for p in prob],
                                "mu": [round(float(v), 4) for v in mu[0]],
                                "sigma": [round(float(v), 4) for v in sigma[0]],
                                "rng_seed": self.last_seed, "flow_steps": int(self.flow_steps),
                                "target_draws": int(draws),
                                "architecture": self.ckpt.get('architecture', 'legacy-grid-v2'),
                                'affordance_prob': torch.sigmoid(h['interaction_affordance_logits'])[0].cpu().tolist()},
                        planning_time_s=time.perf_counter() - t0)
                xy = xy[0].cpu().numpy()
            else:
                mask = torch.zeros_like(batch["movable"])
                mask[0, list(order)] = True
                b = {**batch, "movable": mask}
                plan = model.sample(b, n_steps=30, generator=self.gen, orders=[order])
                xy = plan["x"][0, :, :2].cpu().numpy()
            targets = self._cells(xy, order, observation.scene)
            if self.snap_targets:
                sc = observation.scene
                occ = {o.cell for o in sc.objects}
                targets = [self._snap(t, sc.objects[j].cell, sc, occ - {sc.objects[j].cell})
                           for t, j in zip(targets, order)]
        ids = [observation.scene.objects[j].object_id for j in order]
        return PlanPrediction(ids, targets, scores={"mover_prob": [round(float(p), 4) for p in prob],
                                                    "mu": [round(float(v), 4) for v in mu[0]],
                                                    "sigma": [round(float(v), 4) for v in sigma[0]],
                                                    "rng_seed": self.last_seed,
                                                    "architecture": self.ckpt.get('architecture', 'legacy-grid-v2'),
                                                    **({'affordance_prob': torch.sigmoid(h['interaction_affordance_logits'])[0].cpu().tolist()}
                                                       if h is not None else {})},
                             planning_time_s=time.perf_counter() - t0)


class PlanCodePlanner(ClearPlanner):
    """CLEAR with the enumerable FSQ plan code (experiments/exp1/plancode_model.py).

    `coverage_mover_rule == "enumerate"`: draw d of the coverage loop is the d-th distinct
    skeleton decoded from the prior-ranked codes (deterministic, no noise, cycling when the
    model proposes fewer distinct skeletons than draws). `decode_rule == "plancode"`: the point
    prediction is the first. The Gaussian rules (independent / coverage_first / mode /
    separation_map) still work on the outputs conditioned on the most probable code."""

    name = "clear"
    _enumerated: list = []

    _cache_key = None
    _cache = None

    def _priority_outputs(self, batch):
        key = (batch['object_features'].shape, float(batch['object_features'].sum()), float(batch['grid'].sum()))
        if self._cache_key == key and self._cache is not None:
            h, self._enumerated = self._cache
        else:
            h = self.model.encode(batch)
            n = int(batch['object_mask'][0].sum())
            self._enumerated = self.model.enumerate_orders(h, n)
            if self.abstraction:
                self._enumerated = self._abstraction_reorder(self._observation, self._enumerated, key=lambda e: e[0])
            self._cache_key, self._cache = key, (h, self._enumerated)
        n = int(batch['object_mask'][0].sum())
        return h['mu'][:, :n], h['sigma'][:, :n] * getattr(self, 'priority_sigma_scale', 1.), h['selection'][:, :n], h

    def _order(self, batch, model, mu, sigma, prob) -> tuple:
        if self.sampling and self.coverage_mover_rule == "enumerate":
            return self._enumerated[int(self.draw_index) % len(self._enumerated)][0]
        if not self.sampling and getattr(self, 'decode_rule', 'mode') == 'plancode':
            return self._enumerated[0][0]
        return super()._order(batch, model, mu, sigma, prob)


class ClearMeanPlanner(ClearPlanner):
    name = "clear_mean"
    mean = True

    def _order(self, batch, model, mu, sigma, prob) -> tuple:
        return tuple(sorted((j for j in range(prob.shape[0]) if float(prob[j]) > 0.5),
                            key=lambda j: float(mu[0][j])))


class ClearSeqPlanner(ClearPlanner):
    """CLEAR with the mover SET chosen by the sequential head rather than by `round(sum p)`
    over independent marginals. The ORDER still comes from the priority field, so Coverage@32
    keeps its mechanism and only the set changes."""

    name = "clear_seq"

    def _order(self, batch, model, mu, sigma, prob) -> tuple:
        movers = model.select_movers(batch, generator=self.gen, sample=self.sampling)
        if not movers:
            return ()
        u = (mu[0] + sigma[0] * model.priority_head.sample_noise(mu[0], generator=self.gen)
             if self.sampling else mu[0])
        return tuple(sorted(movers, key=lambda j: float(u[j])))


class AutoregressivePlanner(_LearnedPlanner):
    """Decoder-style planners: greedy decoding is the point prediction; `sampling=True`
    (set by the coverage loop) draws one categorical sequence instead, so Coverage@32 gets 32
    distinct plans rather than the greedy one repeated. Gumbel-Sinkhorn and PolyNet-style
    expose the same `greedy_decode` / `sample_decode` / `predict_targets` interface."""

    name = "autoregressive"

    def _decode(self, batch) -> tuple:
        if self.sampling:
            return self.model.sample_decode(batch, generator=self.gen)[0]
        return self.model.greedy_decode(batch)[0]

    @torch.no_grad()
    def predict(self, observation: Observation, agent: PublicAgent) -> PlanPrediction:
        if isinstance(agent, AgentProfile):
            raise TypeError("a learned planner must not receive the privileged simulator profile")
        t0 = time.perf_counter()
        batch = self._batch(observation)
        order = tuple(self._decode(batch))
        targets: list = []
        if order:
            xy = self.model.predict_targets(batch, [order])[0]
            targets = self._finish_targets(xy, order, observation.scene)
        ids = [observation.scene.objects[j].object_id for j in order]
        return PlanPrediction(ids, targets, scores={"rng_seed": self.last_seed},
                             planning_time_s=time.perf_counter() - t0)


class GumbelSinkhornPlanner(AutoregressivePlanner):
    """Point: maximum-weight matching of the noiseless scores. Draws: Gumbel-perturbed matching."""
    name = "gumbel_sinkhorn"


class PolyNetPlanner(AutoregressivePlanner):
    """Point: greedy under the checkpoint's validation-selected `point_code`. Draws: cycle the
    strategy codes equally (draw d uses code d mod K), categorical sampling under each."""
    name = "polynet"
    point_rule = "ckpt"     # "ckpt": greedy under the checkpoint's frozen code; "likelihood": PolyNet's
                            # decode-every-code-keep-the-best rule (model.decode_by_likelihood)

    def _decode(self, batch) -> tuple:
        if self.sampling:
            code = int(self.draw_index) % int(self.model.n_codes)
            return self.model.sample_decode(batch, generator=self.gen, code=code)[0]
        if self.point_rule == "likelihood":
            return self.model.decode_by_likelihood(batch)[0]
        return self.model.greedy_decode(batch)[0]


def make_planner(method: str, checkpoint: str | None = None, max_orders: int = 64,
                 device: str = "cpu", clear_decode: str = "mode", polynet_point_rule: str = "ckpt",
                 gs_noise_std_mult: float = 0.0,
                 clear_coverage_selection: str = "independent",
                 clear_flow_steps: int = 30, clear_target_draws: int = 1, clear_abstraction: bool = False,
                 clear_priority_scale: float = 1., clear_coverage_candidate: str | None = None) -> Planner:
    """`clear_decode` picks CLEAR's point estimate: "mode" (top-k with k = round(sum p),
    the default), "separation_map" (MAP subset under the coverage sampler's learned-priority
    separation rule), or "sample" (one Bernoulli draw, the behaviour before the decoding fix).
    It does not affect the coverage draws, which are always stochastic.

    `polynet_point_rule` ("ckpt" | "likelihood") and `gs_noise_std_mult` (0 = the checkpoint's
    fixed `noise_factor`) are inference-only knobs for the two extra baselines; the defaults
    reproduce the `test3` runs exactly. Both are chosen on validation and frozen before a
    fresh test split is scored. `clear_coverage_selection="coverage_first"` activates the
    frozen joint 32-draw schedule developed on val2 (REPORT, 2026-09-07).

    `clear_flow_steps` is the number of Euler steps used to integrate the target flow and
    `clear_target_draws` the number of flow draws the point estimate takes the modal target
    cell over. Both apply only to the shared affordance architecture, are chosen on validation
    and frozen before a test split is scored; the defaults (30, 1) reproduce the first run."""
    if method == "oracle":
        return OraclePlanner(max_orders)          # exact search, no tensors
    if checkpoint is None:
        raise ValueError(f"{method} needs a checkpoint")
    pl = {"clear": ClearPlanner, "clear_mean": ClearMeanPlanner, "clear_seq": ClearSeqPlanner,
          "autoregressive": AutoregressivePlanner, "gumbel_sinkhorn": GumbelSinkhornPlanner,
          "polynet": PolyNetPlanner}[method](checkpoint, device=device)
    if method == "clear" and clear_decode == "sample":
        pl.sampling = True
    elif method == "clear" and clear_decode not in ("mode", "separation_map", "plancode"):
        raise ValueError(f"clear_decode must be 'mode', 'separation_map', 'plancode' or 'sample', got {clear_decode!r}")
    if method == "clear" and getattr(pl.model, 'is_plancode', False):
        pl.__class__ = PlanCodePlanner
    elif clear_decode == "plancode" or clear_coverage_selection == "enumerate":
        raise ValueError("'plancode' decoding and 'enumerate' coverage need a plan-code checkpoint")
    if method == "clear":
        pl.decode_rule = clear_decode
        if clear_coverage_candidate is not None:
            from experiments.exp1.sampling_dev import CANDIDATES
            if clear_coverage_candidate not in CANDIDATES:
                raise ValueError('unknown CLEAR coverage candidate: ' + clear_coverage_candidate)
        pl.coverage_candidate = clear_coverage_candidate
        if clear_coverage_selection not in ("independent", "cardinality", "coverage_first", "enumerate"):
            raise ValueError("clear_coverage_selection must be 'independent', 'cardinality', 'coverage_first' or "
                             "'enumerate', "
                             f"got {clear_coverage_selection!r}")
        pl.coverage_mover_rule = clear_coverage_selection
        pl.abstraction = bool(clear_abstraction)
    if method in ("clear", "clear_mean"):
        if not np.isfinite(clear_priority_scale) or clear_priority_scale <= 0:
            raise ValueError('clear_priority_scale must be finite and positive')
        pl.priority_sigma_scale = float(clear_priority_scale)
        if int(clear_flow_steps) < 1 or int(clear_target_draws) < 1:
            raise ValueError("clear_flow_steps and clear_target_draws must be >= 1")
        pl.flow_steps = int(clear_flow_steps)
        pl.target_draws = int(clear_target_draws)
    if method == "polynet":
        if polynet_point_rule not in ("ckpt", "likelihood"):
            raise ValueError(f"polynet_point_rule must be 'ckpt' or 'likelihood', got {polynet_point_rule!r}")
        pl.point_rule = polynet_point_rule
    if method == "gumbel_sinkhorn":
        if gs_noise_std_mult < 0:
            raise ValueError("gs_noise_std_mult must be >= 0")
        pl.model.noise_std_mult = float(gs_noise_std_mult)
    return pl


# --------------------------------------------------------------------------------------
# evaluation


def stable_seed(scene_id: str, method: str, training_seed: int, draw: int = -1,
                base_seed: int = 0) -> int:
    """Per-prediction RNG seed keyed to WHAT is being predicted, not to a list index, so a
    sharded evaluation and a whole-run evaluation produce identical per-scene predictions.
    `draw = -1` is the point prediction; coverage draws use 0..31."""
    key = f"{int(base_seed)}|{scene_id}|{method}|{int(training_seed)}|{int(draw)}".encode()
    return int.from_bytes(hashlib.blake2b(key, digest_size=4).digest(), "little") % (2**31 - 1)


def scene_seed(base_seed: int, idx: int, salt: int = 0) -> int:
    """Legacy index-keyed seed. Kept only as the fallback in render_qualitative when no trial
    record exists; evaluation uses `stable_seed`."""
    return (int(base_seed) * 1_000_003 + int(idx) * 7919 + salt) % (2**31 - 1)


@dataclass
class TrialArtifacts:
    prediction: PlanPrediction
    outcome: Any
    coverage_orders: list = field(default_factory=list)


class Instrument:
    """LEAP 2026 WP-0 per-candidate log. Off (None) leaves every output byte-identical.

    One row per verifier call: the point prediction (draw = -1) and every coverage draw
    (draw = 0..31, k = draw + 1). `rows` is written to `candidates.jsonl` by the caller."""

    def __init__(self):
        self.rows: list[dict] = []


def failing_interaction_index(outcome) -> int | None:
    """0-based index of the first interaction the verifier (execute_plan) rejected; K when
    every interaction executed but the goal stayed unreachable; None on success."""
    if outcome.success:
        return None
    if outcome.steps and not outcome.steps[-1].success:
        return len(outcome.steps) - 1
    return len(outcome.steps)


def _candidate_row(m: SceneManifest, planner: Planner, training_seed: int, draw: int, pred,
                   outcome, planning_s: float, verifier_s: float, k_star) -> dict:
    return dict(scene_id=m.scene_id, method=planner.name, training_seed=int(training_seed),
                draw=int(draw), k=int(draw) + 1, order=[int(i) for i in pred.object_ids],
                predicted_K=len(pred.object_ids), success=bool(outcome.success),
                failure_type=None if outcome.success else outcome.failure_type,
                failing_interaction_index=failing_interaction_index(outcome),
                verifier_steps=len(outcome.steps), planning_s=float(planning_s),
                verifier_s=float(verifier_s), k_star=k_star, scene_family=m.scene_family,
                coverage_rule=getattr(planner, "coverage_mover_rule", None))


def evaluate_scene(planner: Planner, m: SceneManifest, idx: int, seed: int, training_seed: int,
                   coverage_draws: int = 32, stochastic: bool = True,
                   instrument: Instrument | None = None) -> tuple[TrialRecord, TrialArtifacts]:
    if m.oracle is None:
        raise ValueError(f"{m.scene_id} has no oracle label -- run label_with_oracle first")
    scene = scene_from_manifest(m)
    agent = agent_from_manifest(m)
    obs = Observation(scene, agent.public(), m.scene_id)
    agent_arg = agent if planner.privileged else agent.public()
    label = m.oracle
    k_star = label.min_interactions if label.solvable else None
    valid_orders = [tuple(o) for o in label.valid_orders]

    rng_seed = stable_seed(m.scene_id, planner.name, training_seed, -1, seed)
    planner.reset(rng_seed)
    with stopwatch() as t:
        pred = planner.predict(obs, agent_arg)
    t_exec0 = time.perf_counter()
    outcome = execute_plan(scene, agent, list(pred.object_ids), list(pred.target_configurations))
    exec_s = time.perf_counter() - t_exec0

    k_pred = pred.num_interactions
    success = bool(outcome.success)
    extra: dict[str, Any] = {
        "solvable": bool(label.solvable), "k_star": k_star, "predicted_k": int(k_pred),
        "optimal_set_complete": bool(label.optimal_set_complete),
        "n_optimal_orders": len(valid_orders),
        "order_hit": M.order_hit(pred.object_ids, valid_orders, label.optimal_set_complete, success, k_star),
        "interaction_regret": M.interaction_regret(k_pred, k_star, success),
        "abstain_correct": (None if label.solvable else int(k_pred == 0)),
        "scene_family": m.scene_family, "map_size": m.extra.get("map_size"),
        "num_objects": len(m.objects), "template_id": m.extra.get("template_id"),
        "agent_path_length": int(outcome.agent_path_length) if success else None,
        "oracle_agent_path_length": (label.extra.get("optimal_plans") or [{}])[0].get("agent_path_length") if label.solvable else None,
        "rng_seed": int(rng_seed), "privileged": bool(planner.privileged),
        "coverage_at_32": None, "invalid_sample_rate_at_32": None, "n_covered_orders": None,
        "k_star_bin": M.k_star_bin(k_star),
    }
    cov_orders: list = []
    sampled, flags, draw_log = [], [], []
    applicable = M.coverage_applicable(valid_orders, label.optimal_set_complete)
    # WP-0: with instrumentation on, draw for EVERY solvable scene so Success@k and the
    # first-valid k are defined beyond the coverage-applicable subset; coverage metrics are
    # still only filled where they were before.
    if applicable or (instrument is not None and stochastic and label.solvable and not planner.privileged):
        if planner.privileged and "all_optimal_orders" in pred.scores:
            sampled = [tuple(o) for o in pred.scores["all_optimal_orders"]]
            flags = [True] * len(sampled)  # the oracle's set is realised by construction
            cov_orders = sampled
        elif stochastic:
            sampled, flags = [], []
            _was_sampling = getattr(planner, "sampling", False)
            schedule = (planner.prepare_coverage_orders(obs, training_seed, coverage_draws)
                        if hasattr(planner, "prepare_coverage_orders") else None)
            planner.sampling = True          # coverage asks what the distribution covers
            # Only the legacy flow is deterministic for a fixed observation/order.
            # The shared flow starts from fresh Gaussian noise on EVERY draw; caching
            # its first target would turn 32 samples into repeated copies of that draw.
            reuse_targets = (type(planner) is ClearPlanner and schedule is not None
                             and planner.coverage_mover_rule == "coverage_first"
                             and not getattr(planner.model, 'is_shared_affordance', False))
            order_predictions = {}
            for d in range(coverage_draws):
                planner.draw_index = d      # PolyNet cycles its strategy codes over the draws
                if schedule is not None:
                    planner.coverage_order = schedule[d]
                planner.reset(stable_seed(m.scene_id, planner.name, training_seed, d, seed))
                cache_key = tuple(schedule[d]) if reuse_targets else None
                t_p0 = time.perf_counter()
                if reuse_targets and cache_key in order_predictions:
                    p = order_predictions[cache_key]
                else:
                    p = planner.predict(obs, agent_arg)
                    if reuse_targets:
                        order_predictions[cache_key] = p
                t_p1 = time.perf_counter()
                oc = execute_plan(scene, agent, list(p.object_ids), list(p.target_configurations))
                if instrument is not None:
                    draw_log.append(_candidate_row(m, planner, training_seed, d, p, oc,
                                                   t_p1 - t_p0, time.perf_counter() - t_p1, k_star))
                sampled.append(tuple(p.object_ids))
                flags.append(bool(oc.success))
            cov_orders = sampled
            planner.sampling = _was_sampling
            if schedule is not None:
                planner.coverage_order = None
        else:  # deterministic method: M identical draws
            sampled, flags = [tuple(pred.object_ids)] * coverage_draws, [success] * coverage_draws
            cov_orders = [tuple(pred.object_ids)]
    if applicable:
        extra["coverage_at_32"] = M.coverage(sampled, valid_orders)
        extra["invalid_sample_rate_at_32"] = M.invalid_sample_rate(flags)
        # Budget curve from PREFIXES of the same draws, so @32 is unchanged and one run gives
        # the whole curve. Caveat for CLEAR under coverage_first: its 32 draws are a schedule
        # built to spread early, so a prefix of it is front-loaded by design, while every
        # i.i.d. sampler's prefix is just k independent draws. Read the two accordingly.
        for k in COVERAGE_BUDGETS:
            if k <= len(sampled):
                extra[f"coverage_at_{k}"] = M.coverage(sampled[:k], valid_orders)
                extra[f"invalid_sample_rate_at_{k}"] = M.invalid_sample_rate(flags[:k])
        extra["n_covered_orders"] = len(set(cov_orders) & set(valid_orders))
    if instrument is not None:
        stats = (label.extra or {}).get("stats") or {}
        first_valid = next((i + 1 for i, f in enumerate(flags) if f), None)
        extra.update({
            "mode_failing_interaction_index": failing_interaction_index(outcome),
            "mode_verifier_s": float(exec_s),
            "n_draws": len(flags), "first_valid_k": first_valid,
            # calls counted from the point prediction (call 1); draws are calls 2..n_draws+1
            "verifier_calls_to_first_valid": 1 if success else (None if first_valid is None else 1 + first_valid),
            "verifier_calls_total": 1 + len(flags),
            "draw_success_flags": [bool(f) for f in flags],
            "draw_ks": [len(o) for o in sampled],
            "draw_planning_s": float(sum(r["planning_s"] for r in draw_log)),
            "draw_verifier_s": float(sum(r["verifier_s"] for r in draw_log)),
            "oracle_orders_enumerated": stats.get("orders_enumerated"),
            "oracle_orders_realized": stats.get("orders_realized"),
            "oracle_time_s": stats.get("time_s"),
            "coverage_rule": getattr(planner, "coverage_mover_rule", None),
        })
        instrument.rows.append(_candidate_row(m, planner, training_seed, -1, pred, outcome,
                                              float(pred.planning_time_s or t["s"]), exec_s, k_star))
        instrument.rows.extend(draw_log)

    rec = TrialRecord(
        experiment=EXPERIMENT, method=planner.name, training_seed=int(training_seed), scene_id=m.scene_id,
        physics_seed=0, predicted_order=[int(i) for i in pred.object_ids],
        executed_order=[int(i) for i in outcome.executed_order], num_attempts=1, task_success=success,
        planning_time_s=float(pred.planning_time_s or t["s"]), execution_time_s=float(exec_s),
        failure_type=None if success else outcome.failure_type, strict_success=success,
        embodiment_id=agent.agent_id, extra=extra,
    )
    return rec, TrialArtifacts(pred, outcome, cov_orders)


def evaluate_split(planner: Planner, manifests: list[SceneManifest], seed: int, training_seed: int,
                   coverage_draws: int = 32, log_every: int = 25, stochastic: bool | None = None,
                   keep_artifacts: bool = False, instrument: Instrument | None = None):
    # CLEAR and its sequential-selection variant both have a distribution to draw from;
    # CLEAR-Mean and the autoregressive baseline are deterministic by construction.
    stochastic = planner.name in STOCHASTIC_METHODS if stochastic is None else stochastic
    records, artifacts = [], {}
    t0 = time.perf_counter()
    for idx, m in enumerate(manifests):
        rec, art = evaluate_scene(planner, m, idx, seed, training_seed, coverage_draws, stochastic,
                                  instrument=instrument)
        records.append(rec)
        if keep_artifacts:
            artifacts[m.scene_id] = art
        if log_every and (idx + 1) % log_every == 0:
            print(f"  [{planner.name}] {idx + 1}/{len(manifests)} scenes  {time.perf_counter() - t0:.1f}s", flush=True)
    return records, artifacts


# --------------------------------------------------------------------------------------
# run-directory artifacts (0_overall section 9)


def environment_txt() -> str:
    from clear.provenance import package_revision
    commit = package_revision()['commit']
    return "\n".join([
        f"python {sys.version.split()[0]}", f"torch {torch.__version__}", f"numpy {np.__version__}",
        f"platform {platform.platform()}", f"git_commit {commit}",
        f"OMP_NUM_THREADS {os.environ.get('OMP_NUM_THREADS', '')}", f"torch_threads {torch.get_num_threads()}",
    ]) + "\n"


def write_run_dir(run_dir: str, config_text: str, manifest_path: str, records: list[TrialRecord],
                  checkpoint_or_version: str) -> None:
    from experiments.common.interfaces import write_trials
    os.makedirs(os.path.join(run_dir, "figures"), exist_ok=True)
    os.makedirs(os.path.join(run_dir, "videos"), exist_ok=True)
    with open(os.path.join(run_dir, "config.yaml"), "w") as f:
        f.write(config_text)
    with open(os.path.join(run_dir, "scene_manifest.jsonl"), "w") as f:
        f.write(os.path.abspath(manifest_path) + "\n")
    write_trials(os.path.join(run_dir, "trial_metrics.jsonl"), records)
    with open(os.path.join(run_dir, "checkpoint_or_version.txt"), "w") as f:
        f.write(checkpoint_or_version + "\n")
    with open(os.path.join(run_dir, "environment.txt"), "w") as f:
        f.write(environment_txt())
    summary = quick_summary(records)
    with open(os.path.join(run_dir, "aggregate_metrics.json"), "w") as f:
        json.dump(summary, f, indent=2)


def quick_summary(records: list[TrialRecord]) -> dict:
    """Per-run means (no CIs -- the paired, CI-carrying table is `aggregate`'s job)."""
    solv = [r for r in records if r.extra.get("solvable")]
    uns = [r for r in records if not r.extra.get("solvable")]
    cov = [r.extra["coverage_at_32"] for r in solv if r.extra.get("coverage_at_32") is not None]
    inv = [r.extra["invalid_sample_rate_at_32"] for r in solv if r.extra.get("invalid_sample_rate_at_32") is not None]

    def mean(xs):
        xs = [x for x in xs if x is not None]
        return float(np.mean(xs)) if xs else None

    fails = {}
    for r in solv:
        if not r.task_success:
            fails[r.failure_type] = fails.get(r.failure_type, 0) + 1
    return {
        "n_trials": len(records), "n_solvable": len(solv), "n_unsolvable": len(uns),
        "task_success": mean([r.task_success for r in solv]),
        "order_hit": mean([r.extra.get("order_hit") for r in solv]),
        "interaction_regret": mean([r.extra.get("interaction_regret") for r in solv]),
        "coverage_at_32": mean(cov), "n_coverage_scenes": len(cov),
        "invalid_sample_rate_at_32": mean(inv),
        "abstain_accuracy": mean([r.extra.get("abstain_correct") for r in uns]),
        "planning_time_s_mean": mean([r.planning_time_s for r in records]),
        "failure_types_solvable": fails,
    }
