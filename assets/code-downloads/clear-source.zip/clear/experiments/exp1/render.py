"""Qualitative panels (spec section 9), selected by fixed rules -- never by visual appeal.

Rules (first match in scene_id order over the frozen test split, using the rendered method's
own trial records):
  1. unique-order scene with K* >= 3
  2. multi-order scene where the method recovered >= 2 optimal orders (n_covered_orders >= 2)
  3. a DISTRACTOR-family scene
Each panel: grid + start/goal, object ids, predicted interaction numbers, displacement arrows,
agent path before (dashed) and after (solid) the interactions, oracle K* and predicted K.
"""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

from clear.data.capability import WALL  # noqa: E402

from experiments.common.interfaces import TrialRecord  # noqa: E402
from experiments.common.manifests import SceneManifest  # noqa: E402
from experiments.exp1.dataset import agent_from_manifest, scene_from_manifest  # noqa: E402
from experiments.exp1.environment import AgentProfile, GridScene, execute_plan  # noqa: E402


def select_qualitative(manifests: list[SceneManifest], records: dict[str, TrialRecord]) -> list[tuple[str, SceneManifest]]:
    ms = sorted(manifests, key=lambda m: m.scene_id)
    picks: list[tuple[str, SceneManifest]] = []

    def first(pred):
        for m in ms:
            if m.oracle is not None and pred(m, records.get(m.scene_id)):
                return m
        return None

    m1 = first(lambda m, r: m.oracle.solvable and m.oracle.optimal_set_complete
               and len(m.oracle.valid_orders) == 1 and (m.oracle.min_interactions or 0) >= 3)
    if m1:
        picks.append(("unique_order_k3plus", m1))
    m2 = first(lambda m, r: r is not None and (r.extra.get("n_covered_orders") or 0) >= 2)
    if m2:
        picks.append(("multi_order_recovered", m2))
    else:
        # Fallback (fixed rule, still not visual appeal): the method recovered fewer than two
        # optimal orders anywhere -- happens with an undertrained checkpoint. Show the
        # multi-order scene (complete set, >= 2 optimal orders) on which it recovered the MOST,
        # ties broken by scene_id, so the panel documents the shortfall instead of vanishing.
        pool = [m for m in ms if m.oracle is not None and m.oracle.solvable
                and m.oracle.optimal_set_complete and len(m.oracle.valid_orders) >= 2]
        if pool:
            best = max(pool, key=lambda m: ((records.get(m.scene_id).extra.get("n_covered_orders") or 0)
                                            if records.get(m.scene_id) else 0, [-ord(c) for c in m.scene_id]))
            picks.append(("multi_order_best_recovered", best))
    m3 = first(lambda m, r: m.scene_family == "DISTRACTOR")
    if m3:
        picks.append(("distractor", m3))
    return picks


def draw_panel(ax, scene: GridScene, agent: AgentProfile, pred_ids, pred_targets, label, title: str):
    h, w = scene.shape
    img = np.where(scene.terrain == WALL, 0.25, 1.0)
    ax.imshow(img, cmap="gray", vmin=0, vmax=1, origin="upper", extent=(-0.5, w - 0.5, h - 0.5, -0.5))
    ax.set_xticks(np.arange(-0.5, w, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, h, 1), minor=True)
    ax.grid(which="minor", color="#cccccc", linewidth=0.4)
    ax.tick_params(which="both", length=0, labelbottom=False, labelleft=False)
    ax.text(scene.start[1], scene.start[0], "S", ha="center", va="center", fontsize=11, color="green", weight="bold")
    ax.text(scene.goal[1], scene.goal[0], "G", ha="center", va="center", fontsize=11, color="red", weight="bold")
    outcome = execute_plan(scene, agent, list(pred_ids), list(pred_targets))
    step_of = {int(i): k + 1 for k, i in enumerate(pred_ids)}
    tgt_of = {int(i): tuple(t) for i, t in zip(pred_ids, pred_targets)}
    for o in scene.objects:
        for (r, c) in o.cells():
            ax.add_patch(Rectangle((c - 0.4, r - 0.4), 0.8, 0.8, facecolor="#1f77b4",
                                   alpha=0.85, edgecolor="k", lw=0.6))
        ax.text(o.cell[1], o.cell[0], f"{o.object_id}", ha="center", va="center", fontsize=8, color="white")
        if o.object_id in step_of:
            ax.text(o.cell[1] + 0.42, o.cell[0] - 0.42, f"#{step_of[o.object_id]}", ha="center", va="center",
                    fontsize=8, color="black", bbox=dict(boxstyle="circle,pad=0.15", fc="yellow", ec="k", lw=0.5))
            tr, tc = tgt_of[o.object_id]
            ax.annotate("", xy=(tc, tr), xytext=(o.cell[1], o.cell[0]),
                        arrowprops=dict(arrowstyle="->", color="orange", lw=1.6))
            ax.add_patch(Rectangle((tc - 0.3, tr - 0.3), 0.6, 0.6, fill=False, edgecolor="orange", lw=1.2, ls="--"))
    trace = outcome.agent_trace
    if len(trace) > 1:
        first_push = None
        for s in outcome.steps:
            if s.success:
                first_push = tuple(s.info["interaction_cell"])
                break
        cut = len(trace)
        if first_push is not None and first_push in trace:
            cut = trace.index(first_push) + 1
        before = np.array(trace[:cut])
        after = np.array(trace[cut - 1:])
        ax.plot(before[:, 1], before[:, 0], ls="--", color="green", lw=1.4, label="agent path before")
        if len(after) > 1:
            ax.plot(after[:, 1], after[:, 0], ls="-", color="purple", lw=1.4, alpha=0.8, label="agent path after")
    k_star = label.min_interactions if (label is not None and label.solvable) else None
    ax.set_title(f"{title}\nK*={k_star}  predicted K={len(pred_ids)}  "
                 f"{'success' if outcome.success else outcome.failure_type}", fontsize=8)


def render_figure(items: list[tuple[str, SceneManifest, TrialRecord | None, list, list]], out_path: str,
                  method: str) -> str:
    n = max(1, len(items))
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 5.0), squeeze=False)
    for ax, (rule, m, rec, ids, targets) in zip(axes[0], items):
        scene = scene_from_manifest(m)
        agent = agent_from_manifest(m)
        draw_panel(ax, scene, agent, ids, targets, m.oracle,
                   f"[{rule}] {m.scene_family}\n{m.scene_id} ({method})")
    for ax in axes[0][len(items):]:
        ax.axis("off")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path
