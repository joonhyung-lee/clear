"""Model construction / checkpoint IO shared by cli.train and evaluator (spec 6.2-6.4).

CLEAR here is the existing `clear.model.clear.PAMO` configured as the paper recipe for this
experiment:
  drop_obj=('can_move',)      no oracle mover label enters the object token
  mover_head=True             predicts a mover distribution; CLEAR samples it while
                              CLEAR-Mean uses P(move) > 0.5
  capability_encoder='vector' receives one constant 6-D compatibility vector in every scene
Training batches commit each example to ONE stored optimal plan (dataset.commit_order) so the
rank sentinel / K-slot schedule / mover target all mean "in this plan", matching inference
with movable_from_head=True.
"""
from __future__ import annotations

import os

import torch
import torch.nn.functional as F
from torch import nn

from clear.model.clear import PAMO

from clear.model.affordancenet import AffordanceTransformer

from baselines.autoregressive_order.model import AutoregressiveOrderModel
from baselines.gumbel_sinkhorn_order.model import GumbelSinkhornOrderModel
from baselines.polynet_order.model import PolyNetOrderModel

CLEAR_KWARGS = dict(drop_obj=("can_move",), mover_head=True, capability_encoder="vector",
                    order_objective="pairwise", causal_mask=True)


def build_clear(model_cfg: dict, canvas_hw) -> PAMO:
    torch.set_num_threads(int(os.environ.get("OMP_NUM_THREADS", "10")))
    architecture = model_cfg.get('architecture', 'legacy-grid-v2')
    if architecture == 'clear-joint-matching-v1':
        from experiments.exp1.joint_matching_model import GridJointMatchingModel
        keys = ('n_codes', 'max_plans', 'prior_weight', 'dim', 'depth', 'heads',
                'causal', 'target_scale', 'push_reachability', 'rank_selected_only',
                'goal_blocked', 'matching_weight', 'matching_warmup', 'matching_ramp', 'pair_chunk',
                'abstract_predicates')
        return GridJointMatchingModel(canvas_hw, **{k: model_cfg[k] for k in keys if k in model_cfg})
    if architecture == 'clear-affordance-order-causal-v1':
        from experiments.exp1.shared_model import GridAffordanceFlowModel
        return GridAffordanceFlowModel(canvas_hw, dim=int(model_cfg.get('dim', 128)),
                                      depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                      causal=bool(model_cfg.get('causal', True)),
                                      target_scale=model_cfg.get('target_scale'),
                                      push_reachability=model_cfg.get('push_reachability', False),
                                      rank_selected_only=model_cfg.get('rank_selected_only', False),
                                      cardinality_weight=model_cfg.get('cardinality_weight', 0.),
                                      goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture == 'clear-plancode-fsq-v1':
        from experiments.exp1.plancode_model import GridPlanCodeModel
        return GridPlanCodeModel(canvas_hw, levels=model_cfg.get('levels', (5, 5, 5)),
                                 posterior_depth=int(model_cfg.get('posterior_depth', 2)),
                                 prior_weight=float(model_cfg.get('prior_weight', 1.0)),
                                 dim=int(model_cfg.get('dim', 128)),
                                 depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                 causal=bool(model_cfg.get('causal', True)),
                                 target_scale=model_cfg.get('target_scale'),
                                 push_reachability=model_cfg.get('push_reachability', False),
                                 rank_selected_only=model_cfg.get('rank_selected_only', False),
                                 cardinality_weight=model_cfg.get('cardinality_weight', 0.),
                                 goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture == 'clear-planslots-scene-v1':
        from experiments.exp1.planslots_scene_model import GridPlanSlotsSceneModel
        return GridPlanSlotsSceneModel(canvas_hw, scene_update=str(model_cfg.get('scene_update', 'flow')),
                                       aff_weight=float(model_cfg.get('aff_weight', 1.0)), passes=int(model_cfg.get('passes', 2)),
                                       rank_head=bool(model_cfg.get('rank_head', False)),
                                       n_codes=int(model_cfg.get('n_codes', 16)), max_plans=model_cfg.get('max_plans'),
                                       prior_weight=float(model_cfg.get('prior_weight', 1.0)),
                                       flow_plans_per_example=int(model_cfg.get('flow_plans_per_example', 2)),
                                       dim=int(model_cfg.get('dim', 128)), depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                       causal=bool(model_cfg.get('causal', True)), target_scale=model_cfg.get('target_scale'),
                                       push_reachability=model_cfg.get('push_reachability', False),
                                       rank_selected_only=model_cfg.get('rank_selected_only', False),
                                       goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture == 'clear-planslots-v1':
        from experiments.exp1.planslots_model import GridPlanSlotsModel
        return GridPlanSlotsModel(canvas_hw, n_codes=int(model_cfg.get('n_codes', 16)), max_plans=model_cfg.get('max_plans'),
                                  prior_weight=float(model_cfg.get('prior_weight', 1.0)),
                                  flow_plans_per_example=int(model_cfg.get('flow_plans_per_example', 2)),
                                  slot_flow=bool(model_cfg.get('slot_flow', True)),
                                  rank_head=bool(model_cfg.get('rank_head', False)),
                                  dim=int(model_cfg.get('dim', 128)), depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                  causal=bool(model_cfg.get('causal', True)), target_scale=model_cfg.get('target_scale'),
                                  push_reachability=model_cfg.get('push_reachability', False),
                                  rank_selected_only=model_cfg.get('rank_selected_only', False),
                                  goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture == 'clear-planslots-state-v1':
        from experiments.exp1.planslots_state_model import GridPlanSlotsStateModel
        return GridPlanSlotsStateModel(canvas_hw, n_codes=int(model_cfg.get('n_codes', 16)), max_plans=model_cfg.get('max_plans'),
                                       prior_weight=float(model_cfg.get('prior_weight', 1.0)),
                                       flow_plans_per_example=int(model_cfg.get('flow_plans_per_example', 2)),
                                       dim=int(model_cfg.get('dim', 128)), depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                       causal=bool(model_cfg.get('causal', True)), target_scale=model_cfg.get('target_scale'),
                                       push_reachability=model_cfg.get('push_reachability', False),
                                       rank_selected_only=model_cfg.get('rank_selected_only', False),
                                       goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture == 'clear-setcover-v2':
        from experiments.exp1.setcover_v2_model import GridSetCoverV2Model
        return GridSetCoverV2Model(canvas_hw, n_codes=int(model_cfg.get('n_codes', 16)), max_plans=int(model_cfg.get('max_plans', 8)),
                                   commit_weight=float(model_cfg.get('commit_weight', 0.5)), prior_weight=float(model_cfg.get('prior_weight', 1.0)),
                                   validity_weight=float(model_cfg.get('validity_weight', 1.0)), code_layers=int(model_cfg.get('code_layers', 1)),
                                   dim=int(model_cfg.get('dim', 128)), depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                   causal=bool(model_cfg.get('causal', True)), target_scale=model_cfg.get('target_scale'),
                                   push_reachability=model_cfg.get('push_reachability', False),
                                   rank_selected_only=model_cfg.get('rank_selected_only', False),
                                   cardinality_weight=model_cfg.get('cardinality_weight', 0.),
                                   goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture == 'clear-setcover-v1':
        from experiments.exp1.setcover_model import GridSetCoverModel
        return GridSetCoverModel(canvas_hw, n_codes=int(model_cfg.get('n_codes', 16)), max_plans=int(model_cfg.get('max_plans', 8)),
                                 commit_weight=float(model_cfg.get('commit_weight', 0.5)), prior_weight=float(model_cfg.get('prior_weight', 1.0)),
                                 dim=int(model_cfg.get('dim', 128)), depth=int(model_cfg.get('depth', 4)), heads=int(model_cfg.get('heads', 4)),
                                 causal=bool(model_cfg.get('causal', True)), target_scale=model_cfg.get('target_scale'),
                                 push_reachability=model_cfg.get('push_reachability', False),
                                 rank_selected_only=model_cfg.get('rank_selected_only', False),
                                 cardinality_weight=model_cfg.get('cardinality_weight', 0.),
                                 goal_blocked=model_cfg.get('goal_blocked', False))
    if architecture != 'legacy-grid-v2':
        raise ValueError('unknown grid CLEAR architecture: ' + architecture)
    return PAMO(grid_hw=tuple(canvas_hw), dim=int(model_cfg.get("dim", 128)), depth=int(model_cfg.get("depth", 4)),
                heads=int(model_cfg.get("heads", 4)), dim_head=int(model_cfg.get("dim_head", 32)),
                sigma_weight=float(model_cfg.get("sigma_weight", 0.01)),
                mover_weight=float(model_cfg.get("mover_weight", 0.3)), **CLEAR_KWARGS)


def build_autoregressive(model_cfg: dict, canvas_hw) -> AutoregressiveOrderModel:
    torch.set_num_threads(int(os.environ.get("OMP_NUM_THREADS", "10")))
    return AutoregressiveOrderModel(grid_hw=tuple(canvas_hw), dim=int(model_cfg.get("dim", 128)),
                                    depth=int(model_cfg.get("depth", 4)), heads=int(model_cfg.get("heads", 4)),
                                    dim_head=int(model_cfg.get("dim_head", 32)), drop_obj=("can_move",),
                                    max_steps=int(model_cfg.get("max_steps", 16)),
                                    push_reachability=bool(model_cfg.get("push_reachability", False)))


def build_clear_seq(model_cfg: dict, canvas_hw) -> "SequentialMoverPAMO":
    """CLEAR plus the sequential mover head (experiment 01 only; `clear/` untouched)."""
    torch.set_num_threads(int(os.environ.get("OMP_NUM_THREADS", "10")))
    return SequentialMoverPAMO(
        grid_hw=tuple(canvas_hw), dim=int(model_cfg.get("dim", 128)),
        depth=int(model_cfg.get("depth", 4)), heads=int(model_cfg.get("heads", 4)),
        dim_head=int(model_cfg.get("dim_head", 32)),
        sigma_weight=float(model_cfg.get("sigma_weight", 0.01)),
        mover_weight=float(model_cfg.get("mover_weight", 0.3)),
        seq_weight=float(model_cfg.get("seq_weight", 0.3)),
        seq_max_steps=int(model_cfg.get("max_steps", 16)), **CLEAR_KWARGS)


def _ar_kwargs(model_cfg: dict, canvas_hw) -> dict:
    return dict(grid_hw=tuple(canvas_hw), dim=int(model_cfg.get("dim", 128)),
                depth=int(model_cfg.get("depth", 4)), heads=int(model_cfg.get("heads", 4)),
                dim_head=int(model_cfg.get("dim_head", 32)), drop_obj=("can_move",),
                max_steps=int(model_cfg.get("max_steps", 16)),
                push_reachability=bool(model_cfg.get("push_reachability", False)))


def build_gumbel_sinkhorn(model_cfg: dict, canvas_hw, hp: dict | None = None) -> GumbelSinkhornOrderModel:
    """Same encoders and target head as the AR baseline; a one-shot (n+1)-item permutation
    decoder with STOP marking the prefix. `hp` = configs' `gumbel_sinkhorn:` block."""
    torch.set_num_threads(int(os.environ.get("OMP_NUM_THREADS", "10")))
    hp = dict(hp or {})
    return GumbelSinkhornOrderModel(**_ar_kwargs(model_cfg, canvas_hw),
                                    sinkhorn_iters=int(hp.get("sinkhorn_iters", 20)),
                                    tau_start=float(hp.get("tau_start", 1.0)),
                                    tau_end=float(hp.get("tau_end", 0.1)),
                                    noise_factor=float(hp.get("noise_factor", 1.0)))


def build_polynet(model_cfg: dict, canvas_hw, hp: dict | None = None) -> PolyNetOrderModel:
    """The AR decoder plus binary strategy codes through a residual MLP (PolyNet-style)."""
    torch.set_num_threads(int(os.environ.get("OMP_NUM_THREADS", "10")))
    hp = dict(hp or {})
    return PolyNetOrderModel(**_ar_kwargs(model_cfg, canvas_hw), z_dim=int(hp.get("z_dim", 2)))


def build(method: str, model_cfg: dict, canvas_hw, method_cfg: dict | None = None):
    """`method_cfg` carries the method-specific block from the config (gumbel_sinkhorn / polynet)."""
    if method in ('clear_seq', 'clear_seq_mean') and model_cfg.get('architecture') == 'clear-affordance-order-causal-v1':
        raise ValueError('clear_seq is a legacy ablation; use an explicit legacy configuration')
    if method == "gumbel_sinkhorn":
        return build_gumbel_sinkhorn(model_cfg, canvas_hw, method_cfg)
    if method == "polynet":
        return build_polynet(model_cfg, canvas_hw, method_cfg)
    if method in ("clear_seq", "clear_seq_mean"):
        return build_clear_seq(model_cfg, canvas_hw)
    if method in ("clear", "clear_mean"):
        return build_clear(model_cfg, canvas_hw)
    if method == "autoregressive":
        return build_autoregressive(model_cfg, canvas_hw)
    raise ValueError(method)


def clear_empty_plan_loss(model: PAMO, batch) -> torch.Tensor:
    """Mover-head BCE toward 'move nothing' for examples whose committed plan is empty (K* = 0
    or unsolvable). PAMO.forward needs >= 1 mover per example, so these are trained through the
    selection head alone -- the same head, the same target convention (rank < n == in plan)."""
    movable = batch["movable"]
    feat0 = model.object_features(batch, batch["x0"], torch.zeros_like(batch["s"]), 0.0, movable)
    _mu, _sigma, logit = model.priority_head(batch["grid"], feat0, model._cap(batch), return_mover=True)
    return model.mover_weight * F.binary_cross_entropy_with_logits(logit, torch.zeros_like(logit))


def save_checkpoint(path: str, model, method: str, model_cfg: dict, canvas_hw, training_seed: int,
                    step: int, extra: dict | None = None, method_cfg: dict | None = None) -> None:
    """Every checkpoint carries method, full method-specific config, canvas, training seed,
    step, parameter counts and any validation-selected point rule (PolyNet's code)."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if method.startswith('clear'):
        shared = model_cfg.get('architecture') in ('clear-affordance-order-causal-v1', 'clear-plancode-fsq-v1', 'clear-setcover-v1', 'clear-setcover-v2', 'clear-planslots-v1', 'clear-planslots-state-v1', 'clear-planslots-scene-v1')
        if shared != bool(getattr(model, 'is_shared_affordance', False)):
            raise ValueError('model and checkpoint architecture disagree')
    n_total = sum(p.numel() for p in model.parameters())
    n_decoder = decoder_param_count(model)
    rec = {"model": model.state_dict(), "method": method, "model_cfg": dict(model_cfg),
           "architecture": model_cfg.get('architecture', 'legacy-grid-v2') if method.startswith('clear') else method,
           "method_cfg": dict(method_cfg or getattr(model, "hparams", {}) or {}),
           "canvas_hw": [int(v) for v in canvas_hw], "training_seed": int(training_seed),
           "step": int(step), "n_params": int(n_total), "n_params_decoder": int(n_decoder),
           **(extra or {})}
    if hasattr(model, "point_code"):
        rec["point_code"] = int(model.point_code)
    torch.save(rec, path)


def decoder_param_count(model) -> int:
    """Order-decoder parameters only (everything that is not a shared encoder or the target
    head), for the like-for-like capacity report the fairness contract asks for."""
    if getattr(model, 'is_shared_affordance', False):
        return sum(p.numel() for p in model.ordering.parameters())
    shared = ("to_object_tokens.", "capability_encoder.", "scene_encoder.", "transformer.",
              "tgt_", "to_target.")
    if isinstance(model, PAMO):
        # PAMO's decoder is the priority head minus its encoders
        return sum(p.numel() for n, p in model.named_parameters()
                   if n.startswith("priority_head.") and not any(
                       k in n for k in ("scene_encoder", "capability_encoder", "to_object_tokens", ".transformer.")))
    return sum(p.numel() for n, p in model.named_parameters() if not n.startswith(shared))


def load_checkpoint(path: str):
    ck = torch.load(path, map_location="cpu", weights_only=False)
    method = ck["method"]
    if method.startswith('clear'):
        architecture = ck['model_cfg'].get('architecture', 'legacy-grid-v2')
        if ck.get('architecture', 'legacy-grid-v2') != architecture:
            raise ValueError('checkpoint architecture does not match model_config; retrain rather than relabel')
    model = build(method, ck["model_cfg"], ck["canvas_hw"], ck.get("method_cfg"))
    model.load_state_dict(ck["model"])
    if "point_code" in ck and hasattr(model, "point_code"):
        model.point_code = int(ck["point_code"])
    model.eval()
    return model, ck


# --------------------------------------------------------------------------------------
# Experiment-01-only: sequential mover selection.
#
# `clear/` is NOT modified. Everything below subclasses PAMO inside this experiment, so the
# other three experiments and every existing checkpoint are untouched.


class SequentialMoverHead(nn.Module):
    """Pick the mover SET one object at a time, conditioned on the objects already picked.

    PAMO's mover head emits one INDEPENDENT Bernoulli marginal per object. BRANCH's
    distribution over mover sets is multimodal by construction -- the family exists because
    two or more different sets are optimal -- and no product of independent marginals can
    express "A or B, never both": with optimal sets {A, C} and {B, C} the marginals are about
    p_A = p_B = 0.5, p_C = 0.9, whose argmax is the hybrid {A, B} that is in no optimal order.
    On validation that is 8.9 % of BRANCH scenes ("right size, wrong subset"), and every
    marginal-based reranking tried made it worse rather than better (see REPORT).

    This head factorises the set distribution autoregressively instead, which can represent
    it. It reuses the priority head's per-object tokens -- computed once -- and conditions
    through a learned "placed" offset plus one attention layer, so the extra cost per step is
    a transformer pass over n <= 12 tokens rather than a second encode of the scene.

    The ordering is left alone: permutation errors are 0.2 % under the current decoding, and
    the priority field's sampled ordering is what produces Coverage@32.
    """

    def __init__(self, dim: int, heads: int = 4, dim_head: int = 32, max_steps: int = 16):
        super().__init__()
        self.max_steps = int(max_steps)
        self.placed_embed = nn.Parameter(torch.zeros(dim))
        self.step_embed = nn.Embedding(self.max_steps + 1, dim)
        self.stop_token = nn.Parameter(torch.randn(dim) * 0.02)
        self.mix = AffordanceTransformer(dim, depth=1, heads=heads, dim_head=dim_head)
        self.to_logit = nn.Linear(dim, 1)

    def step_logits(self, tokens, placed, steps):
        """tokens (B, n, d), placed (B, n) bool, steps (B,) long -> (B, n + 1) with STOP last."""
        st = self.step_embed(steps.clamp(max=self.max_steps))
        h = tokens + placed[..., None].to(tokens.dtype) * self.placed_embed + st[:, None, :]
        h = self.mix(h)
        obj = self.to_logit(h).squeeze(-1)
        stop = self.to_logit(self.stop_token[None, :] + st).squeeze(-1)
        lg = torch.cat([obj, stop[:, None]], dim=-1)
        pad = torch.zeros_like(placed[:, :1])
        return lg.masked_fill(torch.cat([placed, pad], dim=-1), float("-inf"))


class SequentialMoverPAMO(PAMO):
    """CLEAR with the mover set chosen sequentially. Identical to `PAMO` otherwise -- same
    priority field, same flow, same losses -- so a comparison isolates the selection change."""

    def __init__(self, *args, dim: int = 128, heads: int = 4, dim_head: int = 32,
                 seq_weight: float = 0.3, seq_max_steps: int = 16, **kw):
        super().__init__(*args, dim=dim, heads=heads, dim_head=dim_head, **kw)
        self.seq_mover = SequentialMoverHead(dim, heads=heads, dim_head=dim_head,
                                             max_steps=seq_max_steps)
        self.seq_weight = float(seq_weight)

    def object_tokens(self, batch, context=None):
        feat0 = self.object_features(batch, batch["x0"], torch.zeros_like(batch["s"]), 0.0,
                                     batch["movable"])
        return self.priority_head._encode(batch["grid"], feat0, self._cap(batch), context)

    def seq_mover_loss(self, batch, context=None):
        """Teacher-forced cross entropy over the committed plan, STOP after the last object.

        The plan is read from `batch['rank']`: ranks below n are the plan in order, and
        `commit_order` guarantees nothing else is marked movable, so an empty plan is simply
        STOP at step 0. Every step is built at once and run as one (T*b) batch, the same way
        the autoregressive baseline teacher-forces.
        """
        rank = batch["rank"]
        b, n = rank.shape
        dev = rank.device
        tokens = self.object_tokens(batch, context)
        k = (rank < n).sum(dim=-1)                       # plan length per example
        order = rank.argsort(dim=-1)                     # plan members first, by rank
        T = int(k.max().item()) + 1                      # picks, plus the STOP step
        step = torch.arange(T, device=dev)

        # target[t, i] = the object with rank t, or STOP (index n) once the plan is finished
        target = torch.full((T, b), n, dtype=torch.long, device=dev)
        m = min(T, n)
        target[:m] = order[:, :m].t()
        target = torch.where(step[:, None] < k[None, :], target,
                             torch.full_like(target, n))
        placed = rank[None, :, :] < step[:, None, None]  # (T, b, n): ranks already consumed
        valid = step[:, None] <= k[None, :]              # steps up to and including STOP

        rep = lambda x: x[None].expand(T, *x.shape).reshape(T * b, *x.shape[1:])
        lg = self.seq_mover.step_logits(rep(tokens), placed.reshape(T * b, n),
                                        step[:, None].expand(T, b).reshape(-1))
        ce = F.cross_entropy(lg, target.reshape(-1), reduction="none").view(T, b)
        return ce[valid].mean()

    def forward(self, batch, context=None):
        loss, parts = super().forward(batch, context)
        seq = self.seq_mover_loss(batch, context)
        return loss + self.seq_weight * seq, {**parts, "seq_mover": seq.item()}

    @torch.no_grad()
    def select_movers(self, batch, generator=None, sample: bool = False, context=None):
        """-> tuple of object indices, chosen sequentially. `sample=True` draws instead of
        taking the argmax, which is what the coverage draws use."""
        tokens = self.object_tokens(batch, context)
        b, n, _ = tokens.shape
        assert b == 1, "inference selects for one scene at a time"
        placed = torch.zeros(b, n, dtype=torch.bool, device=tokens.device)
        chosen: list[int] = []
        for t in range(min(self.seq_mover.max_steps, n)):
            steps = torch.full((b,), t, dtype=torch.long, device=tokens.device)
            lg = self.seq_mover.step_logits(tokens, placed, steps)
            if sample:
                j = int(torch.multinomial(F.softmax(lg, dim=-1)[0], 1, generator=generator))
            else:
                j = int(lg[0].argmax())
            if j == n:
                break
            chosen.append(j)
            placed[0, j] = True
        return tuple(chosen)


def clear_seq_empty_plan_loss(model: SequentialMoverPAMO, batch) -> torch.Tensor:
    """Empty-plan examples for the sequential head: STOP at step 0, plus the mover-head BCE
    toward 'move nothing' that plain CLEAR already uses."""
    return clear_empty_plan_loss(model, batch) + model.seq_weight * model.seq_mover_loss(batch)
