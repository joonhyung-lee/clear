"""Exact minimum-interaction oracle for Experiment 01 (spec section 5).

Algorithm -- the existing `clear.data.oracle.solve` idea (search over (agent cell, set of moved
objects) with the moved objects vanishing, cost = interactions first) reorganised so that the
COMPLETE set of minimum-interaction orders is enumerated and every order is realised into
concrete target cells under the environment's exact feasibility rules:

  1. reach(S)   = cells the agent reaches from start with the objects in S removed and every
                  other object blocking (order-independent: a flood fill).
  2. enterable  = objects not in S that the agent could start pushing from reach(S): some
                  interaction cell behind the object lies in reach(S), the push direction is
                  allowed for object and body, and the cells ahead are free of walls / unmoved
                  objects (the PUSHABLE_PLAN gate of the legacy oracle, now always on).
  3. K = 0, 1, 2, ...: enumerate every order (i_1..i_K) with i_j enterable from
                  reach({i_1..i_{j-1}}) and goal in reach({i_1..i_K}) -- a lower bound on the
                  true plan set. Realise each order (step 4); the first K with at least one
                  realisable order is K_star and the realisable orders form Pi_star.
  4. realise    = sequential target search with look-ahead validity (the legacy
                  find_parking/park_valid rule): for object i_k pick the nearest target
                  (BFS rings, goal-ward tie-break) whose execution is feasible in `GridEnv`
                  and after which the remaining objects stay enterable in sequence and the
                  goal opens; bounded backtracking over the next candidates. Several
                  realisations are collected and the shortest agent path is kept.

Optimality membership is by interaction count only; agent path length ranks plans WITHIN
the optimal set (spec 5's secondary cost) and is stored per plan. `optimal_set_complete` is
False whenever the order enumeration was truncated by `max_orders`.

`brute_force` is the independent validator (spec 12-14): Dijkstra over the JOINT state
(agent cell, every object cell) with all feasible move(object, target) transitions, each
object moved at most once. Small maps only.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from itertools import count

import numpy as np

from experiments.exp1.environment import DIRECTIONS, AgentProfile, GridEnv, GridScene, WALL, flood_fill

MAX_ORDERS = 64                 # order-enumeration cap -> optimal_set_complete=False when hit
MAX_REALIZATIONS_PER_ORDER = 6  # distinct target assignments tried per order (keep min path)
CANDIDATE_BRANCH = 3            # valid targets tried per object before backtracking stops
MAX_CANDIDATES = 96             # BFS ring cells inspected per object


@dataclass
class OraclePlan:
    order: list[int]
    targets: list[tuple[int, int]]
    agent_path_length: int

    def to_dict(self) -> dict:
        return {"order": [int(i) for i in self.order],
                "targets": [[int(r), int(c)] for r, c in self.targets],
                "agent_path_length": int(self.agent_path_length)}

    @classmethod
    def from_dict(cls, d: dict) -> "OraclePlan":
        return cls([int(i) for i in d["order"]], [tuple(t) for t in d["targets"]],
                   int(d["agent_path_length"]))


@dataclass
class OracleResult:
    solvable: bool
    min_interactions: int | None
    optimal_plans: list[OraclePlan]          # one canonical (shortest-path) plan per order
    optimal_set_complete: bool
    n_movable: int
    movable_ids: list[int]
    distractors: list[int]                   # movable objects in no optimal order
    stats: dict = field(default_factory=dict)

    @property
    def optimal_orders(self) -> list[tuple[int, ...]]:
        return [tuple(p.order) for p in self.optimal_plans]

    def to_label_dict(self) -> dict:
        return {
            "solvable": bool(self.solvable),
            "min_interactions": None if self.min_interactions is None else int(self.min_interactions),
            "valid_orders": [list(o) for o in self.optimal_orders],
            "valid_plan_ids": [f"plan_{k}" for k in range(len(self.optimal_plans))],
            "optimal_set_complete": bool(self.optimal_set_complete),
            "extra": {
                "optimal_plans": [p.to_dict() for p in self.optimal_plans],
                "n_movable": int(self.n_movable),
                "movable_ids": [int(i) for i in self.movable_ids],
                "distractors": [int(i) for i in self.distractors],
                "stats": dict(self.stats),
            },
        }


# --------------------------------------------------------------------------------------
# vanish-semantics reachability


def _blocked_cells(scene: GridScene, moved: frozenset, positions=None) -> set:
    occ = set()
    for o in scene.objects:
        if o.object_id in moved:
            continue
        at = None if positions is None else positions.get(o.object_id)
        occ.update(o.cells(at))
    return occ


def vanish_reach(scene: GridScene, moved: frozenset, src=None, positions=None) -> set:
    """Cells reachable with objects in `moved` removed, all others blocking."""
    return flood_fill(scene.terrain, _blocked_cells(scene, moved, positions),
                      scene.start if src is None else src)


def enterable(scene: GridScene, emb: AgentProfile, moved: frozenset, reach: set,
              positions=None, candidates=None) -> list[int]:
    """Objects (not in moved) the agent could start pushing from `reach`."""
    out = []
    blocked = _blocked_cells(scene, moved, positions)
    pool = scene.objects if candidates is None else [scene.by_id(i) for i in candidates]
    for o in pool:
        if o.object_id in moved or not emb.can_move(o):
            continue
        at = o.cell if positions is None else positions[o.object_id]
        fp = set(o.cells(at))
        others = blocked - fp
        ok = False
        for d in o.pushable_directions:
            if d not in emb.can_push:
                continue
            dr, dc = DIRECTIONS[d]
            # ahead footprint free of walls / other blocking cells
            ahead = [(r + dr, c + dc) for r, c in fp]
            if any(scene.is_wall(a) or (a in others) for a in ahead):
                continue
            for r, c in fp:
                behind = (r - dr, c - dc)
                if behind not in fp and behind in reach:
                    ok = True
                    break
            if ok:
                break
        if ok:
            out.append(o.object_id)
    return out


def enumerate_orders(scene: GridScene, emb: AgentProfile, k: int, max_orders: int = MAX_ORDERS):
    """All vanish-feasible orders of exactly k pushes that open the goal. -> (orders, complete)."""
    memo: dict[frozenset, set] = {}

    def reach_of(s: frozenset) -> set:
        r = memo.get(s)
        if r is None:
            r = vanish_reach(scene, s)
            memo[s] = r
        return r

    orders: list[tuple[int, ...]] = []
    complete = True

    def dfs(prefix: tuple[int, ...]):
        nonlocal complete
        if len(orders) >= max_orders:
            complete = False
            return
        s = frozenset(prefix)
        reach = reach_of(s)
        if len(prefix) == k:
            if scene.goal in reach:
                orders.append(prefix)
            return
        for i in enterable(scene, emb, s, reach):
            dfs(prefix + (i,))
            if len(orders) >= max_orders:
                complete = False
                return

    dfs(())
    return orders, complete


# --------------------------------------------------------------------------------------
# realisation: orders -> concrete targets


def _candidate_targets(env: GridEnv, object_id: int, max_candidates: int = MAX_CANDIDATES):
    """Feasible targets for the object from the CURRENT env state, nearest-first (BFS depth
    along the object path), goal-ward within a ring -- the legacy park_candidates rule."""
    feas = env.enumerate_targets(object_id)
    if not feas:
        return []
    cur = env.positions[object_id]
    goal = env.scene.goal
    gv = (goal[0] - cur[0], goal[1] - cur[1])

    def key(t):
        path = feas[t][0]
        goalward = (t[0] - cur[0]) * gv[0] + (t[1] - cur[1]) * gv[1]
        return (len(path), -goalward, t)

    out = [t for t in sorted(feas, key=key) if not set(env.scene.by_id(object_id).cells(t)) & {goal}]
    return out[:max_candidates]


def _lookahead_ok(env: GridEnv, pending: list[int]) -> bool:
    """With the env in its current (post-push) state, can the remaining objects still be
    entered in sequence (each vanishing after its push) and does the goal open at the end?"""
    scene = env.scene
    moved = frozenset(env.executed)
    positions = dict(env.positions)
    reach = vanish_reach(scene, moved, src=env.agent, positions=positions)
    for j in pending:
        if j not in enterable(scene, env.emb, moved, reach, positions=positions, candidates=[j]):
            return False
        moved = moved | {j}
        reach = vanish_reach(scene, moved, src=env.agent, positions=positions)
    return scene.goal in reach


def realize_order(scene: GridScene, emb: AgentProfile, order: tuple[int, ...],
                  max_realizations: int = MAX_REALIZATIONS_PER_ORDER,
                  branch: int = CANDIDATE_BRANCH) -> list[OraclePlan]:
    """Concrete plans for `order` (targets + agent path length), shortest first; [] if the
    order admits no feasible realisation under the bounded search."""
    found: list[OraclePlan] = []

    def rec(env: GridEnv, k: int, targets: list):
        if len(found) >= max_realizations:
            return
        if k == len(order):
            path = _final_walk(env)
            if path is not None:
                found.append(OraclePlan(list(order), list(targets), env.agent_path_length + path))
            return
        i = order[k]
        tried = 0
        for cand in _candidate_targets(env, i):
            sub = _clone(env)
            res = sub.apply(i, cand)
            if not res.success:
                continue
            if not _lookahead_ok(sub, list(order[k + 1:])):
                continue
            tried += 1
            rec(sub, k + 1, targets + [cand])
            if tried >= branch or len(found) >= max_realizations:
                return

    env = GridEnv(scene, emb)
    if len(order) == 0:
        path = _final_walk(env)
        return [OraclePlan([], [], path)] if path is not None else []
    rec(env, 0, [])
    found.sort(key=lambda p: (p.agent_path_length, p.targets))
    return found


def _final_walk(env: GridEnv):
    from experiments.exp1.environment import bfs_path
    p = bfs_path(env.scene.terrain, env.occupied(), env.agent, env.scene.goal)
    return None if p is None else len(p) - 1


def _clone(env: GridEnv) -> GridEnv:
    new = GridEnv.__new__(GridEnv)
    new.scene, new.emb = env.scene, env.emb
    new.agent_profile = env.agent_profile
    new.positions = dict(env.positions)
    new.agent = env.agent
    new.executed = list(env.executed)
    new.agent_trace = list(env.agent_trace)
    new.agent_path_length = env.agent_path_length
    return new


# --------------------------------------------------------------------------------------
# the oracle


def solve(scene: GridScene, emb: AgentProfile, max_orders: int = MAX_ORDERS,
          k_max: int | None = None) -> OracleResult:
    t0 = time.perf_counter()
    movable = [o.object_id for o in scene.objects if emb.can_move(o)]
    k_hi = len(movable) if k_max is None else min(k_max, len(movable))
    stats = {"orders_enumerated": 0, "orders_realized": 0}
    for k in range(0, k_hi + 1):
        cands, complete = enumerate_orders(scene, emb, k, max_orders=max_orders)
        stats["orders_enumerated"] += len(cands)
        plans: list[OraclePlan] = []
        for order in cands:
            r = realize_order(scene, emb, order)
            if r:
                plans.append(r[0])
        if plans:
            plans.sort(key=lambda p: (p.agent_path_length, p.order))
            stats["orders_realized"] = len(plans)
            stats["orders_unrealized_at_k_star"] = len(cands) - len(plans)
            stats["k_lower_bound_gap"] = 0
            stats["time_s"] = time.perf_counter() - t0
            used = {i for p in plans for i in p.order}
            # `complete` so far only says the ENUMERATION was not capped. realize_order is a
            # bounded search (MAX_REALIZATIONS_PER_ORDER, CANDIDATE_BRANCH), so an enumerated
            # order it fails to realise may be infeasible OR merely missed; we cannot tell
            # which, and the two are indistinguishable to Coverage@32's denominator. The set
            # is therefore certified complete only when every candidate at K* was realised.
            complete = bool(complete) and len(plans) == len(cands)
            return OracleResult(True, k, plans, complete, len(movable), movable,
                                [i for i in movable if i not in used], stats)
        if cands and not complete:
            # capped enumeration at this K with nothing realisable: we cannot certify K*
            stats["time_s"] = time.perf_counter() - t0
            return OracleResult(False, None, [], False, len(movable), movable, list(movable), stats)
    stats["time_s"] = time.perf_counter() - t0
    return OracleResult(False, None, [], True, len(movable), movable, list(movable), stats)


# --------------------------------------------------------------------------------------
# independent brute-force validator (small maps)


def brute_force(scene: GridScene, emb: AgentProfile, max_states: int = 200_000):
    """Joint-state search: layers of interaction count; every feasible move(object, target)
    from every state; each object at most once. -> (k_star or None, set(orders), complete).
    Uses only GridEnv (no vanish semantics, no heuristics) -- this is the ground truth the
    oracle is validated against in the unit tests."""
    env0 = GridEnv(scene, emb)
    if env0.goal_reachable():
        return 0, {()}, True
    # state key: (agent cell, tuple of positions); value: set of orders that reach it
    key0 = (env0.agent, tuple(sorted(env0.positions.items())))
    layer: dict[tuple, set] = {key0: {()}}
    envs: dict[tuple, GridEnv] = {key0: env0}
    n_states = 1
    for k in count(1):
        if not layer:
            return None, set(), True
        nxt: dict[tuple, set] = {}
        nenvs: dict[tuple, GridEnv] = {}
        hits: set = set()
        for key, orders in layer.items():
            env = envs[key]
            moved = set(env.executed)
            for o in scene.objects:
                if o.object_id in moved or not emb.can_move(o):
                    continue
                for tgt, (path, ic, comp) in env.enumerate_targets(o.object_id).items():
                    if set(o.cells(tgt)) & {scene.goal}:
                        continue
                    sub = _clone(env)
                    res = sub.apply(o.object_id, tgt)
                    if not res.success:
                        continue
                    new_orders = {ordr + (o.object_id,) for ordr in orders}
                    if sub.goal_reachable():
                        hits |= new_orders
                        continue
                    nk = (sub.agent, tuple(sorted(sub.positions.items())))
                    if nk in nxt:
                        nxt[nk] |= new_orders
                    else:
                        nxt[nk] = new_orders
                        nenvs[nk] = sub
                        n_states += 1
                        if n_states > max_states:
                            return None, set(), False
        if hits:
            return k, hits, True
        layer, envs = nxt, nenvs
        if k >= len(scene.objects):
            return None, set(), True


def order_distractors(result: OracleResult) -> list[int]:
    return list(result.distractors)
