"""Controlled B/C objective; historical PlanSlots loss remains unchanged.

All matched references receive flow supervision, averaged within scene. C adds
per-selected-coordinate FM cost to assignment only, with shared reference noise
and time across slots. The same samples are reused for differentiable training.
"""
from __future__ import annotations

import math
import torch
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment

from clear.model.clear import per_example_rank_loss
from experiments.exp1.planslots_model import GridPlanSlotsModel
from experiments.exp1.dataset import commit_order


def assign(cost, plan_mask):
    """Return one injective slot assignment per reference, separately per scene."""
    pairs = []
    for i in range(len(cost)):
        cols = torch.where(plan_mask[i])[0].cpu().numpy()
        if not len(cols):
            raise ValueError('each scene needs at least one reference (empty order is valid)')
        if len(cols) > cost.shape[1]:
            raise ValueError('more references than slots')
        rows, chosen = linear_sum_assignment(cost[i].detach().cpu().numpy()[:, cols])
        pairs.extend((i, int(k), int(cols[p])) for k, p in zip(rows, chosen))
    return pairs


def scene_mean(values, scene_ids, batch_size):
    sums = values.new_zeros(batch_size).index_add(0, scene_ids, values)
    counts = values.new_zeros(batch_size).index_add(0, scene_ids, torch.ones_like(values))
    if (counts == 0).any():
        raise ValueError('every scene must contribute a reference')
    return (sums / counts).mean()


class GridJointMatchingModel(GridPlanSlotsModel):
    def __init__(self, canvas_hw, *, matching_weight=1., matching_warmup=1000,
                 matching_ramp=4000, pair_chunk=64, **kwargs):
        if not math.isfinite(matching_weight) or matching_weight < 0:
            raise ValueError('matching_weight must be finite and nonnegative')
        if matching_warmup < 0 or matching_ramp < 1 or pair_chunk < 1:
            raise ValueError('invalid matching schedule/chunk')
        if kwargs.get('slot_flow', True) is not True:
            raise ValueError('controlled B/C requires slot-conditioned flow')
        super().__init__(canvas_hw, **kwargs)
        if self.max_plans > self.K:
            raise ValueError('reference cap cannot exceed number of slots')
        self.matching_weight = float(matching_weight)
        self.matching_warmup, self.matching_ramp = int(matching_warmup), int(matching_ramp)
        self.pair_chunk = int(pair_chunk)
        self.register_buffer('training_step', torch.zeros((), dtype=torch.long))

    def set_training_step(self, step):
        if step < 0:
            raise ValueError('nonnegative completed update count required')
        self.training_step.fill_(step)

    @property
    def refinement_weight(self):
        fraction = (int(self.training_step) - self.matching_warmup) / self.matching_ramp
        return self.matching_weight * min(1., max(0., fraction))

    def make_batch(self, examples, device='cpu', include_targets=True):
        if include_targets:
            for ex in examples:
                sup = getattr(ex, 'plan_supervision', {}) or {}
                orders = list(getattr(ex, 'valid_orders', []) or []) or list(sup) or list(ex.orders)
                for order in sorted(set(map(tuple, orders)))[:self.max_plans]:
                    if order and order not in sup:
                        raise ValueError('reference order lacks its own continuous targets')
            examples = [commit_order(ex, ex.orders[0]) for ex in examples]
        return super().make_batch(examples, device, include_targets)

    def _pair_flow(self, h, batch, pairs, noise, time):
        results = []
        for start in range(0, len(pairs), self.pair_chunk):
            idx = torch.tensor(pairs[start:start+self.pair_chunk], device=noise.device)
            bi, ki, pi = idx.unbind(-1)
            rank, mask = batch['plans'][bi, pi], batch['object_mask'][bi]
            selected = mask & (rank >= 0) & (rank < rank.shape[-1])
            target = batch['plan_targets'][bi, pi] * selected[..., None]
            eps, t = noise[bi, pi], time[bi, pi]
            mixed = (1-t[:, None, None])*eps + t[:, None, None]*target
            sub = {k: h[k][bi] for k in ('embodiment', 'scene', 'key_mask')}
            velocity = self.flow(h['modulated'][bi, ki], sub['embodiment'], sub['scene'],
                                 mixed, t, rank, selected, key_mask=self.flow_key_mask(sub, mask))
            squared = (velocity - (target-eps)).square() * selected[..., None]
            # Empty order contributes zero, still counted in the scene average.
            results.append(squared.sum((1, 2)) / (2*selected.sum(-1)).clamp_min(1))
        return torch.cat(results)

    def loss(self, batch, generator=None):
        h = self._encode(batch)
        mask, plans, pm = batch['object_mask'], batch['plans'], batch['plan_mask']
        b, n = mask.shape
        p = plans.shape[1]
        sel, mu, _ = self.decode_all(h)
        ranks = plans[:, None].expand(b, self.K, p, n).reshape(-1, n)
        masks = mask[:, None, None].expand(b, self.K, p, n).reshape(-1, n)
        selected = masks & (ranks >= 0)
        logits = sel[:, :, None].expand(b, self.K, p, n).reshape(-1, n)
        means = mu[:, :, None].expand(b, self.K, p, n).reshape(-1, n)
        selection = (F.binary_cross_entropy_with_logits(logits, selected.float(), reduction='none') * masks).sum(-1) / masks.sum(-1).clamp_min(1)
        sentinel = torch.where(selected, ranks, torch.full_like(ranks, n))
        valid = selected if self.rank_selected_only else masks
        discrete = (selection + per_example_rank_loss(means, sentinel, valid)).view(b, self.K, p)
        targets = batch['plan_targets']
        noise = torch.randn(targets.shape, device=targets.device, generator=generator)*self.flow.noise_std
        time = torch.rand((b, p), device=targets.device, generator=generator)
        weight = self.refinement_weight
        cost = discrete.detach().clone()
        if weight:
            all_pairs = [(i, k, j) for i in range(b) for k in range(self.K) for j in range(p) if pm[i, j]]
            with torch.no_grad():
                flow_cost = self._pair_flow(h, batch, all_pairs, noise, time)
                idx = torch.tensor(all_pairs, device=cost.device)
                cost[idx[:, 0], idx[:, 1], idx[:, 2]] += weight*flow_cost
        pairs = assign(cost, pm)
        idx = torch.tensor(pairs, device=cost.device)
        bi, ki, pi = idx.unbind(-1)
        matched = torch.zeros_like(h['prior_logits'])
        matched[bi, ki] = 1
        parts = dict(cover=scene_mean(discrete[bi, ki, pi], bi, b),
                     flow=scene_mean(self._pair_flow(h, batch, pairs, noise, time), bi, b),
                     prior=F.binary_cross_entropy_with_logits(h['prior_logits'], matched))
        aff = h['interaction_affordance_logits']
        parts['affordance'] = F.binary_cross_entropy_with_logits(aff[mask], batch['affordance_target'][mask]) if mask.any() else aff.sum()*0
        total = parts['cover'] + parts['flow'] + self.prior_weight*parts['prior'] + parts['affordance']
        stats = {k: float(v.detach()) for k, v in parts.items()}
        baseline = {(i, p): k for i, k, p in assign(discrete, pm)}
        stats.update(refinement_weight=weight,
                     assignment_changed=sum(baseline[i, p] != k for i, k, p in pairs) / len(pairs))
        return total, stats
