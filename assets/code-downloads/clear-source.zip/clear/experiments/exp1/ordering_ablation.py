"""Frozen-v5 permutation-only evaluation; preserve native RNG, flow and voting."""
import argparse,hashlib,json,time,subprocess
from pathlib import Path
import numpy as np
import torch
from experiments.common.manifests import read_manifests
from experiments.exp1.dataset import scene_from_manifest, agent_from_manifest
from experiments.exp1.environment import execute_plan
from experiments.exp1.evaluator import ClearPlanner, make_planner, evaluate_scene, environment_txt
from experiments.exp1.structural_confirmation import verify_release
from experiments.exp1.structural_training import sha

STUDY=Path('experiments/exp1/studies/ordering_ablation_20260913')
ROOT=Path('runs/exp1_scratch/ordering_ablation_20260913')
RELEASE=Path('experiments/exp1/configs/structural_release.json')

def tensor_hash(x):return hashlib.sha256(x.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
def permutation_seed(scene_id,seed,mode,index):
 payload=json.dumps(['exp1_ordering_ablation_v1',scene_id,int(seed),mode,int(index)],ensure_ascii=False,separators=(',',':')).encode()
 return int.from_bytes(hashlib.blake2b(payload,digest_size=8).digest(),'little')
def permute(order,scene,scene_id,seed,mode,index,condition):
 canonical=sorted(order)
 if len(set(canonical))!=len(canonical):raise ValueError('duplicate object')
 if condition=='native':return tuple(order)
 if condition=='random':return tuple(int(j) for j in np.random.default_rng(permutation_seed(scene_id,seed,mode,index)).permutation(canonical))
 if condition!='heuristic':raise ValueError(condition)
 r,c=scene.start
 return tuple(sorted(canonical,key=lambda j:(abs(scene.objects[j].cell[0]-r)+abs(scene.objects[j].cell[1]-c),*scene.objects[j].cell,scene.objects[j].object_id)))

class OrderingPlanner(ClearPlanner):
 def _order(self,batch,model,mu,sigma,prob):
  original=super()._order(batch,model,mu,sigma,prob)
  mode='distribution' if self.sampling else 'point';index=self.draw_index if self.sampling else -1
  order=permute(original,self.observation.scene,self.observation.scene_id,self.training_seed,mode,index,self.condition)
  assert sorted(order)==sorted(original)
  self.trace=dict(native_order=list(original),order=list(order),subset=sorted(order),mode=mode,sample_index=index,
                  permutation_seed=permutation_seed(self.observation.scene_id,self.training_seed,mode,index),
                  priority_hashes=[tensor_hash(x) for x in (mu,sigma,prob)],noise=None)
  return order
 def predict(self,observation,agent):
  self.observation=observation
  return super().predict(observation,agent)

def instrument(planner):
 """Observe actual first flow input; cloned generator never consumes the live stream."""
 original=planner.model.generate_targets
 def generated(h,batch,rank,selected,steps=30,generator=None):
  clone=torch.Generator(device=rank.device);clone.set_state(generator.get_state())
  state=tensor_hash(generator.get_state());shape=(*h['objects'].shape[:2],planner.model.flow.target_dim)
  noise=torch.randn(shape,device=rank.device,generator=clone)
  active=selected[...,None]&batch.get('target_code_mask',torch.ones(shape,dtype=torch.bool,device=rank.device))
  expected=torch.where(active,noise,torch.zeros_like(noise));calls=[0]
  def hook(module,args):
   if calls[0]==0:assert torch.equal(args[3],expected),'actual initial flow noise mismatch'
   calls[0]+=1
  handle=planner.model.flow.register_forward_pre_hook(hook)
  try:result=original(h,batch,rank,selected,steps,generator)
  finally:handle.remove()
  assert calls[0]==steps
  planner.trace['noise']=dict(shape=list(shape),sha256=tensor_hash(noise),rng_state_sha256=state,
                             object_sha256=[tensor_hash(noise[:,j,:]) for j in range(shape[1])],values=noise.cpu().tolist(),
                             encoder_objects_sha256=tensor_hash(h['objects']),rank=rank.cpu().tolist(),flow_calls=calls[0])
  return result
 planner.model.generate_targets=generated

def planner_for(arm,seed,device,wrapped=True):
 r=json.loads(RELEASE.read_text());spec=r['arms'][arm]
 p=make_planner(spec['method'],spec['checkpoints'][str(seed)]['path'],device=device,**spec['inference'])
 if arm=='clear' and wrapped:
  p.__class__=OrderingPlanner;p.condition='native';p.training_seed=seed;instrument(p)
 return p

def verify_protocol():
 p=STUDY/'protocol.json';reg=json.loads(p.read_text());verify_release(json.loads(RELEASE.read_text()))
 for f,h in reg['hashes'].items():assert sha(f)==h,f
 return reg

def freeze():
 STUDY.mkdir(parents=True,exist_ok=True);ROOT.mkdir(parents=True,exist_ok=True)
 release=json.loads(RELEASE.read_text());verify_release(release)
 assert release['splits']['original_fresh']['sha256']=='740d9ac9d041738b74028772670d9e4b6afd975b29a90a78d84d15020d8538c8'
 hashes={str(RELEASE):sha(RELEASE),__file__:sha(__file__)}
 for p,h in release['code_sha256'].items():hashes[p]=h
 for arm in ['clear','autoregressive','gumbel_sinkhorn','polynet']:
  for v in release['arms'][arm]['checkpoints'].values():hashes[v['path']]=v['sha256']
 spec=release['splits']['original_fresh'];hashes[spec['path']]=spec['sha256']
 reg=dict(study='ordering_ablation_20260913',created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),hashes=hashes,split=spec,
 conditions=['native','random','heuristic'],training_seeds=list(range(5)),evaluation_seed=0,final_plans=111000,
 point_draws=4,distribution_draws=32,flow_steps=30,heuristic='static Manhattan distance from initial agent; tie (distance,row,col,object_id)',
 permutation_rng='JSON UTF8 compact separators, ensure_ascii=False; BLAKE2b digest_size=8, little-endian unsigned integer; numpy.default_rng; canonical sorted object indices',
 primary=['native-random:task_success','native-heuristic:task_success'],statistics='5000 paired crossed train-seed/base-scene bootstrap stratified by family, seed=1313; pointwise95% CI and Bonferroni97.5% for two primary contrasts; other metrics secondary',
 historical_reproduction='full native vs unmodified planner parity; compare historical recoverable scene metrics. If any historical discrepancy, re-evaluate all three baselines and publish six-row same-runtime table; retain historical cohort',
 no_training=True,role='post-confirmation inference ablation on historical original_fresh scenes; no model/heuristic selection',environment=environment_txt())
 with (STUDY/'protocol.json').open('x') as f:json.dump(reg,f,indent=2)
 print('Frozen protocol',sha(STUDY/'protocol.json'))

def run(condition,seed,device,limit=None):
 reg=verify_protocol();arm='clear' if condition in reg['conditions'] else condition
 if condition in ('random','heuristic') and limit is None:
  assert (STUDY/'NATIVE_GATE.json').is_file(),'native gate required'
 out=ROOT/('development' if limit else 'final')/f'{condition}_seed{seed}'
 out.mkdir(parents=True,exist_ok=False)
 p=planner_for(arm,seed,device);wrapped=arm=='clear'
 if wrapped:p.condition=condition
 manifests=read_manifests(reg['split']['path'])
 if limit:
  # Fixed prefix from each family, development parity only; never a model-selection score.
  families=sorted({m.scene_family for m in manifests});manifests=[m for family in families for m in [x for x in manifests if x.scene_family==family][:limit]]
 historical={x['scene_id']:x for x in map(json.loads,(Path(json.loads(RELEASE.read_text())['output_root'])/'original_fresh'/f'{arm}_seed{seed}'/'trial_metrics.jsonl').read_text().splitlines())}
 original=planner_for(arm,seed,device,False) if condition=='native' else None
 predictions=[];reference=[]
 def logged(obs,agent):
  pred=raw_predict(obs,agent);predictions.append((pred,json.loads(json.dumps(p.trace)) if wrapped else None));return pred
 raw_predict=p.predict;p.predict=logged
 if original:
  op=original.predict
  def logged_reference(obs,agent):
   pred=op(obs,agent);reference.append(pred);return pred
  original.predict=logged_reference
 start=time.monotonic();count=0;differences=[]
 identity=dict(condition=condition,seed=seed,device=device,protocol_sha256=sha(STUDY/'protocol.json'),environment=environment_txt())
 (out/'run.json').write_text(json.dumps(identity,indent=2)+'\n')
 with (out/'trials.jsonl').open('x') as trial,(out/'predictions.jsonl').open('x') as raw:
  for i,m in enumerate(manifests):
   predictions.clear();reference.clear();rec,art=evaluate_scene(p,m,i,0,seed,32,True)
   r=json.loads(rec.to_json());r['condition']=condition;r['minimal_success']=int(rec.task_success and len(rec.executed_order)==m.oracle.min_interactions)
   assert r['minimal_success']<=rec.task_success
   if original:
    ref,_=evaluate_scene(original,m,i,0,seed,32,True)
    assert len(predictions)==len(reference)
    for (a,_),b in zip(predictions,reference):assert a.object_ids==b.object_ids and a.target_configurations==b.target_configurations,'wrapper parity failed'
    rr=json.loads(ref.to_json())
    for k in ('predicted_order','executed_order','task_success','failure_type','order_hit','coverage_at_32','invalid_sample_rate_at_32'):assert r[k]==rr[k],k
   for k in ('predicted_order','executed_order','task_success','failure_type','order_hit','coverage_at_32','invalid_sample_rate_at_32'):
    if r[k]!=historical[m.scene_id][k]:differences.append(dict(scene_id=m.scene_id,metric=k,old=historical[m.scene_id][k],new=r[k]))
   scene,agent=scene_from_manifest(m),agent_from_manifest(m);flags=[]
   for j,(pred,trace) in enumerate(predictions):
    oc=execute_plan(scene,agent,pred.object_ids,pred.target_configurations)
    if j==0:assert oc.success==rec.task_success and oc.executed_order==rec.executed_order
    else:flags.append(oc.success)
    raw.write(json.dumps(dict(scene_id=m.scene_id,training_seed=seed,condition=condition,sample_index=j-1,prediction=pred.to_dict(),trace=trace,
                             success=oc.success,executed_order=oc.executed_order,failure_type=oc.failure_type,k_star=m.oracle.min_interactions))+'\n');count+=1
   if r['coverage_at_32'] is not None:assert len(flags)==32 and 1-sum(flags)/32==r['invalid_sample_rate_at_32']
   else:assert not flags
   trial.write(json.dumps(r)+'\n');trial.flush();raw.flush()
   if (i+1)%25==0:print(condition,seed,i+1,round(time.monotonic()-start),flush=True)
 verify_protocol()
 done=dict(identity,n_scenes=len(manifests),n_plans=count,wrapper_parity_plans=count if original else 0,
           historical_difference_count=len(differences),trials_sha256=sha(out/'trials.jsonl'),predictions_sha256=sha(out/'predictions.jsonl'),elapsed_s=time.monotonic()-start)
 (out/'historical_differences.json').write_text(json.dumps(differences,indent=2)+'\n')
 (out/'DONE.json').write_text(json.dumps(done,indent=2)+'\n');print('DONE',condition,seed,count,len(differences),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['freeze','run']);p.add_argument('--condition');p.add_argument('--seed',type=int);p.add_argument('--device',default='cpu');p.add_argument('--limit',type=int);a=p.parse_args()
 if a.command=='freeze':freeze()
 else:run(a.condition,a.seed,a.device,a.limit)
