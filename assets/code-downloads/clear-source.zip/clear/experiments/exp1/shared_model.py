"""Grid adapter for CLEAR's affordance / ordering / causal-flow architecture."""
import numpy as np
import torch

from clear.model.clear import AffordanceConditionedCore
from clear.model.encoders import SceneEncoder, SCENE_CHANS
from experiments.exp1.environment import AgentProfile, DIRECTIONS, GridEnv, flood_fill

ARCHITECTURE = 'clear-affordance-order-causal-v1'
OBJECT_DIM = 12


class GridAffordanceFlowModel(AffordanceConditionedCore):
    is_shared_affordance = True

    def __init__(self, canvas_hw, dim=128, depth=4, heads=4, causal=True, target_scale=None,
                 push_reachability=False, rank_selected_only=False, cardinality_weight=0., goal_blocked=False,
                 abstract_predicates=False):
        self.canvas_hw = tuple(canvas_hw)
        self.push_reachability = bool(push_reachability)
        self.goal_blocked = bool(goal_blocked)
        self.abstract_predicates = bool(abstract_predicates)   # WP-R: 4 per-object predicates from the abstraction
        if self.goal_blocked and not self.push_reachability:
            raise ValueError('goal_blocked requires push_reachability features')
        self.rank_selected_only = bool(rank_selected_only)
        if not np.isfinite(cardinality_weight) or cardinality_weight < 0:
            raise ValueError('cardinality_weight must be finite and nonnegative')
        self.cardinality_weight = float(cardinality_weight)
        object_dim = OBJECT_DIM + 4 * self.push_reachability + self.goal_blocked + 4 * self.abstract_predicates
        # Cells per unit of target code. None keeps the original canvas normalisation, under
        # which a 1-3 cell push becomes a code of std 0.028 against the flow's N(0, 1) prior:
        # the flow then has to land within 0.0156 -- a 64th of the prior's scale -- to round to
        # the right cell. A scale of a couple of cells puts the code back on the prior's scale.
        self.target_scale = None if target_scale is None else float(target_scale)
        h, w = self.canvas_hw
        super().__init__(dim, object_dim, None, 6, 2,
                         object_dim + (SCENE_CHANS + 1) * h * w, depth, heads, causal=causal)
        self.scene_encoder = SceneEncoder(dim, self.canvas_hw)

    def _encode(self, batch):
        return super()._encode(dict(batch, scene_tokens=self.scene_encoder(batch['grid'])))

    def forward(self, batch):
        return self.loss(batch)

    def code_scale(self):
        """(x, y) cells per unit of target code; must match `collate`."""
        height, width = self.canvas_hw
        return [width, height] if self.target_scale is None else [self.target_scale, self.target_scale]

    def make_batch(self, examples, device='cpu', include_targets=True):
        return collate(examples, self.canvas_hw, device, include_targets, self.target_scale,
                       self.push_reachability, self.goal_blocked, self.abstract_predicates)

    @torch.no_grad()
    def sample_targets(self, batch, order, steps=30, generator=None, h=None, draws=1):
        """-> (draws, n, 2) target cells in grid coordinates.

        `draws > 1` integrates independent noise draws as extra batch rows, so K draws cost
        the same `steps` sequential flow evaluations as one, only wider.
        """
        h = self._encode(batch) if h is None else h
        rank = torch.full_like(batch['object_mask'], -1, dtype=torch.long)
        if order:
            rank[0, list(order)] = torch.arange(len(order), device=rank.device)
        if draws > 1:
            if batch['object_mask'].shape[0] != 1:
                # `expand` only widens rows that are already singleton; with several scenes in
                # the batch some tensors would widen and others would not, silently mixing
                # scenes into one another's draws.
                raise ValueError('draws > 1 samples targets for one scene at a time')
            expand = lambda v: v.expand(draws, *v.shape[1:]) if torch.is_tensor(v) and v.shape[0] == 1 else v
            h = {k: expand(v) for k, v in h.items()}
            batch = {k: expand(v) for k, v in batch.items()}
            rank = rank.expand(draws, *rank.shape[1:])
        code = self.generate_targets(h, batch, rank, rank >= 0, steps, generator)
        return batch['x0'] + code * code.new_tensor(self.code_scale())


def collate(examples, canvas_hw, device='cpu', include_targets=True, target_scale=None,
            push_reachability=False, goal_blocked=False, abstract_predicates=False):
    if not examples:
        raise ValueError('nonempty grid batch required')
    h, w = canvas_hw
    object_dim = OBJECT_DIM + 4 * bool(push_reachability) + bool(goal_blocked) + 4 * bool(abstract_predicates)
    code_scale = [w, h] if target_scale is None else [float(target_scale), float(target_scale)]
    b, n = len(examples), max(1, max(len(ex.x0) for ex in examples))
    arrays = dict(object_features=np.zeros((b, n, object_dim), np.float32),
                  object_mask=np.zeros((b, n), bool),
                  structure=np.zeros((b, 1, 6), np.float32), structure_mask=np.ones((b, 1), bool),
                  grid=np.stack([ex.grid for ex in examples]).astype(np.float32),
                  x0=np.zeros((b, n, 2), np.float32),
                  affordance_features=np.zeros((b, n, object_dim + (SCENE_CHANS + 1) * h * w), np.float32))
    if include_targets:
        arrays.update(rank=np.full((b, n), -1, np.int64), target_code=np.zeros((b, n, 2), np.float32),
                      affordance_target=np.zeros((b, n), np.float32))
    for k, ex in enumerate(examples):
        if not hasattr(ex, 'grid_scene') or not hasattr(ex, 'public_agent'):
            raise ValueError('grid observation metadata required; use the updated dataset adapter')
        scene, agent = ex.grid_scene, ex.public_agent
        arrays['structure'][k, 0] = agent.structure.vector()
        occupancy = np.zeros((h, w), np.float32)
        for obj in scene.objects:
            for r, c in obj.cells():
                occupancy[r, c] = 1
        geometry = np.concatenate([ex.grid, occupancy[None]], axis=0).reshape(-1)
        if push_reachability or goal_blocked:
            # Observation-only first-push access, not a feasibility/selection mask: a later
            # object may become accessible after a predecessor moves. No rollout or labels.
            blocked = {cell for obj in scene.objects for cell in obj.cells()}
            reach = flood_fill(scene.terrain, blocked, scene.start)
        if include_targets:
            env = GridEnv(scene, AgentProfile(agent.agent_id, agent.structure, agent.can_push))
        for i, obj in enumerate(scene.objects):
            r, c = obj.cell
            footprint = np.asarray(obj.footprint)
            row = [c / w, r / h, 0., 1., obj.mass / 20., obj.extent,
                   (np.ptp(footprint[:, 0]) + 1) / h, (np.ptp(footprint[:, 1]) + 1) / w,
                   *[float(d in obj.pushable_directions) for d in DIRECTIONS]]
            if push_reachability:
                row.extend(float(d in obj.pushable_directions and d in agent.can_push and
                                 any((rr - dr, cc - dc) in reach for rr, cc in obj.cells()))
                           for d, (dr, dc) in DIRECTIONS.items())
            if goal_blocked:
                row.append(float(scene.goal not in reach))
            if abstract_predicates:
                from experiments.exp1.abstraction import cached_object_predicates
                row.extend(cached_object_predicates(
                    scene, AgentProfile(agent.agent_id, agent.structure, tuple(agent.can_push)))[i])
            arrays['object_features'][k, i] = row
            arrays['object_mask'][k, i] = True
            arrays['x0'][k, i] = [c, r]
            arrays['affordance_features'][k, i] = np.concatenate([row, geometry])
            if include_targets:
                arrays['affordance_target'][k, i] = any(
                    env.check_move(obj.object_id, (r + dr, c + dc)).ok
                    for dr, dc in DIRECTIONS.values())
        if include_targets:
            if len(ex.orders) != 1:
                raise ValueError('commit one reference order before forming a training batch')
            for rank, i in enumerate(ex.orders[0]):
                arrays['rank'][k, i] = rank
                arrays['target_code'][k, i] = (ex.x1[i, :2] - ex.x0[i, :2]) / code_scale
    return {key: torch.as_tensor(value, device=device) for key, value in arrays.items()}
