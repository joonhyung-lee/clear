"""Experiment 01 -- Controlled Interaction Ordering in 2D Grid Scenes (exp_v2/01_exp_2d_grid.md).

Package layout (spec section 11):
  environment.py  discrete grid world with one fixed abstract agent and constant interaction rules.
  generator.py    five ordering-focused scene families from topology templates, template-level split.
  oracle.py       exact minimum-interaction oracle with complete optimal-set enumeration.
  dataset.py      manifests -> pamo `Example`s for training CLEAR / the autoregressive baseline.
  evaluator.py    planners (oracle, clear, clear_mean, autoregressive) + the shared evaluator.
  metrics.py      task success, order hit, successful-plan regret, and order coverage.
  render.py       rule-selected qualitative panels.
  cli.py          generate_dataset / label_with_oracle / train / evaluate / aggregate / render_qualitative.
"""
