"""Exp4 joint adaptation from the warm5000 seed-0 checkpoint (matched full / no-mask).

Same objective, optimizer, schedule, sampler budget and traversal supervision as
experiments.exp3.trajectory_v3.shared_cli.train; the only additions are (1) the declared
minibatch mixture Exp3 50% / Exp4 initial 25% / Exp4 intermediate+repair 25% with logged draw
counts, (2) an explicit no-mask initialization artifact (same tensors, config.causal=false),
and (3) affordance warmup fixed to 0 (the parent already completed its 5000-step warmup).
"""
import argparse
import json
import math
import platform
import time
from collections import Counter
from pathlib import Path

import torch

from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.cli import read_jsonl
from experiments.exp3.trajectory_v3.data import collate
from experiments.exp3.trajectory_v3.navigation_cache import GeometryCache
from experiments.exp3.trajectory_v3.shared_cli import add_current_navigation, evaluate, make_navigator, sample_training_indices, validate_training_data
from experiments.exp3.trajectory_v3.shared_morphology import SHARED_SCHEMA, SharedMorphologyModel, attach_probe_scenes, checkpoint_record, collate_probes, load_shared_checkpoint
from experiments.exp3.trajectory_v3.training_state import atomic_save, file_hash, learning_rate, source_revision

MIXTURE = dict(exp3=8, exp4_initial=4, exp4_adaptive=4)   # of a 16-row batch


def group_of(row, repair_balanced=False):
    g = row.get("group")
    if g is None:
        return "exp3"
    if repair_balanced:
        return g
    return "exp4_initial" if g == "exp4_initial" else "exp4_adaptive"


def build_nomask_init(parent_checkpoint, out, device="cpu"):
    """Copy the parent's tensors into a causal=false model; record both identities."""
    parent, record = load_shared_checkpoint(parent_checkpoint, device)
    config = dict(parent.config); config["causal"] = False
    model = SharedMorphologyModel(**config).to(device)
    model.load_state_dict(parent.state_dict(), strict=True)
    artifact = checkpoint_record(model, record["controller_profiles"], record["navigation"], step=0, seed=record.get("seed"),
                                 training_mode="nomask_initialization_copy", parent_checkpoint=str(parent_checkpoint),
                                 parent_sha256=file_hash(parent_checkpoint), scope="identical tensors; only config.causal differs")
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    atomic_save(artifact, out)
    same = all(torch.equal(a, b) for a, b in zip(parent.state_dict().values(), model.state_dict().values()))
    return dict(path=str(out), sha256=file_hash(out), tensors_identical=bool(same), config_diff=["causal"])


def train(args):
    mixture = dict(exp3=8, exp4_initial=2, exp4_intermediate=2, exp4_repair=4) if args.repair_balanced else MIXTURE
    config = json.loads(Path(args.config).read_text())
    settings, navigation = config["train"], config["navigation"]
    settings["steps"] = int(args.steps)
    settings["affordance_warmup_steps"] = 0
    rows, probes = read_jsonl(args.data), read_jsonl(args.probes)
    rows, profiles, summary = validate_training_data(rows, probes, config)
    if not args.allow_geometric_teacher and any(r["teacher"]["validation"] == "geometric" for r in rows):
        raise ValueError("geometric teachers require --allow-geometric-teacher")
    training = [r for r in rows if r["split"] == "train"]
    validation = [r for r in rows if r["split"] == "val"]
    probe_train = [p for p in probes if p["split"] == "train"]
    probe_val = [p for p in probes if p["split"] == "val"]
    groups = {g: [i for i, r in enumerate(training) if group_of(r, args.repair_balanced) == g] for g in mixture}
    if any(not v for v in groups.values()):
        raise ValueError("every mixture group needs training rows: " + str({k: len(v) for k, v in groups.items()}))
    if sum(mixture.values()) != settings["batch_size"]:
        raise ValueError("mixture must sum to the batch size")
    exp3_bodies = {}
    for i in groups["exp3"]:
        exp3_bodies.setdefault(training[i]["body_id"], []).append(i)
    out = Path(args.out)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError("training output must be empty")
    out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(int(settings.get("cpu_threads", 2)))
    torch.manual_seed(args.seed)
    model = SharedMorphologyModel(**config["model"]).to(args.device)
    initial_model, initial_record = load_shared_checkpoint(args.init_checkpoint, args.device)
    if initial_model.config != model.config or initial_record["controller_profiles"] != profiles:
        raise ValueError("adaptation requires the same model architecture and frozen-controller profiles")
    model.load_state_dict(initial_model.state_dict(), strict=True)
    initialization = dict(checkpoint=str(args.init_checkpoint), checkpoint_sha256=file_hash(args.init_checkpoint),
                          step=initial_record.get("step"), training_mode=initial_record.get("training_mode"), optimizer="fresh")
    del initial_model
    optimizer = torch.optim.AdamW(model.parameters(), lr=settings["lr"], weight_decay=settings.get("weight_decay", .01))
    generator = torch.Generator(device=args.device).manual_seed(args.seed)
    sampling = torch.Generator().manual_seed(args.seed)
    geometry_cache = GeometryCache(settings.get("geometry_cache_size", 512))
    learning_rate(settings, 1)
    weight = float(settings["affordance_weight"])
    identity = dict(config=config, seed=args.seed, data_hash=digest(rows), probe_hash=digest(probes), mixture=mixture,
                    input_hashes=dict(data=file_hash(args.data), probes=file_hash(args.probes)), initialization=initialization)
    if model.traversal_head == "encoder":
        attach_probe_scenes(probes, model.config.get("scene_dim", 9))
    report = dict(schema=SHARED_SCHEMA, architecture="shared_morphology", dataset=summary, **identity,
                  group_rows={g: len(v) for g, v in groups.items()}, exp3_body_rows={b: len(v) for b, v in exp3_bodies.items()},
                  parameter_count=sum(p.numel() for p in model.parameters()), code=source_revision(),
                  teacher_provenance=dict(Counter(r["teacher"].get("proxy", r["teacher"]["validation"]) for r in training)),
                  environment=dict(python=platform.python_version(), torch=str(torch.__version__), cuda=torch.version.cuda, device=str(args.device)),
                  navigation_context="recomputed before every optimizer step and validation", affordance_warmup_steps=0,
                  status="training_in_progress; physical performance not evaluated")
    (out / "training.json").write_text(json.dumps(report, indent=2) + "\n")
    scene_dim = model.config.get("scene_dim", 9)
    full = collate(training, model.config["waypoints"], args.device, scene_dim=scene_dim)
    val_batches = [collate(validation[i:i + settings["batch_size"]], model.config["waypoints"], args.device, scene_dim=scene_dim)
                   for i in range(0, len(validation), settings["batch_size"])]
    draws = Counter(); body_draws = Counter(); history = []; started = time.perf_counter()

    def draw_batch():
        indices = []
        per_body = mixture["exp3"] // len(exp3_bodies)
        for body in sorted(exp3_bodies):
            pool = exp3_bodies[body]
            indices.extend(pool[i] for i in torch.randint(len(pool), (per_body,), generator=sampling).tolist())
        for g in mixture:
            if g == "exp3":
                continue
            pool = groups[g]
            indices.extend(pool[i] for i in torch.randint(len(pool), (mixture[g],), generator=sampling).tolist())
        order = torch.randperm(len(indices), generator=sampling).tolist()
        return [indices[i] for i in order]

    def snapshot(step, **metadata):
        return checkpoint_record(model, profiles, navigation, step=step, seed=args.seed, training_mode="exp4_joint_adaptation",
                                 config=config, mixture=mixture, draw_counts=dict(draws), body_draw_counts=dict(body_draws),
                                 initialization=initialization, environment=report["environment"], code=report["code"], **metadata)

    for step in range(1, settings["steps"] + 1):
        lr = learning_rate(settings, step)
        for group in optimizer.param_groups:
            group["lr"] = lr
        indices = draw_batch()
        for i in indices:
            draws[group_of(training[i], args.repair_balanced)] += 1; body_draws[training[i]["body_id"]] += 1
        probe_indices = sample_training_indices(probe_train, settings["probe_batch_size"], sampling, settings.get("balance_bodies", False))
        model.eval()
        navigator = make_navigator(model, profiles, navigation, geometry_cache)
        static = {k: v[indices] for k, v in full.items()}
        batch = add_current_navigation(static, [training[i] for i in indices], navigator)
        probe_batch = collate_probes([probe_train[i] for i in probe_indices], args.device)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss, terms = model.joint_loss(batch, probe_batch, generator, weight)
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite shared training loss")
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        optimizer.step()
        if step % 20 == 0 or step == 1:
            print(json.dumps(dict(event="step", step=step, loss=float(loss.detach()), terms=terms, lr=lr, grad_norm=float(grad_norm),
                                  elapsed_s=time.perf_counter() - started, s_per_step=(time.perf_counter() - started) / step)), flush=True)
        if step % settings["eval_every"] == 0 or step == settings["steps"]:
            score, val_terms = evaluate(model, validation, probe_val, profiles, navigation, settings["batch_size"], weight, args.device, geometry_cache, val_batches)
            if not math.isfinite(score):
                raise FloatingPointError("non-finite validation loss")
            history.append(dict(step=step, train_loss=float(loss.detach()), train_terms=terms, validation_loss=score, validation_terms=val_terms,
                                lr=lr, grad_norm=float(grad_norm), elapsed_s=time.perf_counter() - started, draws=dict(draws), body_draws=dict(body_draws)))
            print(json.dumps(history[-1]), flush=True)
            record = snapshot(step, phase="joint", validation_loss=score, validation_terms=val_terms)
            atomic_save(record, out / "last.pt")
            if settings.get("keep_every") and step % settings["keep_every"] == 0:
                atomic_save(record, out / f"step_{step:06d}.pt")
            (out / "loss.json").write_text(json.dumps(history, indent=2) + "\n")
    report.update(completed_steps=settings["steps"], plan_examples_seen=settings["steps"] * settings["batch_size"], draw_counts=dict(draws),
                  body_draw_counts=dict(body_draws), final_validation_loss=history[-1]["validation_loss"], elapsed_s=time.perf_counter() - started,
                  selection_rule="fixed last step; validation is a finiteness/plumbing check, never checkpoint selection",
                  last_sha256=file_hash(out / "last.pt"), status="training_completed; physical performance not evaluated")
    (out / "training.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    t = sub.add_parser("train")
    t.add_argument("--data", required=True); t.add_argument("--probes", required=True); t.add_argument("--config", required=True)
    t.add_argument("--init-checkpoint", required=True); t.add_argument("--out", required=True); t.add_argument("--device", default="cuda:0")
    t.add_argument("--seed", type=int, default=0); t.add_argument("--steps", type=int, required=True)
    t.add_argument("--allow-geometric-teacher", action="store_true")
    t.add_argument("--repair-balanced", action="store_true", help="development fine-tune: batch mixture Exp3/initial/intermediate/repair = 8/2/2/4")
    n = sub.add_parser("nomask-init")
    n.add_argument("--parent", required=True); n.add_argument("--out", required=True)
    a = p.parse_args()
    if a.command == "train":
        print(json.dumps({k: v for k, v in train(a).items() if k in ("completed_steps", "draw_counts", "body_draw_counts", "final_validation_loss", "elapsed_s", "last_sha256")}))
    else:
        print(json.dumps(build_nomask_init(a.parent, a.out)))


if __name__ == "__main__":
    main()
