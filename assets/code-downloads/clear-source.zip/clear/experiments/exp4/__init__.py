"""Experiment 04 -- Long-Horizon Interaction Robustness in MuJoCo (exp_v2/04_exp_maze_long_horizon.md).

Modules (spec section 16):
  world          grid Scene -> metric world (cells, footprints, fine occupancy), observation, point cloud
  generator      six long-horizon scene families, K* bins, manifests
  perturbations  five perturbation families x low/medium/high, deterministic from perturbation_seed
  controller     InteractionController implementations (CPU kinematic default; Spot/SUMO bridge stub)
  contact        shared contact-candidate prefilter + learned / uniform selectors
  model          CLEAR (PAMO) and CLEAR-Regression (endpoint head) with paired training
  planners       the four methods behind the common Planner interface (+ a privileged scripted oracle)
  evaluator      closed-loop episode runner, TrialRecord + replay sidecar
  metrics        the four headline metrics and aggregation
  replay         sidecar io
  render_*       the three qualitative panels (matplotlib only)
  cli            generate_dataset / label_with_oracle / train / evaluate / aggregate / render_qualitative
"""
