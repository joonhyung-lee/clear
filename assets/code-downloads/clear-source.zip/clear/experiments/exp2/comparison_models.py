"""Matched-observation controls; local adaptations, not published reproductions."""
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from experiments.exp2.model import SceneSequencerNet, build_model
from clear.model.clear import CLEARCore

ARMS = ('clear', 'bc', 'plan_bc', 'bc_shared', 'ar_bc', 'clear_nocausal', 'clear_regression', 'clear_noaffordance')
SCHEMA = 'scene-comparison-v2'


def suffix_sequence(rank):
    n = rank.shape[1]
    valid = (rank >= 0) & (rank < n)
    order = rank.masked_fill(~valid, n).argsort(dim=1, stable=True)
    length = valid.sum(1)
    slots = torch.arange(n, device=rank.device)[None]
    labels = torch.where(slots < length[:, None], order, n)
    labels = torch.cat([labels, torch.full_like(labels[:, :1], n)], 1)
    return labels, length


class ComparisonNet(SceneSequencerNet):
    def __init__(self, arm='ar_bc', dim=128, depth=4, heads=4, mu_scale=0.0, **kwargs):
        if arm not in ARMS or arm in ('bc', 'clear', 'plan_bc'):
            raise ValueError(arm)
        if arm == 'clear_nocausal':
            kwargs['causal'] = False
        if arm == 'clear_noaffordance':
            kwargs['no_affordance'] = True
        super().__init__(dim, depth, heads, mu_scale=mu_scale, **kwargs)
        self.arm = arm
        self.config['arm'] = arm
        if arm == 'clear_nocausal':
            self.flow.causal = False
        if arm in ('bc_shared', 'ar_bc', 'clear_regression'):
            del self.flow
        if arm in ('bc_shared', 'ar_bc'):
            del self.ordering
        if arm in ('bc_shared', 'clear_regression'):
            self.target_head = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, 3))
            nn.init.zeros_(self.target_head[-1].weight)
            nn.init.zeros_(self.target_head[-1].bias)
        if arm == 'bc_shared':
            self.choice_head = nn.Linear(dim, 1)
        if arm == 'ar_bc':
            self.bos = nn.Parameter(torch.zeros(dim))
            self.previous = nn.Linear(dim + 3, dim)
            self.position = nn.Embedding(6, dim)
            layer = nn.TransformerDecoderLayer(dim, heads, 4 * dim, dropout=0, batch_first=True)
            self.decoder = nn.TransformerDecoder(layer, depth)
            self.query = nn.Linear(dim, dim, bias=False)
            self.stop = nn.Linear(dim, 1)
            self.ar_target = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, 3))
            nn.init.zeros_(self.ar_target[-1].weight)
            nn.init.zeros_(self.ar_target[-1].bias)

    def independent_targets(self, h, batch):
        return self.target_codec(batch['object_features']) + self.flow_scale * self.target_head(h['objects'])

    def _encode(self, batch):
        if self.arm == 'clear_noaffordance':
            neutral = torch.zeros_like(batch['object_mask'], dtype=batch['object_features'].dtype)[..., None]
            h = CLEARCore._encode(self, dict(batch, navigation_features=neutral))
            if self.mu_scale:
                h['mu'] = torch.tanh(h['mu']) * self.mu_scale
            return h
        if self.arm not in ('bc_shared', 'ar_bc'):
            return super()._encode(batch)
        emb = self.encoder.structure_in.pool(batch['structure'], batch['structure_mask'])
        queries = batch['affordance_features']
        logits = self.interaction_affordance(emb[:, None].expand(-1, 5, -1), queries)
        h = self.encoder(dict(batch, navigation_features=logits.sigmoid()[..., None]))
        h['interaction_affordance_logits'] = logits
        return h

    def decode_prefix(self, h, ids, codes):
        b, k = ids.shape
        previous = h['objects'].gather(1, ids.clamp(max=4)[..., None].expand(-1, -1, h['objects'].shape[-1]))
        previous = self.previous(torch.cat([previous, codes], -1))
        x = torch.cat([self.bos[None, None].expand(b, 1, -1), previous], 1)
        x = x + self.position(torch.arange(k + 1, device=x.device))[None]
        mask = torch.ones(k + 1, k + 1, dtype=torch.bool, device=x.device).triu(1)
        z = self.decoder(x, h['tokens'], tgt_mask=mask)
        logits = torch.einsum('bkd,bnd->bkn', self.query(z), h['objects']) / z.shape[-1] ** .5
        used = torch.zeros(b, k + 1, 5, dtype=torch.bool, device=x.device)
        if k:
            used[:, 1:] = F.one_hot(ids.clamp(max=4), 5).bool().cumsum(1).bool()
        logits = logits.masked_fill(used, -1e9)
        return torch.cat([logits, self.stop(z)], -1), z

    def loss(self, object_features, rank, choice, target_code, *, plan_target_code, affordance_target):
        if self.arm in ('clear_nocausal',):
            return super().loss(object_features, rank, choice, target_code,
                                plan_target_code=plan_target_code, affordance_target=affordance_target)
        batch = self.batch(object_features)
        batch.update(rank=rank, target_code=plan_target_code)
        h = self._encode(batch)
        if self.arm == 'clear_noaffordance':
            parts = self.ordering.loss(h['selection'], h['mu'], h['sigma'], rank, batch['object_mask'])
            parts['kl'] = self.kl_weight * parts['kl']
            parts['flow'] = self.flow_weight * self.flow_loss(h, batch)
        else:
            parts = dict(affordance=F.binary_cross_entropy_with_logits(h['interaction_affordance_logits'], affordance_target))
            active = (rank >= 0)[..., None] & batch['target_code_mask']
            if self.arm == 'ar_bc':
                labels, length = suffix_sequence(rank)
                ids = labels[:, :-1]
                codes = plan_target_code.gather(1, ids.clamp(max=4)[..., None].expand(-1, -1, 3))
                codes = torch.where((ids < 5)[..., None], codes, torch.zeros_like(codes))
                logits, z = self.decode_prefix(h, ids, codes)
                valid = torch.arange(6, device=rank.device)[None] <= length[:, None]
                parts['sequence'] = F.cross_entropy(logits[valid], labels[valid])
                obj = h['objects'].gather(1, ids.clamp(max=4)[..., None].expand(-1, -1, z.shape[-1]))
                origin = self.target_codec(object_features).gather(1, ids.clamp(max=4)[..., None].expand(-1, -1, 3))
                predicted = origin + self.flow_scale * self.ar_target(torch.cat([z[:, :5], obj], -1))
                slots = batch['target_code_mask'].gather(1, ids.clamp(max=4)[..., None].expand(-1, -1, 3))
                slots = slots & (ids < 5)[..., None]
                parts['target'] = F.mse_loss(predicted[slots]/self.flow_scale, codes[slots]/self.flow_scale) if slots.any() else predicted.sum() * 0
                first = logits[:, 0, :5].softmax(-1)
            else:
                predicted = self.independent_targets(h, batch)
                parts['target'] = F.mse_loss(predicted[active]/self.flow_scale, plan_target_code[active]/self.flow_scale) if active.any() else predicted.sum() * 0
                if self.arm == 'bc_shared':
                    logits = self.choice_head(h['objects']).squeeze(-1)
                    parts['choice'] = F.cross_entropy(logits, choice)
                    first = logits.softmax(-1)
                else:
                    parts.update(self.ordering.loss(h['selection'], h['mu'], h['sigma'], rank, batch['object_mask']))
                    parts['kl'] = self.kl_weight * parts['kl']
                    first = torch.softmax(-h['mu'] + F.logsigmoid(h['selection']), -1)
            parts['availability'] = self.availability_weight * (first * (1 - affordance_target)).sum(-1).mean()
        total = sum(parts.values())
        return total, {k: float(v.detach()) for k, v in parts.items()}

    @torch.no_grad()
    def plan(self, object_features, generator=None, sample=False, steps=30):
        if object_features.shape[0] != 1:
            raise ValueError('one scene required')
        if self.arm == 'clear_nocausal':
            return super().plan(object_features, generator, sample, steps)
        batch = self.batch(object_features)
        h = self._encode(batch)
        if self.arm == 'bc_shared':
            order = self.choice_head(h['objects'])[0, :, 0].argsort(descending=True)
            codes = self.independent_targets(h, batch)[0]
            return [(int(i), codes[i].cpu().numpy()) for i in order]
        if self.arm == 'ar_bc':
            ids = torch.empty(1, 0, dtype=torch.long, device=object_features.device)
            codes = torch.empty(1, 0, 3, device=object_features.device)
            result = []
            for _ in range(5):
                logits, z = self.decode_prefix(h, ids, codes)
                i = (int(torch.multinomial(logits[0, -1].softmax(-1), 1, generator=generator))
                     if sample else int(logits[0, -1].argmax()))
                if i == 5:
                    break
                code = self.target_codec(object_features)[:, i] + self.flow_scale * self.ar_target(torch.cat([z[:, -1], h['objects'][:, i]], -1))
                code = code * batch['target_code_mask'][:, i]
                result.append((i, code[0].cpu().numpy()))
                ids = torch.cat([ids, ids.new_tensor([[i]])], 1)
                codes = torch.cat([codes, code[:, None]], 1)
            return result
        rank, selected = self.ordering.sample(h['selection'], h['mu'], h['sigma'], batch['object_mask'],
                                              generator=generator, sample_selection=sample)
        if self.arm == 'clear_regression':
            codes = self.independent_targets(h, batch) * batch['target_code_mask']
        else:
            codes = self.generate_targets(h, batch, rank, selected, steps, generator)
        order = sorted((int(rank[0, i]), i) for i in range(5) if selected[0, i])
        return [(i, codes[0, i].cpu().numpy()) for _, i in order]

    @torch.no_grad()
    def act(self, object_features, generator=None):
        plan = self.plan(object_features, generator=generator)
        return plan[0] if plan else (None, None)


def make_model(arm='clear', dim=128, depth=4, heads=4, mu_scale=0.0, **kwargs):
    cfg = dict(arm=arm, dim=dim, depth=depth, heads=heads, mu_scale=mu_scale, **kwargs)
    return build_model(**cfg) if arm in ('clear', 'bc', 'plan_bc') else ComparisonNet(**cfg)


def load_comparison(blob, arm):
    if arm in ('ivntr', 'chd'):
        from experiments.exp2.external_models import load_external
        if blob.get('model_config', {}).get('arm') != arm:
            raise ValueError('external checkpoint arm mismatch')
        return load_external(blob)
    if blob.get('schema') != SCHEMA or blob.get('model_config', {}).get('arm') != arm:
        raise ValueError('comparison checkpoint schema/arm mismatch; no legacy fallback')
    net = make_model(**blob['model_config'])
    net.load_state_dict(blob['state_dict'], strict=True)
    return net.eval()
