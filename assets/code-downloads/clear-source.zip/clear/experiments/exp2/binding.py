"""Per-episode lock bindings, so the task stops being a memorised table (exp2_scene).

README section 2d measured that scene's decisions are a **286-row lookup over
nine booleans**, accuracy 0.955 -- which is why BC ties CLEAR. One of those
rows is the constant "button 0 gates the drawer, button 1 gates the window".
Vary it per episode and that row stops existing: the model has to *read* which
button gates what.

Why subsets and not a permutation. Scene has two buttons and two slides, so
permuting them gives only **two** bindings (identity and swap) -- you cannot
hold one out and still have training data, and the lookup table merely doubles.
Letting each button gate an arbitrary SUBSET of the slides gives
`(2^2)^2 = 16` configurations, of which 9 are non-degenerate (every slide
gated by at least one button, so nothing is permanently locked or permanently
free). That is enough to hold configurations out. No MJCF change: only the
damping assignment inside `_apply_button_states` moves.

A slide is unlocked when **every** button that gates it is pressed. With the
shipped binding that reduces to exactly the original behaviour, which
`demo()` asserts.
"""

import sys

import mujoco
import numpy as np

sys.path.insert(0, '.')

SLIDES = ('drawer', 'window')
JOINT = {'drawer': 'drawer_slide', 'window': 'window_slide'}
HANDLE = {'drawer': 'drawer_handle', 'window': 'window_handle'}
LOCKED_DAMPING, FREE_DAMPING = 1e6, 2.0

# button -> frozenset of slides it gates. The shipped binding is the identity.
SHIPPED = ((0,), (1,))          # button 0 gates slide 0 (drawer), button 1 gates slide 1


def all_bindings():
    """Every non-degenerate binding, as a tuple of per-button slide-index tuples.

    Non-degenerate = each slide is gated by at least one button. A slide gated
    by nobody is permanently free and carries no precondition; the task would
    lose the very structure being tested.
    """
    out = []
    for b0 in range(4):
        for b1 in range(4):
            gates = (tuple(s for s in range(2) if b0 >> s & 1),
                     tuple(s for s in range(2) if b1 >> s & 1))
            covered = set(gates[0]) | set(gates[1])
            if covered == {0, 1}:
                out.append(gates)
    return out


def gated_by(binding, slide_idx):
    """Which buttons gate this slide."""
    return tuple(b for b, gates in enumerate(binding) if slide_idx in gates)


def is_unlocked(binding, button_states, slide_idx):
    """A slide is free only when EVERY button gating it is pressed."""
    return all(button_states[b] == 1 for b in gated_by(binding, slide_idx))


def install(env, binding):
    """Replace the env's hardcoded lock rule with `binding`, in place.

    Wraps `_apply_button_states` rather than editing `ogbench`: the method is
    called from five places in `scene_env` (reset, set_state, the three
    initialisers and `post_step`), so binding it on the instance catches all of
    them and nothing upstream has to change.
    """
    u = env.unwrapped
    u._exp2_binding = tuple(tuple(g) for g in binding)

    def apply_button_states(self=u):
        for i in range(self._num_buttons):
            for gid in self._button_geom_ids_list[i]:
                self._model.geom(gid).rgba = self._colors[
                    'red' if self._cur_button_states[i] == 0 else 'white']
        for s, name in enumerate(SLIDES):
            free = is_unlocked(self._exp2_binding, self._cur_button_states, s)
            self._model.joint(JOINT[name]).damping[0] = (
                FREE_DAMPING if free else LOCKED_DAMPING)
            self._model.material(HANDLE[name]).rgba = self._colors[
                'white' if free else 'red']
        mujoco.mj_forward(self._model, self._data)

    u._apply_button_states = apply_button_states
    u._apply_button_states()
    return u._exp2_binding


def binding_of(env):
    return getattr(env.unwrapped, '_exp2_binding', SHIPPED)


def features(binding):
    """(2, 2) gate matrix, the observation the model has to read.

    Row b, column s is 1 when button b gates slide s. Handing this over is the
    point: the *relation* becomes an input rather than a constant of the
    environment, so a table over the state booleans alone can no longer answer.
    """
    m = np.zeros((2, 2), np.float32)
    for b, gates in enumerate(binding):
        for s in gates:
            m[b, s] = 1.0
    return m


def demo():
    from experiments.exp2.scene_bridge import make_env

    bindings = all_bindings()
    assert len(bindings) == 9, len(bindings)
    assert SHIPPED in bindings
    # every binding leaves both slides gated by someone
    for b in bindings:
        assert set(b[0]) | set(b[1]) == {0, 1}, b

    # the shipped binding must reproduce scene's own rule exactly
    for states in ((0, 0), (0, 1), (1, 0), (1, 1)):
        assert is_unlocked(SHIPPED, states, 0) == (states[0] == 1)
        assert is_unlocked(SHIPPED, states, 1) == (states[1] == 1)

    env, _ = make_env()
    u = env.unwrapped
    for binding in (SHIPPED, ((0, 1), (0,))):
        install(env, binding)
        for states in ((0, 0), (0, 1), (1, 0), (1, 1)):
            u._cur_button_states = np.array(states)
            u._apply_button_states()
            for s, name in enumerate(SLIDES):
                free = u._model.joint(JOINT[name]).damping[0] == FREE_DAMPING
                assert free == is_unlocked(binding, states, s), (binding, states, name)
    # a binding where button 0 gates BOTH slides: pressing button 1 alone frees nothing
    install(env, ((0, 1), (0,)))
    u._cur_button_states = np.array([0, 1])
    u._apply_button_states()
    assert u._model.joint('drawer_slide').damping[0] == LOCKED_DAMPING
    assert u._model.joint('window_slide').damping[0] == LOCKED_DAMPING

    print(f'ok  {len(bindings)} non-degenerate bindings; shipped rule reproduced; '
          f'damping follows the binding on all 4 button states x 2 bindings')
    print(f'    gate matrix for {SHIPPED}:\n{features(SHIPPED)}')


if __name__ == '__main__':
    demo()
