"""UR5e scene port of maze's SUMO-style residual QDCEM executor.

This uses the repository's NumPy QDCEM, not the official SUMO runtime. The
ogbench feedback controller is the common proposal/guide; sampled spline
residuals compete in real MuJoCo rollouts. The best evaluated candidate is
executed; LA-QDPP changes the elites used by the next CEM iteration. Rollout
cost includes every simulated step, including the guide trajectory.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, asdict
import time

import mujoco
import numpy as np

from clear.util import CEMConfig, QDCEM
from experiments.exp2.scene_bridge import MAX_STEPS_PER_INTERACTION, read_state, set_target


class SceneSnapshot:
    """Exact local transaction over physics, lock dynamics, oracle and RNG state.

    Never restores a hypothetical state into real execution. Every rollout
    starts from this snapshot and the caller restores it in a finally block.
    """
    _fields = ('_cur_button_states', '_prev_button_states', '_target_task',
               '_target_block', '_target_button', '_target_button_states',
               '_target_drawer_pos', '_target_window_pos', '_success',
               '_reset_next_step', '_prev_qpos', '_prev_qvel', '_prev_ob_info',
               '_target_effector_pose')
    _model_fields = ('dof_damping', 'geom_rgba', 'mat_rgba', 'site_pos')

    def __init__(self, env, agent):
        u = env.unwrapped
        self.data = mujoco.MjData(u._model)
        mujoco.mj_copyData(self.data, u._model, u._data)
        self.fields = {k: copy.deepcopy(getattr(u, k)) for k in self._fields if hasattr(u, k)}
        self.model = {k: getattr(u._model, k).copy() for k in self._model_fields}
        self.random = copy.deepcopy(u.np_random.bit_generator.state)
        self.global_random = np.random.get_state()
        self.agent = {k: copy.deepcopy(v) for k, v in vars(agent).items() if k != '_env'}
        self.wrappers = []
        wrapper = env
        while wrapper is not u:
            if '_elapsed_steps' in vars(wrapper):
                self.wrappers.append((wrapper, wrapper._elapsed_steps))
            wrapper = wrapper.env

    def restore(self, env, agent):
        u = env.unwrapped
        for k in self._fields:
            if k in self.fields:
                setattr(u, k, copy.deepcopy(self.fields[k]))
            elif k in vars(u):
                delattr(u, k)
        for k, v in self.model.items():
            getattr(u._model, k)[:] = v
        mujoco.mj_copyData(u._data, u._model, self.data)
        u.np_random.bit_generator.state = copy.deepcopy(self.random)
        np.random.set_state(self.global_random)
        for k in list(vars(agent)):
            if k != '_env':
                delattr(agent, k)
        vars(agent).update(copy.deepcopy(self.agent))
        for wrapper, elapsed in self.wrappers:
            wrapper._elapsed_steps = elapsed


@dataclass(frozen=True)
class SceneMPCConfig:
    selector: str = 'laqdpp'
    rollouts: int = 8
    elites: int = 3
    nodes: int = 3
    horizon: int = 8
    execute: int = 4
    iterations: int = 2
    residual: float = 0.15
    seed: int = 0

    def __post_init__(self):
        if not 1 <= self.execute <= self.horizon:
            raise ValueError('need 1 <= execute <= horizon')
        if self.iterations < 2:
            raise ValueError('need >=2 iterations for elite selection to affect execution')
        if not np.isfinite(self.residual) or self.residual <= 0:
            raise ValueError('residual must be finite and positive')
        if not 1 <= self.elites <= self.rollouts:
            raise ValueError('need 1 <= elites <= rollouts')


class SceneMPCExecutor:
    method = 'scene-sumo-style-qdcem-v1'

    def __init__(self, config=SceneMPCConfig()):
        self.config = config
        self.rng = np.random.default_rng(config.seed)
        self.audit = []

    def _rollout(self, env, agent, residuals, ob, info):
        trajectory, steps = [], 0
        for residual in residuals:
            action = np.clip(np.asarray(agent.select_action(ob, info)) + residual, -1, 1)
            ob, _, term, trunc, info = env.step(action)
            trajectory.append(np.r_[info['proprio/effector_pos'],
                                     info['privileged/block_0_pos'],
                                     info['privileged/drawer_pos'], info['privileged/window_pos']])
            steps += 1
            if agent.done or term or trunc:
                break
        return ob, info, np.asarray(trajectory), steps

    def optimize(self, env, agent, target, ob, info, cem):
        cfg = self.config
        snapshot = SceneSnapshot(env, agent)
        started = time.perf_counter()
        physical_steps, evaluated, history = 0, 0, []
        dt = env.unwrapped._control_timestep
        # Fixed guide trajectory defines phase-aware tracking without teacher targets.
        # This extra physical evaluation is explicitly charged in the audit.
        best_reward, best_controls = -np.inf, None
        try:
            _, _, guide, count = self._rollout(env, agent, np.zeros((cfg.horizon, 5)), ob, info)
            physical_steps += count
            snapshot.restore(env, agent)
            for iteration in range(cfg.iterations):
                knots = cem.sample()
                controls = cem.controls(knots, cfg.horizon, dt)
                rewards = []
                for residuals in controls:
                    snapshot.restore(env, agent)
                    _, final, trajectory, count = self._rollout(env, agent, residuals, ob, info)
                    physical_steps += count
                    evaluated += 1
                    m = min(len(trajectory), len(guide))
                    # Track guide's actual physical motion, especially grasp/release
                    # phases where short-term object progress is initially zero.
                    tracking = float(np.square(trajectory[:m] - guide[:m]).mean())
                    kind, spec = target
                    if kind == 'button':
                        desired = snapshot.fields['_target_button_states'][int(spec)]
                        error = float(read_state(final)['buttons'][int(spec)] != desired)
                    else:
                        error = float(np.linalg.norm(read_state(final)[kind] - spec))
                    reward = -(20 * tracking + error ** 2 + .001 * np.square(residuals).mean())
                    if not np.isfinite(reward):
                        reward = -np.inf
                    rewards.append(reward)
                    if reward > best_reward:
                        best_reward, best_controls = reward, residuals.copy()
                cem.update(knots, np.asarray(rewards))
                topk = np.argsort(-np.asarray(rewards), kind='stable')[:cfg.elites].tolist()
                history.append(dict(iteration=iteration, **cem.last, topk=topk,
                                    elite_differs_from_topk=set(cem.last.get('elite', [])) != set(topk)))
        finally:
            snapshot.restore(env, agent)
        if best_controls is None:
            raise RuntimeError('no finite MPC candidate')
        self.audit.append(dict(physical_steps=physical_steps, candidates=evaluated,
                               guide_rollouts=1, seconds=time.perf_counter() - started,
                               selector=cfg.selector, iterations=history,
                               residual_norm=float(np.linalg.norm(best_controls)),
                               best_reward=float(best_reward)))
        return best_controls

    def __call__(self, env, oracles, target, ob, info):
        ob, info = set_target(env, target)
        agent = oracles[target[0]]
        agent.reset(ob, info)
        cfg = self.config
        cem = QDCEM(CEMConfig(num_rollouts=cfg.rollouts, num_nodes=cfg.nodes,
                             num_elites=cfg.elites, horizon_s=cfg.horizon * env.unwrapped._control_timestep,
                             selector=cfg.selector, sigma_init=.3),
                    -np.full(5, cfg.residual), np.full(5, cfg.residual), self.rng)
        trunc, count = False, 0
        while count < MAX_STEPS_PER_INTERACTION:
            residuals = self.optimize(env, agent, target, ob, info, cem)
            for residual in residuals[:min(cfg.execute, MAX_STEPS_PER_INTERACTION - count)]:
                action = np.clip(np.asarray(agent.select_action(ob, info)) + residual, -1, 1)
                ob, _, term, trunc, info = env.step(action)
                count += 1
                if agent.done or term or trunc:
                    return ob, info, trunc
            cem.shift(cfg.execute * env.unwrapped._control_timestep)
        return ob, info, trunc

    def report(self):
        return dict(method=self.method, config=asdict(self.config), optimizations=len(self.audit),
                    physical_steps=sum(a['physical_steps'] for a in self.audit),
                    candidates=sum(a['candidates'] for a in self.audit),
                    changed_elite_sets=sum(it['elite_differs_from_topk'] for a in self.audit for it in a['iterations']),
                    seconds=sum(a['seconds'] for a in self.audit), trace=self.audit)
