"""Paired manifest-based evaluation of the complete scene CLEAR system.

Example:
 MUJOCO_GL=egl python -m experiments.exp2.evaluate_full --planner clear \
   --checkpoint runs/exp2_full/clear_scaled/clear.pt --manifest runs/exp2_full/data/manifest.json \
   --executor sumo-laqdpp --out runs/exp2_full/full.json
"""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch

from experiments.exp2.dataset import encode, _object_index
from experiments.exp2.model import load_model
from experiments.exp2.evaluation_manifest import validate_manifest
from experiments.exp2.run_scene import decode_target
from experiments.exp2.scene_bridge import make_env, set_scene_init, resolve_goal, read_state, goal_satisfied, precondition_violation, run_interaction, reference_sequencer, random_sequencer, in_drawer_at, cube_target_now
from experiments.exp2.sumo_executor import SceneMPCConfig, SceneMPCExecutor
from clear.model.causalflownet import rank_selected


def reset_scene(env, spec, seed):
    env.reset(seed=seed)
    np.random.seed(seed)
    set_scene_init(env, spec['init'])
    u = env.unwrapped
    return u.compute_observation(), u.get_reset_info(), resolve_goal(env, spec)


class Policy:
    def __init__(self, name, checkpoint=None, seed=0, steps=30, device='cpu'):
        self.name, self.steps, self.device = name, steps, device
        self.rng = np.random.default_rng(seed)
        self.generator = torch.Generator(device=device).manual_seed(seed)
        self.net = None
        if checkpoint:
            blob = torch.load(checkpoint, map_location=device, weights_only=True)
            expected = name if name in ('bc', 'plan_bc') else 'clear'
            self.net = load_model(blob, expected).to(device)
        if name not in ('reference', 'random') and self.net is None:
            raise ValueError('learned planners require a checkpoint; no reference fallback')

    @torch.no_grad()
    def plan(self, env, state, goal):
        f = torch.as_tensor(encode(env, state, goal), device=self.device)[None]
        if self.name == 'bc':
            raise ValueError('next-action BC cannot emit a one-pass plan; use plan_bc')
        if self.name == 'plan_bc':
            plan = self.net.plan(f)
        elif self.name in ('clear_mean', 'clear_no_order'):
            batch = self.net.batch(f)
            h = self.net._encode(batch)
            priority = h['mu'] if self.name == 'clear_mean' else torch.rand(h['mu'].shape, device=f.device, generator=self.generator)
            rank, selected = rank_selected(priority, h['selection'] > 0)
            code = self.net.generate_targets(h, batch, rank, selected, self.steps, self.generator)
            plan = [(int(i), code[0, i].cpu().numpy()) for i in rank[0].argsort(stable=True) if selected[0, i]]
        else:
            plan = self.net.plan(f, self.generator, sample=False, steps=self.steps)
            if self.name == 'clear_origin':
                if self.net.target_frame != 'train_affine':
                    raise ValueError('origin target control requires a train-affine checkpoint')
                # Keep generated noise consumption identical to CLEAR. This
                # controls target values, not inference speed or compute cost.
                origin = self.net.target_codec(f)
                plan = [(i, origin[0, i].cpu().numpy()) for i, _ in plan]
        return [decode_target(i, code) for i, code in plan]

    def act(self, env, state, goal):
        if self.name in ('reference', 'random'):
            return dict(reference=reference_sequencer, random=random_sequencer)[self.name](env, state, goal, self.rng)
        if self.name == 'bc':
            features = torch.as_tensor(encode(env, state, goal), device=self.device)[None]
            idx, code = self.net.act(features, self.generator)
            return None if idx is None else decode_target(idx, code)
        plan = self.plan(env, state, goal)
        return plan[0] if plan else None


def reference_plan(env, oracles, spec, seed, budget):
    ob, info, goal = reset_scene(env, spec, seed)
    plan = []
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        target = reference_sequencer(env, state, goal)
        if target is None:
            break
        plan.append(target)
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break
    return plan, goal_satisfied(read_state(info), goal)


def summarize(rows):
    n = len(rows)
    decisions = sum(r['decisions'] for r in rows)
    violations = sum(r['violations'] for r in rows)
    successes = [r for r in rows if r['success']]
    cube_errors = [t['cube_goal_error_m'] for r in rows for t in r.get('trace', [])
                   if t.get('cube_goal_error_m') is not None]
    return dict(episodes=n, success=sum(r['success'] for r in rows)/n if n else None,
                decisions=decisions, violations=violations,
                decisions_per_scene=decisions/n if n else None,
                violations_per_scene=violations/n if n else None,
                violations_per_decision=violations/decisions if decisions else None,
                interactions_on_success=float(np.mean([r['decisions'] for r in successes])) if successes else None,
                cube_decisions_audited=len(cube_errors),
                cube_goal_error_max_m=max(cube_errors) if cube_errors else None,
                cube_goals_over_tolerance=sum(e > .04 for e in cube_errors),
                physical_rollout_steps=sum(r['executor'].get('physical_steps', 0) for r in rows),
                wall_seconds=sum(r['seconds'] for r in rows))


def cube_goal_error(env, goal, target):
    """Evaluation-only release-goal error at the state where a cube is executed.

    This audits the final cube goal after the known drawer translation, not an
    arbitrary intermediate subgoal. It never changes the selected target.
    """
    if target[0] != 'cube':
        return None
    expected = (cube_target_now(env.unwrapped, goal[3], goal[1])
                if in_drawer_at(env.unwrapped, goal[3], goal[1]) else goal[3])
    return float(np.linalg.norm(np.asarray(target[1]) - expected))


def evaluate(args):
    torch.set_num_threads(2)
    checkpoint_manifest = None
    if args.checkpoint:
        blob = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
        checkpoint_manifest = blob.get('manifest_sha256')
        if not checkpoint_manifest:
            raise ValueError('checkpoint has no recorded training manifest')
    manifest, manifest_hash, training_hash = validate_manifest(
        args.manifest, checkpoint_manifest, getattr(args, 'training_manifest', None))
    specs = manifest['splits'][args.split]
    chosen = list(enumerate(specs))[args.start:args.start+args.limit if args.limit else None]
    env, oracles = make_env(seed=args.seed)
    rows, excluded = [], []
    checkpoint_hash = hashlib.sha256(args.checkpoint.read_bytes()).hexdigest() if args.checkpoint else None
    source_files = [Path(__file__), Path(__file__).with_name('sumo_executor.py'),
                    Path(__file__).with_name('model.py'), Path(__file__).with_name('target_codec.py'),
                    Path(__file__).with_name('evaluation_manifest.py'),
                    Path(__file__).with_name('scene_bridge.py'),
                    Path('clear/maze/qd_cem.py')]
    result = dict(schema='scene-full-evaluation-v1', manifest_sha256=manifest_hash,
                  training_manifest_sha256=training_hash,
                  source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files},
                  checkpoint_sha256=checkpoint_hash,
                  config={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},
                  rows=rows, excluded=excluded)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    try:
        for i, spec in chosen:
            for attempt in range(args.episodes):
                episode_seed = int(np.random.SeedSequence([args.seed, i, attempt]).generate_state(1)[0])
                policy = Policy(args.planner, args.checkpoint, episode_seed, args.flow_steps, args.device)
                plan = None
                initial_plan_seconds = 0.0
                if args.mode == 'open':
                    ref, solved = reference_plan(env, oracles, spec, episode_seed, args.budget)
                    indices = [_object_index(t) for t in ref]
                    if not solved or len(set(indices)) != len(indices):
                        excluded.append(dict(scene=i, attempt=attempt, reason='reference_failed' if not solved else 'repeated_object'))
                        continue
                    ob, info, goal = reset_scene(env, spec, episode_seed)
                    if args.planner == 'reference':
                        plan = ref
                    elif args.planner == 'random':
                        raise ValueError('random uses reference selection/targets in open mode; use explicit ordering ablation')
                    else:
                        plan_started = time.perf_counter()
                        plan = policy.plan(env, read_state(info), goal)
                        initial_plan_seconds = time.perf_counter() - plan_started
                ob, info, goal = reset_scene(env, spec, episode_seed)
                if args.executor == 'oracle':
                    executor = run_interaction
                else:
                    executor = SceneMPCExecutor(SceneMPCConfig(selector=args.executor.removeprefix('sumo-'),
                        rollouts=args.rollouts, elites=args.elites, horizon=args.horizon,
                        execute=args.execute, iterations=args.iterations, seed=episode_seed))
                started = time.perf_counter()
                trace = []
                for step in range(args.budget):
                    state = read_state(info)
                    if goal_satisfied(state, goal):
                        break
                    target = (plan[step] if step < len(plan) else None) if plan is not None else policy.act(env, state, goal)
                    if target is None:
                        break
                    if not np.isfinite(np.asarray(target[1])).all():
                        raise ValueError('nonfinite model target')
                    violation = precondition_violation(env, state, goal, target)
                    target_error = cube_goal_error(env, goal, target)
                    before = env.unwrapped._data.time
                    ob, info, trunc = executor(env, oracles, target, ob, info)
                    trace.append(dict(object=target[0], target=np.asarray(target[1]).tolist(), violation=violation,
                                      cube_goal_error_m=target_error,
                                      simulation_seconds=env.unwrapped._data.time-before))
                    if trunc:
                        break
                row = dict(scene=i, attempt=attempt, reset_seed=episode_seed,
                           success=goal_satisfied(read_state(info),goal), decisions=len(trace),
                           violations=sum(t['violation'] is not None for t in trace), trace=trace,
                           seconds=time.perf_counter()-started+initial_plan_seconds,
                           initial_plan_seconds=initial_plan_seconds,
                           executor=executor.report() if isinstance(executor,SceneMPCExecutor) else dict(method='ogbench-oracle'))
                rows.append(row)
                result['summary'] = summarize(rows)
                args.out.write_text(json.dumps(result, indent=2)+'\n')
                print(json.dumps(dict(scene=i, attempt=attempt, **result['summary'])), flush=True)
    finally:
        env.close()
    result['summary'] = summarize(rows)
    args.out.write_text(json.dumps(result, indent=2)+'\n')
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--planner', choices=['reference','random','bc','plan_bc','clear','clear_mean','clear_no_order','clear_origin'],default='clear')
    ap.add_argument('--checkpoint',type=Path)
    ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--training-manifest',type=Path)
    ap.add_argument('--split',default='val')
    ap.add_argument('--mode',choices=['closed','open'],default='closed')
    ap.add_argument('--executor',choices=['oracle','sumo-topk','sumo-dpp','sumo-laqdpp'],default='sumo-laqdpp')
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--seed',type=int,default=0)
    ap.add_argument('--episodes',type=int,default=1)
    ap.add_argument('--budget',type=int,default=12)
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--limit',type=int)
    ap.add_argument('--flow-steps',type=int,default=30)
    ap.add_argument('--device',default='cpu')
    ap.add_argument('--rollouts',type=int,default=8)
    ap.add_argument('--elites',type=int,default=3)
    ap.add_argument('--horizon',type=int,default=8)
    ap.add_argument('--execute',type=int,default=4)
    ap.add_argument('--iterations',type=int,default=2)
    a=ap.parse_args()
    if a.mode=='open' and a.planner in ('bc','random'):
        ap.error('open mode requires clear, plan_bc or reference')
    if min(a.episodes,a.budget,a.flow_steps)<=0 or a.start<0 or (a.limit is not None and a.limit<=0):
        ap.error('positive episodes/budget/flow-steps/limit and nonnegative start required')
    evaluate(a)


if __name__=='__main__':
    main()
