"""Train each arm on identical frozen data, recording seeds and file hashes."""
from clear.provenance import package_revision
import argparse
from pathlib import Path
import subprocess
import numpy as np
import torch

from experiments.exp2.comparison_models import ARMS, SCHEMA, make_model
from experiments.exp2.comparison_protocol import file_hash
from experiments.exp2.dataset import DATA_SCHEMA


def load_data(path, device):
    with np.load(path) as f:
        if str(f['schema']) != DATA_SCHEMA or 'manifest_sha256' not in f or 'scene_id' not in f:
            raise ValueError('frozen comparison data required')
        keys = ('object_features', 'rank', 'choice', 'target_code', 'plan_target_code', 'affordance_target')
        data = {k: torch.as_tensor(f[k], device=device) for k in keys}
        return data, str(f['manifest_sha256'])


def loss(net, data):
    return net.loss(**{k: v for k, v in data.items() if net.arm != 'bc' or k not in ('plan_target_code', 'affordance_target')})


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--arm', choices=ARMS, required=True)
    ap.add_argument('--data', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--seed', type=int, required=True)
    ap.add_argument('--steps', type=int, default=6000)
    ap.add_argument('--target-steps', type=int, default=3000)
    ap.add_argument('--target-lr', type=float, default=1e-4)
    ap.add_argument('--dim', type=int, default=128)
    ap.add_argument('--depth', type=int, default=4)
    ap.add_argument('--heads', type=int, default=4)
    ap.add_argument('--batch', type=int, default=128)
    ap.add_argument('--lr', type=float, default=3e-4)
    ap.add_argument('--mu-scale', type=float, default=0.)
    ap.add_argument('--target-frame', choices=('absolute', 'goal_relative', 'train_affine'), default='train_affine')
    ap.add_argument('--affordance-context', choices=('global', 'local', 'local_access'), default='local_access')
    ap.add_argument('--availability-weight', type=float, default=1.)
    ap.add_argument('--flow-scale', type=float, default=.1)
    ap.add_argument('--kl-weight', type=float, default=1e-3)
    ap.add_argument('--causal', type=int, choices=(0, 1), default=1,
                    help='clear arm only: 1=legacy rank-causal mask (default), 0=observation-consistent (no_causal_mask ablation)')
    ap.add_argument('--causal-bias-slope', type=float, default=0.,
                    help='clear arm only, requires --causal 0: graded penalty per rank-gap instead of a hard block (soft-causal variant); 0 is a no-op')
    ap.add_argument('--threads', type=int, default=1)
    a = ap.parse_args(argv)
    if (a.out.exists() or min(a.steps, a.batch, a.threads) < 1 or a.target_steps < 0
            or a.lr <= 0 or a.target_lr <= 0):
        raise ValueError('output must be new and training arguments positive')
    if a.causal_bias_slope and a.causal:
        raise ValueError('--causal-bias-slope requires --causal 0 (it only grades the movable-movable penalty causal=False leaves open)')
    if (a.causal_bias_slope or not a.causal) and a.arm != 'clear':
        raise ValueError('--causal/--causal-bias-slope are only wired for arm=clear; use clear_nocausal for the existing hard no-causal ablation')
    torch.set_num_threads(a.threads)
    torch.manual_seed(a.seed)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    train, manifest = load_data(a.data / 'train.npz', device)
    val, val_manifest = load_data(a.data / 'val.npz', device)
    if manifest != val_manifest:
        raise ValueError('train and val manifests differ')
    cfg = dict(arm=a.arm, dim=a.dim, depth=a.depth, heads=a.heads, mu_scale=a.mu_scale,
               target_frame=a.target_frame, affordance_context=a.affordance_context,
               availability_weight=a.availability_weight, flow_scale=a.flow_scale,
               kl_weight=a.kl_weight)
    if a.arm == 'clear':
        cfg.update(causal=bool(a.causal), causal_bias_slope=a.causal_bias_slope)
    net = make_model(**cfg).to(device)
    if a.target_frame == 'train_affine':
        rank, targets = train['rank'], train['plan_target_code']
        if a.arm == 'bc':
            rank = torch.full_like(rank, -1)
            rank.scatter_(1, train['choice'][:, None], 0)
        net.target_codec.fit(train['object_features'], rank, targets)
    opt = torch.optim.AdamW(net.parameters(), lr=a.lr, weight_decay=1e-4)
    g = torch.Generator().manual_seed(a.seed)
    history = []
    target_prefix = ('flow.' if hasattr(net, 'flow') else 'ar_target.' if a.arm == 'ar_bc'
                     else 'target_head.' if hasattr(net, 'target_head') else 'target.')
    for step in range(1, a.steps + a.target_steps + 1):
        if step == a.steps + 1:
            for name, p in net.named_parameters():
                p.requires_grad_(name.startswith(target_prefix))
                p.grad = None
            opt = torch.optim.AdamW([p for p in net.parameters() if p.requires_grad],
                                    lr=a.target_lr, weight_decay=1e-4)
        ids = torch.randint(len(train['choice']), (a.batch,), generator=g).to(device)
        total, parts = loss(net, {k: v[ids] for k, v in train.items()})
        if not torch.isfinite(total):
            raise ValueError('nonfinite training loss')
        opt.zero_grad(set_to_none=True)
        total.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.)
        opt.step()
        if step == a.steps:
            joint_gradient_params = sum(p.numel() for p in net.parameters() if p.grad is not None)
        if step % max(1, a.steps // 8) == 0 or step == a.steps + a.target_steps:
            history.append(dict(step=step, **parts))
            print(history[-1], flush=True)
    net.eval()
    with torch.no_grad():
        _, val_parts = loss(net, val)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(dict(schema=SCHEMA, model_config=net.config, state_dict=net.cpu().state_dict(),
                    train_seed=a.seed, steps=a.steps, target_steps=a.target_steps,
                    target_lr=a.target_lr, target_parameter_prefix=target_prefix, batch=a.batch, lr=a.lr,
                    selection_rule='fixed final update; development configuration must be frozen before test',
                    manifest_sha256=manifest, train_sha256=file_hash(a.data / 'train.npz'),
                    val_sha256=file_hash(a.data / 'val.npz'), n_params=sum(p.numel() for p in net.parameters()),
                    val_losses=val_parts, history=history, torch_version=str(torch.__version__),
                    n_parameters_with_gradient=joint_gradient_params,
                    n_target_parameters=sum(p.numel() for p in net.parameters() if p.requires_grad),
                    code_commit=package_revision()['commit']), a.out)
    print(f'saved {a.out}; validation losses are diagnostics, not executed success')


if __name__ == '__main__':
    main()
