"""Run a sequencer on `ogbench`'s scene tasks and report the CLEAR metrics.

    python3 experiments/exp2/run_scene.py --episodes 5
    python3 experiments/exp2/run_scene.py --sequencer random --episodes 20
    python3 experiments/exp2/run_scene.py --diagnostic --tasks 1 3

One episode = one of scene's 5 tasks, driven interaction by interaction: the
sequencer names the next object and its desired state, `ogbench`'s own oracle
executes it, and the loop stops when the task goal holds or the interaction
budget runs out.

Three headline metrics, per the 4bb16605 review:

    executed success        did the task actually finish in the simulator
    interactions on success cost of the plans that worked
    precondition violations attempts the scene forbids (locked slide, cube
                            released at an in-drawer goal with the drawer shut)

Exact agreement with one reference order is NOT a headline metric: several
distinct orders solve some of these tasks, so agreement penalises valid plans
(`clear-report-executed-success`).

`--diagnostic` is the ordering control: it takes the reference plan's own
(object, target) pairs and replays PERMUTATIONS of them, so object selection
and target accuracy are held fixed and only the order varies.

`--sequencer clear` and `--sequencer bc` load the checkpoints `train.py` writes
and raise if one is missing. They never fall back to `reference_sequencer`: a
silent fallback would report the hand-written order as a model result.
"""

import argparse
import itertools
import pathlib
import sys

import numpy as np

sys.path.insert(0, '.')

from experiments.exp2.scene_bridge import DRAWER_OPEN, DRAWER_SHUT, OBJECTS, WINDOW_OPEN, WINDOW_SHUT, goal_satisfied, make_env, precondition_violation, random_sequencer, read_state, reference_sequencer, run_interaction, set_target, set_task_init, task_goal

MAX_PERMUTATIONS = 60


_NETS = {}


def learned_sequencer(arm):
    """A trained net as a sequencer. `arm` is 'clear' or 'bc'.

    Re-queried after every interaction, so returning the same object again is
    normal and the returned target may be an intermediate state neither the
    current state nor the goal contains.

    Raises if the checkpoint is missing. **Never fall back to
    `reference_sequencer`** — a silent fallback would report the hand-written
    order as a model result, which is the failure mode the whole harness is
    built to avoid.
    """
    import pathlib

    import torch

    from experiments.exp2.dataset import encode
    from experiments.exp2.model import load_model

    def seq(env, state, goal, rng=None):
        if arm not in _NETS:
            path = pathlib.Path(f'experiments/exp2/checkpoints_shared/{arm}.pt')
            if not path.exists():
                raise FileNotFoundError(
                    f'no checkpoint at {path}. Train one first:\n'
                    f'  python3 experiments/exp2/dataset.py\n'
                    f'  python3 experiments/exp2/train.py --arm {arm}')
            blob = torch.load(path, map_location='cpu', weights_only=True)
            net = load_model(blob, expected_arm=arm)
            _NETS[arm] = net
        net = _NETS[arm]
        features = torch.as_tensor(encode(env, state, goal))[None]
        generator = None if rng is None else torch.Generator().manual_seed(int(rng.integers(0, 2**63 - 1)))
        idx, code = net.act(features, generator=generator)
        if idx is None:
            return None                       # the net selected nothing: it is done
        return decode_target(idx, code)

    return seq


def decode_target(idx, code):
    """Object index + (3,) code -> the tuple the executor speaks."""
    kind = OBJECTS[idx]
    code = np.asarray(code, dtype=float)
    width = 3 if kind == 'cube' else 1 if kind in ('drawer', 'window') else 0
    if code.shape != (3,) or not np.isfinite(code[:width]).all():
        raise ValueError('target code must have three slots and finite active coordinates')
    if kind == 'cube':
        return ('cube', np.asarray(code, dtype=float))
    if kind.startswith('button_'):
        return ('button', int(kind.split('_')[1]))
    # slides: snap to the nearer of the two reachable positions, since the
    # oracles drive to a slide pose and the joint range admits only these two
    lo, hi = ((DRAWER_OPEN, DRAWER_SHUT) if kind == 'drawer'
              else (WINDOW_SHUT, WINDOW_OPEN))
    want = float(code[0])
    return (kind, lo if abs(want - lo) <= abs(want - hi) else hi)


SEQUENCERS = dict(reference=reference_sequencer, random=random_sequencer,
                  clear=learned_sequencer('clear'), bc=learned_sequencer('bc'))


def run_spec(env, oracles, spec, sequencer, budget=12, rng=None):
    """One generated scene (see `splits.py`) instead of a shipped task."""
    from experiments.exp2.scene_bridge import resolve_goal, set_scene_init

    env.reset()
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()
    n, violations = 0, 0
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        target = sequencer(env, state, goal, rng)
        if target is None:
            break
        violations += precondition_violation(env, state, goal, target) is not None
        n += 1
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break
    return goal_satisfied(read_state(info), goal), n, violations


def evaluate_split(env, oracles, name, sequencer, seed, budget, episodes=1):
    from experiments.exp2.splits import make_splits

    specs = make_splits(seed=seed)[name]
    wins, costs, viol = [], [], []
    for i, spec in enumerate(specs):
        for ep in range(episodes):
            np.random.seed(seed * 100003 + i * 17 + ep)
            rng = np.random.default_rng([seed, i, ep])
            ok, n, v = run_spec(env, oracles, spec, sequencer, budget, rng)
            wins.append(ok)
            viol.append(v)
            if ok:
                costs.append(n)
    return (float(np.mean(wins)), float(np.mean(costs)) if costs else float('nan'),
            float(np.mean(viol)), len(wins))


def run_episode(env, oracles, task_idx, sequencer, budget=12, rng=None):
    """Closed loop: observe, choose one interaction, execute, repeat.

    Returns `(solved, interactions, violations, trace)`.
    """
    env.reset()
    set_task_init(env, task_idx)
    goal = task_goal(env, task_idx)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()

    trace, violations = [], 0
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        target = sequencer(env, state, goal, rng)
        if target is None:
            break
        bad = precondition_violation(env, state, goal, target)
        violations += bad is not None
        trace.append((target[0], target[1] if target[0] == 'button'
                      else np.round(target[1], 3), bad))
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break
    return goal_satisfied(read_state(info), goal), len(trace), violations, trace


def reference_plan(env, oracles, task_idx, budget=12):
    """The (object, target) pairs the reference sequencer actually executes.

    Captured as literal values, so `--diagnostic` can permute them without the
    sequencer silently recomputing a target for the new state -- that is what
    holds target accuracy fixed while the order varies.
    """
    env.reset()
    set_task_init(env, task_idx)
    goal = task_goal(env, task_idx)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()
    plan = []
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        target = reference_sequencer(env, state, goal)
        if target is None:
            break
        plan.append((target[0], np.asarray(target[1]) if target[0] != 'button'
                     else target[1]))
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break
    return plan


def execute_plan(env, oracles, task_idx, plan):
    """Replay a fixed (object, target) list open loop. Returns (solved, violations)."""
    env.reset()
    set_task_init(env, task_idx)
    goal = task_goal(env, task_idx)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()
    violations = 0
    for target in plan:
        violations += precondition_violation(
            env, read_state(info), goal, target) is not None
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break
    return goal_satisfied(read_state(info), goal), violations


def diagnostic(env, oracles, task_idx, rng, name, reps=2):
    """Same objects, same targets, order permuted -- does order alone decide?

    Every permutation inside one rep runs under the SAME motion seed, because
    the oracles draw their retreat pose from the global `np.random` and the
    comparison is only matched if that draw is held fixed across orders. Reps
    then average over motion noise, which is what makes the reference's own
    rate meaningful -- it is 0.80 on tasks 4 and 5, not 1.00.
    """
    plan = reference_plan(env, oracles, task_idx)
    ident = tuple(range(len(plan)))
    perms = list(itertools.permutations(range(len(plan))))
    total = len(perms)
    if total > MAX_PERMUTATIONS:                     # task5 has 8! orders
        keep = {ident}
        while len(keep) < MAX_PERMUTATIONS:
            keep.add(tuple(rng.permutation(len(plan))))
        perms = [ident] + sorted(keep - {ident})

    ref_wins, other_wins, other_n = 0, 0, 0
    for rep in range(reps):
        for pm in perms:
            np.random.seed(1000 + rep)               # matched motion draw across orders
            solved, _ = execute_plan(env, oracles, task_idx, [plan[i] for i in pm])
            if pm == ident:
                ref_wins += solved
            else:
                other_wins += solved
                other_n += 1
    note = '' if total <= MAX_PERMUTATIONS else f' (sampled from {total})'
    print(f'  {name:26s} plan length {len(plan)}   reference {ref_wins}/{reps}   '
          f'other orders {other_wins}/{other_n} = {other_wins / max(other_n, 1):.2f}{note}')
    return len(plan), ref_wins, reps, other_wins, other_n


def _repeat_free_plan(env, oracles, spec, budget=12, reset=True):
    """The reference's plan for a generated spec, or None if it repeats an object.

    `OrderingHead` gives one rank per object, so a whole-order prediction
    cannot express a plan that touches the same object twice. 25 of 40 val
    scenes are repeat-free; the rest are outside this regime and are reported
    as excluded rather than silently dropped.
    """
    from experiments.exp2.scene_bridge import resolve_goal, set_scene_init

    if reset:
        env.reset()
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()
    plan, keys = [], []
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        t = sequencer_target = reference_sequencer(env, state, goal)
        if t is None:
            break
        keys.append(t[0] if t[0] != 'button' else f'button_{t[1]}')
        plan.append((t[0], np.asarray(t[1]) if t[0] != 'button' else t[1]))
        ob, info, trunc = run_interaction(env, oracles, t, ob, info)
        if trunc:
            break
    if not plan or len(keys) != len(set(keys)):
        return None
    return plan


def _closed_loop_plan(env, oracles, spec, sequencer, budget=12, rng=None):
    """The order an arm produces while being re-queried -- privileged, since it
    sees the state after every interaction. Used to give BC a row at all."""
    from experiments.exp2.scene_bridge import resolve_goal, set_scene_init

    env.reset()
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()
    plan = []
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        t = sequencer(env, state, goal, rng)
        if t is None:
            break
        plan.append((t[0], np.asarray(t[1]) if t[0] != 'button' else t[1]))
        ob, info, trunc = run_interaction(env, oracles, t, ob, info)
        if trunc:
            break
    return plan


def _clear_one_pass_plan(env, spec, draws=1, seed=0):
    """CLEAR's whole order from ONE forward pass at the initial state.

    No re-querying and no simulator feedback -- this is the regime BC cannot
    enter. `draws` samples the ordering head repeatedly to measure diversity.
    """
    import torch

    from experiments.exp2.dataset import encode
    from experiments.exp2.scene_bridge import resolve_goal, set_scene_init

    env.reset()
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    _, info = u.compute_observation(), u.get_reset_info()
    net = _clear_net()
    features = torch.as_tensor(encode(env, read_state(info), goal))[None]
    g = torch.Generator().manual_seed(seed)
    return [[decode_target(i, code) for i, code in net.plan(features, generator=g)]
            for _ in range(draws)]


def heuristic_plan(env, spec):
    """A whole order from the initial state with NO learning, for the one-pass
    regime — the fair comparator for `_clear_one_pass_plan`.

    Fixed object priority (buttons, then cube, then slides), keeping only the
    objects not already at their goal and taking each target straight from the
    goal. It encodes "unlock before you move a slide" by putting the buttons
    first, and nothing else. BC cannot appear in this regime at all: it is a
    next-action model, so producing an order from one observation would need a
    dynamics model, which would no longer be BC.
    """
    from experiments.exp2.scene_bridge import TOL_CUBE, TOL_SLIDE, cube_target_now, resolve_goal, set_scene_init

    env.reset()
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    _, info = u.compute_observation(), u.get_reset_info()
    st = read_state(info)
    plan = []
    for i in (0, 1):
        if st['buttons'][i] != goal[0][i]:
            plan.append(('button', i))
    if np.linalg.norm(st['cube'] - goal[3]) > TOL_CUBE:
        plan.append(('cube', cube_target_now(u, goal[3], goal[1])))
    if abs(st['drawer'] - goal[1]) > TOL_SLIDE:
        plan.append(('drawer', goal[1]))
    if abs(st['window'] - goal[2]) > TOL_SLIDE:
        plan.append(('window', goal[2]))
    return plan


def _clear_net():
    import pathlib

    import torch

    from experiments.exp2.model import load_model

    if 'clear' not in _NETS:
        path = pathlib.Path('experiments/exp2/checkpoints_shared/clear.pt')
        if not path.exists():
            raise FileNotFoundError(f'no checkpoint at {path}; run train.py --arm clear')
        blob = torch.load(path, map_location='cpu', weights_only=True)
        net = load_model(blob, expected_arm='clear')
        _NETS['clear'] = net
    return _NETS['clear']


ELIGIBLE = pathlib.Path('experiments/exp2/openloop_eligible.json')


def eligible_scenes(env, oracles, splits, seed=0, budget=12):
    """The repeat-free scenes, derived ONCE and cached.

    Deriving this per run made the comparison unusable: the reference is
    re-simulated to find repeats, the oracles draw from the global
    `np.random`, and `env.reset()` re-randomises the arm pose from the env's
    own stream -- so the eligible set drifted 20/22/23/24/27 across five runs
    of the same command and the success rates swung by 0.3 with it. Fixed set,
    fixed reset seeds, or this measures nothing.
    """
    import json

    from experiments.exp2.splits import make_splits

    if ELIGIBLE.exists():
        keep = json.loads(ELIGIBLE.read_text())
    else:
        keep = {}
        for name in splits:
            specs = make_splits(seed=seed)[name]
            idx = []
            for k, spec in enumerate(specs):
                np.random.seed(seed * 99991 + k)
                env.reset(seed=seed * 31 + k)
                if _repeat_free_plan(env, oracles, spec, budget, reset=False) is not None:
                    idx.append(k)
            keep[name] = idx
        ELIGIBLE.write_text(json.dumps(keep, indent=1))
    return keep


def openloop(env, oracles, split='val', seed=0, budget=12, draws=8, attempts=3,
             splits=('val', 'test_button', 'test_cube')):
    """Execute a whole predicted order without re-querying.

    The regime `analyze.py orders` showed is load-bearing: only 0.23 of orders
    over the same interactions reach the goal. BC has no order to give from one
    pass, so its row is its CLOSED-LOOP order replayed open loop -- privileged,
    and labelled as such.
    """
    from experiments.exp2.splits import make_splits

    keep = eligible_scenes(env, oracles, splits, seed, budget)
    kept, plans = [], []
    for name in splits:
        specs = make_splits(seed=seed)[name]
        for k in keep[name]:
            np.random.seed(seed * 99991 + k)
            env.reset(seed=seed * 31 + k)
            plan = _repeat_free_plan(env, oracles, specs[k], budget, reset=False)
            if plan is not None:
                kept.append((name, k, specs[k]))
                plans.append(plan)
    total = sum(len(make_splits(seed=seed)[n]) for n in splits)
    print(f'{len(kept)} repeat-free scenes of {total} over {list(splits)}; '
          f'{attempts} controlled attempts each')

    rows = {}
    for name in ('reference', 'bc', 'heuristic', 'clear'):
        wins, distinct = [], []
        for i, (_, k, spec) in enumerate(kept):
            if name == 'reference':
                cand = [plans[i]]
            elif name == 'heuristic':
                cand = [heuristic_plan(env, spec)]
            elif name == 'bc':
                np.random.seed(seed * 7717 + i)
                env.reset(seed=seed * 31 + k)
                cand = [_closed_loop_plan(env, oracles, spec, SEQUENCERS['bc'], budget,
                                          np.random.default_rng([seed, i]))]
            else:
                cand = _clear_one_pass_plan(env, spec, draws, seed)
            distinct.append(len({tuple((kk, str(np.round(v, 3))) for kk, v in pl)
                                 for pl in cand}))
            for att in range(attempts):
                np.random.seed(seed * 7717 + i * 13 + att)
                solved, _ = _execute_spec(env, oracles, spec, cand[0], budget,
                                          reset_seed=seed * 31 + k * 7 + att)
                wins.append(solved)
        m = float(np.mean(wins))
        se = (m * (1 - m) / len(wins)) ** 0.5
        tag = ('closed-loop order replayed open loop (PRIVILEGED)'
               if name in ('reference', 'bc') else
               'initial state only, no learning' if name == 'heuristic' else
               f'initial state only, ONE forward pass ({np.mean(distinct):.2f} '
               f'distinct orders per {draws} draws)')
        print(f'  {name:10s} open-loop success {m:5.2f} +- {se:.3f}   [{tag}]')
        rows[name] = (m, se)
    return rows


def coverage(env, oracles, seed=0, budget=12, draws=16, max_len=4,
             splits=('val', 'test_button', 'test_cube')):
    """Reference-target order coverage@K, not generated-plan success.

    For every repeat-free scene short enough to enumerate (plan length
    <= `max_len`, so at most 24 permutations), execute all permutations of the
    reference's own interaction set under a MATCHED reset seed to get the
    valid-order set for those reference targets and that seed. Draw K plans
    from CLEAR and ask how many of those
    valid orders it produced.

    Two orders count as the same if their object sequences match. This metric
    does not execute or validate CLEAR's generated targets; use open-loop
    execution success for that. A draw whose selected object SET differs from the
    reference's is counted in `off-set`, not against coverage, since it is
    answering a different question.

    Reported per scene and averaged:
        |valid|      how many orders of that set solve at all
        distinct@K   distinct object sequences CLEAR drew
        covered@K    of the valid orders, how many CLEAR drew
        hit@K        did CLEAR draw at least one valid order
    """
    from experiments.exp2.splits import make_splits

    keep = eligible_scenes(env, oracles, splits, seed, budget)
    net = _clear_net()
    rows = []
    for name in splits:
        specs = make_splits(seed=seed)[name]
        for k in keep[name]:
            spec = specs[k]
            np.random.seed(seed * 99991 + k)
            env.reset(seed=seed * 31 + k)
            plan = _repeat_free_plan(env, oracles, spec, budget, reset=False)
            if plan is None or len(plan) > max_len or len(plan) < 2:
                continue
            # Valid with reference targets under one matched execution seed.
            valid = set()
            for pm in itertools.permutations(range(len(plan))):
                np.random.seed(seed * 7717 + k)
                ok, _ = _execute_spec(env, oracles, spec, [plan[i] for i in pm], budget,
                                      reset_seed=seed * 31 + k)
                if ok:
                    valid.add(tuple(plan[i][0] if plan[i][0] != 'button'
                                    else f'button_{plan[i][1]}' for i in pm))
            if not valid:
                continue
            ref_set = {t[0] if t[0] != 'button' else f'button_{t[1]}' for t in plan}
            drawn, off_set = set(), 0
            for pl in _clear_one_pass_plan(env, spec, draws, seed):
                keys = tuple(t[0] if t[0] != 'button' else f'button_{t[1]}' for t in pl)
                if set(keys) != ref_set:
                    off_set += 1
                    continue
                drawn.add(keys)
            covered = len(drawn & valid)
            rows.append((len(plan), len(valid), len(drawn), covered,
                         covered > 0, off_set / draws))
    if not rows:
        print('no scene short enough to enumerate; raise --max-len')
        return
    a = np.array([r[:5] for r in rows], dtype=float)
    off = np.mean([r[5] for r in rows])
    print('reference-target order coverage (generated targets are not scored)')
    print(f'{len(rows)} scenes with 2 <= plan length <= {max_len}, K={draws} draws')
    print(f'  plan length      mean {a[:, 0].mean():.2f}')
    print(f'  |valid orders|   mean {a[:, 1].mean():.2f}')
    print(f'  distinct@{draws}      mean {a[:, 2].mean():.2f}')
    print(f'  covered@{draws}       mean {a[:, 3].mean():.2f}  '
          f'= {a[:, 3].sum() / a[:, 1].sum():.2f} of all valid orders')
    print(f'  hit@{draws}           {a[:, 4].mean():.2f} of scenes drew at least one valid order')
    print(f'  off-set draws    {off:.2f} (selected a different object set than the reference)')


def _execute_spec(env, oracles, spec, plan, budget, reset_seed=0):
    from experiments.exp2.scene_bridge import resolve_goal, set_scene_init

    env.reset(seed=reset_seed)
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()
    for target in plan[:budget]:
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break
    return goal_satisfied(read_state(info), goal), len(plan)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sequencer', default='reference', choices=sorted(SEQUENCERS))
    ap.add_argument('--tasks', type=int, nargs='*', default=[0, 1, 2, 3, 4])
    ap.add_argument('--episodes', type=int, default=5, help='episodes per task')
    ap.add_argument('--budget', type=int, default=12, help='max interactions')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--trace', action='store_true', help='print each episode plan')
    ap.add_argument('--reps', type=int, default=2,
                    help='motion-noise draws per permutation, for --diagnostic')
    ap.add_argument('--split', nargs='*', default=None,
                    help='evaluate on generated splits instead of the shipped tasks')
    ap.add_argument('--openloop', action='store_true',
                    help='execute a whole predicted order without re-querying')
    ap.add_argument('--draws', type=int, default=8,
                    help='ordering-head samples per scene, for --openloop')
    ap.add_argument('--attempts', type=int, default=3,
                    help='controlled execution attempts per scene, for --openloop')
    ap.add_argument('--diagnostic', action='store_true',
                    help='ordering control: permute the reference plan instead')
    ap.add_argument('--coverage', action='store_true', help='reference-target valid-order coverage@K')
    ap.add_argument('--max-len', type=int, default=4, help='longest plan to enumerate for --coverage')
    a = ap.parse_args()

    env, oracles = make_env(seed=a.seed)
    names = [t['task_name'] for t in env.unwrapped.task_infos]

    if a.coverage:
        coverage(env, oracles, a.seed, a.budget, a.draws, a.max_len)
        return

    if a.openloop:
        openloop(env, oracles, (a.split or ['val'])[0], a.seed, a.budget, a.draws,
                 a.attempts)
        return

    if a.diagnostic:
        print('ordering control: reference plan, same objects and targets, order permuted')
        for t in a.tasks:
            diagnostic(env, oracles, t, np.random.default_rng(a.seed), names[t], a.reps)
        return

    seq = SEQUENCERS[a.sequencer]
    if a.split:
        print(f'scene-v0  sequencer={a.sequencer}  generated splits  '
              f'budget {a.budget}  seed {a.seed}')
        for name in a.split:
            sr, mc, mv, n = evaluate_split(env, oracles, name, seq, a.seed, a.budget)
            print(f'  {name:12s} {n:4d} scenes   success {sr:5.2f}   '
                  f'interactions {mc:5.2f}   violations/scene {mv:5.2f}')
        return

    print(f'scene-v0  sequencer={a.sequencer}  {a.episodes} episodes/task  '
          f'budget {a.budget}  seed {a.seed}')
    rows = []
    for t in a.tasks:
        wins, costs, viol = [], [], []
        for ep in range(a.episodes):
            # one stream per (task, episode) so a run is reproducible from --seed.
            # The oracles draw their own retreat pose from the GLOBAL np.random
            # (e.g. DrawerMarkovOracle.reset's `_final_pos`), so seed that too or
            # the same sequencer decisions still give different motions.
            rng = np.random.default_rng([a.seed, t, ep])
            np.random.seed(abs(hash((a.seed, t, ep))) % (2 ** 31))
            solved, n, v, trace = run_episode(env, oracles, t, seq, a.budget, rng)
            wins.append(solved)
            viol.append(v)
            if solved:
                costs.append(n)
            if a.trace:
                print(f'  {names[t]:26s} ep{ep} {"OK " if solved else "FAIL"} '
                      f'{n} interactions, {v} violations  {trace}')
        rows.append((names[t], float(np.mean(wins)),
                     float(np.mean(costs)) if costs else float('nan'),
                     float(np.mean(viol))))
        print(f'  {rows[-1][0]:26s} success {rows[-1][1]:5.2f}   '
              f'interactions {rows[-1][2]:5.2f}   violations/episode {rows[-1][3]:5.2f}')

    print(f'  {"ALL":26s} success {np.mean([r[1] for r in rows]):5.2f}   '
          f'violations/episode {np.mean([r[3] for r in rows]):5.2f}')


if __name__ == '__main__':
    main()
