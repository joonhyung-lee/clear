"""Freeze scene identities before training; collect reference labels only on train/val."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from concurrent.futures import ProcessPoolExecutor

from experiments.exp2.splits import make_splits


def plain(x):
    if isinstance(x, dict):
        return {k: plain(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [plain(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    return x


def digest(x):
    return hashlib.sha256(json.dumps(plain(x), sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def seed_for(*parts):
    return int(digest(parts)[:8], 16)


def scene_id(spec):
    return digest({k: spec[k] for k in ('init', 'goal')})


def freeze(seed=20260911, train=240, val=80, test=80, excluded=()):
    if min(train, val, test) < 1:
        raise ValueError('positive split sizes required')
    excluded = set(excluded)
    seen, result = set(excluded), {}
    for name, source, count in [('train', 'train', train), ('val', 'val', val),
                                ('test_seen', 'val', test), ('test_binding', 'test_binding', test)]:
        result[name] = []
        for attempt in range(100):
            candidates = make_splits(seed_for(seed, name, attempt), per_split=count)[source]
            for spec in candidates:
                sid = scene_id(spec)
                if sid in seen:
                    continue
                seen.add(sid)
                result[name].append(dict(scene_id=sid, spec=plain(spec)))
                if len(result[name]) == count:
                    break
            if len(result[name]) == count:
                break
        if len(result[name]) != count:
            raise ValueError('could not generate enough distinct scenes')
    return dict(schema='scene-manifest-v1', seed=seed, splits=result,
                excluded_scene_ids=sorted(excluded),
                note='Fresh scene identities; the two held-out binding types remain the previously studied types.')


def validate(manifest):
    if manifest.get('schema') != 'scene-manifest-v1':
        raise ValueError('manifest schema mismatch')
    seen = set(manifest.get('excluded_scene_ids', []))
    for name, rows in manifest['splits'].items():
        if not rows:
            raise ValueError('empty split: ' + name)
        for row in rows:
            if plain(row['spec']['binding']) != plain(row['spec']['init']['binding']):
                raise ValueError('reported and initialized lock bindings differ')
            if row['scene_id'] != scene_id(row['spec']) or row['scene_id'] in seen:
                raise ValueError('duplicate, excluded or corrupted scene identity')
            seen.add(row['scene_id'])


def excluded_identities(path):
    """Normalize both archived manifest schemas to physical init/goal identities."""
    old = json.loads(Path(path).read_text())
    if old.get('schema') == 'scene-manifest-v1':
        validate(old)
        return [row['scene_id'] for rows in old['splits'].values() for row in rows]
    if old.get('schema') == 'scene-stable-splits-v2':
        return [scene_id(spec) for rows in old['splits'].values() for spec in rows]
    raise ValueError('unsupported historical manifest schema')


def collect_access_episode(job):
    from experiments.exp2.access_dataset import episode
    split, item, seed, budget = job
    reset = seed_for(seed, item['scene_id'], 'demonstration_reset')
    _, _, rows, audit = episode((split, reset, item['spec'], 0, budget))
    for row in rows:
        row['scene_id'] = item['scene_id']
    return split, item['scene_id'], rows, audit


def collect(manifest_path, out, budget=12, workers=8):
    from experiments.exp2.dataset import DATA_SCHEMA
    manifest = json.loads(Path(manifest_path).read_text())
    validate(manifest)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    audit = []
    kept = {name: [] for name in ('train', 'val')}
    jobs = [(name, item, manifest['seed'], budget) for name in kept for item in manifest['splits'][name]]
    try:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            for name, sid, rows, outcome in pool.map(collect_access_episode, jobs):
                audit.append(dict(split=name, scene_id=sid, **outcome))
                if outcome['success']:
                    kept[name].extend(rows)
                if len(audit) % 40 == 0:
                    print(f'collected {len(audit)}/{len(jobs)} scenes', flush=True)
        for name, rows in kept.items():
            if not rows:
                raise ValueError('no solved reference decisions: ' + name)
            arrays = {k: np.stack([r[k] for r in rows]) for k in
                      ('object_features', 'rank', 'choice', 'target_code', 'plan_target_code', 'affordance_target')}
            np.savez_compressed(out / f'{name}.npz', **arrays, schema=np.array(DATA_SCHEMA),
                                scene_id=np.array([r['scene_id'] for r in rows]), manifest_sha256=np.array(file_hash(manifest_path)))
    finally:
        (out / 'collection_audit.json').write_text(json.dumps(audit, indent=2))
        (out / 'collection_protocol.json').write_text(json.dumps(dict(
            teacher='window-access-counterfactual-v1', budget=budget,
            manifest_sha256=file_hash(manifest_path),
            note='Offline access probes; shared solved demonstrations; test scenes never collected.'), indent=2))


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    freeze_parser = sub.add_parser('freeze')
    freeze_parser.add_argument('--out', type=Path, required=True)
    freeze_parser.add_argument('--seed', type=int, default=20260911)
    freeze_parser.add_argument('--train', type=int, default=240)
    freeze_parser.add_argument('--val', type=int, default=80)
    freeze_parser.add_argument('--test', type=int, default=80)
    freeze_parser.add_argument('--exclude-manifest', type=Path, action='append', default=[])
    collector = sub.add_parser('collect')
    collector.add_argument('--manifest', type=Path, required=True)
    collector.add_argument('--out', type=Path, required=True)
    collector.add_argument('--budget', type=int, default=12)
    collector.add_argument('--workers', type=int, default=8)
    a = ap.parse_args(argv)
    if a.cmd == 'collect':
        collect(a.manifest, a.out, a.budget, a.workers)
        return
    exclusions = []
    for p in a.exclude_manifest:
        exclusions.extend(excluded_identities(p))
    manifest = freeze(a.seed, a.train, a.val, a.test, exclusions)
    manifest['exclusion_sources'] = {str(p): file_hash(p) for p in a.exclude_manifest}
    validate(manifest)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    with a.out.open('x') as f:
        json.dump(manifest, f, indent=2)
    print(file_hash(a.out))


if __name__ == '__main__':
    main()
