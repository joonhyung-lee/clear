"""Generate shared BC/CLEAR demonstrations with offline physical access probes."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path

import numpy as np

from experiments.exp2.access_teacher import AccessTeacher
from experiments.exp2.dataset import DATA_SCHEMA, encode, target_code, _object_index, attach_suffix_targets
from experiments.exp2.evaluate_full import reset_scene
from experiments.exp2.scene_bridge import make_env, read_state, goal_satisfied, run_interaction


def episode(job):
    split,index,spec,seed,budget = job
    env,oracles = make_env(seed=seed)
    try:
        ob,info,goal = reset_scene(env,spec,seed*100003+index)
        teacher = AccessTeacher(env,oracles)
        rows,trace = [],[]
        for _ in range(budget):
            state = read_state(info)
            if goal_satisfied(state,goal):break
            labels = teacher.labels(state,goal)
            target = teacher.act(state,goal)
            if target is None:break
            rows.append(dict(object_features=encode(env,state,goal),choice=_object_index(target),
                             target_code=target_code(target),affordance_target=labels,scene_id=index))
            trace.append(dict(object=target[0],target=np.asarray(target[1]).tolist()))
            ob,info,trunc = run_interaction(env,oracles,target,ob,info)
            if trunc:break
        attach_suffix_targets(rows)
        success = goal_satisfied(read_state(info),goal)
        return split,index,rows,dict(success=success,decisions=len(rows),probes=teacher.probes,
                                     blocked=teacher.blocked,trace=trace)
    finally:
        env.close()


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest',type=Path,default=Path('runs/exp2_full/data/manifest.json'))
    ap.add_argument('--out',type=Path,default=Path('runs/exp2_improvement/access_data'))
    ap.add_argument('--workers',type=int,default=8)
    ap.add_argument('--seed',type=int,default=0)
    ap.add_argument('--budget',type=int,default=12)
    args=ap.parse_args(argv)
    original=args.manifest.read_text().strip();manifest=json.loads(original)
    manifest['demonstration_protocol']=dict(method='window-access-counterfactual-v1',seed=args.seed,
        budget=args.budget,source_manifest_sha256=hashlib.sha256(original.encode()).hexdigest(),
        note='Same scenes/goals; physical queries are offline supervision only.')
    raw=json.dumps(manifest,sort_keys=True,separators=(',',':'))
    digest=hashlib.sha256(raw.encode()).hexdigest()
    args.out.mkdir(parents=True,exist_ok=True);(args.out/'manifest.json').write_text(raw+'\n')
    jobs=[(split,i,spec,args.seed,args.budget) for split,specs in manifest['splits'].items() for i,spec in enumerate(specs)]
    rows={k:[] for k in manifest['splits']};reports={k:[] for k in rows}
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for split,index,episode_rows,report in pool.map(episode,jobs):
            reports[split].append(dict(scene=index,**report))
            if report['success']:rows[split].extend(episode_rows)
            if (index+1)%40==0:print(split,index+1,'scenes complete',flush=True)
    for split,data in rows.items():
        if not data:raise ValueError(f'no solved demonstration for {split}')
        arrays={k:np.asarray([r[k] for r in data]) for k in data[0]}
        np.savez_compressed(args.out/f'{split}.npz',schema=np.array(DATA_SCHEMA),
                            manifest_sha256=np.array(digest),**arrays)
    report=dict(manifest_sha256=digest,decisions={k:len(v) for k,v in rows.items()},scenes=reports)
    (args.out/'generation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(decisions=report['decisions'],success={k:sum(r['success'] for r in v)/len(v) for k,v in reports.items()})),flush=True)


if __name__=='__main__':main()
