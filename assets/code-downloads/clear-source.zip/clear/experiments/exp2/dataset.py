"""Decision-level training data for the scene sequencer (exp2_scene).

One example per DECISION, not per episode: the reference sequencer is run in
the simulator and every `(observed state, goal) -> chosen (object, target)` is
logged. Labels are therefore **grounded** — each one was executed and the
episode it belongs to is marked solved or not, so unsolved episodes can be
dropped rather than trusted.

Shared by every learned arm (CLEAR and goal-conditioned BC), which is the
review's contract: same observations, same data, same target representation.

    python3 experiments/exp2/dataset.py --out experiments/exp2/data_shared

Token layout, per object, in `OBJECTS` order (cube, button_0, button_1,
drawer, window). `object_features` is 18 wide:

    [0:5]   one-hot kind
    [5:8]   current state, padded  (button bit | slide pos | cube xyz)
    [8:11]  goal state, padded
    [11:14] goal minus current
    [14]    already at goal
    [15]    drawer-corrected cube goal, y only (0 for non-cube tokens)
    [16:18] this object's slice of the observed lock binding

There is no computed `locked` input feature. The gate matrix and button states
are observations; current precondition labels supervise the affordance head
only. The drawer correction of `cube_target_now` is observed kinematics.
`plan_target_code` holds each object's NEXT executed target in the suffix,
including intermediate drawer states. It is supervision only, never an input.

`rank` is the position of each object's NEXT occurrence in the reference's
remaining plan, `-1` if it never appears again. Not a whole-episode order: one
object can be touched twice (`task2` presses a button twice), so the label is
the suffix order from the current state and the sequencer is re-queried after
every interaction.
"""

import argparse
import pathlib
import sys

import numpy as np

sys.path.insert(0, '.')

from experiments.exp2.scene_bridge import OBJECTS, TOL_CUBE, TOL_SLIDE, cube_target_now, goal_satisfied, in_drawer_at, make_env, read_state, reference_sequencer, resolve_goal, run_interaction, set_scene_init, set_target, precondition_violation
from experiments.exp2.splits import make_splits, manifest_json

OBJECT_FEATURES = 18
TARGET_DIM = 3
DATA_SCHEMA = 'clear-scene-suffix-affordance-v1'
KIND_OF = {'cube': 0, 'button_0': 1, 'button_1': 2, 'drawer': 3, 'window': 4}


def _slots(kind, buttons, drawer, window, cube):
    """The 3-wide state slot for one object token."""
    if kind == 'cube':
        return np.asarray(cube, dtype=float)
    if kind == 'button_0':
        return np.array([buttons[0], 0.0, 0.0])
    if kind == 'button_1':
        return np.array([buttons[1], 0.0, 0.0])
    if kind == 'drawer':
        return np.array([drawer, 0.0, 0.0])
    return np.array([window, 0.0, 0.0])


def encode(env, state, goal):
    """(5, OBJECT_FEATURES) object tokens for one decision."""
    from experiments.exp2.binding import binding_of, features as gate_features

    g_buttons, g_drawer, g_window, g_cube = goal
    gates = gate_features(binding_of(env))
    rows = []
    for kind in OBJECTS:
        cur = _slots(kind, state['buttons'], state['drawer'], state['window'], state['cube'])
        tar = _slots(kind, g_buttons, g_drawer, g_window, g_cube)
        tol = TOL_CUBE if kind == 'cube' else (TOL_SLIDE if kind in ('drawer', 'window') else 0.5)
        at_goal = float(np.linalg.norm(cur - tar) <= tol)
        corrected = 0.0
        if kind == 'cube' and in_drawer_at(env.unwrapped, g_cube, g_drawer):
            corrected = float(cube_target_now(env.unwrapped, g_cube, g_drawer)[1])
        one_hot = np.eye(len(OBJECTS))[KIND_OF[kind]]
        rows.append(np.concatenate([one_hot, cur, tar, tar - cur, [at_goal], [corrected],
                                    _gate_row(gates, kind)]))
    return np.stack(rows).astype(np.float32)


def _gate_row(gates, kind):
    """This token's slice of the lock binding: two numbers.

    A button token carries which slides IT gates; a slide token carries which
    buttons gate IT; the cube carries zeros. Handing the relation over as an
    input is the point of `binding.py` -- with it fixed, "button 0 gates the
    drawer" is a constant of the environment and a table over the state
    booleans alone answers everything (README section 2d, 0.955).
    """
    if kind == 'button_0':
        return gates[0]
    if kind == 'button_1':
        return gates[1]
    if kind == 'drawer':
        return gates[:, 0]
    if kind == 'window':
        return gates[:, 1]
    return np.zeros(2, np.float32)


def target_code(target):
    """The (3,) desired-state code for the chosen object.

    Buttons carry no parameter (pressing toggles), slides carry a scalar, the
    cube carries xyz — one width, masked per kind at training time.
    """
    kind, spec = target
    if kind == 'button':
        return np.zeros(TARGET_DIM, np.float32)
    if kind == 'cube':
        return np.asarray(spec, dtype=np.float32)
    return np.array([float(spec), 0.0, 0.0], np.float32)


def _object_index(target):
    kind, spec = target
    return KIND_OF['cube' if kind == 'cube' else
                   f'button_{int(spec)}' if kind == 'button' else kind]


def _suffix_rank(plan_indices):
    """Position of each object's NEXT occurrence in the remaining plan, -1 if absent."""
    rank = np.full(len(OBJECTS), -1, np.int64)
    seen, pos = set(), 0
    for idx in plan_indices:
        if idx not in seen:
            rank[idx] = pos
            seen.add(idx)
            pos += 1
    return rank


def attach_suffix_targets(rows):
    for k, row in enumerate(rows):
        row['rank'] = _suffix_rank([r['choice'] for r in rows[k:]])
        targets = np.zeros((len(OBJECTS), TARGET_DIM), np.float32)
        seen = set()
        for future in rows[k:]:
            i = future['choice']
            if i not in seen:
                targets[i] = future['target_code']
                seen.add(i)
        row['plan_target_code'] = targets


def affordance_labels(env, state, goal):
    queries = [('cube', goal[3]), ('button', 0), ('button', 1),
               ('drawer', goal[1]), ('window', goal[2])]
    return np.asarray([precondition_violation(env, state, goal, target) is None
                       for target in queries], np.float32)


def episode(env, oracles, spec, budget=12, reset_seed=0):
    """Run the reference on one spec, returning its decisions and the outcome."""
    env.reset(seed=reset_seed)
    np.random.seed(reset_seed)
    set_scene_init(env, spec['init'])
    goal = resolve_goal(env, spec)
    u = env.unwrapped
    ob, info = u.compute_observation(), u.get_reset_info()

    rows, chosen = [], []
    for _ in range(budget):
        state = read_state(info)
        if goal_satisfied(state, goal):
            break
        target = reference_sequencer(env, state, goal)
        if target is None:
            break
        rows.append(dict(object_features=encode(env, state, goal),
                         choice=_object_index(target),
                         target_code=target_code(target),
                         affordance_target=affordance_labels(env, state, goal)))
        chosen.append(_object_index(target))
        ob, info, trunc = run_interaction(env, oracles, target, ob, info)
        if trunc:
            break

    # rank label needs the whole plan, so it is filled in after the roll-out
    attach_suffix_targets(rows)
    return rows, goal_satisfied(read_state(info), goal)


def build(out_dir, seed=0, per_split=None, budget=12, keep_failed=False):
    env, oracles = make_env(seed=seed)
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    report = []
    splits = make_splits(seed=seed, per_split=per_split)
    manifest = manifest_json(splits)
    (out / 'manifest.json').write_text(manifest + '\n')
    import hashlib
    manifest_hash = hashlib.sha256(manifest.encode()).hexdigest()
    for name, specs in splits.items():
        rows, solved = [], 0
        for i, spec in enumerate(specs):
            np.random.seed(seed * 100003 + i)      # the oracles' global motion draw
            ep, ok = episode(env, oracles, spec, budget, reset_seed=seed * 100003 + i)
            for row in ep:
                row['scene_id'] = i
            solved += ok
            if ok or keep_failed:
                rows.extend(ep)
        if not rows:
            report.append(f'  {name:12s} EMPTY -- no episode solved')
            continue
        np.savez_compressed(
            out / f'{name}.npz',
            schema=np.array(DATA_SCHEMA),
            manifest_sha256=np.array(manifest_hash),
            scene_id=np.array([r['scene_id'] for r in rows]),
            object_features=np.stack([r['object_features'] for r in rows]),
            rank=np.stack([r['rank'] for r in rows]),
            choice=np.array([r['choice'] for r in rows], np.int64),
            target_code=np.stack([r['target_code'] for r in rows]),
            plan_target_code=np.stack([r['plan_target_code'] for r in rows]),
            affordance_target=np.stack([r['affordance_target'] for r in rows]))
        report.append(f'  {name:12s} {len(specs):4d} scenes, reference solved '
                      f'{solved / len(specs):.2f}, {len(rows):5d} decisions')
    print(f'objects {OBJECTS}\nfeatures {OBJECT_FEATURES}, target dim {TARGET_DIM}')
    print('\n'.join(report))
    return out


def demo():
    """One scene end to end: labels must be grounded and shaped as documented."""
    env, oracles = make_env(seed=0)
    spec = make_splits(seed=0, per_split=4)['train'][0]
    rows, ok = episode(env, oracles, spec)
    assert rows, 'reference produced no decision'
    r = rows[0]
    assert r['object_features'].shape == (len(OBJECTS), OBJECT_FEATURES), r['object_features'].shape
    assert r['rank'].shape == (len(OBJECTS),) and r['rank'].max() >= 0
    assert r['rank'][r['choice']] == 0, 'the chosen object must be rank 0 of its own decision'
    assert r['target_code'].shape == (TARGET_DIM,)
    # no locked feature: the button rows must not encode what they gate
    assert r['object_features'].shape[1] == OBJECT_FEATURES
    print(f'ok  {len(rows)} decisions, solved={ok}, '
          f'first rank {r["rank"].tolist()}, chose {OBJECTS[r["choice"]]}')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='experiments/exp2/data_shared')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--per-split', type=int, default=None)
    ap.add_argument('--budget', type=int, default=12)
    ap.add_argument('--demo', action='store_true')
    a = ap.parse_args()
    if a.demo:
        demo()
    else:
        build(a.out, a.seed, a.per_split, a.budget)
