"""Verify evaluation provenance and append fixed, disjoint confirmation scenes."""
import argparse
import hashlib
import json
from pathlib import Path

from experiments.exp2.splits import SPLIT_SCHEMA, make_splits


def read_manifest(path):
    raw = path.read_text().strip()
    data = json.loads(raw)
    if data.get('schema') != SPLIT_SCHEMA:
        raise ValueError('expected the versioned stable scene manifest')
    return data, hashlib.sha256(raw.encode()).hexdigest()


def validate_manifest(path, checkpoint_hash=None, training_path=None):
    manifest, digest = read_manifest(path)
    if training_path is None:
        if checkpoint_hash is not None and checkpoint_hash != digest:
            raise ValueError('checkpoint training manifest differs from evaluation manifest')
        return manifest, digest, checkpoint_hash
    training, parent = read_manifest(training_path)
    if checkpoint_hash is not None and checkpoint_hash != parent:
        raise ValueError('checkpoint does not match the supplied training manifest')
    if manifest.get('parent_manifest_sha256') != parent:
        raise ValueError('confirmation manifest must identify its exact training parent')
    for name, scenes in training['splits'].items():
        if manifest['splits'].get(name) != scenes:
            raise ValueError('all original training/development splits must remain unchanged')
    return manifest, digest, parent


def confirmation_manifest(training_path, seed=20260910, count=40):
    if count < 1:
        raise ValueError('confirmation scene count must be positive')
    training, digest = read_manifest(training_path)
    # Normalize NumPy arrays/tuples once so exact scene identities are comparable.
    candidates = json.loads(json.dumps(make_splits(seed, per_split=8 * count),
                                       default=lambda x: x.tolist()))
    key = lambda spec: json.dumps(spec, sort_keys=True, separators=(',', ':'))
    seen = {key(spec) for scenes in training['splits'].values() for spec in scenes}
    for source, destination in [('val', 'confirm_seen'), ('test_binding', 'confirm_binding')]:
        chosen = []
        for spec in candidates[source]:
            identity = key(spec)
            if identity in seen:
                continue
            chosen.append(spec)
            seen.add(identity)
            if len(chosen) == count:
                break
        if len(chosen) != count:
            raise ValueError('fixed candidate pool did not contain enough disjoint scenes')
        training['splits'][destination] = chosen
    training.update(parent_manifest_sha256=digest, confirmation_seed=seed,
                    confirmation_count_per_split=count)
    return training


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--training-manifest', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--seed', type=int, default=20260910)
    ap.add_argument('--count', type=int, default=40)
    a = ap.parse_args()
    manifest = confirmation_manifest(a.training_manifest, a.seed, a.count)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(manifest, sort_keys=True, separators=(',', ':')) + '\n')
    _, digest, parent = validate_manifest(a.out, training_path=a.training_manifest)
    print(json.dumps(dict(manifest_sha256=digest, training_manifest_sha256=parent,
                          seed=a.seed, count_per_split=a.count)))


if __name__ == '__main__':
    main()
