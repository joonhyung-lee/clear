"""Drive `ogbench`'s `scene-v0` from an explicit interaction sequence (exp2_scene).

`ogbench` splits the scene task in exactly the place CLEAR needs:

    which object to interact with   `env.set_new_target()` -- RANDOM in the
                                    shipped data-collection loop
    how to do it                    `oracles/{markov,plan}/*` -- scripted
                                    task-space controllers, one per object kind

`generate_manipspace.py` picks the target at random and lets the oracle execute.
This module replaces the random picker with an explicit one, so a sequencer --
`reference_sequencer` here, CLEAR's priority head later -- decides the ORDER
while `ogbench`'s own controllers stay the executor. Nothing about the arm,
the gripper or the contact model is reimplemented.

The env must run in `mode='data_collection'`: only that mode publishes the
`privileged/target_*` keys the oracles read.
"""

import mujoco
import numpy as np

TOL_SLIDE = 0.04        # scene_env._compute_successes uses this for drawer/window
TOL_CUBE = 0.04         # and this for the cube
DRAWER_OPEN = -0.16
DRAWER_SHUT = 0.0
WINDOW_OPEN = 0.2
WINDOW_SHUT = 0.0
OBJECTS = ('cube', 'button_0', 'button_1', 'drawer', 'window')
MAX_STEPS_PER_INTERACTION = 300


def make_env(max_episode_steps=2000, seed=0, width=200, height=200):
    """`scene-v0` in data-collection mode, plus the four scripted oracles."""
    import gymnasium

    import ogbench.manipspace  # noqa: F401  (registers the ids)
    from ogbench.manipspace.oracles.markov.button_markov import ButtonMarkovOracle
    from ogbench.manipspace.oracles.markov.cube_markov import CubeMarkovOracle
    from ogbench.manipspace.oracles.markov.drawer_markov import DrawerMarkovOracle
    from ogbench.manipspace.oracles.markov.window_markov import WindowMarkovOracle

    env = gymnasium.make('scene-v0', terminate_at_goal=False, mode='data_collection',
                         max_episode_steps=max_episode_steps, width=width, height=height)
    # `task_infos` is only built in 'task' mode; the goals are static data, so
    # populate them here to read the same 5 task specs in data-collection mode
    env.unwrapped.set_tasks()
    env.unwrapped.num_tasks = len(env.unwrapped.task_infos)
    env.reset(seed=seed)
    oracles = {
        'cube': CubeMarkovOracle(env=env, min_norm=0.4, max_step=100),
        'button': ButtonMarkovOracle(env=env, min_norm=0.4),
        'drawer': DrawerMarkovOracle(env=env, min_norm=0.4),
        'window': WindowMarkovOracle(env=env, min_norm=0.4),
    }
    return env, oracles


def task_goal(env, task_idx):
    """The `(buttons, drawer, window, cube_xyz)` goal of one of scene's 5 tasks."""
    g = env.unwrapped.task_infos[task_idx]['goal']
    return (np.asarray(g['button_states']).copy(), float(g['drawer_pos']),
            float(g['window_pos']), np.asarray(g['block_xyzs'][0]).copy())


def set_task_init(env, task_idx):
    """Force the scene to a task's INIT state while staying in data-collection
    mode -- `initialize_episode` only does this in 'task' mode, which does not
    publish the target keys the oracles need."""
    from ogbench.manipspace import lie

    u = env.unwrapped
    init = u.task_infos[task_idx]['init']
    u.initialize_arm()
    for i in range(u._num_cubes):
        u._data.joint(f'object_joint_{i}').qpos[:3] = init['block_xyzs'][i]
        u._data.joint(f'object_joint_{i}').qpos[3:] = lie.SO3.identity().wxyz.tolist()
        u._data.joint(f'object_joint_{i}').qvel[:] = 0.0
    u._cur_button_states = np.asarray(init['button_states']).copy()
    u._apply_button_states()
    u._data.joint('drawer_slide').qpos[0] = init['drawer_pos']
    u._data.joint('window_slide').qpos[0] = init['window_pos']
    u._data.joint('drawer_slide').qvel[0] = 0.0
    u._data.joint('window_slide').qvel[0] = 0.0
    mujoco.mj_forward(u._model, u._data)


def drawer_site_y(u, qpos=None):
    """y of the drawer interior reference at slide position `qpos`.

    The site is affine in the slide (it moves -1 in y per unit of qpos), so the
    pose at any slide position is read off the CURRENT measurement rather than
    hardcoding the mesh offsets.
    """
    now = float(u._data.joint('drawer_slide').qpos[0])
    y_now = float(u._data.site_xpos[u._drawer_site_id][1])
    return y_now if qpos is None else y_now + (now - qpos)


def in_drawer_at(u, xyz, drawer_qpos):
    """`scene_env._is_in_drawer`, but evaluated at an arbitrary slide position
    instead of only the current one."""
    y = drawer_site_y(u, drawer_qpos)
    low = np.array([0.21, y - 0.27, 0.0])
    high = np.array([0.45, y - 0.07, 0.15])
    return bool(np.all(low <= xyz) and np.all(xyz <= high))


# scene's own task4/5 goals put the cube at y = -0.356 with the drawer SHUT,
# where the handle site sits at y = -0.240 -- so the in-drawer goal is the site
# minus this, and reusing the offset keeps generated scenes identical in kind to
# the shipped ones instead of guessing a depth
IN_DRAWER_OFFSET = np.array([0.33, -0.116, 0.065986])


def in_drawer_goal(u, drawer_qpos=DRAWER_SHUT):
    """The cube's in-drawer goal position at a given slide position."""
    out = IN_DRAWER_OFFSET.copy()
    out[1] += drawer_site_y(u, drawer_qpos)
    return out


def set_scene_init(env, spec):
    """Force the scene to an arbitrary init spec (see exp2_scene/splits.py).

    The generalisation of `set_task_init`, which can only replay one of the five
    shipped `task_infos` entries.
    """
    from ogbench.manipspace import lie

    from experiments.exp2.binding import SHIPPED, install

    u = env.unwrapped
    install(env, spec.get('binding', SHIPPED))
    u.initialize_arm()
    u._data.joint('object_joint_0').qpos[:3] = np.asarray(spec['cube'], dtype=float)
    u._data.joint('object_joint_0').qpos[3:] = lie.SO3.identity().wxyz.tolist()
    u._data.joint('object_joint_0').qvel[:] = 0.0
    u._cur_button_states = np.asarray(spec['buttons']).copy()
    u._apply_button_states()
    u._data.joint('drawer_slide').qpos[0] = float(spec['drawer'])
    u._data.joint('window_slide').qpos[0] = float(spec['window'])
    u._data.joint('drawer_slide').qvel[0] = 0.0
    u._data.joint('window_slide').qvel[0] = 0.0
    mujoco.mj_forward(u._model, u._data)


def resolve_goal(env, spec):
    """A spec's goal as the `(buttons, drawer, window, cube)` tuple the rest of
    the harness speaks. Resolves the `'in_drawer'` sentinel against geometry."""
    g = spec['goal']
    cube = g['cube']
    if isinstance(cube, str):
        assert cube == 'in_drawer', cube
        cube = in_drawer_goal(env.unwrapped, float(g['drawer']))
    return (np.asarray(g['buttons']).copy(), float(g['drawer']), float(g['window']),
            np.asarray(cube, dtype=float).copy())


def set_target(env, target):
    """The deterministic counterpart of `set_new_target`.

    `target` is `('button', k)`, `('drawer', pos)`, `('window', pos)` or
    `('cube', xyz)`. Writes the same `_target_*` fields and target sites that
    the random picker writes, so the oracles are driven unmodified.
    """
    from ogbench.manipspace import lie

    u = env.unwrapped
    kind, spec = target
    if kind == 'button':
        u._target_task = 'button'
        u._target_button = int(spec)
        u._target_button_states[int(spec)] = (
            u._cur_button_states[int(spec)] + 1) % u._num_button_states
    elif kind == 'drawer':
        u._target_task = 'drawer'
        u._target_drawer_pos = float(spec)
        u._model.site('drawer_handle_center_target').pos[1] = float(spec)
    elif kind == 'window':
        u._target_task = 'window'
        u._target_window_pos = float(spec)
        u._model.site('window_handle_center_target').pos[0] = float(spec)
    elif kind == 'cube':
        u._target_task = 'cube'
        u._target_block = 0
        mid = u._cube_target_mocap_ids[0]
        u._data.mocap_pos[mid] = np.asarray(spec, dtype=float)
        u._data.mocap_quat[mid] = lie.SO3.identity().wxyz.tolist()
    else:
        raise ValueError(f'unknown target kind: {kind}')
    mujoco.mj_kinematics(u._model, u._data)
    return u.compute_observation(), u.get_reset_info()


def run_interaction(env, oracles, target, ob, info):
    """Hand one target to `ogbench`'s oracle and let it drive to completion."""
    ob, info = set_target(env, target)
    agent = oracles['button' if target[0] == 'button' else target[0]]
    agent.reset(ob, info)
    trunc = False
    for _ in range(MAX_STEPS_PER_INTERACTION):
        ob, _, term, trunc, info = env.step(
            np.clip(np.asarray(agent.select_action(ob, info)), -1, 1))
        if agent.done or term or trunc:
            break
    return ob, info, trunc


def read_state(info):
    """The five interactable objects, as plain numbers."""
    return dict(
        buttons=np.array([int(info['privileged/button_0_state']),
                          int(info['privileged/button_1_state'])]),
        drawer=float(info['privileged/drawer_pos'][0]),
        window=float(info['privileged/window_pos'][0]),
        cube=np.asarray(info['privileged/block_0_pos'], dtype=float).copy(),
    )


def goal_satisfied(state, goal):
    g_buttons, g_drawer, g_window, g_cube = goal
    return bool(np.all(state['buttons'] == g_buttons)
                and abs(state['drawer'] - g_drawer) <= TOL_SLIDE
                and abs(state['window'] - g_window) <= TOL_SLIDE
                and np.linalg.norm(state['cube'] - g_cube) <= TOL_CUBE)


def cube_target_now(u, goal_cube, goal_drawer):
    """Where to release the cube RIGHT NOW so it ends at `goal_cube`.

    A cube inside the drawer rides with it, and the task goals record the cube
    at the GOAL slide position -- task4's `[0.33, -0.356, 0.066]` is in the
    drawer only when the drawer is shut. Aiming at that world point while the
    drawer is open drops the cube behind the drawer and the plan loops forever
    (the failure this function fixes). The slide moves the interior by exactly
    the change in `drawer_slide`, so the correction is one term.
    """
    now = float(u._data.joint('drawer_slide').qpos[0])
    out = np.asarray(goal_cube, dtype=float).copy()
    out[1] += goal_drawer - now
    return out


def reference_sequencer(env, state, goal, rng=None):
    """Minimum-interaction order that respects scene's own preconditions.

    The precedence is the whole point of the task: button 0 locks the drawer
    (`scene_env._apply_button_states` sets `drawer_slide` damping to 1e6) and
    button 1 locks the window, so a slide that has to move needs its button
    pressed FIRST, and the buttons are restored LAST because unlocking moves
    them off their own goal.

    Closed loop on purpose -- it takes the observed state, not a plan, so it is
    the exact interface CLEAR's priority head has to implement.
    """
    from experiments.exp2.binding import binding_of, gated_by

    u = env.unwrapped
    g_buttons, g_drawer, g_window, g_cube = goal
    binding = binding_of(env)

    def unlock(slide_idx):
        """The next button to press to free this slide, or None if it is free.

        Reads the binding instead of assuming button 0 gates the drawer: under
        a per-episode binding that assumption is exactly the memorised row the
        experiment is removing (see `binding.py`). A slide is free only when
        every button gating it is pressed, so this returns them one at a time
        and the closed loop works through them.
        """
        for b in gated_by(binding, slide_idx):
            if state['buttons'][b] == 0:
                return ('button', b)
        return None

    # 1. Cube first. A put-in-drawer goal needs the drawer OPEN to insert, and
    #    the slide step below then carries the cube to its recorded goal pose --
    #    closing before the cube is in would undo the work.
    if in_drawer_at(u, g_cube, g_drawer):
        if not in_drawer_at(u, state['cube'], state['drawer']):
            if abs(state['drawer'] - DRAWER_OPEN) > TOL_SLIDE:
                return unlock(0) or ('drawer', DRAWER_OPEN)
            return ('cube', cube_target_now(u, g_cube, g_drawer))
    elif np.linalg.norm(state['cube'] - g_cube) > TOL_CUBE:
        return ('cube', g_cube)

    # 2. Slides, each gated by its own lock button.
    if abs(state['drawer'] - g_drawer) > TOL_SLIDE:
        return unlock(0) or ('drawer', g_drawer)
    if abs(state['window'] - g_window) > TOL_SLIDE:
        return unlock(1) or ('window', g_window)

    # 3. Buttons last.
    for i in (0, 1):
        if state['buttons'][i] != g_buttons[i]:
            return ('button', i)
    return None


def random_sequencer(env, state, goal, rng=None):
    """Object choice at random, but every TARGET computed the same way the
    reference does -- including the drawer correction of `cube_target_now`.

    Without that the arm would also be handicapped on target accuracy, and a
    gap against it could not be attributed to ordering (the confound in the
    first version of this file: it returned the raw final `goal[3]`, which is
    unreachable while the drawer is open). Now the arms differ in WHICH object
    and in WHAT ORDER, and in nothing else.
    """
    rng = np.random.default_rng() if rng is None else rng
    kind = ['cube', 'button', 'drawer', 'window'][int(rng.integers(4))]
    if kind == 'button':
        return ('button', int(rng.integers(2)))
    if kind == 'drawer':
        return ('drawer', DRAWER_SHUT if state['drawer'] < -0.08 else DRAWER_OPEN)
    if kind == 'window':
        return ('window', WINDOW_OPEN if state['window'] <= 0.1 else WINDOW_SHUT)
    return ('cube', cube_target_now(env.unwrapped, goal[3], goal[1]))


def precondition_violation(env, state, goal, target):
    """Does this interaction attempt something the scene forbids right now?

    Three cases, all of them the lock structure `_apply_button_states` builds:
    moving the drawer while button 0 leaves it locked, moving the window while
    button 1 leaves it locked, and releasing the cube at an in-drawer goal
    while the drawer is not open. Reported as a rate alongside executed
    success, because a plan can stumble into the goal while still violating
    preconditions and paying for it in interactions.
    """
    from experiments.exp2.binding import binding_of, is_unlocked

    binding = binding_of(env)
    kind, spec = target
    if kind == 'drawer' and not is_unlocked(binding, state['buttons'], 0):
        return 'drawer locked'
    if kind == 'window' and not is_unlocked(binding, state['buttons'], 1):
        return 'window locked'
    if kind == 'cube' and in_drawer_at(env.unwrapped, goal[3], goal[1]):
        if abs(state['drawer'] - DRAWER_OPEN) > TOL_SLIDE:
            return 'drawer not open for cube'
    return None
