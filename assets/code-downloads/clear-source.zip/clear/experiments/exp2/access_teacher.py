"""Offline demonstration repair for window-blocked cube access.

This teacher may query physics during data generation. Learned evaluation
never calls it. It changes neither task goals nor the low-level controller.
"""
import mujoco
import numpy as np

from experiments.exp2.binding import binding_of, gated_by
from experiments.exp2.dataset import affordance_labels
from experiments.exp2.scene_bridge import WINDOW_OPEN, TOL_SLIDE, TOL_CUBE, cube_target_now, in_drawer_at, precondition_violation, read_state, reference_sequencer, run_interaction
from experiments.exp2.sumo_executor import SceneSnapshot


class AccessTeacher:
    def __init__(self, env, oracles):
        self.env, self.oracles = env, oracles
        self.cache = {}
        self.probes = 0
        self.blocked = 0

    def blocked_cube(self, state, goal):
        """Does opening the window rescue an otherwise failing cube move?"""
        env, u = self.env, self.env.unwrapped
        if (np.linalg.norm(state['cube']-goal[3]) <= TOL_CUBE
                or abs(state['window']-WINDOW_OPEN) <= TOL_SLIDE):
            return False
        xyz = cube_target_now(u,goal[3],goal[1]) if in_drawer_at(u,goal[3],goal[1]) else goal[3]
        target = ('cube',xyz)
        if precondition_violation(env,state,goal,target) is not None:
            return False  # Existing logical supervision handles this prerequisite.
        key = np.r_[u._data.qpos,state['buttons'],xyz].tobytes()
        if key in self.cache:
            return self.cache[key]
        snapshot = SceneSnapshot(env,self.oracles['cube'])

        def succeeds():
            ob, info = u.compute_observation(),u.get_reset_info()
            _, final, _ = run_interaction(env,self.oracles,target,ob,info)
            return np.linalg.norm(read_state(final)['cube']-xyz) <= TOL_CUBE

        blocked = False
        try:
            self.probes += 1
            if not succeeds():
                snapshot.restore(env,self.oracles['cube'])
                u._data.joint('window_slide').qpos[0] = WINDOW_OPEN
                u._data.joint('window_slide').qvel[0] = 0.
                mujoco.mj_forward(u._model,u._data)
                blocked = bool(succeeds())
        finally:
            snapshot.restore(env,self.oracles['cube'])
        self.cache[key] = blocked
        self.blocked += int(blocked)
        return blocked

    def labels(self,state,goal):
        labels = affordance_labels(self.env,state,goal)
        if self.blocked_cube(state,goal):
            labels[0] = 0.
        return labels

    def act(self,state,goal):
        if self.blocked_cube(state,goal):
            # Execute the prerequisites normally. Counterfactual states above
            # provide labels only; none are installed into a real demonstration.
            for button in gated_by(binding_of(self.env),1):
                if state['buttons'][button] == 0:
                    return ('button',button)
            return ('window',WINDOW_OPEN)
        return reference_sequencer(self.env,state,goal)
