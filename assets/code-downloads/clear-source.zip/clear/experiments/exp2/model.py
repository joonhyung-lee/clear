"""CLEAR scene adapter: learned preconditions, latent order, causal target flow.

The fixed body, observed scene and task-specific target codec are adapters;
the morphology/affordance head and rank-causal flow are shared CLEAR modules.
The legacy direct-regression network remains an explicit BC baseline. It is
not parameter-matched to full CLEAR and is not an ordering-only ablation.
"""

import sys
import numpy as np

import torch
from torch import nn
from torch.nn import functional as F

sys.path.insert(0, '.')

from clear.model.clear import OrderingHead, SharedEncoder
from clear.model.clear import AffordanceConditionedCore

from experiments.exp2.dataset import OBJECT_FEATURES, TARGET_DIM
from experiments.exp2.scene_bridge import OBJECTS
from experiments.exp2.target_codec import FRAMES, SceneTargetCodec

N_OBJECTS = len(OBJECTS)
SCENE_FEATURES = 1          # fixed body, fixed table: one constant context token
STRUCTURE_FEATURES = 1      # one row, one body -- keeps the core's interface


class LegacySceneSequencerNet(nn.Module):
    def __init__(self, dim=128, depth=3, heads=4, arm='clear', mu_scale=1.0, target_frame='absolute', geometry_skip=False):
        super().__init__()
        assert arm in ('clear', 'bc')
        self.arm = arm
        self.mu_scale = float(mu_scale)
        if target_frame not in FRAMES:
            raise ValueError('unknown target frame')
        self.target_frame = target_frame
        self.target_codec = SceneTargetCodec(target_frame)
        self.config = dict(dim=dim, depth=depth, heads=heads, arm=arm, mu_scale=self.mu_scale,
                           target_frame=target_frame)
        self.encoder = SharedEncoder(dim, OBJECT_FEATURES, SCENE_FEATURES, STRUCTURE_FEATURES,
                                     depth=depth, heads=heads)
        self.ordering = OrderingHead(dim)
        self.choice = nn.Linear(dim, 1)          # BC arm: 5-way over objects
        self.target = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, TARGET_DIM))
        self.geometry_skip = bool(geometry_skip)
        self.config['geometry_skip'] = self.geometry_skip
        if self.geometry_skip:
            self.target[-1] = nn.Linear(dim + OBJECT_FEATURES, TARGET_DIM)

    def batch(self, object_features):
        """Wrap object features in the core's batch contract."""
        b = object_features.shape[0]
        dev = object_features.device
        return dict(
            object_features=object_features,
            object_mask=torch.ones(b, N_OBJECTS, dtype=torch.bool, device=dev),
            scene_features=torch.ones(b, 1, SCENE_FEATURES, device=dev),
            scene_mask=torch.ones(b, 1, dtype=torch.bool, device=dev),
            structure=torch.ones(b, 1, STRUCTURE_FEATURES, device=dev),
            structure_mask=torch.ones(b, 1, dtype=torch.bool, device=dev))

    def forward(self, object_features):
        h = self.encoder(self.batch(object_features))
        objects = h['objects']
        selection, mu, sigma = self.ordering(objects)
        if self.mu_scale:
            mu = torch.tanh(mu) * self.mu_scale
        target = (self.target[-1](torch.cat([self.target[0](objects), object_features], -1))
                  if self.geometry_skip else self.target(objects))
        return dict(selection=selection, mu=mu, sigma=sigma,
                    choice=self.choice(objects).squeeze(-1),
                    target=target + self.target_codec(object_features))

    def loss(self, object_features, rank, choice, target_code):
        out = self.forward(object_features)
        mask = torch.ones_like(rank, dtype=torch.bool)
        parts = {}
        if self.arm == 'clear':
            parts = self.ordering.loss(out['selection'], out['mu'], out['sigma'], rank, mask)
            parts = {k: v for k, v in parts.items()}
            parts['kl'] = parts['kl'] * 0.01
        else:
            parts['choice'] = F.cross_entropy(out['choice'], choice)
        # target supervised only on the object actually chosen, and only on the
        # slots that object uses: buttons carry no parameter at all
        picked = out['target'][torch.arange(len(choice), device=choice.device), choice]
        is_button = (choice == 1) | (choice == 2)
        is_cube = choice == 0
        width = torch.where(is_cube, 3, 1).unsqueeze(1)
        slot = torch.arange(TARGET_DIM, device=choice.device).unsqueeze(0) < width
        slot = slot & (~is_button).unsqueeze(1)
        parts['target'] = (F.mse_loss(picked[slot], target_code[slot])
                           if slot.any() else picked.sum() * 0)
        return sum(parts.values()), {k: float(v.detach()) for k, v in parts.items()}

    @torch.no_grad()
    def plan(self, object_features, generator=None, sample=True):
        """ONE forward pass -> the whole order, plus each object's target.

        This is the capability the open-loop regime scores and the one BC does
        not have: `arm='bc'` carries a per-decision softmax and no order at
        all, so it cannot produce a plan without being rolled out in the
        simulator (which is a different, privileged regime -- see
        `run_scene.py --openloop`).

        Returns `[(object index, (3,) target code), ...]` in execution order,
        or `[]` if the selection head chose nothing. `sample=True` draws the
        selection and the priorities, so repeated calls give different valid
        orders -- the diversity `analyze.py orders` measured (1.60 distinct
        valid first objects per scene).
        """
        if self.arm != 'clear':
            raise NotImplementedError(
                "arm='bc' has no ordering head, so it cannot emit a whole "
                'order from one pass. That asymmetry is the point of the '
                'open-loop comparison, not a gap to paper over.')
        out = self.forward(object_features)
        mask = torch.ones(1, N_OBJECTS, dtype=torch.bool, device=object_features.device)
        rank, _ = self.ordering.sample(out['selection'], out['mu'], out['sigma'], mask,
                                       generator=generator, sample_selection=sample)
        chosen = [(int(rank[0, i]), i) for i in range(N_OBJECTS) if rank[0, i] >= 0]
        return [(i, out['target'][0, i].cpu().numpy()) for _, i in sorted(chosen)]

    @torch.no_grad()
    def act(self, object_features, generator=None):
        """(chosen object index, its (3,) target code) for one state."""
        out = self.forward(object_features)
        if self.arm == 'bc':
            idx = int(out['choice'].argmax(-1)[0])
        else:
            mask = torch.ones(1, N_OBJECTS, dtype=torch.bool, device=object_features.device)
            rank, active = self.ordering.sample(out['selection'], out['mu'], out['sigma'],
                                                mask, generator=generator)
            if not bool(active.any()):
                return None, None
            order = rank[0].clone()
            order[order < 0] = N_OBJECTS + 1     # unselected objects go last
            idx = int(order.argmin())
        return idx, out['target'][0, idx].cpu().numpy()


SCHEMA = 'clear-scene-affordance-causal-v1'


class PlanBCNet(LegacySceneSequencerNet):
    """One-pass structured BC: deterministic order and independent suffix targets.

    Shares observations, suffix labels and information budget with CLEAR. This
    is a learned full-plan baseline, so open-loop evaluation does not rely on
    excluding next-action BC from that protocol.
    """
    def __init__(self, dim=128, depth=4, heads=4, target_frame='absolute', geometry_skip=False, **kwargs):
        super().__init__(dim, depth, heads, arm='clear', mu_scale=0.0, target_frame=target_frame, geometry_skip=geometry_skip)
        self.arm = 'plan_bc'
        self.config = dict(dim=dim, depth=depth, heads=heads, arm=self.arm, target_frame=target_frame, geometry_skip=bool(geometry_skip))

    def loss(self, object_features, rank, choice, target_code, *, plan_target_code=None,
             affordance_target=None):
        from clear.model.ordernet import sampled_priority_rank_loss
        if plan_target_code is None:
            raise ValueError('structured BC requires suffix targets')
        out = self(object_features)
        selected = rank >= 0
        sentinel = rank.masked_fill(~selected, N_OBJECTS)
        parts = dict(selection=F.binary_cross_entropy_with_logits(out['selection'], selected.float()),
                     order=sampled_priority_rank_loss(out['mu'], sentinel, torch.ones_like(selected)))
        slots = torch.zeros_like(plan_target_code, dtype=torch.bool)
        slots[:, 0] = True
        slots[:, 3:, 0] = True
        slots &= selected[..., None]
        parts['target'] = (F.mse_loss(out['target'][slots], plan_target_code[slots])
                           if slots.any() else out['target'].sum() * 0)
        return sum(parts.values()), {k: float(v.detach()) for k, v in parts.items()}

    @torch.no_grad()
    def plan(self, object_features, generator=None, **kwargs):
        out = self(object_features)
        order = out['mu'][0].argsort(stable=True)
        return [(int(i), out['target'][0, i].cpu().numpy()) for i in order if out['selection'][0, i] > 0]

    @torch.no_grad()
    def act(self, object_features, generator=None):
        plan = self.plan(object_features)
        return plan[0] if plan else (None, None)


class SceneSequencerNet(AffordanceConditionedCore):
    """Observed preconditions -> ordering -> order-conditioned target flow.

Each object owns its next-occurrence target. Repeated-object episodes require
closed-loop calls; a whole-order call is valid only for repeat-free episodes.
"""
    def __init__(self, dim=128, depth=4, heads=4, arm='clear', mu_scale=0.0,
                 flow_scale=0.1, flow_weight=1.0, kl_weight=1e-3,
                 availability_weight=0.0, no_affordance=False, causal=True, target_frame='absolute', geometry_skip=False,
                 affordance_context='global', causal_bias_slope=0.0,
                 order_temperature=1.0, availability_bias=0.0):
        if arm != 'clear':
            raise ValueError('use build_model for the explicitly separate BC baseline')
        if affordance_context not in ('global', 'local', 'local_access'):
            raise ValueError('unknown affordance query context')
        query_dim = N_OBJECTS * OBJECT_FEATURES + N_OBJECTS if affordance_context == 'global' else OBJECT_FEATURES + 3
        if affordance_context == 'local_access':
            query_dim += 1
        super().__init__(dim, OBJECT_FEATURES, SCENE_FEATURES, STRUCTURE_FEATURES, TARGET_DIM,
                         query_dim, depth, heads, causal=causal, causal_bias_slope=causal_bias_slope)
        self.affordance_context = affordance_context
        if any(not np.isfinite(v) or v < 0 for v in (order_temperature, availability_bias)):
            raise ValueError('decoding temperature and availability bias must be finite and nonnegative')
        self.order_temperature = float(order_temperature)
        self.availability_bias = float(availability_bias)
        self.arm = arm
        if not np.isfinite(mu_scale) or mu_scale < 0:
            raise ValueError('mu_scale must be finite and nonnegative')
        self.mu_scale = float(mu_scale)
        if not np.isfinite(flow_scale) or flow_scale <= 0:
            raise ValueError('flow_scale must be finite and positive')
        if any(not np.isfinite(w) or w < 0 for w in (flow_weight, kl_weight, availability_weight)):
            raise ValueError('loss weights must be finite and nonnegative')
        self.flow_scale, self.flow_weight = float(flow_scale), float(flow_weight)
        self.kl_weight, self.availability_weight = float(kl_weight), float(availability_weight)
        self.no_affordance = bool(no_affordance)
        if target_frame not in FRAMES:
            raise ValueError('unknown target frame')
        self.target_frame = target_frame
        self.target_codec = SceneTargetCodec(target_frame)
        self.config = dict(dim=dim, depth=depth, heads=heads, arm=arm, mu_scale=self.mu_scale,
                           flow_scale=flow_scale, flow_weight=flow_weight, kl_weight=kl_weight,
                           availability_weight=availability_weight, no_affordance=no_affordance,
                           causal=causal, target_frame=target_frame, geometry_skip=bool(geometry_skip),
                           affordance_context=affordance_context, causal_bias_slope=float(causal_bias_slope))
        self.geometry_skip = bool(geometry_skip)
        # Omit default decoding settings to preserve historical checkpoint configs.
        if order_temperature != 1.0 or availability_bias != 0.0:
            self.config.update(order_temperature=self.order_temperature,
                               availability_bias=self.availability_bias)
        if self.geometry_skip:
            # Preserve the raw observed geometry alongside contextual tokens.
            # This is static information, so every causal rank may read it.
            self.flow.cfg_in[0] = nn.Linear(dim + OBJECT_FEATURES + TARGET_DIM + dim // 2, dim)

    def _encode(self, batch):
        if self.no_affordance:
            # Matched ablation: retain head and supervision, remove its conditioning.
            from clear.model.clear import CLEARCore
            embodiment = self.encoder.structure_in.pool(batch['structure'], batch['structure_mask'])
            queries = batch['affordance_features']
            logits = self.interaction_affordance(embodiment[:, None].expand(-1, queries.shape[1], -1), queries)
            h = CLEARCore._encode(self, dict(batch, navigation_features=
                                            torch.zeros_like(logits)[..., None]))
            h['interaction_affordance_logits'] = logits
        else:
            h = super()._encode(batch)
        if self.mu_scale:
            h['mu'] = torch.tanh(h['mu']) * self.mu_scale
        if self.geometry_skip:
            h['objects'] = torch.cat([h['objects'], batch['object_features']], -1)
        return h

    def flow_loss(self, h, batch, generator=None):
        # Units of the flow's latent code; decoding restores metres. No goal snapping.
        origin = self.target_codec(batch['object_features'])
        return super().flow_loss(h, dict(batch, target_code=(batch['target_code'] - origin) / self.flow_scale), generator)

    @torch.no_grad()
    def generate_targets(self, h, batch, rank, selected, steps=30, generator=None, trace=None):
        """`trace` is passed through to the flow; the scene's own origin and scale are applied to
        each intermediate too, so a traced state is in the same units as the returned target."""
        raw = [] if trace is not None else None
        code = super().generate_targets(h, batch, rank, selected, steps, generator, trace=raw) * self.flow_scale
        origin = self.target_codec(batch['object_features'])
        shift = torch.where(selected[..., None] & batch['target_code_mask'], origin, 0.0)
        if trace is not None:
            trace.extend((t, state * self.flow_scale + shift) for t, state in raw)
        return code + shift

    def batch(self, object_features):
        b, n, f = object_features.shape
        if (n, f) != (N_OBJECTS, OBJECT_FEATURES):
            raise ValueError('scene object-feature schema mismatch; regenerate data and checkpoint')
        device = object_features.device
        if self.affordance_context == 'global':
            queries = torch.cat([object_features.flatten(1)[:, None].expand(-1, n, -1),
                                 torch.eye(n, device=device)[None].expand(b, -1, -1)], -1)
        else:
            # Public per-object geometry/binding plus raw button and drawer states.
            # The head learns their relationship; no computed lock/availability bit.
            shared_state = torch.cat([object_features[:, 1:3, 5], object_features[:, 3, 5:6]], -1)
            if self.affordance_context == 'local_access':
                shared_state = torch.cat([shared_state, object_features[:, 4, 5:6]], -1)
            queries = torch.cat([object_features, shared_state[:, None].expand(-1, n, -1)], -1)
        slots = torch.zeros(b, n, TARGET_DIM, dtype=torch.bool, device=device)
        slots[:, 0, :] = True
        slots[:, 3:, 0] = True
        return dict(object_features=object_features, object_mask=torch.ones(b, n, dtype=torch.bool, device=device),
                    scene_features=torch.ones(b, 1, SCENE_FEATURES, device=device),
                    scene_mask=torch.ones(b, 1, dtype=torch.bool, device=device),
                    structure=torch.ones(b, 1, STRUCTURE_FEATURES, device=device),
                    structure_mask=torch.ones(b, 1, dtype=torch.bool, device=device),
                    affordance_features=queries, target_code_mask=slots)

    def forward(self, object_features):
        h = self._encode(self.batch(object_features))
        return dict(selection=h['selection'], mu=h['mu'], sigma=h['sigma'],
                    affordance_logits=h['interaction_affordance_logits'])

    def loss(self, object_features, rank, choice, target_code, *, plan_target_code=None,
             affordance_target=None):
        if plan_target_code is None or affordance_target is None:
            raise ValueError('full suffix targets and affordance labels required; regenerate the scene dataset')
        batch = self.batch(object_features)
        if plan_target_code.shape != batch['target_code_mask'].shape:
            raise ValueError('one 3D next-occurrence target per object is required')
        if (affordance_target.shape != rank.shape or not torch.isfinite(affordance_target).all()
                or ((affordance_target < 0) | (affordance_target > 1)).any()):
            raise ValueError('one finite binary affordance label per object is required')
        if not torch.allclose(plan_target_code[torch.arange(len(choice), device=choice.device), choice], target_code):
            raise ValueError('chosen target and suffix target disagree')
        batch.update(rank=rank, target_code=plan_target_code, affordance_target=affordance_target)
        h = self._encode(batch)
        parts = self.ordering.loss(h['selection'], h['mu'], h['sigma'], rank, batch['object_mask'])
        parts['flow'] = self.flow_loss(h, batch)
        parts['affordance'] = F.binary_cross_entropy_with_logits(h['interaction_affordance_logits'], affordance_target)
        # Price choosing an unavailable interaction NOW; future selection stays legal.
        first = torch.softmax(-h['mu'] + F.logsigmoid(h['selection']), -1)
        parts['availability'] = (first * (1 - affordance_target)).sum(-1).mean()
        total = (parts['selection'] + parts['order'] + self.kl_weight * parts['kl']
                 + self.flow_weight * parts['flow'] + parts['affordance']
                 + self.availability_weight * parts['availability'])
        return total, {k: float(v.detach()) for k, v in parts.items()}

    @torch.no_grad()
    def sample(self, batch, steps=30, generator=None, max_interactions=None, sample_selection=False):
        if self.order_temperature == 1.0 and self.availability_bias == 0.0:
            return super().sample(batch, steps, generator, max_interactions, sample_selection)
        h = self._encode(batch)
        # Lower priorities execute earlier. Learned availability is a soft penalty;
        # unavailable future interactions remain selected in the suffix.
        mu = h['mu'] - self.availability_bias * F.logsigmoid(h['interaction_affordance_logits'])
        rank, selected = self.ordering.sample(
            h['selection'], mu, h['sigma'] * self.order_temperature,
            batch['object_mask'], generator, max_interactions, sample_selection)
        code = self.generate_targets(h, batch, rank, selected, steps, generator)
        return dict(rank=rank, selected=selected, code=code,
                    selection_logits=h['selection'], affordance_logits=h['interaction_affordance_logits'])

    @torch.no_grad()
    def plan(self, object_features, generator=None, sample=True, steps=30):
        if object_features.shape[0] != 1:
            raise ValueError('plan accepts exactly one scene')
        batch = self.batch(object_features)
        out = self.sample(batch, steps=steps, generator=generator, sample_selection=sample)
        chosen = [(int(out['rank'][0, i]), i) for i in range(N_OBJECTS) if out['selected'][0, i]]
        return [(i, out['code'][0, i].cpu().numpy()) for _, i in sorted(chosen)]

    @torch.no_grad()
    def act(self, object_features, generator=None):
        plan = self.plan(object_features, generator=generator, sample=False)
        return plan[0] if plan else (None, None)


def build_model(dim=128, arm='clear', depth=None, heads=4, mu_scale=0.0, target_frame='absolute', geometry_skip=False, **kwargs):
    if arm == 'clear':
        return SceneSequencerNet(dim, depth or 4, heads, mu_scale=mu_scale, target_frame=target_frame, geometry_skip=geometry_skip, **kwargs)
    if arm == 'bc':
        return LegacySceneSequencerNet(dim, depth or 3, heads, arm='bc', mu_scale=mu_scale, target_frame=target_frame, geometry_skip=geometry_skip)
    if arm == 'plan_bc':
        return PlanBCNet(dim, depth or 4, heads, target_frame=target_frame, geometry_skip=geometry_skip)
    raise ValueError('unknown learned arm: ' + arm)


def load_model(blob, expected_arm=None):
    arm = blob.get('arm')
    if expected_arm is not None and arm != expected_arm:
        raise ValueError('checkpoint arm does not match requested sequencer')
    if arm == 'clear' and blob.get('schema') != SCHEMA:
        raise ValueError('legacy CLEAR checkpoint cannot load as affordance/causal CLEAR; regenerate data and retrain')
    cfg = blob.get('model_config', dict(dim=blob.get('dim', 128), arm=arm, mu_scale=blob.get('mu_scale', 0.0)))
    cfg = dict(cfg)
    if arm == 'clear':
        # Historical checkpoints used metre-valued flow codes. A new default
        # must never silently rescale their generated targets at load time.
        cfg.setdefault('flow_scale', 1.0)
    if cfg.get('arm') != arm:
        raise ValueError('checkpoint config/arm mismatch')
    model = build_model(**cfg)
    model.load_state_dict(blob['state_dict'], strict=True)
    return model.eval()
