"""Scene splits over button-state combinations x cube position (exp2_scene).

Repeating the five shipped tasks is not an evaluation — the 4bb16605 review's
point. A scene is fully described by an (init, goal) pair over four things:

    buttons  (2,) in {0,1}^2        which locks are open
    cube     xyz                    or the in-drawer goal
    drawer   DRAWER_OPEN | SHUT
    window   WINDOW_OPEN | SHUT

Held out on the two axes the user chose, so generalisation over lock
configuration and over cube geometry are answered separately:

    train        seen button combos  x seen cube cells
    val          seen               x seen        (disjoint seeds)
    test_button  UNSEEN button combo x seen cube cells
    test_cube    seen button combos  x UNSEEN cube cells
    test_both    UNSEEN              x UNSEEN

The five shipped tasks stay available as a named subset (`SHIPPED`) so the
numbers already in `README.md` remain comparable.
"""

import hashlib
import json

import numpy as np

SPLIT_SCHEMA = 'scene-stable-splits-v2'


def manifest_json(splits):
    return json.dumps(dict(schema=SPLIT_SCHEMA, splits=splits), sort_keys=True,
                      default=lambda x: x.tolist(), separators=(',', ':'))

from experiments.exp2.binding import SHIPPED, all_bindings
from experiments.exp2.scene_bridge import DRAWER_OPEN, DRAWER_SHUT, WINDOW_OPEN, WINDOW_SHUT

# scene_env._object_sampling_bounds
CUBE_XY_LOW, CUBE_XY_HIGH = np.array([0.30, -0.07]), np.array([0.45, 0.18])
CUBE_Z = 0.02
GRID = 4                                        # 4 x 4 = 16 cube cells

BUTTON_COMBOS = [(0, 0), (0, 1), (1, 0), (1, 1)]
HELD_OUT_BUTTONS = (0, 1)                       # never seen in train/val
# a checkerboard of cube cells is held out: it leaves every held-out cell with
# seen neighbours, so `test_cube` measures interpolation rather than
# extrapolation off the edge of the workspace
HELD_OUT_CUBE = {(r, c) for r in range(GRID) for c in range(GRID) if (r + c) % 4 == 1}
# two of the nine non-degenerate lock bindings are never trained on
HELD_OUT_BINDINGS = {((1,), (0,)), ((0, 1), (0,))}

SHIPPED = 'shipped'                             # the five task_infos entries


def cube_cells():
    """The (row, col) -> xyz table. Row/col index the sampling bounds."""
    xs = np.linspace(CUBE_XY_LOW[0], CUBE_XY_HIGH[0], GRID)
    ys = np.linspace(CUBE_XY_LOW[1], CUBE_XY_HIGH[1], GRID)
    return {(r, c): np.array([xs[r], ys[c], CUBE_Z]) for r in range(GRID) for c in range(GRID)}


def _specs(button_pairs, cube_pairs, rng, in_drawer_frac=0.25, bindings=None):
    """One spec per ZIPPED (button pair, cube pair).

    Zipped, not a cartesian product: a product followed by a truncation gives
    every kept spec the same button pair, which is how the first version of
    this file produced 240 train scenes over exactly one lock configuration.
    `demo()` asserts the diversity so it cannot regress.
    """
    cells = cube_cells()
    out = []
    for (b_init, b_goal), (c_init, c_goal) in zip(button_pairs, cube_pairs):
        in_drawer = rng.random() < in_drawer_frac
        binding = (bindings[int(rng.integers(len(bindings)))] if bindings
                   else SHIPPED)
        out.append(dict(
            binding=binding,
            init=dict(buttons=np.array(b_init), cube=cells[c_init].copy(),
                      binding=binding,
                      drawer=float(rng.choice([DRAWER_OPEN, DRAWER_SHUT])),
                      window=float(rng.choice([WINDOW_OPEN, WINDOW_SHUT]))),
            goal=dict(buttons=np.array(b_goal),
                      # the in-drawer goal is recorded at the SHUT slide position,
                      # exactly as scene's own task4/5 goals are
                      cube=('in_drawer' if in_drawer else cells[c_goal].copy()),
                      drawer=DRAWER_SHUT if in_drawer
                      else float(rng.choice([DRAWER_OPEN, DRAWER_SHUT])),
                      window=float(rng.choice([WINDOW_OPEN, WINDOW_SHUT]))),
            button_pair=(b_init, b_goal), cube_pair=(c_init, c_goal),
        ))
    return out


def make_splits(seed=0, per_split=None):
    """The five splits, as dicts of scene specs. Deterministic in `seed`."""
    seen_b = [b for b in BUTTON_COMBOS if b != HELD_OUT_BUTTONS]
    cells = list(cube_cells())
    seen_c = [c for c in cells if c not in HELD_OUT_CUBE]
    held_c = sorted(HELD_OUT_CUBE)

    def pairs(items, rng, k):
        """k (init, goal) pairs drawn from `items`; init may equal goal."""
        return [(items[int(rng.integers(len(items)))], items[int(rng.integers(len(items)))])
                for _ in range(k)]

    # bindings are the third held-out axis (see binding.py): with the lock
    # relation fixed, "button 0 gates the drawer" is one memorised row and the
    # nine-boolean lookup table is complete
    seen_bind = [b for b in all_bindings() if b not in HELD_OUT_BINDINGS]
    held_bind = [b for b in all_bindings() if b in HELD_OUT_BINDINGS]

    out = {}
    for name, bs, cs, bd, n in (('train', seen_b, seen_c, seen_bind, 240),
                                ('val', seen_b, seen_c, seen_bind, 40),
                                ('test_button', [HELD_OUT_BUTTONS], seen_c, seen_bind, 40),
                                ('test_cube', seen_b, held_c, seen_bind, 40),
                                ('test_both', [HELD_OUT_BUTTONS], held_c, seen_bind, 40),
                                ('test_binding', seen_b, seen_c, held_bind, 40)):
        # Python hash() changes between processes, invalidating paired arms.
        stream = int.from_bytes(hashlib.sha256(name.encode()).digest()[:4], 'little')
        rng = np.random.default_rng([seed, stream])
        n = per_split or n
        out[name] = _specs(pairs(bs, rng, n), pairs(cs, rng, n), rng, bindings=bd)
    return out


def describe(splits):
    lines = [f'cube grid {GRID}x{GRID} = {GRID ** 2} cells, '
             f'{len(HELD_OUT_CUBE)} held out; button combos {BUTTON_COMBOS}, '
             f'held out {HELD_OUT_BUTTONS}']
    for name, specs in splits.items():
        bs = {s['button_pair'] for s in specs}
        cs = {s['cube_pair'] for s in specs}
        drawer_goals = sum(isinstance(s['goal']['cube'], str) for s in specs)
        lines.append(f'  {name:12s} {len(specs):4d} scenes   '
                     f'{len(bs)} button pairs, {len(cs)} cube pairs, '
                     f'{len({s["binding"] for s in specs})} bindings, '
                     f'{drawer_goals} put-in-drawer goals')
    return '\n'.join(lines)


def demo():
    splits = make_splits(seed=0)
    print(describe(splits))
    # the held-out axes must not leak
    seen_b = {s['button_pair'][0] for s in splits['train']} | \
             {s['button_pair'][1] for s in splits['train']}
    assert HELD_OUT_BUTTONS not in seen_b, 'held-out button combo leaked into train'
    seen_c = {s['cube_pair'][0] for s in splits['train']} | \
             {s['cube_pair'][1] for s in splits['train']}
    assert not (seen_c & HELD_OUT_CUBE), 'held-out cube cells leaked into train'
    assert all(s['button_pair'][0] == HELD_OUT_BUTTONS or
               s['button_pair'][1] == HELD_OUT_BUTTONS for s in splits['test_button'])
    assert all(s['cube_pair'][0] in HELD_OUT_CUBE or s['cube_pair'][1] in HELD_OUT_CUBE
               for s in splits['test_cube'])
    # train and val must not be the same scenes
    key = lambda s: (s['button_pair'], s['cube_pair'], s['init']['drawer'], s['goal']['window'])
    assert len({key(s) for s in splits['train']} & {key(s) for s in splits['val']}) < len(splits['val']), \
        'val is a subset of train'
    # every seen lock configuration must actually appear, or the split is
    # measuring one configuration and calling it four
    train_b = {s['button_pair'] for s in splits['train']}
    assert len(train_b) >= len(seen_b) * 2, f'train covers only {len(train_b)} button pairs'
    assert len({s['cube_pair'] for s in splits['train']}) > 50
    train_bind = {s['binding'] for s in splits['train']}
    assert not (train_bind & HELD_OUT_BINDINGS), 'held-out binding leaked into train'
    assert len(train_bind) == len(all_bindings()) - len(HELD_OUT_BINDINGS), train_bind
    assert {s['binding'] for s in splits['test_binding']} <= HELD_OUT_BINDINGS
    print(f'ok  held-out axes do not leak; train covers {len(train_b)} button pairs '
          f'and {len(train_bind)} of {len(all_bindings())} lock bindings')


if __name__ == '__main__':
    import sys
    sys.path.insert(0, '.')
    demo()
