"""Paper-derived Exp2 adapters, NOT official benchmark reproductions.

IVNTR: sparse effect-vector invention, neural transition constraints, learned
STRIPS operators, bounded search and continuous sampler (physics refinement is
in external_evaluate). Fixed scene objects replace lifted arbitrary object sets.
CHD: Gaussian HL state/LL interaction diffusion, staggered segment denoising and
bidirectional learned reward guidance. Continuous coordinates replace Kitchen
World token embeddings. See EXTERNAL_BASELINES_20260913.md for deviations.
"""
import heapq
import itertools
import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


def mlp(din, dout, width=192):
    return nn.Sequential(nn.Linear(din, width), nn.SiLU(), nn.Linear(width, width), nn.SiLU(), nn.Linear(width, dout))


def physical(f):
    return torch.cat([f[:, 0, 5:8], f[:, 1:, 5]], -1)


def predicate_input(f):
    return torch.cat([physical(f), f[:, :, 16:18].flatten(1)], -1)


def js_bernoulli(p, q):
    p, q = p.clamp(1e-6, 1-1e-6), q.clamp(1e-6, 1-1e-6)
    m = (p+q)/2
    def kl(x):
        return x * (x/m).log() + (1-x)*((1-x)/(1-m)).log()
    return (kl(p)+kl(q))/2


class PredicateBank(nn.Module):
    """Independent classifiers, batched across symbolic effect candidates."""
    def __init__(self, count, width=32):
        super().__init__()
        self.w1 = nn.Parameter(torch.randn(count, 17, width)/17**.5)
        self.b1 = nn.Parameter(torch.zeros(count, width))
        self.w2 = nn.Parameter(torch.randn(count, width)/width**.5)
        self.b2 = nn.Parameter(torch.zeros(count))

    def forward(self, x):
        h = torch.tanh(torch.einsum('bf,pfh->bph', x, self.w1)+self.b1)
        return torch.einsum('bph,ph->bp', h, self.w2)+self.b2

    def constraint_loss(self, x, y, action, vectors):
        p, q = self(x), self(y)
        delta = vectors[:, action].T
        changed = delta != 0
        bce = F.binary_cross_entropy_with_logits(p, (1-delta)/2, reduction='none')
        bce += F.binary_cross_entropy_with_logits(q, (1+delta)/2, reduction='none')
        # Equal weight per controller, as in IVNTR Eq.5; sparse events must not
        # be hidden by a large population of unchanged transitions.
        row = torch.where(changed, bce/2, js_bernoulli(p.sigmoid(), q.sigmoid()))
        return torch.stack([row[action == a].mean(0) for a in action.unique()]).mean(0)


class IVNTRScene(nn.Module):
    arm = 'ivntr'
    def __init__(self, predicates=12, width=192, candidate_policy='v2', min_candidates=1):
        super().__init__()
        if candidate_policy not in ('v2', 'parity') or min_candidates < 1:
            raise ValueError('unknown candidate policy')
        self.config = dict(arm=self.arm, predicates=predicates, width=width)
        # v3 parity: when the used tier exposes fewer distinct objects than this,
        # generalised-tier prefixes/controllers and then not-at-goal objects are
        # appended so the common retry wrapper has alternates. Weights unchanged.
        self.candidate_policy, self.min_candidates = candidate_policy, int(min_candidates)
        if candidate_policy != 'v2':
            self.config.update(candidate_policy=candidate_policy, min_candidates=self.min_candidates)
        self.predicates = PredicateBank(predicates)
        self.sampler = mlp(99, 3, width)
        self.register_buffer('centers', torch.zeros(2, 2))
        self.register_buffer('origin', torch.zeros(9, 91, 3))
        self.register_buffer('scale', torch.tensor([.1, .1, .1]))
        self.operators = []
        # Backoff tier: generalised operators, consulted only when the specific
        # ones admit no plan. Returning nothing ends the episode in the runner.
        self.fallback_operators = []
        self.search_limit = 256
        self.last_planning = {}

    def action_ids(self, f, choice, target):
        ids = torch.zeros_like(choice)
        for obj in (1, 2):
            mask = choice == obj
            ids[mask] = 1 + 2*(obj-1) + (f[mask, obj, 5] < .5).long()
        for obj in (3, 4):
            mask = choice == obj
            ids[mask] = 5 + 2*(obj-3) + (target[mask, 0, None]-self.centers[obj-3]).abs().argmin(-1)
        return ids

    @staticmethod
    def object_id(action):
        return 0 if action == 0 else 1+(action-1)//2

    def abstract(self, f):
        return torch.cat([f[:, :, 14] > .5, self.predicates(predicate_input(f)) > 0], -1)

    def targets(self, f):
        x = f.flatten(1)
        design = torch.cat([x, torch.ones_like(x[:, :1])], -1)
        base = torch.einsum('bf,afk->bak', design, self.origin)
        inp = torch.cat([x[:, None].expand(-1, 9, -1), torch.eye(9, device=x.device)[None].expand(len(x), -1, -1)], -1)
        return base + self.scale * self.sampler(inp)

    def search(self, initial, operators):
        goal = lambda state: all(state[:5])
        frontier = [(sum(not v for v in initial[:5]), 0, 0, initial, ())]
        seen = {(initial, -1): 0}
        serial = itertools.count(1)
        solutions, best, expanded = [], None, 0
        while frontier and expanded < self.search_limit:
            _, depth, _, state, path = heapq.heappop(frontier)
            expanded += 1
            if path and best is None:
                best = path
            if goal(state):
                if path:
                    if all(p[0] != path[0] for p in solutions):
                        solutions.append(path)
                if len(solutions) >= 3:
                    break
                continue
            if depth >= 12:
                continue
            for op in operators:
                if any(state[i] != bool(v) for i, v in op['pre']):
                    continue
                nxt = list(state)
                for i, v in op['eff']:
                    nxt[i] = bool(v)
                nxt = tuple(nxt)
                nd = depth+1
                first = path[0] if path else op['action']
                key = (nxt, first)
                if nxt == state or seen.get(key, 100) <= nd:
                    continue
                seen[key] = nd
                priority = nd + 2*sum(not v for v in nxt[:5])
                heapq.heappush(frontier, (priority, nd, next(serial), nxt, path+(op['action'],)))
        return solutions or ([best] if best else []), expanded, len(solutions)

    def fallback_action(self, f, obj):
        """The controller for `obj` that moves it toward its goal from the observed state."""
        if obj == 0:
            return 0
        if obj in (1, 2):
            return 1 + 2*(obj-1) + int(f[0, obj, 5] < .5)
        return 5 + 2*(obj-3) + int((f[0, obj, 8] - self.centers[obj-3]).abs().argmin())

    def distinct_objects(self, actions):
        return len({self.object_id(a) for a in actions})

    def plan(self, features, generator=None, **kwargs):
        initial = tuple(self.abstract(features)[0].tolist())
        operators, tier = self.operators, 'specific'
        paths, expanded, found = self.search(initial, operators)
        if not paths and self.fallback_operators:
            # Specific operators are memorised abstract states: precise where the
            # demonstrations reach, silent everywhere else. Back off rather than
            # hand the runner an empty proposal, which terminates the episode.
            operators, tier = self.operators + self.fallback_operators, 'generalised'
            backoff, extra, found = self.search(initial, operators)
            paths, expanded = backoff, expanded + extra
        # Retry parity: BC hands the runner every object ranked, so a planner that
        # returns a single action makes the common retry wrapper a no-op for it.
        # Solution prefixes stay first; remaining applicable controllers follow.
        applicable = [op['action'] for op in operators
                      if all(initial[i] == bool(v) for i, v in op['pre'])]
        actions = list(dict.fromkeys([p[0] for p in paths] + applicable))
        skeletons = [list(p) for p in paths]
        alternates = dict(generalised=0, unmet_goal=0)
        if self.candidate_policy == 'parity' and self.distinct_objects(actions) < self.min_candidates:
            if tier == 'specific' and self.fallback_operators:
                every = self.operators + self.fallback_operators
                general, extra, _ = self.search(initial, every)
                expanded += extra
                general_applicable = [op['action'] for op in every if all(initial[i] == bool(v) for i, v in op['pre'])]
                before = len(actions)
                actions = list(dict.fromkeys(actions + [p[0] for p in general] + general_applicable))
                alternates['generalised'] = len(actions) - before
                for p in general:
                    if len(skeletons) < 3 and all(p[0] != q[0] for q in skeletons):
                        skeletons.append(list(p))
            if self.distinct_objects(actions) < self.min_candidates:
                before = len(actions)
                covered = {self.object_id(a) for a in actions}
                unmet = [self.fallback_action(features, obj) for obj in range(5) if not initial[obj] and obj not in covered]
                actions = list(dict.fromkeys(actions + unmet))
                alternates['unmet_goal'] = len(actions) - before
        targets = self.targets(features)[0].detach().cpu().numpy()
        self.last_planning = dict(search_expansions=expanded, symbolic_solutions=found, tier=tier,
                                  skeletons=skeletons, candidates=len(actions),
                                  applicable_operators=len(applicable), simulator_calls=0, simulator_steps=0,
                                  candidate_policy=self.candidate_policy, alternates=alternates)
        return [(self.object_id(a), targets[a]) for a in actions]


def cosine_schedule(steps):
    t = torch.arange(steps+1, dtype=torch.float32)/steps
    a = torch.cos((t+.008)/1.008*math.pi/2).square()
    return (1-a[1:]/a[:-1]).clamp(max=.999)


class CHDScene(nn.Module):
    arm = 'chd'
    def __init__(self, width=192, steps=32, segments=3, segment_length=2, guidance=.1, samples=1):
        super().__init__()
        self.config = dict(arm=self.arm, width=width, steps=steps, segments=segments,
                           segment_length=segment_length, guidance=guidance, samples=samples)
        self.steps, self.segments, self.segment_length = steps, segments, segment_length
        self.guidance, self.samples = guidance, samples
        self.high = mlp(90 + segments*7 + 16, segments*7, width)
        self.low = mlp(90 + segment_length*9 + 14 + 16 + segments, segment_length*9, width)
        self.reward = mlp(90 + segment_length*9 + 14 + 16 + segments, 1, width)
        self.register_buffer('state_mean', torch.zeros(7))
        self.register_buffer('state_std', torch.ones(7))
        self.register_buffer('target_origin', torch.zeros(5, 91, 3))
        self.register_buffer('beta', cosine_schedule(steps))
        self.register_buffer('abar', (1-self.beta).cumprod(0))
        self.last_planning = {}

    def time_embedding(self, t):
        z = t[:, None] * torch.exp(torch.arange(8, device=t.device)*(-math.log(10000)/7))[None]
        return torch.cat([z.sin(), z.cos()], -1)

    def condition(self, features, g, t):
        b = len(features)
        start = ((physical(features)-self.state_mean)/self.state_std)[:, None]
        endpoints = torch.cat([torch.cat([start, g[:, :-1]], 1), g], -1)
        return torch.cat([features.flatten(1)[:, None].expand(-1, self.segments, -1), endpoints,
                          self.time_embedding(t)[:, None].expand(-1, self.segments, -1),
                          torch.eye(self.segments, device=g.device)[None].expand(b, -1, -1)], -1)

    def high_noise(self, f, g, t):
        return self.high(torch.cat([f.flatten(1), g.flatten(1), self.time_embedding(t)], -1)).reshape_as(g)

    def low_noise(self, f, x, g, t):
        return self.low(torch.cat([x.flatten(2), self.condition(f, g, t)], -1)).reshape_as(x)

    def value(self, f, x, g, t):
        return self.reward(torch.cat([x.flatten(2), self.condition(f, g, t)], -1)).squeeze(-1)

    def q(self, x, t, noise):
        a = self.abar[t].reshape((-1,)+(1,)*(x.ndim-1))
        return a.sqrt()*x + (1-a).sqrt()*noise

    def loss(self, f, g, x, reward):
        b = len(f)
        t = torch.randint(0, self.steps, (b,), device=f.device)
        ng, nx = torch.randn_like(g), torch.randn_like(x)
        gt = self.q(g, (t-1).clamp(min=0), ng)
        # At the last LL reverse step, HL is already clean. Include this
        # boundary in training rather than extrapolating an unseen timestep.
        gt = torch.where((t == 0)[:, None, None], g, gt)
        xt = self.q(x, t, nx)
        high = F.mse_loss(self.high_noise(f, self.q(g, t, ng), t.float()), ng)
        low = F.mse_loss(self.low_noise(f, xt, gt, t.float()), nx)
        val = F.mse_loss(self.value(f, xt, gt, t.float()), reward)
        return high+low+val, dict(high=float(high.detach()), low=float(low.detach()), reward=float(val.detach()))

    def reverse(self, x, eps, t, generator):
        beta, a = self.beta[t], self.abar[t]
        x0 = ((x-(1-a).sqrt()*eps)/a.sqrt()).clamp(-6, 6)
        if t == 0:
            return x0
        ap = self.abar[t-1]
        mean = ap.sqrt()*beta/(1-a)*x0 + (1-beta).sqrt()*(1-ap)/(1-a)*x
        var = beta*(1-ap)/(1-a)
        return mean + var.sqrt()*torch.randn(x.shape, device=x.device, generator=generator)

    def value_loss(self, f, g, x, reward):
        """Reward-guidance term only, for sequences with no denoising target."""
        t = torch.randint(0, self.steps, (len(f),), device=f.device)
        ng, nx = torch.randn_like(g), torch.randn_like(x)
        gt = torch.where((t == 0)[:, None, None], g, self.q(g, (t-1).clamp(min=0), ng))
        return F.mse_loss(self.value(f, self.q(x, t, nx), gt, t.float()), reward)

    def _denoise(self, features, generator):
        d = features.device
        g = torch.randn((1, self.segments, 7), device=d, generator=generator)
        x = torch.randn((1, self.segments, self.segment_length, 9), device=d, generator=generator)
        # Staggered initialization: high is one reverse step ahead of low.
        with torch.no_grad():
            g = self.reverse(g, self.high_noise(features, g, torch.tensor([self.steps-1.], device=d)), self.steps-1, generator)
        for t in range(self.steps-1, -1, -1):
            tt = torch.tensor([float(t)], device=d)
            old_g = g
            with torch.no_grad():
                nx = self.reverse(x, self.low_noise(features, x, old_g, tt), t, generator)
                ng = (self.reverse(old_g, self.high_noise(features, old_g, tt-1), t-1, generator) if t else old_g)
            if self.guidance:
                with torch.enable_grad():
                    gg, xx = old_g.detach().requires_grad_(True), x.detach().requires_grad_(True)
                    dg, dx = torch.autograd.grad(self.value(features, xx, gg, tt).sum(), (gg, xx))
                # Eq.27/30 mean guidance, weighted by reverse variance.
                variance = (self.beta[t]*(1-self.abar[t-1])/(1-self.abar[t])
                            if t else x.new_zeros(()))
                # The synthesised reward scores object feasibility, not target
                # precision; guiding the continuous residual on it moves targets
                # for a distinction the value never learned.
                dx = torch.cat([dx[..., :6], torch.zeros_like(dx[..., 6:])], -1)
                nx = nx + self.guidance*variance*dx.clamp(-10, 10)
                if t:
                    ng = ng + self.guidance*variance*dg.clamp(-10, 10)
            g, x = ng.detach(), nx.detach()
        return g, x

    def plan(self, features, generator=None, **kwargs):
        # The learned reward is what ranks candidate plans in the paper's guided
        # sampling; a single draw never consults it. Best-of-N under that value.
        draws = []
        for _ in range(self.samples):
            g, x = self._denoise(features, generator)
            with torch.no_grad():
                draws.append((float(self.value(features, x, g, features.new_zeros(1)).sum()), g, x))
        score, g, x = max(draws, key=lambda z: z[0])
        tokens = x[0].reshape(-1, 9)
        design = torch.cat([features.flatten(1), features.new_ones(1, 1)], -1)
        origins = torch.einsum('bf,nfk->bnk', design, self.target_origin)[0]
        plan, proposed = [], []
        for token in tokens:
            obj = int(token[:6].argmax())
            if obj == 5:
                break
            plan.append((obj, (origins[obj] + .1*token[6:]).cpu().numpy()))
            proposed.append(obj)
        # Retry parity: BC hands the runner all five objects ranked. Objects the
        # sequence did not name follow, ordered by the first token's own slot
        # scores, at their regressed target. Decoded plan order is untouched.
        plan += [(obj, origins[obj].cpu().numpy())
                 for obj in tokens[0, :5].argsort(descending=True).tolist() if obj not in proposed]
        self.last_planning = dict(diffusion_steps=self.steps, classifier_guidance=self.guidance,
                                  samples=self.samples, plan_value=score, decoded=len(proposed),
                                  candidates=len(plan), simulator_calls=0, simulator_steps=0)
        return plan


def load_external(blob):
    if blob.get('schema') != 'scene-external-adapter-v1':
        raise ValueError('external checkpoint schema mismatch')
    cfg = dict(blob['model_config'])
    arm = cfg.pop('arm')
    net = IVNTRScene(**cfg) if arm == 'ivntr' else CHDScene(**cfg) if arm == 'chd' else None
    if net is None:
        raise ValueError(arm)
    net.load_state_dict(blob['state_dict'], strict=True)
    if arm == 'ivntr':
        net.operators = blob['operators']
        net.fallback_operators = blob.get('fallback_operators', [])
    return net.eval()
