"""Shared coordinate origins for scene target predictors.

The origin uses only the publicly observed final goal. Intermediate targets
(including opening a finally-closed drawer) remain learned displacements.
The optional affine origin is fitted to training labels and checkpointed.
No target projection, simulator query or evaluation label enters decoding.
"""
import torch

FRAMES = ('absolute', 'goal_relative', 'train_affine')


def target_origin(object_features, frame):
    if frame not in ('absolute', 'goal_relative'):
        raise ValueError(f'unknown target frame: {frame}')
    origin = torch.zeros_like(object_features[..., 8:11])
    if frame == 'goal_relative':
        origin[..., 0, :] = object_features[..., 0, 8:11]
        origin[..., 3:, 0] = object_features[..., 3:, 8]
    return origin


class SceneTargetCodec(torch.nn.Module):
    """An optional train-only affine origin; targets remain learned residuals.

    Each object reads its own public observation token. The fit uses only
    selected training targets and is frozen before joint neural training.
    Coefficients and fitted status travel with the checkpoint. No simulator,
    availability label, evaluation target or rank enters decoding.
    """

    def __init__(self, frame='absolute'):
        super().__init__()
        if frame not in FRAMES:
            raise ValueError(f'unknown target frame: {frame}')
        self.frame = frame
        if frame == 'train_affine':
            self.register_buffer('coefficients', torch.zeros(5, 19, 3))
            self.register_buffer('fitted', torch.tensor(False))

    @torch.no_grad()
    def fit(self, features, rank, targets):
        if self.frame != 'train_affine':
            raise ValueError('only train_affine has fitted parameters')
        import numpy as np
        base = target_origin(features, 'goal_relative')
        x = features.detach().cpu().double().numpy()
        y = (targets - base).detach().cpu().double().numpy()
        selected = ((rank >= 0) & (rank < rank.shape[1])).detach().cpu().numpy()
        coefficients = np.zeros((5, 19, 3))
        for obj in (0, 3, 4):
            rows = selected[:, obj]
            if not rows.any():
                raise ValueError(f'no training targets for object {obj}')
            design = np.c_[x[rows, obj], np.ones(rows.sum())]
            width = 3 if obj == 0 else 1
            coefficients[obj, :, :width] = np.linalg.lstsq(
                design, y[rows, obj, :width], rcond=1e-5)[0]
        self.coefficients.copy_(torch.as_tensor(coefficients, device=self.coefficients.device))
        self.fitted.fill_(True)

    def forward(self, features):
        if self.frame != 'train_affine':
            return target_origin(features, self.frame)
        if not bool(self.fitted):
            raise RuntimeError('train_affine must be fit on training targets before use')
        design = torch.cat([features, torch.ones_like(features[..., :1])], -1)
        residual = torch.einsum('bnf,nfk->bnk', design, self.coefficients)
        return target_origin(features, 'goal_relative') + residual
