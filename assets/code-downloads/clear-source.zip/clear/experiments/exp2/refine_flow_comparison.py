"""Additional train-only flow updates with all policy/representation weights frozen."""
import argparse
from pathlib import Path
import time

import torch

from experiments.exp2.comparison_models import load_comparison
from experiments.exp2.comparison_protocol import file_hash
from experiments.exp2.train_comparison import load_data, loss


def refine(checkpoint, data, out, steps=6000, lr=1e-4, device='cuda', flow_scale=None):
    if out.exists() or steps < 1 or lr <= 0 or (flow_scale is not None and flow_scale <= 0):
        raise ValueError('new output and positive training settings required')
    torch.set_num_threads(1)
    blob = torch.load(checkpoint, map_location='cpu', weights_only=True)
    net = load_comparison(blob, blob['model_config']['arm']).to(device)
    if not hasattr(net, 'flow'):
        raise ValueError('flow arm required')
    previous_scale = net.flow_scale
    if flow_scale is not None:
        net.flow_scale = flow_scale
        net.config['flow_scale'] = flow_scale
    train, manifest = load_data(data/'train.npz', device)
    if manifest != blob['manifest_sha256'] or file_hash(data/'train.npz') != blob['train_sha256']:
        raise ValueError('training provenance changed')
    before = {k:v.clone() for k,v in net.state_dict().items() if not k.startswith('flow.')}
    for name, p in net.named_parameters():
        p.requires_grad_(name.startswith('flow.'))
    seed = blob['train_seed'] + 100000
    torch.manual_seed(seed)
    generator = torch.Generator().manual_seed(seed)
    opt = torch.optim.AdamW([p for p in net.parameters() if p.requires_grad], lr=lr, weight_decay=1e-4)
    start, history = time.perf_counter(), []
    for step in range(1, steps+1):
        ids = torch.randint(len(train['choice']), (blob['batch'],), generator=generator).to(device)
        total, parts = loss(net, {k:v[ids] for k,v in train.items()})
        if not torch.isfinite(total):
            raise ValueError('nonfinite flow training loss')
        opt.zero_grad(set_to_none=True)
        total.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.)
        opt.step()
        if step % 1000 == 0 or step == steps:
            history.append(dict(step=step, **parts))
            print(history[-1], flush=True)
    for key, value in before.items():
        torch.testing.assert_close(value, net.state_dict()[key], rtol=0, atol=0)
    blob.update(state_dict=net.cpu().state_dict(), model_config=net.config, flow_refinement=dict(
        steps=steps, lr=lr, seed=seed, seconds=time.perf_counter()-start, history=history,
        previous_scale=previous_scale, flow_scale=net.flow_scale,
        parent_checkpoint_sha256=file_hash(checkpoint), source_sha256=file_hash(__file__),
        nonflow_state_bit_identical=True))
    out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(blob, out)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('checkpoint', 'data', 'out'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--steps', type=int, default=6000)
    p.add_argument('--flow-scale', type=float)
    p.add_argument('--device', default='cuda')
    a = p.parse_args()
    refine(a.checkpoint, a.data, a.out, a.steps, device=a.device, flow_scale=a.flow_scale)


if __name__ == '__main__':
    main()
