"""Shared contract for the four exp_v2 experiments (exp_v2/0_overall_experiment.md).

interfaces.py   Planner / PlanPrediction / InteractionController / ExecutionResult,
                the failure taxonomy and the per-trial JSON record (spec sections 4, 6.5, 9)
manifests.py    canonical scene manifest + jsonl io + freeze/verify (section 5)
statistics.py   paired bootstrap CI, Holm correction, paired-run validation (section 10)
registry.py     experiment name -> cli module used by scripts/*.py

Owned by the controller. Experiment agents import from here and do not edit;
requested changes go in the agent's REPORT.md under "common/ change requests".
"""
