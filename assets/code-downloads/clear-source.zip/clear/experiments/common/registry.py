"""Experiment name -> cli module. Each experiment package exposes
`experiments.<pkg>.cli` with functions named after the commands below, each
taking `argv: list[str]` and returning an int exit code."""
from __future__ import annotations

import importlib
from types import ModuleType

EXPERIMENTS: dict[str, str] = {
    "grid2d": "experiments.exp1.cli",
}

COMMANDS = (
    "generate_dataset",
    "label_with_oracle",
    "train",
    "evaluate",
    "aggregate",
    "render_qualitative",
)


def load_cli(experiment: str, legacy: bool = False) -> ModuleType:
    try:
        module = EXPERIMENTS[experiment]
    except KeyError:
        raise SystemExit(f"unknown experiment {experiment!r}; choose from {sorted(EXPERIMENTS)}")
    return importlib.import_module(module)
