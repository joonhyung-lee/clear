"""Aggregation and statistics (0_overall_experiment.md section 10). numpy only.

- binary metrics: scene-level mean with paired bootstrap 95% CI
- continuous metrics: mean, median, paired bootstrap CI
- CLEAR vs baseline / ablation: paired difference on the same (scene, seed) keys
- Holm correction within an experiment
- `validate_paired_runs` rejects runs whose methods have different scene sets,
  missing trials, mismatched physics seeds or duplicated pair keys
"""
from __future__ import annotations

import math
import warnings
from collections import Counter, defaultdict
from statistics import NormalDist
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from experiments.common.interfaces import PAIR_KEY, TrialRecord


def _wilson(k: float, n: int, alpha: float) -> tuple[float, float]:
    """Wilson score interval for k successes in n Bernoulli trials."""
    z = NormalDist().inv_cdf(1.0 - alpha / 2.0)
    p = k / n
    denom = 1.0 + z * z / n
    centre = p + z * z / (2 * n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (centre - half) / denom), min(1.0, (centre + half) / denom)


def bootstrap_ci(
    values: Sequence[float], n_boot: int = 10_000, alpha: float = 0.05, seed: int = 0
) -> dict[str, float]:
    x = np.asarray(values, dtype=float)
    if x.size == 0:
        return {"mean": float("nan"), "median": float("nan"), "ci_lo": float("nan"), "ci_hi": float("nan"),
                "n": 0, "ci_method": "empty"}
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, x.size, size=(n_boot, x.size))
    boots = x[idx].mean(axis=1)
    lo, hi = np.quantile(boots, [alpha / 2, 1 - alpha / 2])
    method = "bootstrap"
    if lo == hi:
        # A constant sample gives the percentile bootstrap no spread to resample, so it
        # returns a zero-width "interval" -- which reads as an infinitely precise
        # measurement. For a 0/1 metric (every headline success rate here) the Wilson score
        # interval is the right answer; otherwise flag it rather than pretend.
        if bool(np.isin(x, (0.0, 1.0)).all()):
            lo, hi = _wilson(float(x.sum()), int(x.size), alpha)
            method = "wilson"
        else:
            method = "degenerate"
    return {"mean": float(x.mean()), "median": float(np.median(x)), "ci_lo": float(lo), "ci_hi": float(hi),
            "n": int(x.size), "ci_method": method}


def paired_difference(
    a: Sequence[float], b: Sequence[float], n_boot: int = 10_000, alpha: float = 0.05, seed: int = 0
) -> dict[str, float]:
    """a - b on paired units (same order = same scene/seed). Two-sided bootstrap p-value."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.shape != b.shape:
        raise ValueError(f"paired arrays differ in length: {a.shape} vs {b.shape}")
    d = a - b
    if d.size == 0:
        return {"mean_diff": float("nan"), "ci_lo": float("nan"), "ci_hi": float("nan"), "p_value": float("nan"), "n": 0}
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, d.size, size=(n_boot, d.size))
    boots = d[idx].mean(axis=1)
    lo, hi = np.quantile(boots, [alpha / 2, 1 - alpha / 2])
    obs = d.mean()
    # Two-sided percentile p-value, doubled and floored at 1/n_boot. `boots <= 0` and
    # `boots >= 0` are NOT disjoint: on a sparse binary metric a large mass of bootstrap
    # means is exactly 0 (every resample that misses the few non-zero pairs), so counting
    # that mass in both tails inflates p by up to 2x -- 1 win in 20 came out at p = 0.73.
    # Split the tie mass between the tails instead.
    tie = float((boots == 0).mean())
    below = float((boots < 0).mean()) + 0.5 * tie
    p = 2.0 * min(below, 1.0 - below)
    p = float(min(1.0, max(p, 1.0 / n_boot)))
    return {"mean_diff": float(obs), "ci_lo": float(lo), "ci_hi": float(hi), "p_value": p, "n": int(d.size)}


def holm_correction(pvalues: Mapping[str, float]) -> dict[str, float]:
    """Holm step-down adjusted p-values for one experiment's family of hypotheses."""
    items = sorted(pvalues.items(), key=lambda kv: kv[1])
    m = len(items)
    adjusted: dict[str, float] = {}
    running = 0.0
    for rank, (name, p) in enumerate(items):
        adj = min(1.0, (m - rank) * p)
        running = max(running, adj)  # enforce monotonicity
        adjusted[name] = running
    return adjusted


class PairingError(ValueError):
    pass


def validate_paired_runs(
    records: Iterable[TrialRecord | Mapping[str, Any]],
    methods: Sequence[str] | None = None,
    expected_seeds: int | Mapping[str, int] | None = None,
) -> dict[str, int]:
    """Reject a run unless every method covers the identical set of (scene_id, physics_seed)
    units, with no duplicates and with the same training seeds on every one of its own units.

    Methods may legitimately differ in how many training seeds they have -- the spec gives
    learned methods five and deterministic classical methods one -- so seed counts are compared
    WITHIN a method, not across methods.

    That leaves one hole the records cannot close by themselves: if an entire training seed is
    missing from every unit, the run still looks internally consistent, and the method silently
    improves by dropping its worst seed. Pass `expected_seeds` (an int, or {method: int}) to
    close it; a paper run always knows how many seeds it launched.

    Returns {method: n_units}."""
    recs = [r.to_dict() if isinstance(r, TrialRecord) else dict(r) for r in records]
    if not recs:
        raise PairingError("no trial records")
    keys = Counter(tuple(r[k] for k in PAIR_KEY) for r in recs)
    dups = [k for k, c in keys.items() if c > 1]
    if dups:
        raise PairingError(f"duplicated (method, training_seed, scene_id, physics_seed) keys: {dups[:5]}")
    units: dict[str, set[tuple]] = defaultdict(set)
    seeds: dict[str, dict[tuple, set[int]]] = defaultdict(lambda: defaultdict(set))
    for r in recs:
        unit = (r["scene_id"], r["physics_seed"])
        units[r["method"]].add(unit)
        seeds[r["method"]][unit].add(r["training_seed"])
    if methods is not None:
        missing = set(methods) - set(units)
        if missing:
            raise PairingError(f"methods without trials: {sorted(missing)}")
        units = {m: units[m] for m in methods}
    ref_name, ref = next(iter(units.items()))
    for name, u in units.items():
        if u != ref:
            only_ref = sorted(ref - u)[:5]
            only_this = sorted(u - ref)[:5]
            raise PairingError(
                f"{name} and {ref_name} cover different (scene_id, physics_seed) units; "
                f"missing in {name}: {only_ref}; extra in {name}: {only_this}"
            )
    # A method must also cover every unit with the SAME training seeds. Without this, losing a
    # whole training seed -- a crashed run, an unwritten shard -- still pairs, and the method
    # silently improves by dropping its worst seed.
    for name, per_unit in seeds.items():
        if methods is not None and name not in methods:
            continue
        seed_sets = {frozenset(v) for v in per_unit.values()}
        if len(seed_sets) > 1:
            sizes = sorted({len(v) for v in per_unit.values()})
            ragged = sorted(k for k, v in per_unit.items()
                            if frozenset(v) != max(seed_sets, key=len))[:5]
            raise PairingError(
                f"{name} does not cover every unit with the same training seeds "
                f"(seeds per unit range over {sizes}); short units: {ragged}"
            )
    if expected_seeds is not None:
        for name, per_unit in seeds.items():
            if methods is not None and name not in methods:
                continue
            want = expected_seeds if isinstance(expected_seeds, int) else expected_seeds.get(name)
            if want is None:
                continue
            got = len(next(iter(per_unit.values())))
            if got != want:
                raise PairingError(
                    f"{name} has {got} training seed(s) per unit, expected {want}; "
                    "a whole seed is missing from every unit (a crashed or unwritten run)"
                )
    return {m: len(u) for m, u in units.items()}


def pair_by_unit(records: Iterable[TrialRecord], metric: str, method_a: str, method_b: str) -> tuple[list[float], list[float]]:
    """Return aligned metric arrays for two methods, joined on (scene_id, physics_seed).
    Averages over training seeds within a unit when a method has several."""
    buckets: dict[tuple, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for r in records:
        if r.method not in (method_a, method_b):
            continue
        v = r.to_dict().get(metric)
        if v is None:
            continue
        buckets[(r.scene_id, r.physics_seed)][r.method].append(float(v))
    a, b = [], []
    dropped = 0
    for unit in sorted(buckets):
        vals = buckets[unit]
        if method_a in vals and method_b in vals:
            a.append(float(np.mean(vals[method_a])))
            b.append(float(np.mean(vals[method_b])))
        else:
            dropped += 1
    if dropped:
        # validate_paired_runs checks that trials exist, not that `metric` is present on
        # both sides, so a one-sided metric shrinks the paired n with no other signal.
        warnings.warn(f"pair_by_unit({metric!r}, {method_a!r}, {method_b!r}): dropped {dropped} of "
                      f"{len(buckets)} units where only one method reported the metric",
                      RuntimeWarning, stacklevel=2)
    return a, b


def unit_means(records: Iterable[TrialRecord], metric: str) -> dict[tuple, float]:
    """(group, scene_id, physics_seed) -> mean over training seeds. Same unit as `pair_by_unit`."""
    b: dict[tuple, list[float]] = defaultdict(list)
    for r in records:
        v = r.to_dict().get(metric)
        if v is None or (isinstance(v, float) and math.isnan(v)):
            continue
        b[(r.scene_id, r.physics_seed)].append(float(v))
    return {k: float(np.mean(v)) for k, v in b.items()}


def summarize_metric(records: Iterable[TrialRecord], metric: str, per: str = "method", **kw: Any) -> dict[str, dict[str, float]]:
    """Scene-level summary of `metric` grouped by `per` (default method).

    Collapses to one value per (scene_id, physics_seed) unit first -- the same unit
    `pair_by_unit` uses. Bootstrapping raw trials would resample several training seeds of
    the same scene as if they were independent draws and report a CI that is too narrow.
    """
    groups: dict[str, list[TrialRecord]] = defaultdict(list)
    for r in records:
        groups[str(r.to_dict()[per])].append(r)
    return {g: bootstrap_ci(list(unit_means(rs, metric).values()), **kw) for g, rs in groups.items()}


def seed_cluster_ci(
    records: Iterable[TrialRecord],
    metric: str,
    method: str,
    unit: Sequence[str] = ("scene_id", "physics_seed"),
    n_boot: int = 10_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> dict[str, float]:
    """Two-level bootstrap for a LEARNED method: resample scenes AND training seeds.

    Spec section 6.3 -- "learned-method uncertainty must additionally include training seeds".
    Resampling scenes alone cannot see across-seed spread, so a scene-level CI understates the
    uncertainty of any method trained with several seeds. With one training seed it reduces to
    the scene-level bootstrap.

    Vectorised over a (units x seeds) matrix: the first version looped in Python over every
    unit and seed inside every bootstrap draw and took ~30 s per call at 150 units x 5 seeds x
    10k draws, which made a full aggregate run for an hour.
    """
    table: dict[tuple, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))
    for r in records:
        if r.method != method:
            continue
        d = r.to_dict()
        v = d.get(metric)
        if v is None or (isinstance(v, float) and math.isnan(v)):
            continue
        table[tuple(d[k] for k in unit)][int(d["training_seed"])].append(float(v))
    units = sorted(table)
    seeds = sorted({t for u in table.values() for t in u})
    if not units or not seeds:
        return {"mean": float("nan"), "ci_lo": float("nan"), "ci_hi": float("nan"),
                "n_units": 0, "n_seeds": 0, "seed_spread": float("nan")}
    M = np.full((len(units), len(seeds)), np.nan)
    for i, u in enumerate(units):
        for j, t in enumerate(seeds):
            if t in table[u]:
                M[i, j] = float(np.mean(table[u][t]))

    def _mean(m: np.ndarray) -> float:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            return float(np.nanmean(np.nanmean(m, axis=1)))   # over resampled seeds, then units

    rng = np.random.default_rng(seed)
    U = rng.integers(0, len(units), size=(n_boot, len(units)))
    Sd = rng.integers(0, len(seeds), size=(n_boot, len(seeds)))
    boots = np.fromiter((_mean(M[U[b]][:, Sd[b]]) for b in range(n_boot)), dtype=float, count=n_boot)
    boots = boots[~np.isnan(boots)]
    lo, hi = np.quantile(boots, [alpha / 2, 1 - alpha / 2])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        per_seed_means = np.nanmean(M, axis=0)
    return {"mean": _mean(M), "ci_lo": float(lo), "ci_hi": float(hi),
            "n_units": len(units), "n_seeds": len(seeds),
            "seed_spread": float(np.nanmax(per_seed_means) - np.nanmin(per_seed_means)) if len(seeds) > 1 else 0.0}
