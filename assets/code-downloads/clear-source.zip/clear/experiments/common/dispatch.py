from __future__ import annotations

import argparse
import sys

from experiments.common.registry import COMMANDS, EXPERIMENTS, load_cli


def main(command: str, argv: list[str] | None = None) -> int:
    assert command in COMMANDS, command
    argv = sys.argv[1:] if argv is None else argv
    parser = argparse.ArgumentParser(
        prog=f"run_01_grid.py {command}",
        add_help=False,
        description=f"Dispatch `{command}` to experiments.<experiment>.cli.{command}(argv)",
    )
    parser.add_argument("--experiment", required=True, choices=sorted(EXPERIMENTS))
    parser.add_argument("--legacy", action="store_true", help="use the historical grid-maze model for exp3/exp4")
    if argv in (["-h"], ["--help"]):
        parser.print_help()
        return 0
    args, rest = parser.parse_known_args(argv)
    cli = load_cli(args.experiment, legacy=args.legacy)
    fn = getattr(cli, command, None)
    if fn is None:
        raise SystemExit(f"{cli.__name__} does not implement {command}(argv)")
    return int(fn(rest) or 0)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1], sys.argv[2:]))
