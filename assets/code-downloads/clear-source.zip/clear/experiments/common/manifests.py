"""Canonical scene manifest (0_overall_experiment.md section 5).

Every generated scene is serialised before evaluation; all methods are evaluated
on identical manifests and physics seeds. A test manifest is frozen with
`freeze()` after its first reported run and `verify_frozen()` refuses to run on
a changed file.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable


@dataclass
class SceneObject:
    object_id: int
    asset_id: str
    initial_configuration: list[float]
    mass: float
    geometry: list[float]
    friction: float
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class RobotSpec:
    embodiment_id: str
    structure_file: str | None = None
    structure_hash: str | None = None


@dataclass
class OracleLabel:
    solvable: bool
    min_interactions: int | None
    valid_orders: list[list[int]]
    valid_plan_ids: list[str] = field(default_factory=list)
    optimal_set_complete: bool = True
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class SceneManifest:
    scene_id: str
    scene_family: str
    generation_seed: int
    environment: dict[str, Any]
    objects: list[SceneObject]
    start: list[float]
    goal: dict[str, Any]
    robot: RobotSpec | None = None
    oracle: OracleLabel | None = None
    split: str | None = None
    base_scene_id: str | None = None  # maze pairing unit (03/04)
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "SceneManifest":
        d = dict(d)
        d["objects"] = [SceneObject(**o) for o in d.get("objects", [])]
        if d.get("robot") is not None:
            d["robot"] = RobotSpec(**d["robot"])
        if d.get("oracle") is not None:
            d["oracle"] = OracleLabel(**d["oracle"])
        return cls(**d)

    def canonical_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))


def write_manifests(path: str, manifests: Iterable[SceneManifest]) -> None:
    with open(path, "w") as f:
        for m in manifests:
            f.write(m.canonical_json() + "\n")


def read_manifests(path: str) -> list[SceneManifest]:
    with open(path) as f:
        return [SceneManifest.from_dict(json.loads(line)) for line in f if line.strip()]


def digest(manifests: Iterable[SceneManifest]) -> str:
    h = hashlib.sha256()
    for m in manifests:
        h.update(m.canonical_json().encode())
        h.update(b"\n")
    return h.hexdigest()


def freeze(path: str) -> str:
    """Write `<path>.sha256` next to a manifest file. Call once, after the first
    reported run; commit the .sha256 file."""
    d = digest(read_manifests(path))
    with open(path + ".sha256", "w") as f:
        f.write(d + "\n")
    return d


class FrozenManifestError(RuntimeError):
    pass


def verify_frozen(path: str) -> None:
    """Raise if `<path>.sha256` exists and does not match the file's content."""
    try:
        with open(path + ".sha256") as f:
            expected = f.read().strip()
    except FileNotFoundError:
        return
    actual = digest(read_manifests(path))
    if actual != expected:
        raise FrozenManifestError(
            f"{path} changed after freeze (sha256 {actual[:12]} != {expected[:12]}). "
            "The test manifest is immutable after the first reported run."
        )


def check_unique_ids(manifests: Iterable[SceneManifest]) -> None:
    seen: set[str] = set()
    for m in manifests:
        if m.scene_id in seen:
            raise ValueError(f"duplicate scene_id {m.scene_id}")
        seen.add(m.scene_id)
