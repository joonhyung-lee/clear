"""Common software interface (0_overall_experiment.md section 4), failure taxonomy
(section 6.5) and the per-trial logging record (section 9).

Every method -- classical baseline, oracle, ablation, full CLEAR -- implements
`Planner`. The evaluator owns physics execution and metric computation; a
planner never reads hidden simulator state unless `privileged=True`.
"""
from __future__ import annotations

import json
import time
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Iterator


class FailureType(str, Enum):
    """Exactly one terminal failure type per unsuccessful trial. Diagnostic only."""

    NO_PLAN = "NO_PLAN"
    WRONG_OBJECT_SELECTION = "WRONG_OBJECT_SELECTION"
    INVALID_ORDER = "INVALID_ORDER"
    UNREACHABLE_TARGET = "UNREACHABLE_TARGET"
    CONTACT_FAILURE = "CONTACT_FAILURE"
    OBJECT_TOPPLE = "OBJECT_TOPPLE"
    ROBOT_COLLISION = "ROBOT_COLLISION"
    CONTROLLER_TIMEOUT = "CONTROLLER_TIMEOUT"
    RETRY_EXHAUSTED = "RETRY_EXHAUSTED"
    GOAL_NOT_REACHED = "GOAL_NOT_REACHED"


def coerce_failure(value: FailureType | str | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, FailureType):
        return value.value
    return FailureType(str(value)).value  # raises on unknown labels, on purpose


@dataclass
class PlanPrediction:
    """One plan P = (rho, g). `object_ids` is the interaction order rho,
    `target_configurations[k]` the desired configuration g_k of object_ids[k].
    Maze experiments may additionally fill `body_parts`, `contact_points`, `route_class`."""

    object_ids: list[int]
    target_configurations: list[Any]
    scores: dict[str, Any] = field(default_factory=dict)
    planning_time_s: float = 0.0
    body_parts: list[str] | None = None
    contact_points: list[Any] | None = None
    route_class: str | None = None

    def __post_init__(self) -> None:
        if len(self.object_ids) != len(self.target_configurations):
            raise ValueError(
                f"object_ids ({len(self.object_ids)}) and target_configurations "
                f"({len(self.target_configurations)}) must align"
            )
        if len(set(self.object_ids)) != len(self.object_ids):
            raise ValueError(f"duplicate object in order: {self.object_ids}")

    @property
    def num_interactions(self) -> int:
        return len(self.object_ids)

    @classmethod
    def empty(cls, planning_time_s: float = 0.0, **scores: Any) -> "PlanPrediction":
        return cls([], [], dict(scores), planning_time_s)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class Planner(ABC):
    """`name` appears in tables; `privileged=True` marks oracles that read
    exact feasibility / hidden state and must be labelled as such."""

    name: str = "planner"
    privileged: bool = False

    @abstractmethod
    def reset(self, seed: int) -> None: ...

    @abstractmethod
    def predict(self, observation: Any, embodiment: Any) -> PlanPrediction: ...

    def update(self, observation: Any, execution_result: "ExecutionResult") -> PlanPrediction | None:
        """Closed-loop revision hook. Default: open loop (never revises)."""
        return None


@dataclass
class ExecutionResult:
    success: bool
    failure_type: str | None
    object_before: dict[str, Any]
    object_after: dict[str, Any]
    robot_before: dict[str, Any]
    robot_after: dict[str, Any]
    info: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.failure_type = coerce_failure(self.failure_type)
        if self.success and self.failure_type is not None:
            raise ValueError("successful execution cannot carry a failure_type")


class InteractionController(ABC):
    """Low-level execution interface shared by the maze experiments."""

    @abstractmethod
    def navigate(self, base_goal: Any, observation: Any) -> ExecutionResult: ...

    @abstractmethod
    def interact(
        self,
        object_id: int,
        target_configuration: Any,
        contact_point: Any | None = None,
        body_part: str | None = None,
    ) -> ExecutionResult: ...


PAIR_KEY = ("method", "training_seed", "scene_id", "physics_seed")


@dataclass
class TrialRecord:
    """One JSON line per trial (section 9). Experiment-specific headline metrics
    go in `extra` and are flattened to top level on write."""

    experiment: str
    method: str
    training_seed: int
    scene_id: str
    physics_seed: int
    predicted_order: list[int]
    executed_order: list[int]
    num_attempts: int
    task_success: bool
    planning_time_s: float
    execution_time_s: float
    failure_type: str | None = None
    strict_success: bool | None = None
    embodiment_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    _CORE = (
        "experiment", "method", "training_seed", "scene_id", "physics_seed",
        "embodiment_id", "predicted_order", "executed_order", "num_attempts",
        "task_success", "strict_success", "planning_time_s", "execution_time_s",
        "failure_type",
    )

    def __post_init__(self) -> None:
        self.failure_type = coerce_failure(self.failure_type)
        if self.task_success and self.failure_type is not None:
            raise ValueError("task_success=True with a failure_type")
        if not self.task_success and self.failure_type is None:
            raise ValueError("failed trial needs exactly one failure_type")
        clash = set(self.extra) & set(self._CORE)
        if clash:
            raise ValueError(f"extra keys shadow core fields: {sorted(clash)}")
        if self.strict_success and not self.task_success:
            # strict success is "goal reached AND untouched objects stayed put", so it
            # cannot hold when the goal was not reached
            raise ValueError("strict_success=True requires task_success=True")

    def key(self) -> tuple:
        return tuple(getattr(self, k) for k in PAIR_KEY)

    def to_dict(self) -> dict[str, Any]:
        d = {k: getattr(self, k) for k in self._CORE}
        d.update(self.extra)
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TrialRecord":
        core = {k: d.get(k) for k in cls._CORE}
        extra = {k: v for k, v in d.items() if k not in cls._CORE}
        return cls(**core, extra=extra)

    @classmethod
    def from_json(cls, line: str) -> "TrialRecord":
        return cls.from_dict(json.loads(line))


def write_trials(path: str, records: list[TrialRecord]) -> None:
    with open(path, "w") as f:
        for r in records:
            f.write(r.to_json() + "\n")


def read_trials(path: str) -> list[TrialRecord]:
    with open(path) as f:
        return [TrialRecord.from_json(line) for line in f if line.strip()]


@contextmanager
def stopwatch() -> Iterator[dict[str, float]]:
    """`with stopwatch() as t: ...; t['s']` -- wall-clock seconds for planning_time_s."""
    out: dict[str, float] = {"s": 0.0}
    t0 = time.perf_counter()
    try:
        yield out
    finally:
        out["s"] = time.perf_counter() - t0
