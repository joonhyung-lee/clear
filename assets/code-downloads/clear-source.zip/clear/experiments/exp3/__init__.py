"""Experiment 03: embodiment-aware goal navigation in MuJoCo (exp_v2/03_exp_maze_embodiment.md).

scene_io          MazeScene <-> SceneManifest
capability_probe  isolated traversal / interaction probes -> capability_tables.json (privileged)
generator         8 paired scene families, capability-switch guarantee, topology-hash splits
oracle            privileged solver: route classes, plan signatures, OraclePlanner
model             EmbodimentMazePAMO (clear / clear_noemb / specialist front ends), examples, batches
planners          Planner wrappers for the learned methods (non-privileged belief routing)
evaluator         plan-time violation checks, abstract-controller execution, TrialRecords
metrics           the four headline metrics + aggregation
attribution       counterfactual occlusion over scene tokens with phi_B swapped
render            paired-scene figure, traversability maps
train             smoke-scale training loop
cli               generate_dataset / label_with_oracle / train / evaluate / aggregate / render_qualitative
"""
