"""MazeScene <-> canonical SceneManifest (experiments/common/manifests.py).

One manifest per (base_scene, embodiment): identical environment/objects/start/goal across
the bodies of one base scene (spec 6.1), robot block differing only in embodiment_id and
structure file/hash.  Gates and family parameters ride in `environment` -- the evaluator
reads them for route classes; planners never see a manifest.
"""
from __future__ import annotations

import os

import numpy as np

from experiments.common.manifests import OracleLabel, RobotSpec, SceneManifest, SceneObject
from clear.maze.world import CELL_M, MazeObj, MazeScene, cell_to_world, world_to_cell

GOAL_RADIUS_FRAC = 0.4   # goal disc radius = 0.4 * cell (mj_maze goal_disc)
EXP_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(EXP_ROOT, "data")


def scene_id_of(base_scene_id: str, embodiment_id: str) -> str:
    return f"{base_scene_id}__{embodiment_id}"


def split_scene_id(scene_id: str) -> tuple[str, str]:
    base, body = scene_id.rsplit("__", 1)
    return base, body


def manifest_from_scene(scene: MazeScene, embodiment_id: str, generation_seed: int, split: str,
                        structure_file: str | None, structure_hash: str | None,
                        geometry_file: str | None, extra: dict | None = None) -> SceneManifest:
    env = {
        "geometry_file": geometry_file,
        "terrain": [
            {"kind": "height_m", "rows": np.asarray(scene.height, float).round(4).tolist()},
            {"kind": "slope_deg", "rows": np.asarray(scene.slope_deg, float).round(3).tolist()},
            {"kind": "passage_width_m", "rows": np.asarray(scene.passage_width, float).round(4).tolist()},
        ],
        "grid_hw": list(scene.shape), "cell_m": scene.cell_m, "wall_h": scene.wall_h,
        "gates": {k: [list(c) for c in v] for k, v in scene.gates.items()},
        "params": dict(scene.params),
    }
    objs = [SceneObject(**o.to_manifest(scene.cell_m)) for o in scene.objects]
    sx, sy = cell_to_world(scene.start, scene.cell_m)
    gx, gy = cell_to_world(scene.goal, scene.cell_m)
    return SceneManifest(
        scene_id=scene_id_of(scene.base_scene_id, embodiment_id), scene_family=scene.family,
        generation_seed=int(generation_seed), environment=env, objects=objs,
        start=[round(sx, 4), round(sy, 4)],
        goal={"cell": list(scene.goal), "xy": [round(gx, 4), round(gy, 4)],
              "radius_m": round(GOAL_RADIUS_FRAC * scene.cell_m, 4)},
        robot=RobotSpec(embodiment_id, structure_file, structure_hash),
        split=split, base_scene_id=scene.base_scene_id,
        extra={"start_cell": list(scene.start), "physics_seed": int(generation_seed), **(extra or {})},
    )


def scene_from_manifest(m: SceneManifest) -> MazeScene:
    env = m.environment
    layers = {t["kind"]: np.asarray(t["rows"], np.float32) for t in env["terrain"]}
    cell_m = float(env.get("cell_m", CELL_M))
    objs = []
    for o in m.objects:
        x, y, yaw = o.initial_configuration
        dx, dy, dz = o.geometry
        objs.append(MazeObj.make(o.object_id, world_to_cell((x, y), cell_m), o.mass, dx, dy, dz, o.friction, yaw, cell_m))
    start = tuple(m.extra.get("start_cell") or world_to_cell(m.start, cell_m))
    goal = tuple(m.goal["cell"]) if "cell" in m.goal else world_to_cell(m.goal["xy"], cell_m)
    sc = MazeScene.build(layers["height_m"], start, goal, objs, layers.get("slope_deg"),
                         layers.get("passage_width_m"), env.get("gates"), m.scene_family,
                         m.base_scene_id or split_scene_id(m.scene_id)[0], env.get("params"))
    sc.wall_h = float(env.get("wall_h", sc.wall_h))
    sc.cell_m = cell_m
    return sc


def split_dir(split: str, root: str = DATA_ROOT) -> str:
    return os.path.join(root, split)


def manifest_path(split: str, root: str = DATA_ROOT) -> str:
    return os.path.join(split_dir(split, root), "scene_manifest.jsonl")


def labels_path(split: str, root: str = DATA_ROOT) -> str:
    return os.path.join(split_dir(split, root), "oracle_labels.jsonl")
