"""CLEAR's structural maze adapter, shared by clear / clear_noemb / specialist.

V2: structure + terrain + object observations -> learned selection and sampled
Gaussian priorities -> rank-causal Gaussian-to-target CFM. The endpoint code is
normalised (column, row); the planner projects it to a cell and delegates motion
to the controller. Generative time is not physical time. Auxiliary role,
feasibility and edge heads retain the existing controller interface.

V1: legacy categorical cell head, hard-clamped priority scale and no KL anchor.
Unversioned checkpoints load explicitly as V1; their results are not V2 evidence.

clear uses link-level phi_B through MorphCapabilityEncoder and terrain FiLM.
clear_noemb uses a learned body-independent row bank through the same encoder
architecture; specialist trains one such body-independent model per body.
All three V2 methods include the same target-flow architecture. The learned row
bank adds parameters to none mode, as in the original implementation; report
actual counts rather than claiming exactly equal parameter counts.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from clear.maze.world import NEIGHBORS
from clear.maze.robots import ROLES
from clear.maze.robots import MAX_LINKS, STRUCTURE_DIM
from clear.model.morphology_encoder import MorphologyEncoder
from clear.model.encoders import PerceptionEncoder
from clear.model.ordernet import PriorityHead
from clear.model.ordernet import sampled_priority_rank_loss
from clear.model.causalflownet import RankCausalTargetFlow, priority_scale, selected_ranks
from clear.model.encoders import MetricSceneEncoder, object_features

HEIGHT_CLAMP = 2.0        # metres; the maze's wall height is 1.5
WIDTH_CLAMP = 2.0         # metres; open cells carry CELL_M
SLOPE_CLAMP = 45.0        # degrees
OFF_GRID_STEP = 10.0
N_OBJ_MAX = 8             # padded object slots per scene
DROP_OBJ = ("can_move",)  # the capability label is never an input (spec 4.2)
N_ROLES = len(ROLES)
PERCEPT_CHANS = 1 + len(NEIGHBORS) + 5   # height, 4 edge deltas, slope, width, occ, start, goal


# --------------------------------------------------------------------------------------
# tensor inputs


def edge_deltas_np(heights: np.ndarray) -> np.ndarray:
    h, w = heights.shape
    out = np.full((len(NEIGHBORS), h, w), OFF_GRID_STEP, np.float32)
    for k, (dr, dc) in enumerate(NEIGHBORS):
        r0, r1 = max(0, -dr), h - max(0, dr)
        c0, c1 = max(0, -dc), w - max(0, dc)
        out[k, r0:r1, c0:c1] = heights[r0 + dr:r1 + dr, c0 + dc:c1 + dc] - heights[r0:r1, c0:c1]
    return out


def perception_input(heights, slope, width, occupancy, start, goal, edge_geometry=None):
    """(b, PERCEPT_CHANS, h, w) from six (b, h, w) tensors.  Mirrors
    clear.model.perception_encoder.perception_input with the two metric axes exp 03 adds
    (ramp slope, passage width) -- the model must see them to predict traversability."""
    d = (torch.stack([_edge_delta_t(heights, k) for k in range(len(NEIGHBORS))], dim=1)
         if edge_geometry is None else edge_geometry)
    d = d.clamp(-HEIGHT_CLAMP, HEIGHT_CLAMP) / HEIGHT_CLAMP
    return torch.cat([(heights / HEIGHT_CLAMP)[:, None], d,
                      (slope / SLOPE_CLAMP)[:, None], (width / WIDTH_CLAMP)[:, None],
                      occupancy[:, None].to(heights.dtype), start[:, None].to(heights.dtype),
                      goal[:, None].to(heights.dtype)], dim=1)


def _edge_delta_t(heights, k):
    dr, dc = NEIGHBORS[k]
    nb = torch.full_like(heights, OFF_GRID_STEP)
    h, w = heights.shape[-2:]
    r0, r1 = max(0, -dr), h - max(0, dr)
    c0, c1 = max(0, -dc), w - max(0, dc)
    nb[:, r0:r1, c0:c1] = heights[:, r0 + dr:r1 + dr, c0 + dc:c1 + dc]
    return nb - heights


# --------------------------------------------------------------------------------------
# capability channel


class MorphCapabilityEncoder(nn.Module):
    """phi_B link rows -> (kappa vector for FiLM, kappa token for the transformer).

    clear.model.capability_encoder.MorphCapabilityEncoder with one change it does not
    expose: `in_dim`.  Its MorphologyEncoder is pinned to the v1 18-column rows; exp 03's
    structure_parser emits the adopted v3 20-column rows (STRUCTURE_DIM), so the row width
    has to be passed through.  Everything else -- the set-attention encoder, the linear
    read-out of the token into the conditioning vector -- is the same module and the same
    contract."""

    def __init__(self, dim, cap_dim=64, hidden=128, depth=2, heads=4, p_drop=0.15,
                 in_dim=STRUCTURE_DIM):
        super().__init__()
        self.enc = MorphologyEncoder(dim, hidden=hidden, depth=depth, heads=heads,
                                     p_drop=p_drop, in_dim=in_dim)
        self.to_cap = nn.Linear(dim, cap_dim)
        self.cap_dim = cap_dim

    def forward(self, capability):
        tok = self.enc(capability)
        return self.to_cap(tok[:, 0]), tok


class ConstantCapabilityEncoder(nn.Module):
    """`clear_noemb` / `specialist`: the embodiment token carries no body information.

    Architecturally identical to MorphCapabilityEncoder (same MorphologyEncoder, same
    encoder shape, spec 8.2 'match total per-model capacity') but the rows it encodes
    are a LEARNED CONSTANT bank, not phi_B, so the token is byte-identical for every body
    and no body ID can hide in it (spec 8.3).
    """

    def __init__(self, dim, cap_dim=64, hidden=128, depth=2, heads=4, p_drop=0.15,
                 n_rows=8, in_dim=STRUCTURE_DIM):
        super().__init__()
        self.inner = MorphCapabilityEncoder(dim, cap_dim=cap_dim, hidden=hidden, depth=depth,
                                            heads=heads, p_drop=p_drop)
        self.rows = nn.Parameter(torch.randn(1, n_rows, in_dim) * 0.02)
        self.cap_dim = cap_dim

    def forward(self, capability):
        rows, _ = capability
        b = rows.shape[0]
        const = self.rows.expand(b, -1, -1)
        mask = torch.ones(const.shape[:2], dtype=torch.bool, device=const.device)
        return self.inner((const, mask))


# --------------------------------------------------------------------------------------
# model


class EmbodimentMazePAMO(nn.Module):
    def __init__(self, grid_hw=(12, 12), dim=128, depth=4, heads=4, dim_head=32,
                 percept_dim=96, percept_depth=3, cap_dim=64, cond="film",
                 emb_mode="morph", n_obj=N_OBJ_MAX, drop_obj=DROP_OBJ, p_drop=0.15,
                 contract_version=2, causal=True, object_attributes=False, surface_adapter=False, surface_tread_aware=False):
        super().__init__()
        assert emb_mode in ("morph", "none")
        self.emb_mode, self.grid_hw, self.n_obj = emb_mode, tuple(grid_hw), int(n_obj)
        if contract_version not in (1, 2):
            raise ValueError("unsupported CLEAR maze contract_version")
        self.contract_version, self.causal = int(contract_version), bool(causal)
        self.object_attributes = bool(object_attributes)
        self._architecture = dict(depth=depth, heads=heads, dim_head=dim_head,
                                  percept_depth=percept_depth, cap_dim=cap_dim, cond=cond, p_drop=p_drop,
                                  object_attributes=self.object_attributes)
        self._architecture["surface_adapter"] = bool(surface_adapter)
        self._architecture["surface_tread_aware"] = bool(surface_tread_aware)
        self.surface_adapter = None
        if surface_adapter:
            from experiments.exp3.surface_adapter import SurfaceAdapter
            self.surface_adapter = SurfaceAdapter(cap_dim,surface_tread_aware)
        self.drop_obj = tuple(drop_obj)
        cap_cls = MorphCapabilityEncoder if emb_mode == "morph" else ConstantCapabilityEncoder
        self.capability_encoder = cap_cls(dim, cap_dim=cap_dim, p_drop=p_drop)
        self.perception = PerceptionEncoder(percept_dim, cap_dim=cap_dim, depth=percept_depth,
                                            in_chans=PERCEPT_CHANS, cond=cond)
        self.scene_encoder = MetricSceneEncoder(dim, self.grid_hw, in_dim=percept_dim)
        self.priority_head = PriorityHead(self.grid_hw, dim=dim, depth=depth, heads=heads,
                                          dim_head=dim_head, drop_obj=self.drop_obj,
                                          mover_head=True, obj_extra_dim=4 if self.object_attributes else 0)
        if self.contract_version == 1:
            self.to_target_q = nn.Linear(dim, percept_dim)
            self.target_scale = nn.Parameter(torch.tensor(1.0 / percept_dim ** 0.5))
        else:
            self.target_flow = RankCausalTargetFlow(dim, 2, depth, heads, dim_head, causal)
        self.to_role = nn.Linear(dim, N_ROLES)
        self.to_feas = nn.Linear(dim, N_ROLES)

    # -- forward ------------------------------------------------------------------------
    def front(self, batch):
        cap, cap_token = self.capability_encoder((batch["morph_rows"], batch["morph_mask"]))
        inp = perception_input(batch["heights"], batch["slope"], batch["width"],
                               batch["occupancy"], batch["start_map"], batch["goal_map"],
                               batch.get("edge_geometry"))
        features, edge_logits = _percept(self.perception, inp, cap)
        if self.surface_adapter is not None and "edge_geometry" in batch:
            edge_logits = self.surface_adapter(batch, cap)
        return cap_token, self.scene_encoder(features), edge_logits, features

    def heads(self, batch, cap_token, scene_tokens, features):
        feat = object_features(batch["pose"], batch["mass"], batch["extent"],
                               torch.zeros_like(batch["mass"]), 0.0, batch["movable_in"],
                               self.grid_hw, drop=self.drop_obj)
        if self.object_attributes:
            # Geometry and friction determine reach/tipping in the oracle. The
            # old max-extent-only token made those labels partially unobservable.
            if 'attributes' not in batch:
                raise ValueError('object_attributes model requires freshly labeled attribute-aware examples')
            feat = torch.cat([feat, batch['attributes']], dim=-1)
        out = self.priority_head._encode(None, feat, None, context=(cap_token, scene_tokens))
        mu, raw_sigma = self.priority_head.to_mu_sigma(out).unbind(dim=-1)
        if self.contract_version >= 2:
            sigma = priority_scale(raw_sigma)
        else:
            sigma = F.softplus(raw_sigma).clamp(max=self.priority_head.SIGMA_MAX
                                                - self.priority_head.SIGMA_MIN) + self.priority_head.SIGMA_MIN
        mover_logit = self.priority_head.to_mover(out).squeeze(-1)
        result = dict(mu=mu, sigma=sigma, mover_logit=mover_logit,
                      role_logits=self.to_role(out), feas_logits=self.to_feas(out), obj_out=out)
        if self.contract_version == 1:
            q = self.to_target_q(out)
            result["target_logits"] = (torch.einsum("bnd,bdhw->bnhw", q, features)
                                       * self.target_scale).flatten(2)
        return result

    def forward(self, batch):
        cap_token, scene_tokens, edge_logits, features = self.front(batch)
        h = self.heads(batch, cap_token, scene_tokens, features)
        h["edge_logits"] = edge_logits
        h["context"] = (cap_token, scene_tokens)
        return h

    def sample_targets(self, heads, rank, selected, n_steps=30, generator=None):
        if self.contract_version != 2:
            raise ValueError("legacy maze uses target_logits, not target flow")
        return self.target_flow.sample(heads["obj_out"], *heads["context"], rank, selected,
                                       n_steps=n_steps, generator=generator)

    def loss(self, batch, weights=None, generator=None):
        w = {"rank": 1.0, "mover": 1.0, "edge": 1.0, "target": 1.0, "role": 1.0, "feas": 1.0,
             "kl": 1e-3 if self.contract_version >= 2 else 0.0}
        w.update(weights or {})
        h = self(batch)
        obj = batch["obj_mask"]
        n = batch["rank"].shape[1]
        # --- ordering: Bradley-Terry over the sampled u, weighted by 1/rank distance
        # (the formulation PAMO.forward uses for the gauss head, infer_movable branch)
        u = h["mu"] + h["sigma"] * self.priority_head.sample_noise(h["sigma"], generator=generator)
        rank_loss = sampled_priority_rank_loss(u, batch["rank"], obj)
        # --- mover head: BCE over real slots
        mt = ((batch["rank"] >= 0) & (batch["rank"] < n)).to(h["mover_logit"].dtype)
        mover_loss = _masked_bce(h["mover_logit"], mt, obj)
        # --- edge traversability
        edge_loss = F.binary_cross_entropy_with_logits(h["edge_logits"], batch["edge_label"])
        with torch.no_grad():
            edge_acc = ((h["edge_logits"] > 0).float() == batch["edge_label"]).float().mean()
        # --- target cell / role: movers only
        mv = obj & (batch["target_cell"] >= 0) & (mt > 0)
        if mv.any():
            if self.contract_version == 1:
                target_loss = F.cross_entropy(h["target_logits"][mv], batch["target_cell"][mv])
            else:
                # Oracle park cells already supervise endpoints; no motion labels are invented.
                height, width = self.grid_hw
                cell = batch["target_cell"].clamp(min=0)
                g1 = torch.stack([(cell % width + .5) / width,
                                  (cell // width + .5) / height], dim=-1)
                g0 = torch.randn(g1.shape, device=g1.device, dtype=g1.dtype, generator=generator)
                t = torch.rand(g1.shape[0], device=g1.device, generator=generator)
                gt = (1 - t[:, None, None]) * g0 + t[:, None, None] * g1
                rank, selected = selected_ranks(batch["rank"], mv)
                v = self.target_flow(h["obj_out"], *h["context"], gt, t, rank, selected)
                target_loss = F.mse_loss(v[mv], (g1 - g0)[mv])
            role_loss = F.cross_entropy(h["role_logits"][mv], batch["role"][mv])
        else:
            target_loss = role_loss = h["mu"].sum() * 0.0
        # --- per (object, role) feasibility belief
        feas_loss = _masked_bce(h["feas_logits"], batch["feas_label"], batch["feas_mask"])
        kl = .5 * (h["sigma"].square() + h["mu"].square() - 1) - h["sigma"].log()
        kl_loss = kl[obj].mean() if obj.any() else h["mu"].sum() * 0
        total = (w["kl"] * kl_loss + w["rank"] * rank_loss + w["mover"] * mover_loss + w["edge"] * edge_loss
                 + w["target"] * target_loss + w["role"] * role_loss + w["feas"] * feas_loss)
        return total, {"loss": float(total.detach()), "rank": float(rank_loss.detach()), "mover": float(mover_loss.detach()),
                       "edge": float(edge_loss.detach()), "edge_acc": float(edge_acc),
                       "target": float(target_loss.detach()), "role": float(role_loss.detach()),
                       "feas": float(feas_loss.detach()), "kl": float(kl_loss.detach())}

    def config(self) -> dict:
        return {"grid_hw": list(self.grid_hw), "emb_mode": self.emb_mode, "n_obj": self.n_obj,
                "dim": self.priority_head.to_mu_sigma.in_features,
                "percept_dim": self.scene_encoder.proj[0].in_channels,
                "drop_obj": list(self.drop_obj), "contract_version": self.contract_version,
                "causal": self.causal, **self._architecture}


def _percept(enc: PerceptionEncoder, inp, cap):
    """PerceptionEncoder.forward assembles its own 8-channel input; exp 03 needs 10
    (slope, passage width), so the conv stack is applied to a pre-assembled tensor."""
    if enc.cond == "concat":
        b, _, hh, ww = inp.shape
        inp = torch.cat([inp, cap[:, :, None, None].expand(b, enc.cap_dim, hh, ww)], 1)
        x = enc.act(enc.stem(inp))
        for conv, norm in zip(enc.blocks, enc.norms):
            x = x + enc.act(norm(conv(x)))
    else:
        x = enc.act(enc.stem_film(enc.stem(inp), cap))
        for conv, norm, film in zip(enc.blocks, enc.norms, enc.films):
            x = x + enc.act(film(norm(conv(x)), cap))
    return x, enc.edge_head(x)


def _masked_bce(logit, target, mask):
    if not mask.any():
        return logit.sum() * 0.0
    return F.binary_cross_entropy_with_logits(logit[mask], target[mask].to(logit.dtype))


# --------------------------------------------------------------------------------------
# examples and batches


@dataclass
class MazeExample:
    """One (base scene, embodiment) training example: everything the model sees plus the
    oracle's privileged targets.  Built once by `label_with_oracle`, cached as .npz."""
    scene_id: str
    base_scene_id: str
    embodiment_id: str
    heights: np.ndarray
    slope: np.ndarray
    width: np.ndarray
    occupancy: np.ndarray
    start_map: np.ndarray
    goal_map: np.ndarray
    morph_rows: np.ndarray
    morph_mask: np.ndarray
    pose: np.ndarray           # (N_OBJ_MAX, 3) x=col, y=row, theta
    mass: np.ndarray
    extent: np.ndarray
    obj_mask: np.ndarray
    movable: np.ndarray        # privileged: this body can move it (label only)
    rank: np.ndarray           # position in the oracle order, n = never moved
    target_cell: np.ndarray    # flat index of the oracle park cell, -1 for non-movers
    role: np.ndarray           # ROLES index, -1 for non-movers
    feas_label: np.ndarray     # (N_OBJ_MAX, N_ROLES)
    feas_mask: np.ndarray
    edge_label: np.ndarray     # (4, h, w)
    solvable: bool
    k_star: int
    extra: dict = field(default_factory=dict)


def example_from(scene, cap, structure, result, scene_id, n_obj=N_OBJ_MAX) -> MazeExample:
    """MazeScene + privileged BodyCapability + phi_B + OracleResult -> MazeExample."""
    from clear.maze.robots import padded_rows
    h, w = scene.shape
    n = len(scene.objects)
    assert n <= n_obj, f"{n} objects > N_OBJ_MAX {n_obj}"
    pose = np.zeros((n_obj, 3), np.float32)
    mass = np.zeros(n_obj, np.float32)
    extent = np.zeros(n_obj, np.float32)
    obj_mask = np.zeros(n_obj, bool)
    movable = np.zeros(n_obj, bool)
    feas = np.zeros((n_obj, N_ROLES), np.float32)
    fmask = np.zeros((n_obj, N_ROLES), bool)
    for i, o in enumerate(scene.objects):
        pose[i] = (o.cell[1], o.cell[0], o.theta)
        mass[i], extent[i], obj_mask[i] = o.mass, o.extent, True
        movable[i] = cap.can_move(o)
        for k, role in enumerate(ROLES):
            parts = [p for p in cap.parts if p.role == role]
            fmask[i, k] = True
            feas[i, k] = float(any(cap.part_can_move(p, o)[0] for p in parts))
    rank = np.full(n_obj, n_obj, np.int64)
    target = np.full(n_obj, -1, np.int64)
    role_t = np.full(n_obj, -1, np.int64)
    if result.solvable and result.plans:
        plan = result.plans[0]
        for pos, oid in enumerate(plan.interaction_order):
            i = scene.index_of(int(oid))
            rank[i] = pos
            r, c = plan.target_cells[pos]
            target[i] = int(r) * w + int(c)
            role_t[i] = ROLES.index(plan.part_roles[pos])
    occ = scene.occupancy().astype(np.float32)
    sm = np.zeros((h, w), np.float32); sm[scene.start] = 1.0
    gm = np.zeros((h, w), np.float32); gm[scene.goal] = 1.0
    edge = np.zeros((len(NEIGHBORS), h, w), np.float32)
    for k, (dr, dc) in enumerate(NEIGHBORS):
        for r in range(h):
            for c in range(w):
                edge[k, r, c] = float(cap.can_enter(scene, (r, c), (r + dr, c + dc)))
    rows, rmask = padded_rows(structure.rows, MAX_LINKS)
    return MazeExample(scene_id, scene.base_scene_id, cap.embodiment_id,
                       np.asarray(scene.height, np.float32), np.asarray(scene.slope_deg, np.float32),
                       np.asarray(scene.passage_width, np.float32), occ, sm, gm, rows, rmask,
                       pose, mass, extent, obj_mask, movable, rank, target, role_t, feas, fmask,
                       edge, bool(result.solvable), int(result.k_star or 0),
                       {"family": scene.family, "structure_hash": structure.structure_hash,
                        "object_attributes": [[o.dx_m/scene.cell_m, o.dy_m/scene.cell_m,
                                                o.height_m, o.friction] for o in scene.objects]
                                             + [[0.,0.,0.,0.]]*(n_obj-n)})


def intermediate_examples(scene, cap, structure, result, scene_id):
    """Relabel executed oracle prefixes within the parent's training split.

    Fresh remaining-plan labels, including the final zero-interaction suffix,
    teach re-observation without exposing any held-out scene to training.
    """
    from clear.maze.world import AbstractController
    from experiments.exp3.oracle import label
    if not result.solvable or not result.plans:
        return []
    ctrl = AbstractController(scene.copy(), cap)
    plan = result.plans[0]
    examples = []
    for k, (oid, target, part) in enumerate(zip(plan.interaction_order, plan.target_cells, plan.body_parts)):
        execution = ctrl.interact(oid, target, body_part=part)
        if not execution.success:
            raise ValueError(f'{scene_id}: labeled oracle prefix {k} failed abstract execution')
        remaining = ctrl.scene.copy()
        remaining.start = tuple(ctrl.robot)
        ex = example_from(remaining, cap, structure, label(remaining, cap), f'{scene_id}__prefix{k+1}')
        ex.extra.update(parent_scene_id=scene_id, executed_prefix_length=k+1)
        examples.append(ex)
    return examples


_T = {"heights", "slope", "width", "occupancy", "start_map", "goal_map", "morph_rows",
      "pose", "mass", "extent", "edge_label", "feas_label"}
_B = {"morph_mask", "obj_mask", "movable", "feas_mask"}
_L = {"rank", "target_cell", "role"}


def collate(examples, device="cpu") -> dict:
    """MazeExamples -> the batch dict `EmbodimentMazePAMO.forward` eats.

    `movable_in` is the DUMMY movability column object_features would consume; with
    drop_obj=('can_move',) it is dropped before it reaches the model, so the privileged
    label never becomes an input.  It is passed only to keep the shared signature."""
    out = {}
    for k in _T:
        out[k] = torch.as_tensor(np.stack([getattr(e, k) for e in examples]), dtype=torch.float32, device=device)
    for k in _B:
        out[k] = torch.as_tensor(np.stack([getattr(e, k) for e in examples]), dtype=torch.bool, device=device)
    for k in _L:
        out[k] = torch.as_tensor(np.stack([getattr(e, k) for e in examples]), dtype=torch.int64, device=device)
    out["movable_in"] = torch.zeros_like(out["mass"], dtype=torch.bool)
    attributes = [getattr(e, 'extra', {}).get('object_attributes') for e in examples]
    if all(a is not None for a in attributes):
        out['attributes'] = torch.as_tensor(np.array(attributes), dtype=torch.float32, device=device)
    elif any(a is not None for a in attributes):
        raise ValueError('mixed old/new example schemas; relabel this dataset')
    out["meta"] = [(e.scene_id, e.base_scene_id, e.embodiment_id) for e in examples]
    return out


def save_examples(path: str, examples) -> str:
    import os
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    arrays, meta = {}, []
    keys = sorted(_T | _B | _L)
    for i, e in enumerate(examples):
        for k in keys:
            arrays[f"{i}/{k}"] = getattr(e, k)
        meta.append({"scene_id": e.scene_id, "base_scene_id": e.base_scene_id,
                     "embodiment_id": e.embodiment_id, "solvable": e.solvable,
                     "k_star": e.k_star, "extra": e.extra})
    import json
    arrays["_meta"] = np.frombuffer(json.dumps(meta).encode(), dtype=np.uint8)
    np.savez_compressed(path, **arrays)
    return path


def load_examples(path: str) -> list:
    import json
    z = np.load(path, allow_pickle=False)
    meta = json.loads(bytes(z["_meta"]).decode())
    keys = sorted(_T | _B | _L)
    out = []
    for i, m in enumerate(meta):
        kw = {k: z[f"{i}/{k}"] for k in keys}
        out.append(MazeExample(m["scene_id"], m["base_scene_id"], m["embodiment_id"],
                               solvable=bool(m["solvable"]), k_star=int(m["k_star"]),
                               extra=m["extra"], **kw))
    return out


def build_model(cfg: dict, emb_mode: str, grid_hw=(12, 12)) -> EmbodimentMazePAMO:
    m = cfg.get("model", cfg)
    return EmbodimentMazePAMO(grid_hw=grid_hw, dim=int(m.get("dim", 128)),
                              depth=int(m.get("depth", 4)), heads=int(m.get("heads", 4)),
                              percept_dim=int(m.get("percept_dim", 96)),
                              percept_depth=int(m.get("percept_depth", 3)),
                              cap_dim=int(m.get("cap_dim", 64)), emb_mode=emb_mode,
                              dim_head=int(m.get("dim_head", 32)),
                              cond=m.get("cond", "film"), p_drop=float(m.get("p_drop", .15)),
                              n_obj=int(m.get("n_obj", N_OBJ_MAX)),
                              contract_version=int(m.get("contract_version", 2)),
                              causal=bool(m.get("causal", True)),
                              object_attributes=bool(m.get("object_attributes", False)),
                              drop_obj=tuple(m.get("drop_obj", DROP_OBJ)),
                              surface_adapter=bool(m.get("surface_adapter", False)),
                              surface_tread_aware=bool(m.get("surface_tread_aware", False)))
