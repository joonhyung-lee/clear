"""Learned morphology-conditioned admission thresholds for explicit surfaces.

The thresholds are inferred from phi_B and supervised edge labels, never read
from a privileged capability table during prediction. This optional head keeps
legacy perception and interaction/ordering/flow weights unchanged.
"""
import torch
from torch import nn
from experiments.exp3.model import _edge_delta_t


class SurfaceAdapter(nn.Module):
    def __init__(self,cap_dim,tread_aware=False):
        super().__init__()
        self.tread_aware=tread_aware
        self.network=nn.Sequential(nn.Linear(cap_dim,32),nn.Tanh(),nn.Linear(32,3 if tread_aware else 2))

    def limits(self,cap):
        return self.network(cap).sigmoid()*cap.new_tensor([.6,45.,1.] if self.tread_aware else [.6,45.])

    def forward(self,batch,cap):
        limits=self.limits(cap)
        req=batch['edge_geometry']
        # Neighbor slope, with the same four directions as the generic head.
        slope=torch.stack([_edge_delta_t(batch['slope'],k)+batch['slope'] for k in range(4)],dim=1)
        step_margin=(limits[:,0,None,None,None]-req)/.01
        slope_margin=(limits[:,1,None,None,None]-slope)/.4
        margins=[step_margin,slope_margin]
        if self.tread_aware:
            margins.append((batch['surface_tread']-limits[:,2,None,None,None])/.01)
        logits=-torch.logsumexp(torch.stack([-m for m in margins]),dim=0)
        wall=batch['surface_wall_mask']
        neighbor_wall=torch.stack([_edge_delta_t(wall,k)+wall for k in range(4)],dim=1)>0
        return logits.masked_fill(neighbor_wall,-30.)
