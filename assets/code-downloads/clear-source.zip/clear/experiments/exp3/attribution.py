"""Embodiment-conditioned traversability attribution (spec 11.2).

The claim under test is that the plan changes because phi_B changed, so the analysis holds
the RGB/scene observation fixed and swaps only phi_B.  Spec 11.2's preferred order is
counterfactual occlusion first, integrated gradients second, Grad-CAM only when the spatial
encoder exposes conv maps and raw attention only as a supplementary diagnostic; occlusion
is what is implemented here (option 1).

    occlusion_map(model, example, phi_B)
        For every spatial scene token, blank that patch of the perception input and measure
        how much the model's own route belief moves.  The score reported per cell is the
        change in the predicted traversability of that cell's four edges, plus the change
        in target predictions and mover probabilities, so the map answers "which patch of terrain is this BODY
        reading".  Returns (h, w) in the input grid's own resolution.

    body_contrast(model, example, phi_a, phi_b)
        The same scene under two structural descriptions: (map_a, map_b, map_a - map_b).
        The difference map is the figure -- it is nonzero only if phi_B changed the read.

`clear_noemb` and the specialists have no phi_B channel, so their difference map is exactly
zero by construction; that is the control, and `body_contrast` returns it rather than
refusing, because a flat control panel next to a structured CLEAR panel is the evidence.
"""
from __future__ import annotations

import numpy as np
import torch

from experiments.exp3.model import collate
from clear.model.causalflownet import rank_selected, selection_mask

OCCLUDE_PATCH = 2       # cells; matches MetricSceneEncoder's stride-2 token footprint


@torch.no_grad()
def _route_belief(model, batch, seed=0, flow_steps=30, max_interactions=6):
    out = model(batch)
    edge = torch.sigmoid(out["edge_logits"][0]).cpu().numpy()          # (4, h, w)
    if model.contract_version == 1:
        tgt = torch.softmax(out["target_logits"][0], dim=-1).cpu().numpy()
    else:
        gen = torch.Generator(device=out["mu"].device).manual_seed(seed)
        u = out["mu"] + out["sigma"] * model.priority_head.sample_noise(out["sigma"], generator=gen)
        selected = selection_mask(out["mover_logit"], batch["obj_mask"])
        rank, active = rank_selected(u, selected, limit=max_interactions)
        tgt = model.sample_targets(out, rank, active, n_steps=flow_steps, generator=gen)[0].cpu().numpy()
    mover = torch.sigmoid(out["mover_logit"][0]).cpu().numpy()
    if model.contract_version >= 2:
        valid = batch["obj_mask"][0].cpu().numpy()
        tgt, mover = tgt[valid], mover[valid]
    return edge, tgt, mover


@torch.no_grad()
def occlusion_map(model, example, phi_B=None, patch: int = OCCLUDE_PATCH,
                  device="cpu", seed=0, flow_steps=30, max_interactions=6) -> np.ndarray:
    """V1 compares categorical probabilities; V2 compares normalized endpoints.

    Replaying the same random stream for every perturbation and both bodies
    isolates input changes from sampling noise. V2 values are not probabilities.
    """
    model.eval()
    ex = example
    base = collate([ex], device)
    if phi_B is not None:
        rows, mask = phi_B
        base["morph_rows"] = torch.as_tensor(rows[None], dtype=torch.float32, device=device)
        base["morph_mask"] = torch.as_tensor(mask[None], dtype=torch.bool, device=device)
    e0, t0, m0 = _route_belief(model, base, seed, flow_steps, max_interactions)
    h, w = ex.heights.shape
    out = np.zeros((h, w), np.float32)
    flat_h = float(np.median(ex.heights))
    for r0 in range(0, h, patch):
        for c0 in range(0, w, patch):
            b = {k: (v.clone() if torch.is_tensor(v) else v) for k, v in base.items()}
            sl = (slice(None), slice(r0, r0 + patch), slice(c0, c0 + patch))
            b["heights"][sl] = flat_h
            b["slope"][sl] = 0.0
            b["width"][sl] = float(np.max(ex.width))
            b["occupancy"][sl] = 0.0
            e1, t1, m1 = _route_belief(model, b, seed, flow_steps, max_interactions)
            target_change = np.abs(t1 - t0).mean() * t0.shape[-1] if t0.size else 0.0
            mover_change = np.abs(m1 - m0).mean() if m0.size else 0.0
            score = np.abs(e1 - e0).mean() + target_change + mover_change
            out[r0:r0 + patch, c0:c0 + patch] = score
    return out


def body_contrast(model, example, phi_a, phi_b, **kw):
    """(map_a, map_b, map_a - map_b) for the SAME scene under two structural descriptions."""
    a = occlusion_map(model, example, phi_a, **kw)
    b = occlusion_map(model, example, phi_b, **kw)
    return a, b, a - b


def structure_pair(body_a: str, body_b: str):
    from clear.maze.robots import padded_rows, structure_for
    return padded_rows(structure_for(body_a).rows), padded_rows(structure_for(body_b).rows)
