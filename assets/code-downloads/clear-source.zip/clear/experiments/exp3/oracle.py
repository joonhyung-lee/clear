"""Privileged oracle for exp 03 (spec 7 / 8.1): exact traversal + interaction feasibility per
embodiment, all minimum-interaction plans up to a cap, route classes and plan signatures.

  solve_orders     Dijkstra over (cell, frozenset(moved)) with lexicographic cost
                   (n_moved, path_len) -- clear.data.oracle.solve's search with the body's edge
                   predicate (step / slope / width) and the Sokoban push rule (the cell ahead
                   must be free and placeable; a grasping body may pull instead).
  assemble_plan    parks each mover (clear.data.oracle.park_candidates / park_valid, body-aware
                   through MazeScene.can_enter) and DRY-RUNS the plan on the AbstractController
                   with the privileged body, so the label's targets are exactly what the
                   evaluator's executor can execute; route class and path length are read off
                   the resulting trajectory.
  signature(P)     (route_class, interaction_order, body_part_roles) -- roles, not part names
                   (decision D3 in REPORT): a signature that differs only because the same
                   role has a body-specific name would make every interacting pair a 'switch'.
  OraclePlanner    Planner(privileged=True): predict(observation, BodyCapability).

Labels are validated by construction: every plan in the optimal set was executed on the
abstract controller before it was recorded (spec 12.3: independent validation is the
executor, not the search).
"""
from __future__ import annotations

import copy
import heapq
import json
import time
from dataclasses import asdict, dataclass, field

import numpy as np

from experiments.common.interfaces import PlanPrediction, Planner
from clear.maze.world import AbstractController, MazeScene, NEIGHBORS, bfs_cells, trajectory_length_m
from clear.maze.robots import BodyCapability, ROLES
from clear.data.grid import attach_geometry_points
from clear.data.oracle import park_candidates, park_valid

MAX_ORDERS = 8
ABSTAIN_SIGNATURE = ("none", (), ())   # the correct 'plan' for an unsolvable (scene, body)


@dataclass
class OraclePlan:
    route_class: str
    interaction_order: list          # object ids
    target_cells: list               # (r, c) per interaction
    body_parts: list                 # concrete part names
    part_roles: list                 # ROLES entries
    path_length_m: float
    num_interactions: int
    trajectory: list                 # robot cells of the dry run
    legs: list                       # transit legs (cell paths) of the dry run, in order
    routes: dict = field(default_factory=dict)   # object id -> {"cells", "modes"}

    def signature(self) -> tuple:
        return (self.route_class, tuple(int(i) for i in self.interaction_order), tuple(self.part_roles))

    @property
    def plan_id(self) -> str:
        return signature_id(self.signature())

    def to_dict(self) -> dict:
        d = asdict(self)
        d["signature"] = list(self.signature())
        d["plan_id"] = self.plan_id
        return d


def signature_id(sig) -> str:
    route, order, roles = sig
    return f"{route}|{','.join(str(i) for i in order)}|{','.join(roles)}"


def signature_from_id(pid: str) -> tuple:
    route, order, roles = pid.split("|")
    return (route, tuple(int(i) for i in order.split(",") if i != ""), tuple(r for r in roles.split(",") if r != ""))


@dataclass
class OracleResult:
    embodiment_id: str
    solvable: bool
    k_star: int | None
    plans: list                      # [OraclePlan] all optimal plans (representative per role assignment)
    signatures: list                 # sorted list of signature tuples (the optimal signature set)
    orders: list                     # distinct optimal orders (object ids)
    optimal_set_complete: bool
    solve_time_s: float

    def signature_set(self) -> set:
        return set(tuple(s) if not isinstance(s, tuple) else s for s in self.signatures) or {ABSTAIN_SIGNATURE}

    def to_label(self):
        from experiments.common.manifests import OracleLabel
        return OracleLabel(solvable=self.solvable, min_interactions=self.k_star,
                           valid_orders=[list(o) for o in self.orders],
                           valid_plan_ids=[p.plan_id for p in self.plans],
                           optimal_set_complete=self.optimal_set_complete,
                           # NB: no solve_time_s here.  The manifest is hashed by
                           # manifests.freeze(); a wall-clock field would make the frozen
                           # test split fail verify_frozen() on every re-label.  Timings
                           # live in oracle_labels.jsonl, which is not hashed.
                           extra={"signatures": [signature_id(s) for s in self.signatures]})

    def to_dict(self) -> dict:
        return {"embodiment_id": self.embodiment_id, "solvable": self.solvable, "k_star": self.k_star,
                "orders": [list(o) for o in self.orders], "signatures": [signature_id(s) for s in self.signatures],
                "plans": [p.to_dict() for p in self.plans], "optimal_set_complete": self.optimal_set_complete,
                "solve_time_s": round(self.solve_time_s, 4)}

    @classmethod
    def from_dict(cls, d: dict) -> "OracleResult":
        plans = [OraclePlan(**{k: v for k, v in p.items() if k not in ("signature", "plan_id")}) for p in d["plans"]]
        for p in plans:
            p.target_cells = [tuple(c) for c in p.target_cells]
            p.trajectory = [tuple(c) for c in p.trajectory]
            p.legs = [[tuple(c) for c in leg] for leg in p.legs]
            p.routes = {int(k): v for k, v in p.routes.items()}
        return cls(d["embodiment_id"], d["solvable"], d["k_star"], plans,
                   [signature_from_id(s) for s in d["signatures"]], [tuple(o) for o in d["orders"]],
                   d["optimal_set_complete"], d.get("solve_time_s", 0.0))


# --------------------------------------------------------------------------------------
# search


def _push_or_pull_ok(scene: MazeScene, body, cell, nxt, d, occ, moved) -> bool:
    obj = scene.objects[occ[nxt]]
    blocked_for_obj = scene.object_blocked_cells(obj)
    ahead = (nxt[0] + d[0], nxt[1] + d[1])
    push_ok = (scene.in_bounds(ahead) and not scene.is_wall(ahead) and ahead not in blocked_for_obj
               and (occ.get(ahead) is None or occ.get(ahead) in moved))
    back = (cell[0] - d[0], cell[1] - d[1])
    pull_ok = (body.can_drag and scene.in_bounds(back) and not scene.is_wall(back)
               and scene.can_enter(body, cell, back) and (occ.get(back) is None or occ.get(back) in moved))
    return push_ok or pull_ok


def solve_orders(scene: MazeScene, body: BodyCapability, max_orders: int = MAX_ORDERS):
    """-> (orders (list of tuples of object INDICES), cost) ; ([], None) if unsolvable.
    Cost is lexicographic (n_moved, path_len)."""
    occ = scene.occupied()
    src = (tuple(scene.start), frozenset())
    dist = {src: (0, 0)}
    parents = {src: []}
    pq = [((0, 0), tuple(scene.start), frozenset())]
    goal = tuple(scene.goal)
    while pq:
        cost, cell, moved = heapq.heappop(pq)
        if cost > dist.get((cell, moved), cost):
            continue
        for dr, dc in NEIGHBORS:
            nxt = (cell[0] + dr, cell[1] + dc)
            if not scene.in_bounds(nxt) or not scene.can_enter(body, cell, nxt):
                continue
            idx = occ.get(nxt)
            if idx is None or idx in moved:
                step, nmoved = (0, 1), moved
            else:
                if not body.can_move(scene.objects[idx]):
                    continue
                if not _push_or_pull_ok(scene, body, cell, nxt, (dr, dc), occ, moved):
                    continue
                step, nmoved = (1, 1), moved | {idx}
            ncost = (cost[0] + step[0], cost[1] + step[1])
            nstate = (nxt, nmoved)
            known = dist.get(nstate)
            if known is None or ncost < known:
                dist[nstate] = ncost
                parents[nstate] = [(cell, moved)]
                heapq.heappush(pq, (ncost, nxt, nmoved))
            elif ncost == known and (cell, moved) not in parents[nstate]:
                parents[nstate].append((cell, moved))
    goals = [s for s in dist if s[0] == goal]
    if not goals:
        return [], None
    best = min(dist[s] for s in goals)
    goals = [s for s in goals if dist[s] == best]
    memo = {}

    def orders_to(state):
        if state == src:
            return {()}
        if state in memo:
            return memo[state]
        _, moved = state
        out = set()
        for prev in parents.get(state, []):
            newly = moved - prev[1]
            for s in orders_to(prev):
                out.add(s + tuple(newly) if newly else s)
                if len(out) >= max_orders:
                    break
            if len(out) >= max_orders:
                break
        memo[state] = out
        return out

    orders = set()
    for g in goals:
        orders |= orders_to(g)
        if len(orders) >= max_orders:
            break
    return sorted(orders)[:max_orders], best


# --------------------------------------------------------------------------------------
# plan assembly (parks + dry run on the abstract controller)


def _placeable(scene: MazeScene, obj, cell, positions, i) -> bool:
    if not scene.in_bounds(cell) or scene.is_wall(cell):
        return False
    if cell in (tuple(scene.start), tuple(scene.goal)):
        return False
    if any(j != i and c is not None and tuple(c) == tuple(cell) for j, c in enumerate(positions)):
        return False
    return cell not in scene.object_blocked_cells(obj)


def assemble_plan(scene: MazeScene, body, order, part_choice=None, max_candidates: int = 12):
    """Park + dry-run one order (object INDICES) with `body` (a FeasibilityModel that also
    offers preferred_part / feasible_parts).  `part_choice`: optional {index: part name}.
    -> OraclePlan or None when no executable parking exists."""
    work = scene.copy()
    if work.wall_points is None:
        attach_geometry_points(work, seed=0)
    ctrl = AbstractController(work, body)
    parks, parts, roles, routes = [], [], [], {}
    for k, idx in enumerate(order):
        pending = list(order[k + 1:])
        positions = [o.cell for o in ctrl.scene.objects]
        obj = ctrl.scene.objects[idx]
        chosen = None
        tried = 0
        best = None          # (trajectory length, trial controller, cand, part name, info)
        for cand in park_candidates(ctrl.scene, positions, idx):
            if not _placeable(ctrl.scene, obj, cand, positions, idx):
                continue
            if not park_valid(ctrl.scene, body, positions, idx, pending, cand):
                continue
            tried += 1
            # which part: the caller's choice, else the body's preference (grasp needed if the route pulls)
            trial = copy.deepcopy(ctrl)
            name = (part_choice or {}).get(idx)
            if name is None:
                cand_part = body.preferred_part(obj) if hasattr(body, "preferred_part") else None
                if cand_part is None:
                    return None
                name = cand_part.name
            res = trial.interact(obj.object_id, cand, body_part=name)
            if res.success and "pull" in res.info.get("modes", []) and not trial.body.part(name).can_grasp:
                res = None
            if res is not None and res.success:
                # nearest-first rings can hand back a park that needs a long Sokoban loop while a
                # park one ring further is a straight push: keep the shortest executable one
                # among the first few valid candidates (measured: 9-move zig-zag vs 3 pushes).
                n = len(trial.trajectory) - len(ctrl.trajectory)
                if best is None or n < best[0]:
                    best = (n, trial, cand, name, res.info)
                if len(res.info.get("route", [])) <= 3:
                    break            # already a minimal straight push; nothing shorter exists
            if tried >= max_candidates:
                break
        if best is not None:
            ctrl = best[1]
            chosen = (best[2], best[3], best[4])
        if chosen is None:
            return None
        cand, name, info = chosen
        parks.append(tuple(cand))
        parts.append(name)
        roles.append(body.part(name).role)
        routes[int(obj.object_id)] = {"cells": info.get("route", []), "modes": info.get("modes", [])}
    res = ctrl.navigate(tuple(scene.goal))
    if not res.success or not ctrl.at_goal():
        return None
    traj = list(ctrl.trajectory)
    return OraclePlan(route_class=scene.route_class(traj),
                      interaction_order=[int(scene.objects[i].object_id) for i in order],
                      target_cells=parks, body_parts=parts, part_roles=roles,
                      path_length_m=trajectory_length_m(traj, scene.cell_m), num_interactions=len(order),
                      trajectory=traj, legs=[list(l) for l in getattr(ctrl, "legs", [])], routes=routes)


def role_options(scene: MazeScene, body: BodyCapability, plan: OraclePlan) -> list:
    """All role assignments (one per mover) that are feasible for the body given the plan's
    routes (a pulled object needs a grasping part).  -> list of role tuples."""
    from itertools import product
    opts = []
    for oid in plan.interaction_order:
        obj = scene.object_by_id(oid)
        pulls = "pull" in plan.routes.get(int(oid), {}).get("modes", [])
        roles = sorted({p.role for p in body.parts if body.part_can_move(p, obj)[0] and (p.can_grasp or not pulls)})
        opts.append(roles or [body.part(plan.body_parts[plan.interaction_order.index(oid)]).role])
    return [tuple(t) for t in product(*opts)]


def label(scene: MazeScene, body: BodyCapability, max_orders: int = MAX_ORDERS) -> OracleResult:
    """Full oracle label for one (scene, body): all optimal orders that survive plan
    assembly, their signatures (over every feasible role assignment)."""
    t0 = time.perf_counter()
    orders, cost = solve_orders(scene, body, max_orders)
    if cost is None:
        return OracleResult(body.embodiment_id, False, None, [], [], [], True, time.perf_counter() - t0)
    plans, sigs, kept_orders = [], set(), []
    for order in orders:
        plan = assemble_plan(scene, body, list(order))
        if plan is None:
            continue
        kept_orders.append(tuple(int(scene.objects[i].object_id) for i in order))
        plans.append(plan)
        for roles in role_options(scene, body, plan):
            sigs.add((plan.route_class, tuple(plan.interaction_order), roles))
    if not plans:
        # the search found orders none of which park executably: unsolvable as scored
        return OracleResult(body.embodiment_id, False, None, [], [], [], True, time.perf_counter() - t0)
    complete = len(orders) < max_orders
    return OracleResult(body.embodiment_id, True, int(cost[0]), plans, sorted(sigs), kept_orders,
                        complete, time.perf_counter() - t0)


def label_all(scene: MazeScene, bodies: dict) -> dict:
    return {b: label(scene, cap) for b, cap in bodies.items()}


def switch_pairs(results: dict) -> tuple[list, list]:
    """(pairs whose optimal signature sets differ, pairs whose sets are disjoint = strict)."""
    names = sorted(results)
    differ, strict = [], []
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            sa, sb = results[a].signature_set(), results[b].signature_set()
            if sa != sb:
                differ.append((a, b))
            if not (sa & sb):
                strict.append((a, b))
    return differ, strict


# --------------------------------------------------------------------------------------
# planner


class OraclePlanner(Planner):
    """Privileged: receives the BodyCapability as `embodiment` and re-solves on the observed
    scene (heights / slopes / widths / objects are all observable; the capability predicates
    are not).  Returns the first optimal plan (body's preferred parts)."""
    name = "oracle"
    privileged = True

    def __init__(self, max_orders: int = MAX_ORDERS):
        self.max_orders = max_orders
        self.last: OracleResult | None = None

    def reset(self, seed: int) -> None:
        self.rng = np.random.default_rng(seed)

    def predict(self, observation, embodiment) -> PlanPrediction:
        assert isinstance(embodiment, BodyCapability), "OraclePlanner needs the privileged BodyCapability"
        t0 = time.perf_counter()
        scene = observation.as_scene()
        res = label(scene, embodiment, self.max_orders)
        self.last = res
        dt = time.perf_counter() - t0
        if not res.solvable:
            return PlanPrediction.empty(planning_time_s=dt, k_star=None, abstain=True)
        p = res.plans[0]
        return PlanPrediction(object_ids=list(p.interaction_order), target_configurations=[list(c) for c in p.target_cells],
                              scores={"k_star": res.k_star, "path_length_m": p.path_length_m,
                                      "trajectory": [list(c) for c in p.trajectory], "legs": p.legs,
                                      "routes": p.routes, "edge_trav": None, "part_roles": list(p.part_roles),
                                      "n_optimal_signatures": len(res.signatures)},
                              planning_time_s=dt, body_parts=list(p.body_parts), route_class=p.route_class)

    def update(self, observation, execution_result):
        return None   # the evaluator calls predict() again on the re-observed scene
