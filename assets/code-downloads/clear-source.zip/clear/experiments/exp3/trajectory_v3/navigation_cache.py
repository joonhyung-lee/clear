"""Bounded geometry reuse; learned edge scores remain tied to the current model."""
from collections import OrderedDict
from copy import deepcopy

from experiments.exp3.trajectory_v3.navigation import TerrainNavigator, scene_hash


class GeometryCache:
    def __init__(self, capacity=512):
        if not isinstance(capacity, int) or capacity < 1:
            raise ValueError("positive integer geometry cache capacity required")
        self.capacity, self.values = capacity, OrderedDict()

    def get(self, key, build):
        if key not in self.values:
            self.values[key] = build()
            if len(self.values) > self.capacity:
                self.values.popitem(last=False)
        self.values.move_to_end(key)
        return self.values[key]


class CachedTerrainNavigator(TerrainNavigator):
    def __init__(self, predictor, resolution=.1, threshold=.8, geometry_cache=None, analysis_capacity=128):
        super().__init__(predictor, resolution, threshold)
        if not isinstance(analysis_capacity, int) or analysis_capacity < 1:
            raise ValueError("positive integer analysis cache capacity required")
        self.geometry_cache = geometry_cache if geometry_cache is not None else GeometryCache()
        self.analysis_capacity, self.analyses = analysis_capacity, OrderedDict()

    def geometry(self, scene, embodiment):
        key = (scene_hash(scene), embodiment.footprint_radius_m, self.resolution)
        return self.geometry_cache.get(key, lambda: super(CachedTerrainNavigator, self).geometry(scene, embodiment))

    def analyze(self, scene, embodiment):
        key = (scene_hash(scene), embodiment.identity, self.predictor.identity, self.resolution, self.threshold)
        if key not in self.analyses:
            self.analyses[key] = super().analyze(deepcopy(scene), embodiment)
            if len(self.analyses) > self.analysis_capacity:
                self.analyses.popitem(last=False)
        self.analyses.move_to_end(key)
        return self.analyses[key]
