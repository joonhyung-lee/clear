from collections import deque
from copy import deepcopy
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, ObjectPath

FAMILIES = ("traversal_switch", "manipulation_switch")
PRIMARY_FAMILIES = ("mobility", "manipulation", "control")


def make_scene(family, seed):
    if family not in FAMILIES:
        raise ValueError(f"unknown scene family: {family}")
    rng = np.random.default_rng(seed)
    a, b = float(rng.uniform(1.9, 2.1)), float(rng.uniform(5.9, 6.1))
    ys = [float(rng.uniform(3.0, 3.2)), float(rng.uniform(2.8, 3.0)), float(rng.uniform(4.8, 5.0))]
    half = float(rng.uniform(.61, .65))
    walls = [[0, 0, .2, 8], [7.8, 0, 8, 8], [.2, 0, 7.8, .2], [.2, 7.8, 7.8, 8],
             [3.6, 1.9, 4.4, 6.2]]
    objects, guides = [], []
    for oid, (x, y) in enumerate(zip([a, b, b], ys)):
        lo, hi = (.2, 3.6) if oid == 0 else (4.4, 7.8)
        walls.extend([[lo, y-.125, x-half, y+.125], [x+half, y-.125, hi, y+.125]])
        pose = [x + float(rng.uniform(-.025, .025)), y + float(rng.uniform(-.025, .025)),
                float(rng.uniform(-.04, .04))]
        mass = float(rng.uniform(6, 12)) if family == "manipulation_switch" and oid == 0 else float(rng.uniform(1, 2))
        obj = dict(object_id=oid, pose=pose, size=[.9, .8, .6], mass_kg=mass,
                   friction=float(rng.uniform(.35, .5)))
        objects.append(obj)
        guides.append(ObjectPath(oid, (tuple(pose), (pose[0], y+1., pose[2]),
                                      (x+.95, y+1., pose[2]))).to_dict())
    terrain = []
    if family == "traversal_switch":
        rise = float(rng.uniform(.10, .20))
        for k, level in enumerate([1, 2, 1]):
            terrain.append(dict(bounds=[.2, 4.9+.3*k, 3.6, 5.2+.3*k], height_m=rise*level,
                                kind="stair_tread"))
    scene = dict(schema="clear-maze-path-scene-v1", family=family, generation_seed=int(seed),
                 world_size=[8., 8.], start=[4., float(rng.uniform(.7, 1.2)), 0.], goal=[4., 7.],
                 walls=walls, objects=objects, terrain=terrain,
                 gate_regions=[[a-half, ys[0]-.125, a+half, ys[0]+.125],
                               [b-half, ys[1]-.125, b+half, ys[1]+.125],
                               [b-half, ys[2]-.125, b+half, ys[2]+.125]])
    canonical_layout = {k: scene[k] for k in ("world_size", "walls", "gate_regions")}
    scene["layout_group_id"] = digest(canonical_layout)
    mirrored = bool(rng.integers(2))
    if mirrored:
        scene["walls"] = [[8-r, y0, 8-l, y1] for l, y0, r, y1 in walls]
        scene["gate_regions"] = [[8-r, y0, 8-l, y1] for l, y0, r, y1 in scene["gate_regions"]]
        for obj in objects:
            obj["pose"][0] = 8-obj["pose"][0]
            obj["pose"][2] = -obj["pose"][2]
        for tile in terrain:
            l, y0, r, y1 = tile["bounds"]
            tile["bounds"] = [8-r, y0, 8-l, y1]
        for guide in guides:
            guide["poses"] = [[8-x, y, -yaw] for x, y, yaw in guide["poses"]]
    scene["mirrored"] = mirrored
    scene["base_scene_id"] = family + "-" + digest(scene)[:16]
    scene["development_guides"] = guides
    scene["candidate_orders"] = [[0], [1, 2]]
    scene["capability_status"] = "uncalibrated; candidate routes are not body-specific oracle labels"
    return scene


def _divider(x, openings):
    walls = []
    last = .2
    for low, high in sorted(openings):
        if low > last:
            walls.append([x-.2, last, x+.2, low])
        last = high
    if last < 11.8:
        walls.append([x-.2, last, x+.2, 11.8])
    return walls


def _straight_path(oid, start, goal):
    points = np.linspace(np.asarray(start, float), np.asarray(goal, float), 8)
    return ObjectPath(oid, tuple((float(x), float(y), 0.) for x, y in points)).to_dict()


def make_primary_scene(family, seed, horizon=1):
    """12 m Exp3 primary scene with independently parked objects."""
    if family not in PRIMARY_FAMILIES or horizon not in (0,1,2):
        raise ValueError("primary family must be mobility/manipulation/control and horizon 0/1/2")
    if family != "control" and horizon != 1:
        raise ValueError("mobility/manipulation use body-specific H in {0,1}")
    rng = np.random.default_rng(seed)
    dx, dy = float(rng.uniform(-.25, .25)), float(rng.uniform(-.2, .2))
    mirrored = bool(seed % 2)
    low_y, high_y = 3.+dy, 9.-dy
    first_y, second_y = (high_y, low_y) if mirrored else (low_y, high_y)
    outer = [[0,0,.2,12], [11.8,0,12,12], [.2,0,11.8,.2], [.2,11.8,11.8,12]]
    objects, guides, parks, zones, terrain = [], [], [], [], []

    def box(x, y, mass):
        oid = len(objects)
        pose, target = [x, y, 0.], [x+2.35, y]
        objects.append(dict(object_id=oid, pose=pose, size=[.8,.8,.6],
                            mass_kg=float(mass), friction=.4))
        guides.append(_straight_path(oid,pose[:2],target))
        parking = [target[0]-.35, y-.45, target[0]+.35, y+.45]
        approach = [x-1.6, y-.75, x-.4, y+.75]
        swept = [x-.4, y-.75, target[0]+.4, y+.75]
        parks.append(dict(object_id=oid, bounds=parking, canonical_target=[*target,0.]))
        zones.append(dict(object_id=oid, approach_bounds=approach, swept_bounds=swept,
                          parking_bounds=parking,
                          interaction_bounds=[approach[0], approach[1], swept[2], swept[3]]))

    if family in ("mobility", "manipulation"):
        divider_x = 6.+dx
        openings = [(low_y-1., low_y+1.), (high_y-1., high_y+1.)]
        walls = outer+_divider(divider_x, openings)
        if family == "mobility":
            box(divider_x, first_y, 2.)
            rise = float(rng.uniform(.10,.18))
            stair_y = second_y
            terrain = [dict(kind="stair_tread", bounds=[divider_x-.6,stair_y-1.,divider_x-.2,stair_y+1.], height_m=rise),
                       dict(kind="stair_tread", bounds=[divider_x-.2,stair_y-1.,divider_x+.2,stair_y+1.], height_m=2*rise),
                       dict(kind="stair_tread", bounds=[divider_x+.2,stair_y-1.,divider_x+.6,stair_y+1.], height_m=rise)]
            candidates = [[], [0]]
        else:
            box(divider_x, first_y, 2.)
            box(divider_x, second_y, 4.)
            candidates = [[0], [1]]
    elif horizon == 2:
        first_x, second_x = 4.+dx, 8.-dx
        walls = outer+_divider(first_x, [(first_y-1., first_y+1.)])
        walls += _divider(second_x, [(second_y-1., second_y+1.)])
        box(first_x, first_y, 2.)
        box(second_x, second_y, 2.)
        candidates = [[0,1]]
    elif horizon == 1:
        divider_x, passage_y = 6.+dx, 6.+dy
        walls = outer+_divider(divider_x, [(passage_y-1., passage_y+1.)])
        box(divider_x, passage_y, 2.)
        candidates = [[0]]
    else:
        passage_y = 6.+dy
        walls = outer+_divider(6.+dx, [(passage_y-1., passage_y+1.)])
        candidates = [[]]
    scene = dict(schema="clear-maze-primary-v2", family=family, generation_seed=int(seed),
                 horizon_class=int(horizon), reference_horizons=sorted({len(v) for v in candidates}),
                 topology_template={"mobility":"dual-route", "manipulation":"dual-object-route",
                                    "control":"staggered-independent" if horizon == 2 else "single-route"}[family],
                 mirrored=mirrored, world_size=[12.,12.], start=[1.2,6.,0.], goal=[10.8,6.],
                 walls=walls, objects=objects, terrain=terrain, development_guides=guides,
                 parking_regions=parks, interaction_zones=zones, candidate_orders=candidates,
                 chain_dependency=False, parking_source="independent_geometry_validator",
                 capability_status="pending independent G1/Spot+arm physical calibration")
    scene["layout_group_id"] = digest({k:scene[k] for k in ("family","horizon_class","walls","terrain")})
    scene["base_scene_id"] = f"primary-v2-{family}-h{horizon}-"+digest(scene)[:12]
    return scene


def audit_primary_scene(scene, radius=.55, resolution=.25):
    guides = {p["object_id"]:ObjectPath.from_dict(p) for p in scene["development_guides"]}
    parks = {p["object_id"]:p for p in scene["parking_regions"]}
    results = []
    for order in scene["candidate_orders"]:
        work, valid = deepcopy(scene), True
        for oid in order:
            path, region = guides[oid], parks[oid]["bounds"]
            x, y = path.goal[:2]
            valid &= region[0] <= x <= region[2] and region[1] <= y <= region[3]
            valid &= not path_collision(work, path)
            next(o for o in work["objects"] if o["object_id"] == oid)["pose"] = list(path.goal)
        results.append(dict(order=order, parking_and_sweep_valid=bool(valid),
                            goal_connected=bool(navigation_exists(work, radius, resolution))))
    zones = [(z["object_id"], wall_polygon(z["interaction_bounds"])) for z in scene["interaction_zones"]]
    independent = all(not overlap(a,b) for i,(_,a) in enumerate(zones) for _,b in zones[i+1:])
    clear = all(not any(overlap(zone, wall_polygon(w)) for w in scene["walls"])
                and not any(overlap(zone, rectangle_corners(o["pose"], o["size"]))
                            for o in scene["objects"] if o["object_id"] != oid)
                for oid, zone in zones)
    return dict(base_scene_id=scene["base_scene_id"],
                zero_action_planar_route=navigation_exists(scene, radius, resolution),
                candidate_routes=results, interaction_regions_independent=independent,
                interaction_regions_clear=clear,
                chain_dependency=scene["chain_dependency"], proxy_radius_m=radius,
                navigation_resolution_m=resolution, physical_validated=False)


def rectangle_corners(pose, size):
    x, y, yaw = pose
    c, s = math.cos(yaw), math.sin(yaw)
    local = np.array([[-1,-1], [1,-1], [1,1], [-1,1]], float) * np.asarray(size[:2]) / 2
    return local @ np.array([[c,s],[-s,c]]) + [x,y]


def overlap(a, b):
    for poly in (a, b):
        edges = np.roll(poly, -1, axis=0) - poly
        for dx, dy in edges:
            axis = np.array([-dy, dx])
            pa, pb = a @ axis, b @ axis
            if pa.max() < pb.min()-1e-9 or pb.max() < pa.min()-1e-9:
                return False
    return True


def wall_polygon(wall):
    l, b, r, t = wall
    return np.array([[l,b], [r,b], [r,t], [l,t]])


def path_collision(scene, path, max_step=.025):
    if not np.isfinite(max_step) or max_step <= 0:
        raise ValueError("max_step must be positive")
    objects = {o["object_id"]: o for o in scene["objects"]}
    obj = objects[path.object_id]
    obstacles = [wall_polygon(w) for w in scene["walls"]]
    obstacles += [rectangle_corners(o["pose"], o["size"]) for oid, o in objects.items() if oid != path.object_id]
    from experiments.exp3.trajectory_v3.contracts import angle_delta
    for a, b in zip(path.poses[:-1], path.poses[1:]):
        a, b = np.asarray(a), np.asarray(b)
        dyaw = float(angle_delta(b[2], a[2]))
        sweep = np.linalg.norm(b[:2]-a[:2]) + .5*np.linalg.norm(obj["size"][:2])*abs(dyaw)
        for u in np.linspace(0, 1, max(2, math.ceil(sweep/max_step)+1)):
            pose = a+(b-a)*u
            pose[2] = a[2]+u*dyaw
            polygon = rectangle_corners(pose, obj["size"])
            if (polygon < 0).any() or (polygon > np.asarray(scene["world_size"])).any():
                return True
            if any(overlap(polygon, other) for other in obstacles):
                return True
    return False


def navigation_exists(scene, radius=.25, resolution=.10):
    if not np.isfinite([radius, resolution]).all() or min(radius, resolution) <= 0:
        raise ValueError("positive radius and resolution required")
    w, h = np.ceil(np.asarray(scene["world_size"])/resolution).astype(int)
    xx, yy = np.meshgrid((np.arange(w)+.5)*resolution, (np.arange(h)+.5)*resolution)
    free = np.ones((h,w), dtype=bool)
    # Inflate by half a cell diagonal: the whole cell is clear for a disc robot.
    margin = radius + resolution/math.sqrt(2)
    for l,b,r,t in scene["walls"]:
        dx, dy = np.maximum(np.maximum(l-xx, xx-r),0), np.maximum(np.maximum(b-yy, yy-t),0)
        free &= dx*dx+dy*dy > margin*margin
    for obj in scene["objects"]:
        x,y,yaw = obj["pose"]
        c,s = math.cos(yaw), math.sin(yaw)
        local_x, local_y = c*(xx-x)+s*(yy-y), -s*(xx-x)+c*(yy-y)
        dx,dy = np.maximum(abs(local_x)-obj["size"][0]/2,0), np.maximum(abs(local_y)-obj["size"][1]/2,0)
        free &= dx*dx+dy*dy > margin*margin
    def cell(xy):
        return int(xy[1]/resolution), int(xy[0]/resolution)
    start, goal = cell(scene["start"]), cell(scene["goal"])
    if any(not (0 <= p[0] < h and 0 <= p[1] < w) for p in (start,goal)):
        return False
    if not free[start] or not free[goal]:
        return False
    queue, seen = deque([start]), {start}
    while queue:
        r,c = queue.popleft()
        if (r,c) == goal:
            return True
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            q = r+dr,c+dc
            if 0 <= q[0] < h and 0 <= q[1] < w and free[q] and q not in seen:
                seen.add(q); queue.append(q)
    return False


def audit_scene(scene):
    guides = {v["object_id"]: ObjectPath.from_dict(v) for v in scene["development_guides"]}
    routes = []
    for order in scene["candidate_orders"]:
        work = deepcopy(scene)
        valid = True
        for oid in order:
            path = guides[oid]
            valid &= not path_collision(work, path)
            next(o for o in work["objects"] if o["object_id"] == oid)["pose"] = list(path.goal)
        routes.append(dict(order=order, object_path_collision_free=bool(valid),
                           planar_goal_connected=navigation_exists(work)))
    straight = {str(oid): path_collision(scene, ObjectPath(oid, (p.start, p.goal))) for oid,p in guides.items()}
    return dict(base_scene_id=scene["base_scene_id"], zero_action_planar_route=navigation_exists(scene),
                candidate_routes=routes, endpoint_straight_line_collisions=straight,
                scope="sampled planar geometry; terrain traversal, contact, full-body and dynamics unverified",
                proxy_radius_m=.25, navigation_resolution_m=.10, object_sweep_step_m=.025,
                physical_validated=False)


def public_scene(scene):
    return {k: deepcopy(scene[k]) for k in ("world_size", "walls", "objects", "terrain", "start", "goal")}


def pair_scene(scene, bodies, split="pilot"):
    if not bodies or len(set(bodies)) != len(bodies):
        raise ValueError("distinct bodies required")
    observation_hash = digest(public_scene(scene))
    return [dict(base_scene_id=scene["base_scene_id"], body_id=body, split=split,
                 layout_group_id=scene["layout_group_id"], scene_observation_hash=observation_hash,
                 capability_status="pending_physical_calibration") for body in bodies]


def write_mjcf(scene, destination):
    root = ET.Element("mujoco", model=scene["base_scene_id"])
    ET.SubElement(root, "compiler", angle="radian")
    ET.SubElement(root, "option", timestep="0.002", gravity="0 0 -9.81")
    world = ET.SubElement(root, "worldbody")
    width, height = scene["world_size"]
    ET.SubElement(world,"geom",name="floor",type="plane",pos=f"{width/2} {height/2} 0",
                  size=f"{width/2} {height/2} .1",rgba=".92 .91 .88 1")
    for i,(l,b,r,t) in enumerate(scene["walls"]):
        ET.SubElement(world,"geom",name=f"wall_{i}",type="box",pos=f"{(l+r)/2} {(b+t)/2} .75",
                      size=f"{(r-l)/2} {(t-b)/2} .75",rgba=".28 .28 .30 1")
    for i,tile in enumerate(scene["terrain"]):
        l,b,r,t=tile["bounds"]; z=tile["height_m"]
        ET.SubElement(world,"geom",name=f"tread_{i}",type="box",pos=f"{(l+r)/2} {(b+t)/2} {z/2}",
                      size=f"{(r-l)/2} {(t-b)/2} {z/2}",rgba=".85 .55 .25 1")
    for obj in scene["objects"]:
        x,y,yaw=obj["pose"]; dx,dy,dz=obj["size"]
        body=ET.SubElement(world,"body",name=f"object_{obj['object_id']}",pos=f"{x} {y} {dz/2}",euler=f"0 0 {yaw}")
        ET.SubElement(body,"freejoint")
        ET.SubElement(body,"geom",name=f"object_geom_{obj['object_id']}",type="box",size=f"{dx/2} {dy/2} {dz/2}",
                      mass=str(obj["mass_kg"]),friction=f"{obj['friction']} .005 .0001",rgba=".36 .56 .84 1")
    for name,xy in (("start",scene["start"]),("goal",scene["goal"])):
        ET.SubElement(world,"site",name=name,pos=f"{xy[0]} {xy[1]} .02",size=".1",rgba="0 .6 .3 1")
    ET.indent(root)
    ET.ElementTree(root).write(destination, encoding="unicode")


def write_pilot(output, per_family=10, seed=0, bodies=("husky","spot","spot_arm","g1")):
    if per_family < 1:
        raise ValueError("per_family must be positive")
    output=Path(output)
    output.mkdir(parents=True,exist_ok=True)
    if any(output.iterdir()):
        raise FileExistsError("pilot output must be empty")
    audits,pairs=[] ,[]
    for family in FAMILIES:
        for i in range(per_family):
            scene=make_scene(family,seed+i)
            audit=audit_scene(scene)
            if audit["zero_action_planar_route"] or not all(
                    r["object_path_collision_free"] and r["planar_goal_connected"] for r in audit["candidate_routes"]):
                raise RuntimeError(f"pilot geometry audit failed: {scene['base_scene_id']}")
            if not all(audit["endpoint_straight_line_collisions"].values()):
                raise RuntimeError("pilot no longer distinguishes straight-line endpoint execution")
            stem=output/scene["base_scene_id"]
            stem.with_suffix(".json").write_text(json.dumps(scene,indent=2)+"\n")
            write_mjcf(scene,stem.with_suffix(".xml"))
            audits.append(audit); pairs.extend(pair_scene(scene,bodies))
    (output/"paired_manifest.jsonl").write_text("".join(json.dumps(r,sort_keys=True)+"\n" for r in pairs))
    summary=dict(base_scenes=len(audits),paired_cases=len(pairs),families=list(FAMILIES),bodies=list(bodies),
                 status="geometry_prototype_only",robot_in_mjcf=False,physical_validated=False,audits=audits)
    (output/"audit.json").write_text(json.dumps(summary,indent=2)+"\n")
    return summary


def write_primary_pilot(output, per_case=2, seed=0, bodies=("g1", "spot_arm")):
    """Write the five Exp3 primary geometry cases without assigning body capability labels."""
    if per_case < 1:
        raise ValueError("per_case must be positive")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise FileExistsError("primary pilot output must be empty")
    cases = (("mobility",1), ("manipulation",1), ("control",0), ("control",1), ("control",2))
    audits, pairs, references = [], [], []
    for family, horizon in cases:
        for offset in range(per_case):
            scene = make_primary_scene(family, seed+offset, horizon)
            audit = audit_primary_scene(scene)
            if not audit["interaction_regions_independent"] or not audit["interaction_regions_clear"] or not all(
                    row["parking_and_sweep_valid"] and row["goal_connected"]
                    for row in audit["candidate_routes"]):
                raise RuntimeError(f"primary geometry audit failed: {scene['base_scene_id']}")
            stem = output/scene["base_scene_id"]
            stem.with_suffix(".json").write_text(json.dumps(scene, indent=2)+"\n")
            write_mjcf(scene, stem.with_suffix(".xml"))
            audits.append(audit)
            pairs.extend(pair_scene(scene, bodies, split="development"))
            paths = {p["object_id"]:ObjectPath.from_dict(p) for p in scene["development_guides"]}
            for candidate_index, order in enumerate(scene["candidate_orders"]):
                plan = ObjectMotionPlan(tuple(paths[oid] for oid in order)).to_dict()
                for body in bodies:
                    references.append(dict(reference_id=f"{scene['base_scene_id']}-c{candidate_index}-{body}",
                                           scene=scene, body_id=body, split="development", plan=plan,
                                           teacher=dict(source="primary_v2_geometry_reference",
                                                        validation="geometric_only")))
    (output/"paired_manifest.jsonl").write_text("".join(json.dumps(row, sort_keys=True)+"\n" for row in pairs))
    (output/"reference_rows.jsonl").write_text("".join(json.dumps(row, sort_keys=True)+"\n" for row in references))
    summary = dict(schema="clear-maze-primary-pilot-v2", base_scenes=len(audits),
                   paired_cases=len(pairs), reference_rows=len(references), bodies=list(bodies), candidate_budget=8,
                   status="geometry_validated; body capability and physical execution pending",
                   audits=audits)
    (output/"audit.json").write_text(json.dumps(summary, indent=2)+"\n")
    return summary
