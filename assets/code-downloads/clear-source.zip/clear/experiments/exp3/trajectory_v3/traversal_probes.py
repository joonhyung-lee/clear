"""Directed traversability probes: a frozen mjlab walker crosses one terrain transition.

One tile = one condition (step up/down of h, ramp up/down of grade g, cross-slope g,
flat/ramp at friction mu). The robot spawns on the start plate, is commanded +x at a
constant speed, and the trial is scored on whether it passes the transition before the
first fall / termination. Rows follow traversability.TRAVERSAL_SCHEMA and their
edge features are computed by navigation.transition_features on the SAME scene dict a
planner would see, so probe features and planning features share one definition.

Controller identity: sha256 of the navigation checkpoint file. Spot uses
Mjlab-Velocity-Mixed-Spot + spot_stance_model_13200.pt (the native runtime's nominal-arm
walker); G1 uses Mjlab-Velocity-BlindStairs-Unitree-G1 + g1_blind_stairs_ARCLIP2_model_22800.pt
(the .pt that pairs with the ONNX the native runtime drives). Requires the exp-v3 venv
(mjlab editable).

    PYTHONPATH=. .venv/bin/python -m experiments.exp3.trajectory_v3.traversal_probes \
        --body spot --out experiments/exp3/trajectory_v3/probes_20260909/spot --device cuda:0
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from clear.maze.robots import get as get_body
from experiments.exp3.trajectory_v3.calibration import digest, summarize_probes
from experiments.exp3.trajectory_v3.navigation import EDGE_FIELDS, clearance, scene_hash, transition_features
from experiments.exp3.trajectory_v3.traversability import TRAVERSAL_SCHEMA

ROOT = Path(__file__).resolve().parents[3]
PRETRAINED = ROOT / "asset/pretrained"
TILE = (10.0, 4.0)          # x length, y width of one probe tile (m)
PLATE_X = 4.0               # start plate ends here; the transition starts at x = PLATE_X
RAMP_RUN = 2.0
CROSS_RUN = 4.0
SLAB_THICKNESS = 0.05
SPAWN = (2.0, 2.0)          # spawn xy inside the tile
CLEAR_MARGIN = 1.0          # success = crossed the transition end by this much

WALKERS = {
    "spot": dict(task="Mjlab-Velocity-Mixed-Spot",
                 checkpoint=PRETRAINED / "spot/locomotion/spot_stance_model_13200.pt", speed=0.5),
    "g1": dict(task="Mjlab-Velocity-BlindStairs-Unitree-G1",
               checkpoint=PRETRAINED / "g1/locomotion/g1_blind_stairs_ARCLIP2_model_22800.pt", speed=0.3),
}


# ------------------------------------------------------------------ conditions
@dataclass(frozen=True)
class Condition:
    kind: str          # step_up | step_down | ramp_up | ramp_down | cross | flat
    magnitude: float   # step height (m) or grade (rise/run); 0 for flat
    friction: float

    @property
    def id(self):
        return f"{self.kind}_{self.magnitude:.3f}_mu{self.friction:.2f}"

    def as_dict(self):
        return dict(kind=self.kind, magnitude=self.magnitude, friction=self.friction)


def default_conditions():
    heights = (0.03, 0.06, 0.09, 0.12, 0.15, 0.18, 0.21, 0.25)
    grades = (0.10, 0.20, 0.30, 0.40, 0.50, 0.60)
    cross = (0.10, 0.20, 0.30, 0.40)
    out = [Condition("flat", 0.0, mu) for mu in (0.2, 0.4, 0.6, 0.8)]
    out += [Condition("step_up", h, 0.8) for h in heights]
    out += [Condition("step_down", h, 0.8) for h in heights]
    out += [Condition("ramp_up", g, 0.8) for g in grades]
    out += [Condition("ramp_down", g, 0.8) for g in grades]
    out += [Condition("cross", g, 0.8) for g in cross]
    out += [Condition("ramp_up", 0.3, mu) for mu in (0.3, 0.5)]
    out += [Condition("step_up", 0.12, mu) for mu in (0.3, 0.5)]
    return out


def transition_span(c: Condition):
    """(x_start, x_end, start_height, end_height) of the transition along +x."""
    if c.kind == "flat":
        return PLATE_X, PLATE_X, 0.0, 0.0
    if c.kind == "step_up":
        return PLATE_X, PLATE_X, 0.0, c.magnitude
    if c.kind == "step_down":
        return PLATE_X, PLATE_X, c.magnitude, 0.0
    if c.kind == "ramp_up":
        return PLATE_X, PLATE_X + RAMP_RUN, 0.0, c.magnitude * RAMP_RUN
    if c.kind == "ramp_down":
        return PLATE_X, PLATE_X + RAMP_RUN, c.magnitude * RAMP_RUN, 0.0
    if c.kind == "cross":
        zc = c.magnitude * TILE[1] / 2
        return PLATE_X, PLATE_X + CROSS_RUN, zc, zc
    raise ValueError(c.kind)


def condition_scene(c: Condition):
    """The v3 scene dict (navigation.surface / transition_features contract) of one tile."""
    x0, x1, z0, z1 = transition_span(c)
    w, h = TILE
    mu = c.friction
    tiles = [dict(kind="flat", bounds=[0.0, 0.0, x0, h], height_m=z0, friction=mu)]
    if c.kind in ("ramp_up", "ramp_down"):
        tiles.append(dict(kind="ramp", bounds=[x0, 0.0, x1, h], axis=0, start_height_m=z0, end_height_m=z1, friction=mu))
    elif c.kind == "cross":
        tiles.append(dict(kind="ramp", bounds=[x0, 0.0, x1, h], axis=1, start_height_m=0.0,
                          end_height_m=c.magnitude * h, friction=mu))
    tiles.append(dict(kind="stair_tread" if c.kind in ("step_up", "step_down") else "flat",
                      bounds=[x1, 0.0, w, h], height_m=z1, friction=mu))
    return dict(world_size=[w, h], walls=[], objects=[], terrain=tiles, floor_friction=mu,
                start=[SPAWN[0], SPAWN[1], 0.0], goal=[x1 + CLEAR_MARGIN, h / 2])


def edge_features(c: Condition, radius: float, segment_m: float = 0.2):
    """Features of the navigator-sized segment that crosses (or sits on) the transition."""
    scene = condition_scene(c)
    x0, x1, _, _ = transition_span(c)
    centre = x0 if c.kind in ("step_up", "step_down", "flat") else x0 + (x1 - x0) / 2
    start = np.array([[centre - segment_m / 2, TILE[1] / 2]])
    end = np.array([[centre + segment_m / 2, TILE[1] / 2]])
    clear = float(clearance(scene, (start + end) / 2).min())
    return transition_features(scene, start, end, radius, np.array([clear]))[0], scene


def split_of(conditions):
    """Grouped split: within each kind (sorted by magnitude, friction) the two extremes stay in
    train (the claim is interpolation between probed conditions, not extrapolation past a cliff),
    interior conditions alternate train / val / train / test. No condition appears in two splits."""
    out = {}
    for kind in sorted({c.kind for c in conditions}):
        rows = sorted((c for c in conditions if c.kind == kind), key=lambda c: (c.magnitude, c.friction))
        for i, c in enumerate(rows):
            interior = 0 < i < len(rows) - 1
            out[c.id] = ("val" if i % 4 == 1 else "test" if i % 4 == 3 else "train") if interior else "train"
    return out


# ------------------------------------------------------------------ mjlab terrain
def make_terrain_cfg(conditions):
    import mujoco
    from mjlab.terrains.terrain_generator import SubTerrainCfg, TerrainGeneratorCfg, TerrainGeometry, TerrainOutput
    from mjlab.terrains.utils import make_plane

    @dataclass(kw_only=True)
    class ProbeTerrainCfg(SubTerrainCfg):
        conditions: tuple = ()

        def function(self, difficulty, spec, rng):
            del rng
            index = int(round(difficulty * (len(self.conditions) - 1)))
            c = self.conditions[index]
            x0, x1, z0, z1 = transition_span(c)
            w, h = self.size
            body = spec.body("terrain")
            geoms = []

            def box(pos, size, euler=(0.0, 0.0, 0.0), color=(0.55, 0.55, 0.58, 1.0)):
                g = body.add_geom(type=mujoco.mjtGeom.mjGEOM_BOX, pos=list(pos), size=list(size),
                                  euler=[math.degrees(e) for e in euler])
                g.friction[0] = c.friction
                g.priority = 1          # terrain friction wins the pair, otherwise MuJoCo takes the max
                geoms.append(TerrainGeometry(geom=g, color=color))
                return g

            ground = make_plane(body, self.size, 0.0, center_zero=False)
            ground[0].friction[0] = c.friction
            ground[0].priority = 1
            geoms.append(TerrainGeometry(geom=ground[0], color=(0.55, 0.55, 0.58, 1.0)))
            if z0 > 0:      # raised start plate
                box((x0 / 2, h / 2, z0 / 2), (x0 / 2, h / 2, z0 / 2))
            if c.kind in ("step_up", "step_down") or (c.kind == "flat" and False):
                if z1 > 0:
                    box(((x1 + w) / 2, h / 2, z1 / 2), ((w - x1) / 2, h / 2, z1 / 2), color=(0.75, 0.55, 0.35, 1.0))
            elif c.kind in ("ramp_up", "ramp_down"):
                run = x1 - x0
                pitch = math.atan((z1 - z0) / run)
                hyp = run / math.cos(pitch)
                box(((x0 + x1) / 2, h / 2, (z0 + z1) / 2 - SLAB_THICKNESS / math.cos(pitch)),
                    (hyp / 2, h / 2, SLAB_THICKNESS), euler=(0.0, -pitch, 0.0), color=(0.35, 0.55, 0.75, 1.0))
                if z1 > 0:
                    box(((x1 + w) / 2, h / 2, z1 / 2), ((w - x1) / 2, h / 2, z1 / 2))
            elif c.kind == "cross":
                roll = math.atan(c.magnitude)
                hyp = h / math.cos(roll)
                box(((x0 + x1) / 2, h / 2, z0 - SLAB_THICKNESS / math.cos(roll)), ((x1 - x0) / 2, hyp / 2, SLAB_THICKNESS),
                    euler=(roll, 0.0, 0.0), color=(0.35, 0.55, 0.75, 1.0))
                box(((x1 + w) / 2, h / 2, z1 / 2), ((w - x1) / 2, h / 2, z1 / 2))
            return TerrainOutput(origin=np.array((SPAWN[0], SPAWN[1], z0)), geometries=geoms)

    return TerrainGeneratorCfg(size=TILE, border_width=2.0, num_rows=len(conditions), num_cols=1, curriculum=True,
                               sub_terrains={"probe": ProbeTerrainCfg(conditions=tuple(conditions))}, add_lights=True)


# ------------------------------------------------------------------ geometry check
def check_geometry(conditions, device="cuda:0", body_id="spot", samples=41):
    """Ray-cast the built terrain along each tile's centreline and compare with the analytic
    surface of the scene dict the features come from. Returns per-condition max |error|."""
    import mujoco
    import torch
    import mjlab.tasks  # noqa: F401
    from mjlab.envs import ManagerBasedRlEnv
    from mjlab.tasks.registry import load_env_cfg
    from experiments.exp3.trajectory_v3.navigation import surface

    cfg = load_env_cfg(WALKERS[body_id]["task"], play=True)
    cfg.scene.num_envs = len(conditions)
    cfg.scene.terrain.terrain_generator = make_terrain_cfg(conditions)
    cfg.scene.terrain.max_init_terrain_level = None
    cfg.curriculum = {}
    env = ManagerBasedRlEnv(cfg=cfg, device=device)
    model = env.sim.mj_model
    data = mujoco.MjData(model)
    for j in range(model.njnt):          # lift every free-floating body 100 m so rays only see terrain
        if model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE:
            data.qpos[model.jnt_qposadr[j] + 2] += 100.0
    mujoco.mj_forward(model, data)
    terrain = env.scene.terrain
    origins = terrain.terrain_origins.cpu().numpy()
    report = []
    xs = np.linspace(0.3, TILE[0] - 0.3, samples)
    for i, c in enumerate(conditions):
        origin = origins[i, 0]
        corner = origin[:2] - np.array(SPAWN)
        scene = condition_scene(c)
        analytic, _, _ = surface(scene, np.column_stack([xs, np.full_like(xs, TILE[1] / 2)]))
        measured = []
        for x in xs:
            pnt = np.array([corner[0] + x, corner[1] + TILE[1] / 2, 5.0])
            geomid = np.array([-1], np.int32)
            dist = mujoco.mj_ray(model, data, pnt, np.array([0.0, 0.0, -1.0]), None, 1, -1, geomid)
            measured.append(5.0 - dist if dist >= 0 else np.nan)
        measured = np.asarray(measured)
        err = np.abs(measured - analytic)
        report.append(dict(condition=c.id, max_abs_error_m=float(np.nanmax(err)), nan=int(np.isnan(measured).sum()),
                           profile=[[float(x), float(m), float(a)] for x, m, a in zip(xs, measured, analytic)]))
    env.close()
    return report


# ------------------------------------------------------------------ runner
def save_probe_results(out, rows, trial_records, metadata, min_trials=10):
    """Export learning rows and the matching summary; retain every raw trial for audit."""
    rows = [r for r in rows if r["valid"]]
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "probes.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    summary = summarize_probes(rows, min_trials=min_trials)
    summary.update(metadata)
    summary["invalid_trial_policy"] = "excluded from learning and summary; retained in trials.json"
    (out / "summary.json").write_text(json.dumps(summary, indent=1) + "\n")
    (out / "trials.json").write_text(json.dumps(trial_records) + "\n")
    return summary


def native_structure_rows(robot):
    """Describe the entity actually simulated, including task-specific actuators and links."""
    from clear.data.morphology import link_rows_v3_from_model
    # A scene-attached child cannot compile by reference; copying preserves its edits.
    rows=link_rows_v3_from_model(robot.spec.copy().compile())
    if rows.ndim!=2 or rows.shape[1]!=20 or not np.isfinite(rows).all():
        raise ValueError('invalid native morphology rows')
    return rows.astype(float).tolist()


def confirmed_crossing(reach_step, fall_step, total_steps, post_steps):
    """Require the entire upright confirmation interval before the rollout ends."""
    return bool(0 <= reach_step and reach_step + post_steps < total_steps
                and fall_step > reach_step + post_steps)


def run_probes(body_id, conditions, trials, out, device="cuda:0", seconds=20.0, seed=0, speed=None,
               tracking="closed", min_speed=0.15):
    import torch
    import mjlab.tasks  # noqa: F401  registers tasks
    from dataclasses import asdict
    from mjlab.envs import ManagerBasedRlEnv
    from mjlab.rl import MjlabOnPolicyRunner, RslRlVecEnvWrapper
    from mjlab.tasks.registry import load_env_cfg, load_rl_cfg, load_runner_cls

    walker = WALKERS[body_id]
    speed = walker["speed"] if speed is None else speed
    entry = get_body(body_id)
    radius = entry.loco.width_m / 2
    controller_hash = hashlib.sha256(Path(walker["checkpoint"]).read_bytes()).hexdigest()

    cfg = load_env_cfg(walker["task"], play=True)
    if body_id == "spot":
        from mjlab.tasks.velocity.config.spot import spot_mdp
        spot_mdp.ARM_JITTER = 0.0
    n_env = len(conditions) * trials
    cfg.scene.num_envs = n_env
    cfg.scene.terrain.terrain_generator = make_terrain_cfg(conditions)
    cfg.scene.terrain.max_init_terrain_level = None
    cfg.episode_length_s = 1e6
    cfg.curriculum = {}
    cfg.events = {}          # no reset randomisation, no pushes: the robot is placed once, by us
    cfg.auto_reset = False   # a fallen robot stays where it fell; nothing is ever teleported
    cfg.terminations = {}    # mjlab demands a manual reset after any termination; falls are detected below
    cfg.seed = seed
    t = cfg.commands["twist"]
    t.heading_command = False
    t.ranges.heading = None
    t.rel_standing_envs = 0.0
    t.rel_heading_envs = 0.0
    if hasattr(t, "rel_forward_envs"):
        t.rel_forward_envs = 0.0
    t.resampling_time_range = (1e6, 1e6)
    t.ranges.lin_vel_x = (speed, speed)
    t.ranges.lin_vel_y = (0.0, 0.0)
    t.ranges.ang_vel_z = (0.0, 0.0)

    env = ManagerBasedRlEnv(cfg=cfg, device=device)
    rl = load_rl_cfg(walker["task"])
    wrapped = RslRlVecEnvWrapper(env, clip_actions=rl.clip_actions)
    runner = (load_runner_cls(walker["task"]) or MjlabOnPolicyRunner)(wrapped, asdict(rl), device=device)
    runner.load(str(walker["checkpoint"]), load_cfg={"actor": True}, strict=False, map_location=device)
    policy = runner.get_inference_policy(device=device)
    group = runner.alg.actor.obs_groups[0]
    robot = env.scene["robot"]
    rows_struct = native_structure_rows(robot)
    terrain = env.scene.terrain
    dev = env.device

    # deterministic tile assignment: env i -> condition i // trials
    levels = torch.arange(n_env, device=dev) // trials
    terrain.terrain_levels[:] = levels
    terrain.terrain_types[:] = 0
    terrain.env_origins[:] = terrain.terrain_origins[levels, terrain.terrain_types]
    env.scene.env_origins[:] = terrain.env_origins

    gen = torch.Generator(device=dev).manual_seed(seed)
    jitter_xy = (torch.rand(n_env, 2, generator=gen, device=dev) - 0.5) * torch.tensor([1.0, 1.0], device=dev)
    jitter_yaw = (torch.rand(n_env, generator=gen, device=dev) - 0.5) * math.radians(16.0)

    def place():
        """Spawn on the start plate with a per-trial pose jitter (x, y +-0.5 m, yaw +-8 deg);
        without it every trial of a condition is the same deterministic rollout."""
        st = robot.data.default_root_state.clone()
        st[:, :3] += env.scene.env_origins
        st[:, :2] += jitter_xy
        st[:, 3] = torch.cos(jitter_yaw / 2)
        st[:, 4:6] = 0.0
        st[:, 6] = torch.sin(jitter_yaw / 2)
        st[:, 7:] = 0.0
        robot.write_root_state_to_sim(st)

    obs, _ = env.reset()
    place()
    for _ in range(int(0.5 / env.step_dt)):          # let the placement transient settle standing still
        with torch.inference_mode():
            act = policy({group: obs["actor"]})
        obs, _, _, _, _ = env.step(act * 0)
    place()
    x0 = robot.data.root_link_pos_w[:, 0].clone()
    y0 = robot.data.root_link_pos_w[:, 1].clone()
    prev_x = x0.clone()
    # closed-loop tracking: the deployed navigator steers toward the next waypoint (native_route_check
    # .follow_route); an open-loop +x command has no heading feedback and drifts off any cross-slope,
    # so open-loop labels understate what the navigation stack can actually cross.
    cmd = env.command_manager.get_term("twist")
    if tracking == "closed":
        for flag in ("is_world_env", "is_heading_env", "is_standing_env"):
            if hasattr(cmd, flag):
                getattr(cmd, flag)[:] = False
    teleported = torch.zeros(n_env, dtype=torch.bool, device=dev)
    goal_dx = torch.tensor([transition_span(c)[1] - SPAWN[0] + CLEAR_MARGIN for c in conditions], device=dev)[levels]
    best = torch.zeros(n_env, device=dev)
    dead = torch.zeros(n_env, dtype=torch.bool, device=dev)
    reached = torch.zeros(n_env, dtype=torch.bool, device=dev)
    fell_flag = torch.zeros(n_env, dtype=torch.bool, device=dev)
    fall_step = torch.full((n_env,), 10**9, device=dev, dtype=torch.long)
    term_flag = torch.zeros(n_env, dtype=torch.bool, device=dev)
    step_dt = env.step_dt
    post_steps = int(1.0 / step_dt)
    reach_step = torch.full((n_env,), -1, device=dev, dtype=torch.long)
    settle = int(1.0 / env.step_dt)
    steps = int(seconds / env.step_dt)
    t_start = time.time()
    for k in range(steps):
        if tracking == "closed":
            pos = robot.data.root_link_pos_w[:, :2]
            q = robot.data.root_link_quat_w                      # w, x, y, z
            yaw = torch.atan2(2 * (q[:, 0] * q[:, 3] + q[:, 1] * q[:, 2]),
                              1 - 2 * (q[:, 2] ** 2 + q[:, 3] ** 2))
            dx = (x0 + goal_dx) - pos[:, 0]
            dy = y0 - pos[:, 1]                                  # hold the spawn line, as a route segment does
            distance = torch.sqrt(dx * dx + dy * dy)
            err = (torch.atan2(dy, dx) - yaw + math.pi) % (2 * math.pi) - math.pi
            v = torch.clamp(distance, max=speed).clamp(min=min_speed) * torch.clamp(torch.cos(err), min=0.0)
            w = torch.clamp(1.5 * err, -0.7, 0.7)
            zero = k < settle
            cmd.vel_command_b[:, 0] = 0.0 if zero else v
            cmd.vel_command_b[:, 1] = 0.0
            cmd.vel_command_b[:, 2] = 0.0 if zero else w
        with torch.inference_mode():
            act = policy({group: obs["actor"]})
        obs, _, term, trunc, _ = env.step(act)
        fell = -robot.data.projected_gravity_b[:, 2] < 0.5
        live = ~dead
        x_now = robot.data.root_link_pos_w[:, 0]
        teleported |= (x_now - prev_x).abs() > 0.5     # > 25 m/s: a reset, not locomotion
        prev_x = x_now.clone()
        prog = x_now - x0
        best = torch.where(live, torch.maximum(best, prog), best)
        now = live & ~reached & (prog >= goal_dx) & ~fell     # crossing counts only while upright
        reached |= now
        reach_step = torch.where(now, torch.full_like(reach_step, k), reach_step)
        if k < settle:
            continue
        newly = live & (fell | term | trunc)
        fell_flag |= newly & fell
        fall_step = torch.where(newly & fell, torch.full_like(fall_step, k), fall_step)
        term_flag |= newly & ~fell & (term | trunc)
        dead |= newly
    elapsed = time.time() - t_start
    env.close()

    best, reached, fell_flag, term_flag, reach_step, teleported, fall_step = (
        v.cpu().numpy() for v in (best, reached, fell_flag, term_flag, reach_step, teleported, fall_step))
    if teleported.any():
        print(f"WARNING: {int(teleported.sum())} envs jumped > 0.5 m in one step (physics blow-up or fall off the tile); "
              f"those trials are excluded", flush=True)
    splits = split_of(conditions)
    rng = np.random.default_rng(seed)
    rows, trial_records = [], []
    for c_index, c in enumerate(conditions):
        feats, scene = edge_features(c, radius)
        s_hash = scene_hash(scene)
        for j in range(trials):
            i = c_index * trials + j
            # success = crossed upright AND still upright one second later (a trip over the edge that
            # carries the torso past the line is not a traversal)
            success = confirmed_crossing(reach_step[i], fall_step[i], steps, post_steps)
            fell = bool(fell_flag[i]) and not success
            record = dict(body_id=body_id, condition=c.as_dict(), condition_id=c.id, env_index=i, seed=seed,
                          progress_m=float(best[i]), goal_dx_m=float(goal_dx[i].cpu()) if hasattr(goal_dx, "cpu") else None,
                          reached_step=int(reach_step[i]), fell=fell, terminated=bool(term_flag[i]), speed_m_s=speed,
                          seconds=seconds, controller_hash=controller_hash, tracking=tracking, min_speed_m_s=min_speed,
                          valid=not bool(teleported[i]), success=success,
                          step_dt_s=step_dt,simulation_steps=steps,required_post_crossing_steps=post_steps,
                          fall_step=int(fall_step[i]) if fell_flag[i] else None,
                          post_crossing_observation_complete=bool(reached[i] and reach_step[i]+post_steps<steps))
            trial_records.append(record)
            # Nuisance features the trial does not exercise are randomised so the predictor does not
            # key on them: world heading (physically invariant), segment length (the navigator asks
            # at 0.1-0.2 m) and lateral clearance (passage width was NOT probed; treated as free).
            heading = rng.uniform(0, 2 * math.pi)
            feats = feats.copy(); feats[6], feats[7] = math.cos(heading), math.sin(heading)
            feats[5] = rng.uniform(0.05, 0.5); feats[9] = rng.uniform(radius + 0.02, 3.0)
            rows.append(dict(schema=TRAVERSAL_SCHEMA, edge_fields=list(EDGE_FIELDS), edge_features=[float(v) for v in feats],
                             structure_rows=rows_struct, structure_hash=digest(rows_struct), controller_hash=controller_hash,
                             scene_hash=s_hash, evidence_hash=digest(record), layout_group_id=c.id,
                             execution_seed=int(seed * 100000 + i), split=splits[c.id], backend="dynamic_simulation",
                             success=success, collision=False, fell=fell, body_id=body_id, kind=c.kind,
                             condition=c.as_dict(), footprint_radius_m=radius, progress_m=float(best[i]), tracking=tracking,
                             valid=record["valid"]))
    metadata = dict(success_criterion='crossed upright and observed upright for one full second before rollout timeout',
                   step_dt_s=step_dt,simulation_steps=steps,required_post_crossing_steps=post_steps,
                   invalid_trials=int(teleported.sum()),
                    invalid_by_condition={c.id: int(teleported[c_index * trials:(c_index + 1) * trials].sum())
                                          for c_index, c in enumerate(conditions)
                                          if teleported[c_index * trials:(c_index + 1) * trials].any()},
                   body_id=body_id, task=walker["task"], checkpoint=str(walker["checkpoint"]),
                   controller_hash=controller_hash, structure_hash=digest(rows_struct), footprint_radius_m=radius,
                   structure_source="compiled native task entity; body_id is the task family label",
                   native_spec_sha256=hashlib.sha256(robot.spec.copy().to_xml().encode()).hexdigest(),
                   speed_m_s=speed, min_speed_m_s=min_speed, seconds=seconds, tracking=tracking, trials_per_condition=trials, n_conditions=len(conditions),
                   wall_time_s=elapsed, device=device, split_rule="grouped by condition; every 4th val, next test")
    return save_probe_results(out, rows, trial_records, metadata, min_trials=min(10, trials))


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--body", required=True, help="a WALKERS body, or any registered body given --task and --checkpoint")
    p.add_argument("--task", default=None, help="mjlab task id for a body not in WALKERS")
    p.add_argument("--checkpoint", default=None, help="frozen walker checkpoint for a body not in WALKERS")
    p.add_argument("--import-module", default=None, help="python module that registers a non-mjlab task (e.g. clear.low_level.task_go2)")
    p.add_argument("--out", required=True)
    p.add_argument("--trials", type=int, default=32)
    p.add_argument("--seconds", type=float, default=20.0)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--speed", type=float, default=None)
    p.add_argument("--tracking", choices=("closed", "open"), default="closed",
                   help="closed: steer toward the tile exit like the deployed route executor; open: fixed +x twist")
    p.add_argument("--quick", action="store_true", help="4 conditions, for smoke tests")
    p.add_argument("--min-speed", type=float, default=0.15,
                   help="closed-loop tracker's minimum forward command near the goal (m/s); walkers trained with a "
                        "standing deadband above this value stop short of the +1 m clearance line")
    p.add_argument("--check-geometry", action="store_true", help="ray-cast every tile against the analytic surface and exit")
    a = p.parse_args(argv)
    from clear.maze.robots import configure
    configure()   # deployment assets: the structure rows must describe the body the native stack drives
    if a.import_module:
        import importlib
        importlib.import_module(a.import_module)
    if a.task or a.checkpoint:
        if not (a.task and a.checkpoint and a.speed is not None):
            raise SystemExit("--task, --checkpoint and --speed are required together for a body outside WALKERS")
        from experiments.exp3.trajectory_v3.unseen_bodies import configure as configure_unseen
        configure_unseen()
        WALKERS[a.body] = dict(task=a.task, checkpoint=Path(a.checkpoint), speed=a.speed)
    elif a.body not in WALKERS:
        raise SystemExit(f"{a.body} is not a WALKERS body; pass --task/--checkpoint/--speed")
    conditions = default_conditions()
    if a.quick:
        conditions = [conditions[3], conditions[6], conditions[13], conditions[22]]
    if a.check_geometry:
        report = check_geometry(conditions, a.device, a.body)
        Path(a.out).mkdir(parents=True, exist_ok=True)
        (Path(a.out) / "geometry_check.json").write_text(json.dumps(report, indent=1) + "\n")
        for r in report:
            print(f"{r['condition']:>28}: max|err| {r['max_abs_error_m']*1000:6.1f} mm  nan={r['nan']}")
        return
    summary = run_probes(a.body, conditions, a.trials, a.out, a.device, a.seconds, a.seed, a.speed, a.tracking, a.min_speed)
    for c in summary["conditions"]:
        print(f"{c['kind']:>10} {c['condition']['magnitude']:.2f} mu{c['condition']['friction']:.1f}: "
              f"{c['successes']}/{c['trials']}  ci95=[{c['ci95'][0]:.2f},{c['ci95'][1]:.2f}]")
    print("wall_time_s", round(summary["wall_time_s"], 1))


if __name__ == "__main__":
    main()
