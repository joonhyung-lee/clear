"""Experiment 3 object-path adapter over the CLEAR shared core (clear.model.clear_core).

Inputs stay the v3 public schema (data.collate): 9-D object rows, 9-D scene rows,
20-D structure rows, optional 4-D navigation context. Output is the object order
and a whole waypoint tensor per selected object. No body-ID, capability-table or
EEF input/output. Flow time is never execution time.
"""
import torch

from clear.model.clear import CLEARCore
from clear.model.causalflownet import RankCausalTargetFlow

OBJECT_DIM, SCENE_DIM, STRUCTURE_DIM = 9, 9, 20
# data.raw_scene_features: the same rows with the dropped ramp axis and tile friction kept.
RAW_SCENE_DIM = 13


class RankCausalObjectPathFlow(RankCausalTargetFlow):
    """Whole-path flow: target code = (waypoints-1) x 4 per object."""

    def __init__(self, dim=128, waypoints=8, depth=4, heads=4, causal=True):
        if waypoints < 2 or dim % heads:
            raise ValueError("at least two waypoints and dim divisible by heads required")
        super().__init__(dim, (waypoints - 1) * 4, depth, heads, dim // heads, causal)
        self.waypoints, self.code_dim = waypoints, self.target_dim

    @property
    def output(self):
        return self.head[-1]


class ObjectMotionModel(CLEARCore):
    def __init__(self, dim=128, depth=4, heads=4, waypoints=8, no_embodiment=False, causal=True,
                 navigation_features=0, scene_dim=SCENE_DIM, navigation_norm=False):
        if navigation_features not in (0, 4):
            raise ValueError("navigation context must be disabled or use the four-feature schema")
        if waypoints < 2 or dim % heads:
            raise ValueError("at least two waypoints and dim divisible by heads required")
        if scene_dim not in (SCENE_DIM, RAW_SCENE_DIM):
            raise ValueError("scene rows must use the 9-D public schema or the 13-D raw schema")
        super().__init__(dim, OBJECT_DIM, scene_dim, STRUCTURE_DIM, (waypoints - 1) * 4, depth, heads,
                         navigation_dim=navigation_features, causal=causal, no_embodiment=no_embodiment,
                         navigation_norm=navigation_norm)
        self.flow = RankCausalObjectPathFlow(dim, waypoints, depth, heads, causal)
        self.config = dict(dim=dim, depth=depth, heads=heads, waypoints=waypoints,
                           no_embodiment=no_embodiment, causal=causal, navigation_features=navigation_features)
        # Absent from config at the default width, so every existing checkpoint identity and
        # config-equality check stays exactly what it was.
        if scene_dim != SCENE_DIM:
            self.config["scene_dim"] = scene_dim
        if navigation_norm:
            self.config["navigation_norm"] = True

    path_flow = property(lambda self: self.flow)
    priority = property(lambda self: self.ordering.priority)

    def encode(self, batch):
        h = super().encode(batch)
        b = h["embodiment"].shape[0]
        ones = torch.ones(b, 1, dtype=torch.bool, device=h["embodiment"].device)
        return dict(objects=h["objects"], context=torch.cat([h["embodiment"], h["scene"]], 1),
                    context_mask=torch.cat([ones, h["scene_mask"]], 1),
                    selection=h["selection"], mu=h["mu"], sigma=h["sigma"])

    def loss(self, batch, generator=None):
        # v3 datasets name the waypoint tensor `path_code`; the core reads `target_code`.
        return super().loss(dict(batch, target_code=batch["path_code"]), generator)

    @torch.no_grad()
    def sample(self, batch, steps=30, generator=None, max_interactions=3, sample_selection=False):
        out = super().sample(batch, steps, generator, max_interactions, sample_selection)
        return dict(rank=out["rank"], selected=out["selected"], path_code=out["code"],
                    selection_logits=out["selection_logits"])
