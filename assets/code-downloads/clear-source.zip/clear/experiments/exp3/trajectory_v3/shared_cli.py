"""Explicit shared-morphology training and single-checkpoint planning entry point."""
import argparse
from collections import Counter
import importlib
import json
import math
import platform
import time
from pathlib import Path

import torch

from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.cli import read_jsonl
from experiments.exp3.trajectory_v3.data import collate, validate_dataset, validate_navigation_context
from experiments.exp3.trajectory_v3.navigation_cache import CachedTerrainNavigator, GeometryCache
from experiments.exp3.trajectory_v3.shared_morphology import SHARED_SCHEMA, SharedMorphologyModel, SharedTraversalPredictor, attach_probe_scenes, checkpoint_record, collate_probes, embodiment_from_row, load_shared_planner, refresh_navigation_rows
from experiments.exp3.trajectory_v3.traversability import validate_probes
from experiments.exp3.trajectory_v3.training_state import atomic_save, file_hash, learning_rate, restore_rng, rng_state, source_revision


def validate_training_data(rows, probes, config):
    prepared = []
    for row in rows:
        embodiment = embodiment_from_row(row)
        clean = dict(row, footprint_radius_m=embodiment.footprint_radius_m,
                     controller_hash=embodiment.controller_hash)
        clean.pop("navigation_context", None)
        prepared.append(clean)
    summary = validate_dataset(prepared, config["model"]["waypoints"], config.get("holdout_bodies", ()),
                               config.get("holdout_structure_hashes", ()))
    probe_counts = validate_probes(probes)
    holdout = set(config.get("holdout_structure_hashes", ()))
    holdout.update(digest(r["structure_rows"]) for r in prepared
                   if r["body_id"] in config.get("holdout_bodies", ()))
    if any(p["split"] in ("train", "val") and p["structure_hash"] in holdout for p in probes):
        raise ValueError("held-out structure used in traversal training or validation")
    groups, controllers = {}, {}
    for row in [*prepared, *probes]:
        group = row["scene"]["layout_group_id"] if "scene" in row else row["layout_group_id"]
        if group in groups and groups[group] != row["split"]:
            raise ValueError("layout group leaks across plan and traversal supervision splits")
        groups[group] = row["split"]
        structure = digest(row["structure_rows"])
        if structure in controllers and controllers[structure] != row["controller_hash"]:
            raise ValueError("one frozen controller per structure required across both datasets")
        controllers[structure] = row["controller_hash"]
    profiles = {p["structure_hash"]: p["controller_hash"] for p in probes if p["split"] == "train"}
    if any(r["split"] in ("train", "val") and
           profiles.get(digest(r["structure_rows"])) != r["controller_hash"] for r in prepared):
        raise ValueError("plan train/val structure-controller pairs must be supported by traversal training probes")
    return prepared, profiles, dict(plans=summary, traversal=probe_counts)


def make_navigator(model, profiles, settings, geometry_cache=None):
    return CachedTerrainNavigator(SharedTraversalPredictor(model, profiles), geometry_cache=geometry_cache, **settings)


def add_current_navigation(batch, rows, navigator):
    fresh = refresh_navigation_rows(rows, navigator)
    navigation = torch.zeros(*batch["object_mask"].shape, 4, device=batch["object_features"].device)
    for i, row in enumerate(fresh):
        features = validate_navigation_context(row)
        navigation[i, :len(features)] = torch.as_tensor(features, device=navigation.device)
    return dict(batch, navigation_features=navigation)


def evaluate(model, plan_rows, probe_rows, profiles, navigation, batch_size, affordance_weight, device, geometry_cache=None, static_batches=None):
    model.eval()
    navigator = make_navigator(model, profiles, navigation, geometry_cache)
    generator = torch.Generator(device=device).manual_seed(0)
    plan_total, traversal_total, brier = 0., 0., 0.
    component_totals = {}
    exact_selection, ordered_pairs, correct_pairs = 0, 0, 0
    positives, negatives, false_positive, false_negative = 0, 0, 0, 0
    with torch.no_grad():
        for start in range(0, len(plan_rows), batch_size):
            chunk = plan_rows[start:start + batch_size]
            static = static_batches[start // batch_size] if static_batches is not None else collate(
                chunk, model.config["waypoints"], device, scene_dim=model.config.get("scene_dim", 9))
            batch = add_current_navigation(static, chunk, navigator)
            loss, terms = model.loss(batch, generator)
            plan_total += float(loss) * len(chunk)
            for key, value in terms.items():
                component_totals[key] = component_totals.get(key, 0.) + value * len(chunk)
            if model.cdgs is not None:
                continue  # No CLEAR selection/priority head in the external planner.
            h = model.encode(batch)
            mask, rank = batch["object_mask"], batch["rank"]
            target = (rank >= 0) & mask
            exact_selection += int((((h["selection"] > 0) == target) | ~mask).all(-1).sum())
            pairs = target[:, :, None] & target[:, None, :] & (rank[:, :, None] < rank[:, None, :])
            ordered_pairs += int(pairs.sum())
            correct_pairs += int((pairs & (h["mu"][:, :, None] < h["mu"][:, None, :])).sum())
        for start in range(0, len(probe_rows), batch_size):
            chunk = probe_rows[start:start + batch_size]
            probes = collate_probes(chunk, device)
            traversal_total += float(model.traversal_loss(probes)) * len(chunk)
            probability = model.traversal_probe_logits(probes).sigmoid()
            truth, prediction = probes["target"].bool(), probability >= navigation["threshold"]
            positives += int(truth.sum())
            negatives += int((~truth).sum())
            false_positive += int((prediction & ~truth).sum())
            false_negative += int((~prediction & truth).sum())
            brier += float(((probability - probes["target"]) ** 2).sum())
    plan_loss, traversal_loss = plan_total / len(plan_rows), traversal_total / len(probe_rows)
    diagnostics = dict(object=plan_loss, affordance=traversal_loss,
                       components={k: v / len(plan_rows) for k, v in component_totals.items()},
                       selection_exact=exact_selection / len(plan_rows) if model.cdgs is None else None,
                       mean_priority_pair_accuracy=correct_pairs / ordered_pairs if ordered_pairs else None,
                       ordered_pairs=ordered_pairs, affordance_brier=brier / len(probe_rows),
                       affordance_false_positive_rate=false_positive / negatives if negatives else None,
                       affordance_false_negative_rate=false_negative / positives if positives else None,
                       positive_probes=positives, negative_probes=negatives)
    return plan_loss + affordance_weight * traversal_loss, diagnostics



def sample_training_indices(rows,count,generator,balance_bodies=False):
    if not balance_bodies:
        return torch.randint(len(rows),(count,),generator=generator).tolist()
    groups={}
    for index,row in enumerate(rows):
        body=row.get('body_id',row.get('structure_hash'))
        if body is None:raise ValueError('balanced sampling requires body or structure identity')
        groups.setdefault(body,[]).append(index)
    if not groups or count%len(groups):raise ValueError('batch size must divide equally across bodies')
    indices=[]
    for body in sorted(groups):
        pool=groups[body]
        indices.extend(pool[i] for i in torch.randint(len(pool),(count//len(groups),),generator=generator).tolist())
    return [indices[i] for i in torch.randperm(count,generator=generator).tolist()]


def train(args):
    config = json.loads(Path(args.config).read_text())
    rows, probes = read_jsonl(args.data), read_jsonl(args.probes)
    rows, profiles, summary = validate_training_data(rows, probes, config)
    if not args.allow_geometric_teacher and any(r["teacher"]["validation"] == "geometric" for r in rows):
        raise ValueError("geometric teachers require --allow-geometric-teacher")
    training = [r for r in rows if r["split"] == "train"]
    validation = [r for r in rows if r["split"] == "val"]
    probe_train = [p for p in probes if p["split"] == "train"]
    probe_val = [p for p in probes if p["split"] == "val"]
    if not all((training, validation, probe_train, probe_val)):
        raise ValueError("nonempty train/val sets required for BOTH plan and traversal supervision")
    settings, navigation = config["train"], config["navigation"]
    selection = getattr(args, "select", None) or settings.get("checkpoint_selection", "total")
    if selection not in ("total", "flow"):
        raise ValueError("checkpoint selection must be total or flow")
    if min(settings[k] for k in ("steps", "batch_size", "probe_batch_size", "eval_every")) < 1:
        raise ValueError("positive training budgets required")
    weight = float(settings["affordance_weight"])
    if not math.isfinite(weight) or weight <= 0 or not math.isfinite(settings["lr"]) or settings["lr"] <= 0:
        raise ValueError("positive finite loss weight and learning rate required")
    out = Path(args.out)
    resume = getattr(args, "resume", False)
    if not resume and out.exists() and any(out.iterdir()):
        raise FileExistsError("training output must be empty")
    if resume and not (out / "last.pt").exists():
        raise FileNotFoundError("--resume requires last.pt in --out")
    out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(int(settings.get("cpu_threads", 2)))
    torch.manual_seed(args.seed)
    model = SharedMorphologyModel(**config["model"]).to(args.device)
    if model.traversal_head == "encoder":
        model.initialize_traversal(args.seed)
    initialization=None
    initial_checkpoint=getattr(args,'init_checkpoint',None)
    if initial_checkpoint is not None:
        from experiments.exp3.trajectory_v3.shared_morphology import load_shared_checkpoint
        initial_model,initial_record=load_shared_checkpoint(initial_checkpoint,args.device)
        if initial_model.config!=model.config or initial_record['controller_profiles']!=profiles:
            raise ValueError('fine-tuning requires the same model architecture and frozen-controller profiles')
        model.load_state_dict(initial_model.state_dict(),strict=True)
        initialization=dict(checkpoint_sha256=file_hash(initial_checkpoint),step=initial_record.get('step'),
                            optimizer='fresh',scope='weight initialization; data/config identity belongs to the new run')
        del initial_model
    trainable_prefixes = tuple(settings.get("trainable_prefixes", ()))
    if trainable_prefixes:
        # adapter-style fine-tuning: only parameters whose names match are optimised; everything else is frozen
        trainable = [p for n, p in model.named_parameters() if n.startswith(trainable_prefixes)]
        if not trainable:
            raise ValueError("trainable_prefixes matched no parameter")
        for n, p in model.named_parameters():
            p.requires_grad_(n.startswith(trainable_prefixes))
    else:
        trainable = list(model.parameters())
    optimizer = torch.optim.AdamW(trainable, lr=settings["lr"], weight_decay=settings.get("weight_decay", .01))
    generator = torch.Generator(device=args.device).manual_seed(args.seed)
    sampling = torch.Generator().manual_seed(args.seed)
    geometry_cache = GeometryCache(settings.get("geometry_cache_size", 512))
    warmup = int(settings.get("affordance_warmup_steps", 0))
    if warmup < 0:
        raise ValueError("nonnegative affordance warmup required")
    learning_rate(settings, 1)  # Reject invalid schedules before any optimizer update.
    end_step = getattr(args, "stop_after", None) or settings["steps"]
    if not 1 <= end_step <= settings["steps"]:
        raise ValueError("--stop-after must be within the configured joint training budget")
    identity = dict(config=config, seed=args.seed, data_hash=digest(rows), probe_hash=digest(probes),
                    input_hashes=dict(data=file_hash(args.data), probes=file_hash(args.probes)), selection_metric=selection)
    if initialization is not None:identity['initialization']=initialization
    # After probe_hash above, never before: attach_probe_scenes adds derived geometry to the
    # rows, and probe_hash records what the probe FILE contained.
    if model.traversal_head == "encoder":
        # probe_train / probe_val are views into `probes`, so one pass covers both
        attach_probe_scenes(probes, model.config.get("scene_dim", 9))
    best, history, completed, warmup_completed, elapsed = float("inf"), [], 0, 0, 0.
    if resume:
        saved = torch.load(out / "last.pt", map_location=args.device, weights_only=True)
        state = saved.get("training_state", {})
        if saved.get("schema") != SHARED_SCHEMA or state.get("identity") != identity:
            raise ValueError("resume requires the same shared schema, config, seed, data, and probes")
        if state.get("device_type") != torch.device(args.device).type:
            raise ValueError("resume requires the same device type; use a new run for migration")
        model.load_state_dict(saved["state_dict"], strict=True)
        optimizer.load_state_dict(state["optimizer"])
        restore_rng(state["rng"], generator, sampling)
        best, history = state["best"], state["history"]
        completed, warmup_completed, elapsed = saved["step"], state["warmup_completed"], state["elapsed_s"]
        if completed >= end_step:
            raise ValueError("requested budget is already complete")
        if math.isfinite(best) and not (out / "best.pt").exists():
            raise FileNotFoundError("resume also requires the existing best.pt for checkpoint selection")
    started = time.perf_counter()
    report = dict(schema=SHARED_SCHEMA, architecture="shared_morphology", dataset=summary, **identity,
                  parameter_count=sum(p.numel() for p in model.parameters()),
                  code=source_revision(),
                  teacher_provenance=dict(Counter(r["teacher"].get("proxy", r["teacher"]["validation"]) for r in training)),
                  environment=dict(python=platform.python_version(), torch=str(torch.__version__),
                                   cuda=torch.version.cuda, device=str(args.device)),
                  navigation_context="recomputed before every optimizer step and validation",
                  status="training_in_progress; physical performance not evaluated")
    (out / "training.json").write_text(json.dumps(report, indent=2) + "\n")

    def snapshot(step, **metadata):
        state = dict(identity=identity, optimizer=optimizer.state_dict(), rng=rng_state(generator, sampling),
                     best=best, history=history, warmup_completed=warmup_completed,
                     elapsed_s=elapsed + time.perf_counter() - started, device_type=torch.device(args.device).type)
        return checkpoint_record(model, profiles, navigation, step=step, seed=args.seed,
                                 training_mode="joint_with_online_navigation", config=config,
                                 balanced_body_exposure=(dict(plan_examples_per_body=step*settings["batch_size"]//len({r["body_id"] for r in training}),
                                     joint_probe_examples_per_body=step*settings["probe_batch_size"]//len({r.get("body_id",r["structure_hash"]) for r in probe_train}),
                                     warmup_probe_examples_per_body=warmup_completed*settings["probe_batch_size"]//len({r.get("body_id",r["structure_hash"]) for r in probe_train}))
                                     if settings.get("balance_bodies",False) else None),
                                 training_state=state, environment=report["environment"], code=report["code"], **metadata)

    for warm_step in range(warmup_completed + 1, warmup + 1):
        indices = sample_training_indices(probe_train,settings["probe_batch_size"],sampling,settings.get("balance_bodies",False))
        optimizer.zero_grad(set_to_none=True)
        warm_loss = model.traversal_loss(collate_probes([probe_train[i] for i in indices], args.device))
        if not torch.isfinite(warm_loss):
            raise FloatingPointError("non-finite affordance warmup loss")
        warm_loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        optimizer.step()
        warmup_completed = warm_step
        if warm_step % settings["eval_every"] == 0 or warm_step == warmup:
            atomic_save(snapshot(0, phase="affordance_warmup"), out / "last.pt")
            print(json.dumps(dict(event="affordance_warmup", step=warm_step, loss=float(warm_loss.detach()),
                                  elapsed_s=elapsed + time.perf_counter()-started)), flush=True)
    scene_dim = model.config.get("scene_dim", 9)
    full = collate(training, model.config["waypoints"], args.device, scene_dim=scene_dim)
    val_batches = [collate(validation[i:i + settings["batch_size"]], model.config["waypoints"], args.device,
                           scene_dim=scene_dim)
                   for i in range(0, len(validation), settings["batch_size"])]
    for step in range(completed + 1, end_step + 1):
        lr = learning_rate(settings, step)
        for group in optimizer.param_groups:
            group["lr"] = lr
        indices = sample_training_indices(training,settings["batch_size"],sampling,settings.get("balance_bodies",False))
        probe_indices = sample_training_indices(probe_train,settings["probe_batch_size"],sampling,settings.get("balance_bodies",False))
        model.eval()
        navigator = make_navigator(model, profiles, navigation, geometry_cache)
        static = {k: v[indices] for k, v in full.items()}
        batch = add_current_navigation(static, [training[i] for i in indices], navigator)
        probe_batch = collate_probes([probe_train[i] for i in probe_indices], args.device)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss, terms = model.joint_loss(batch, probe_batch, generator, weight)
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite shared training loss")
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        optimizer.step()
        if step % settings["eval_every"] == 0 or step == end_step:
            score, val_terms = evaluate(model, validation, probe_val, profiles, navigation,
                                        settings["batch_size"], weight, args.device, geometry_cache, val_batches)
            if not math.isfinite(score):
                raise FloatingPointError("non-finite shared validation loss")
            criterion = val_terms["components"]["flow"] if selection == "flow" else score
            if not math.isfinite(criterion):
                raise FloatingPointError("non-finite checkpoint selection score")
            history.append(dict(step=step, train_loss=float(loss.detach()), train_terms=terms,
                                validation_loss=score, validation_terms=val_terms,
                                lr=lr, grad_norm=float(grad_norm), selection_metric=selection, selection_score=criterion))
            history[-1]["elapsed_s"] = elapsed + time.perf_counter()-started
            print(json.dumps(history[-1]), flush=True)
            improved = criterion < best
            if improved:
                best = criterion
            record = snapshot(step, phase="joint", validation_loss=score, validation_terms=val_terms,
                              selection_metric=selection, selection_score=criterion)
            if improved:
                atomic_save(record, out / "best.pt")
            atomic_save(record, out / "last.pt")
            if settings.get("keep_every") and step % settings["keep_every"] == 0:
                atomic_save(record, out / f"step_{step:06d}.pt")
            (out / "loss.json").write_text(json.dumps(history, indent=2) + "\n")
    report.update(completed_steps=end_step, best_validation_loss=min(h["validation_loss"] for h in history),
                  completed_warmup_steps=warmup_completed,
                  plan_examples_seen=end_step*settings['batch_size'],
                  best_selection_score=best,
                  elapsed_s=elapsed + time.perf_counter()-started,
                  status=("training_completed" if end_step == settings["steps"] else "training_paused")
                         + "; physical performance not evaluated")
    if model.cdgs is not None:
        report['short_transition_examples_seen']=2*end_step*settings['batch_size']
    (out / "training.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def infer(args):
    assessor = None
    if args.assessor_factory:
        module, name = args.assessor_factory.split(":")
        assessor = getattr(importlib.import_module(module), name)()
    planner = load_shared_planner(args.checkpoint, args.device, args.candidates, args.flow_steps,
                                  args.seed, args.max_interactions, assessor, args.additional_frozen_controllers)
    row = json.loads(Path(args.input).read_text())
    embodiment = embodiment_from_row(row)
    if args.command == "routes":
        analysis = planner.navigator.analyze(row["scene"], embodiment)
        result = dict(status="predicted_route" if analysis.goal_route else "no_route_found",
                      route=analysis.goal_route, navigation_context=analysis.model_context(),
                      unknown_edges=analysis.unknown_edges, infeasibility_proven=False)
    else:
        decision = planner.decide(row["scene"], embodiment)
        result = dict(status=decision.status, plan=decision.plan.to_dict(), route=decision.route,
                      scene_hash=decision.scene_hash, embodiment_hash=decision.embodiment_hash, trace=decision.trace)
    result.update(architecture="shared_morphology", checkpoint_schema=SHARED_SCHEMA,
                  physical_execution_performed=False)
    path = Path(args.out)
    if path.exists():
        raise FileExistsError("output already exists")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="CLEAR shared morphology: joint training and one-checkpoint planning")
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("train")
    p.add_argument("--data", required=True)
    p.add_argument("--probes", required=True)
    p.add_argument("--config", default="experiments/exp3/configs/trajectory_v3_shared.json")
    p.add_argument("--out", required=True)
    p.add_argument("--device", default="cpu")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--select", choices=("total", "flow"),
                   help="select best.pt by joint validation loss or validation flow loss")
    p.add_argument("--allow-geometric-teacher", action="store_true")
    p.add_argument("--resume", action="store_true", help="resume last.pt in --out with unchanged data/config/seed")
    p.add_argument('--init-checkpoint',help='new run initialized from shared weights, with a fresh optimizer and explicit provenance')
    p.add_argument("--stop-after", type=int, help="pause after this joint step; useful for a short server check")
    for command in ("routes", "plan"):
        p = commands.add_parser(command)
        p.add_argument("--checkpoint", required=True)
        p.add_argument("--input", required=True)
        p.add_argument("--out", required=True)
        p.add_argument("--device", default="cpu")
        p.add_argument("--candidates", type=int, default=8)
        p.add_argument("--flow-steps", type=int, default=30)
        p.add_argument("--seed", type=int, default=0)
        p.add_argument("--max-interactions", type=int)
        p.add_argument("--assessor-factory")
        p.add_argument("--additional-frozen-controllers", nargs="*", default=[])
    args = parser.parse_args(argv)
    result = train(args) if args.command == "train" else infer(args)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
