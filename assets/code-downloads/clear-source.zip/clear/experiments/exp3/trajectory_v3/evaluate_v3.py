"""exp3/exp4 evaluation on the simulated (kinematic, probe-grounded) task backend.

Methods share the OracleAssessor as verifier and the same candidate budget. `clear`, `clear_noemb`,
`random_order` and `all_objects` plan on the LEARNED navigator; `oracle_search` (upper bound) plans on
the probe-table navigator. Metrics follow exp_v3/NIGHT_PLAN_2026-09-09.md "Success metric".
With --shared-checkpoint, learned traversal and object proposals use the same model instance.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, ObjectPath
from experiments.exp3.trajectory_v3.dataset_gen import guide_path, guide_paths, teacher_search
from experiments.exp3.trajectory_v3.navigation import EmbodimentSpec, TerrainNavigator
from experiments.exp3.trajectory_v3.navigation_planner import NavigationInteractionPlanner, NeuralObjectProposer, run_navigation_episode, validate_sequence
from experiments.exp3.trajectory_v3.oracle_capability import OracleAssessor, PermissiveAssessor, ProbeTablePredictor, PushTable, approach_point
from experiments.exp3.trajectory_v3.task_backend import SimulatedTaskBackend

METHODS = ("clear", "clear_noemb", "oracle_search", "random_order", "all_objects")
LEARNED = ("clear", "clear_noemb", "clear_proj", "random_order", "all_objects")
PROJECTION_OFFSETS = tuple((dx, dy) for dx in (-.15, -.1, -.05, 0., .05, .1, .15) for dy in (-.15, -.1, -.05, 0., .05, .1, .15))


class ProjectingProposer:
    """Wrap a proposer: a path that collides with public geometry is shifted rigidly (waypoints
    after the anchored start) by the smallest offset in PROJECTION_OFFSETS that clears it.
    The order and selection are untouched; `projected` / `unprojectable` counts are reported."""

    def __init__(self, inner):
        self.inner, self.projected, self.unprojectable, self.passed = inner, 0, 0, 0

    def __call__(self, scene, embodiment, context):
        from copy import deepcopy
        from experiments.exp3.trajectory_v3.scenes import path_collision
        for plan in self.inner(scene, embodiment, context):
            work, paths = deepcopy(scene), []
            for path in plan.paths:
                if not path_collision(work, path):
                    fixed = path; self.passed += 1
                else:
                    fixed = None
                    pts = np.asarray(path.poses)
                    for dx, dy in sorted(PROJECTION_OFFSETS, key=lambda o: abs(o[0]) + abs(o[1])):
                        if dx == dy == 0:
                            continue
                        moved = pts.copy(); moved[1:, 0] += dx; moved[1:, 1] += dy
                        candidate = ObjectPath(path.object_id, tuple(map(tuple, moved)), path.body_part)
                        if not path_collision(work, candidate):
                            fixed = candidate; self.projected += 1; break
                    if fixed is None:
                        self.unprojectable += 1
                        fixed = path
                paths.append(fixed)
                obj = next((o for o in work["objects"] if o["object_id"] == path.object_id), None)
                if obj is not None:
                    obj["pose"] = list(fixed.goal)
            yield ObjectMotionPlan(tuple(paths))
PERTURBATIONS = ("nominal", "placement_shift", "access_shift")


class RecordingPlanner(NavigationInteractionPlanner):
    def __init__(self, *args, **kwargs):
        self.decision_observer=kwargs.pop('decision_observer',None)
        super().__init__(*args, **kwargs); self.decisions = []

    def decide(self, scene, embodiment):
        decision = super().decide(scene, embodiment); self.decisions.append(decision)
        if self.decision_observer is not None:self.decision_observer(decision)
        return decision


def reseed(proposer, key):
    """Give both bodies of a scene identical sampling randomness.

    Without this the proposer's generator advances between the two episodes of a paired scene, so
    a body-blind model still produces different plans for Spot and G1 and the body-paired plan
    switch measures sampling noise (measured 2026-09-09: the no-embodiment ablation scored the
    same 0.38 as the conditioned model).
    """
    value = int(hashlib.sha256(str(key).encode()).hexdigest()[:8], 16)
    generator = getattr(proposer, "generator", None)
    if generator is not None:
        generator.manual_seed(value)
    rng = getattr(proposer, "rng", None)
    if rng is not None:
        rng.bit_generator.state = np.random.default_rng(value).bit_generator.state


def search_proposer(navigator, assessor):
    def propose(scene, embodiment, context):
        found = teacher_search(scene, embodiment, navigator, assessor)
        if found is not None and found["plan"].paths:
            yield found["plan"]
    return propose


def random_proposer(rng, candidates, everything):
    def propose(scene, embodiment, context):
        ids = [o["object_id"] for o in scene["objects"]]
        for _ in range(candidates):
            if not ids:
                yield ObjectMotionPlan(()); continue
            k = len(ids) if everything else int(rng.integers(1, len(ids)+1))
            order = [ids[i] for i in rng.permutation(len(ids))[:k]]
            paths = []
            for i in order:                       # a random guide variant per object, same menu as the teacher
                options = guide_paths(scene, i)
                if options:
                    paths.append(options[int(rng.integers(len(options)))])
            yield ObjectMotionPlan(tuple(paths))
    return propose


def perturbation_for(kind, row):
    plan, scene = row.get("plan", {}).get("paths", []), row["scene"]
    if kind == "nominal":
        return None
    if kind == "placement_shift":
        if not plan:
            return None
        poses = np.asarray(plan[0]["poses"])[:, :2]
        d = next((b-a for a, b in zip(poses[-2::-1], poses[::-1]) if np.linalg.norm(b-a) > 1e-6), None)
        if d is None:
            return None
        side = np.array([-d[1], d[0]])/np.linalg.norm(d)*.2
        return dict(kind=kind, object_id=plan[0]["object_id"], after_interaction_index=0, dx=float(side[0]), dy=float(side[1]))
    if kind == "access_shift":
        blocker = scene.get("access_blocker_id")
        if blocker is None or len(plan) < 2:
            return None
        approach = np.asarray(approach_point(ObjectPath.from_dict(plan[1])))
        origin = np.asarray(next(o for o in scene["objects"] if o["object_id"] == blocker)["pose"][:2])
        v = approach-origin; v = v/np.linalg.norm(v)*1.4
        return dict(kind=kind, object_id=blocker, after_interaction_index=0, dx=float(v[0]), dy=float(v[1]))
    raise ValueError(kind)


def parse_pairs(text):
    return {k: v for k, v in (item.split("=", 1) for item in text.split(","))} if text else {}


def evaluate(rows, out, mode, probe_summaries, push_summaries=None, checkpoint=None, noemb_checkpoint=None,
             traversability_checkpoint=None, methods=None, seeds=(0, 1, 2), candidates=8, device="cpu", threshold=None,
             shared_checkpoint=None, planner_assessor="oracle"):
    if methods is None:
        methods = [m for m in METHODS if not (shared_checkpoint and m == "clear_noemb")]
    if shared_checkpoint and any((checkpoint, noemb_checkpoint, traversability_checkpoint)):
        raise ValueError("--shared-checkpoint cannot be combined with legacy checkpoints")
    if shared_checkpoint and "clear_noemb" in methods:
        raise ValueError("evaluate a shared no-embodiment checkpoint in a separate run with --methods clear")
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    predictor = ProbeTablePredictor(probe_summaries)
    push = PushTable.from_summaries(push_summaries) if push_summaries else PushTable.from_registry(tuple(probe_summaries))
    oracle_nav, assessor = TerrainNavigator(predictor), OracleAssessor(push, predictor.bodies)
    # the planner may run a weaker verifier than the executor; the backend always uses `assessor`
    planning_assessor = PermissiveAssessor(push, predictor.bodies) if planner_assessor == "permissive" else assessor
    learned_nav = None
    shared_model, shared_record = None, None
    methods = [m for m in methods if not (m in ("clear", "clear_proj") and not (checkpoint or shared_checkpoint)) and not (m == "clear_noemb" and not noemb_checkpoint)]
    if any(m in LEARNED for m in methods):
        if shared_checkpoint:
            from experiments.exp3.trajectory_v3.shared_morphology import load_shared_checkpoint, SharedTraversalPredictor
            shared_model, shared_record = load_shared_checkpoint(shared_checkpoint, device)
            navigation = dict(shared_record["navigation"])
            if threshold is not None:
                navigation["threshold"] = threshold
            learned_nav = TerrainNavigator(SharedTraversalPredictor(shared_model, shared_record["controller_profiles"]),
                                           **navigation)
        else:
            from experiments.exp3.trajectory_v3.traversability import LearnedTraversalPredictor
            if not traversability_checkpoint:
                raise ValueError("learned methods need --traversability-checkpoint or --shared-checkpoint")
            learned_nav = TerrainNavigator(LearnedTraversalPredictor(traversability_checkpoint, device),
                                           threshold=.8 if threshold is None else threshold)
    cells = [("frozen", "nominal")] if mode == "exp3" else [(p, e) for p in ("frozen", "replan_after_interaction") for e in PERTURBATIONS]
    episodes = []
    for method in methods:
        for seed in seeds:
            rng = np.random.default_rng(seed)
            if shared_model is not None and method in ("clear", "clear_proj"):
                from experiments.exp3.trajectory_v3.shared_morphology import SharedObjectProposer
                proposer = SharedObjectProposer(shared_model, learned_nav.predictor, candidates, seed=seed)
                if method == "clear_proj":
                    proposer = ProjectingProposer(proposer)
            elif method == "clear":
                proposer = NeuralObjectProposer(checkpoint, candidates, seed=seed, device=device)
            elif method == "clear_proj":
                proposer = ProjectingProposer(NeuralObjectProposer(checkpoint, candidates, seed=seed, device=device))
            elif method == "clear_noemb":
                proposer = NeuralObjectProposer(noemb_checkpoint, candidates, seed=seed, device=device)
            elif method == "oracle_search":
                proposer = search_proposer(oracle_nav, assessor)
            else:
                proposer = random_proposer(rng, candidates, everything=method == "all_objects")
                proposer.rng = rng          # so reseed() can pin it per scene
            navigator = oracle_nav if method == "oracle_search" else learned_nav
            for index, row in enumerate(rows):
                emb = EmbodimentSpec(row["structure_rows"], row["footprint_radius_m"], row["controller_hash"])
                k_star = row.get("teacher", {}).get("k_star")
                oracle_status = "no_valid_plan_found" if k_star is None else "navigate" if k_star == 0 else "interact"
                horizon = row["scene"].get("navigation_condition", {}).get("horizon")
                reseed(proposer, (seed, row["scene"]["base_scene_id"]))   # identical randomness for both bodies
                for policy, event in cells:
                    perturbation = perturbation_for(event, row)
                    planner = RecordingPlanner(navigator, proposer, planning_assessor, candidates)
                    backend = SimulatedTaskBackend(row["scene"], emb, oracle_nav, assessor,
                                                   np.random.default_rng([seed, index, hash(policy+event) % 2**31]), perturbation)
                    result = run_navigation_episode(planner, emb, backend, policy=policy,
                                                    max_interactions=(horizon or 5)+3 if mode == "exp4" else 8,
                                                    max_time_s=240. if mode == "exp4" else 120.)
                    decision = planner.decisions[0]
                    objects = [p.object_id for p in decision.plan.paths]
                    valid = None
                    if decision.status == "interact":
                        valid = validate_sequence(row["scene"], emb, decision.plan, oracle_nav, assessor)[1] is None
                    episodes.append(dict(scene_id=row["scene"]["base_scene_id"], layout_group_id=row["scene"]["layout_group_id"],
                                         body_id=row["body_id"], method=method, seed=seed, policy=policy, perturbation=event,
                                         perturbation_applied=perturbation is not None, status=result["status"],
                                         task_success=bool(result["task_success"]), planning_calls=result["planning_calls"],
                                         attempted_interactions=result["attempted_interactions"], elapsed_s=result["elapsed_s"],
                                         decision=decision.status, decision_objects=objects, oracle_status=oracle_status, k_star=k_star,
                                         decision_correct=decision.status == oracle_status, plan_valid=valid,
                                         plan=decision.plan.to_dict() if decision.plan.paths else None,
                                         projection=dict(projected=proposer.projected, unprojectable=proposer.unprojectable, passed=proposer.passed)
                                         if isinstance(proposer, ProjectingProposer) else None,
                                         observations=result["measured_boundary_observations"] if result["attempted_interactions"] else None,
                                         minimum_interaction_success=bool(result["task_success"]) and k_star is not None
                                         and result["attempted_interactions"] == k_star, backend_events=backend.events))
    (out/"episodes.jsonl").write_text("".join(json.dumps(e)+"\n" for e in episodes))
    aggregate = aggregate_metrics(episodes)
    aggregate["config"] = dict(mode=mode, methods=methods, seeds=list(seeds), candidates=candidates, rows=len(rows),
                               push_source=push.source, oracle_predictor=predictor.identity,
                               learned_predictor=learned_nav.predictor.identity if learned_nav else None,
                               architecture="shared_morphology" if shared_model is not None else "legacy_separate_models",
                               shared_checkpoint=str(shared_checkpoint) if shared_checkpoint else None,
                               shared_checkpoint_sha256=hashlib.sha256(Path(shared_checkpoint).read_bytes()).hexdigest()
                               if shared_record else None,
                               checkpoint_schema=shared_record["schema"] if shared_record else None,
                               no_embodiment=shared_model.no_embodiment if shared_model is not None else None,
                               navigation=dict(resolution=learned_nav.resolution, threshold=learned_nav.threshold) if learned_nav else None,
                               backend="SimulatedTaskBackend (kinematic proxy on measured probe tables; not dynamics)")
    (out/"aggregate_metrics.json").write_text(json.dumps(aggregate, indent=1)+"\n")
    (out/"RESULTS.md").write_text(results_markdown(aggregate))
    return aggregate


def bootstrap(by_scene, resamples=1000, seed=0):
    """by_scene: scene_id -> list of 0/1 (or numeric). Mean and 95% CI by resampling scenes."""
    keys = sorted(by_scene); rng = np.random.default_rng(seed)
    pooled = [v for k in keys for v in by_scene[k]]
    if not pooled:
        return dict(mean=None, ci95=[None, None], n=0)
    means = []
    for _ in range(resamples):
        pick = rng.integers(len(keys), size=len(keys))
        values = [v for i in pick for v in by_scene[keys[i]]]
        means.append(np.mean(values))
    return dict(mean=float(np.mean(pooled)), ci95=[float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))], n=len(pooled))


def seed_stats(per_seed):
    finite = [v for v in per_seed if np.isfinite(v)]
    return dict(seed_mean=float(np.mean(finite)) if finite else None, seed_sd=float(np.std(finite)) if finite else None)


def aggregate_metrics(episodes):
    groups = {}
    for e in episodes:
        groups.setdefault((e["method"], e["policy"], e["perturbation"]), []).append(e)
    report = {}
    for (method, policy, event), items in sorted(groups.items()):
        seeds = sorted({e["seed"] for e in items})
        metrics = {}
        for name, pick in (("decision_correctness", lambda e: e["decision_correct"]),
                           ("plan_validity", lambda e: e["plan_valid"]),
                           ("task_success", lambda e: e["task_success"]),
                           ("minimum_interaction_success", lambda e: e["minimum_interaction_success"]),
                           ("planning_calls", lambda e: e["planning_calls"]),
                           ("attempted_interactions", lambda e: e["attempted_interactions"])):
            by_scene, per_seed = {}, []
            for s in seeds:
                vals = [(e["scene_id"], float(pick(e))) for e in items if e["seed"] == s and pick(e) is not None]
                per_seed.append(float(np.mean([v for _, v in vals])) if vals else np.nan)
                for scene, v in vals:
                    by_scene.setdefault(scene, []).append(v)
            metrics[name] = dict(**bootstrap(by_scene), **seed_stats(per_seed))
        # body-paired plan switch: same scene, two bodies, different decision/object set, both successful
        by_scene, per_seed = {}, []
        for s in seeds:
            scenes = {}
            for e in items:
                if e["seed"] == s:
                    scenes.setdefault(e["scene_id"], []).append(e)
            vals = []
            for scene, pair in scenes.items():
                if len({e["body_id"] for e in pair}) < 2:
                    continue
                signatures = {(e["decision"], tuple(sorted(e["decision_objects"]))) for e in pair}
                v = float(len(signatures) > 1 and all(e["task_success"] for e in pair))
                vals.append(v); by_scene.setdefault(scene, []).append(v)
            per_seed.append(float(np.mean(vals)) if vals else np.nan)
        metrics["body_paired_plan_switch"] = dict(**bootstrap(by_scene), **seed_stats(per_seed))
        histogram = {}
        for e in items:
            histogram[e["status"]] = histogram.get(e["status"], 0)+1
        metrics["status_histogram"] = histogram
        metrics["episodes"] = len(items)
        report[f"{method}|{policy}|{event}"] = metrics
    return dict(groups=report)


def results_markdown(aggregate):
    names = ("decision_correctness", "plan_validity", "task_success", "minimum_interaction_success", "body_paired_plan_switch",
             "planning_calls", "attempted_interactions")
    lines = ["# exp3/exp4 simulated-backend results", "",
             "Architecture: " + aggregate.get("config", {}).get("architecture", "legacy_separate_models"), "",
             "Kinematic proxy backend on measured probe tables; not physics. mean±sd across seeds, [95% bootstrap CI over scenes].", "",
             "| method | policy | perturbation | n | "+" | ".join(names)+" |", "|"+"---|"*(4+len(names))]
    for key, m in aggregate["groups"].items():
        cells = []
        for n in names:
            v = m[n]
            cells.append("–" if v["mean"] is None else f"{v['seed_mean']:.3f}±{v['seed_sd']:.3f} [{v['ci95'][0]:.2f},{v['ci95'][1]:.2f}]")
        lines.append("| "+" | ".join(key.split("|"))+f" | {m['episodes']} | "+" | ".join(cells)+" |")
    lines += ["", "Status histogram per group:", ""]
    for key, m in aggregate["groups"].items():
        lines.append(f"- {key}: {json.dumps(m['status_histogram'])}")
    return "\n".join(lines)+"\n"


def read_rows(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def main(argv=None):
    p = argparse.ArgumentParser(description="exp3/exp4 evaluation on the simulated backend")
    p.add_argument("--data", required=True); p.add_argument("--unsolved", help="unsolved.jsonl; its test rows join with oracle status no_valid_plan_found")
    p.add_argument("--checkpoint"); p.add_argument("--noemb-checkpoint"); p.add_argument("--traversability-checkpoint")
    p.add_argument("--shared-checkpoint", help="one jointly trained checkpoint for traversal and object planning")
    p.add_argument("--probe-summaries", required=True, help="spot=PATH,g1=PATH"); p.add_argument("--push-summaries")
    p.add_argument("--out", required=True); p.add_argument("--mode", choices=("exp3", "exp4"), default="exp3")
    p.add_argument("--device", default="cpu"); p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    p.add_argument("--methods", nargs="+", choices=(*METHODS, "clear_proj")); p.add_argument("--candidates", type=int, default=8)
    p.add_argument("--threshold", type=float, help="override shared checkpoint threshold (legacy default: 0.8)"); p.add_argument("--limit", type=int)
    p.add_argument("--planner-assessor", choices=("oracle", "permissive"), default="oracle",
                   help="verifier the PLANNER may use; the executor always uses the measured tables")
    args = p.parse_args(argv)
    rows = read_rows(args.data)
    if args.unsolved:
        rows += [r for r in read_rows(args.unsolved) if r["split"] == "test"]
    rows = rows[:args.limit] if args.limit else rows
    result = evaluate(rows, args.out, args.mode, parse_pairs(args.probe_summaries), parse_pairs(args.push_summaries) or None,
                      args.checkpoint, args.noemb_checkpoint, args.traversability_checkpoint, args.methods, args.seeds,
                      args.candidates, args.device, args.threshold, shared_checkpoint=args.shared_checkpoint,
                      planner_assessor=args.planner_assessor)
    print(json.dumps({k: {n: v[n]["mean"] for n in ("decision_correctness", "task_success")} for k, v in result["groups"].items()}, indent=2))


if __name__ == "__main__":
    main()
