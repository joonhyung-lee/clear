"""External pre-execution plan audit, independent of controller outcomes.

Capability is probe-relative: push probability < 0.5 or a geometrically available
route blocked by the frozen-controller traversal graph (threshold 0.8). Geometry
and unknown evidence remain distinct. Body-part validity cannot be learned-plan
accuracy here: body parts are assigned by the executor, not predicted by CLEAR.
"""
from copy import deepcopy
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, angle_delta
from experiments.exp3.trajectory_v3.navigation import clearance, transition_features
from experiments.exp3.trajectory_v3.navigation_cache import CachedTerrainNavigator
from experiments.exp3.trajectory_v3.oracle_capability import approach_point, robot_after
from experiments.exp3.trajectory_v3.scenes import path_collision


class GeometryOnlyPredictor:
    identity='geometry-only-plan-audit-v1'
    source='geometry_only_external_audit'
    def predict(self,features,embodiment):return np.ones(len(features))


class PlanAuditor:
    def __init__(self,oracle_navigator,assessor):
        self.oracle=oracle_navigator;self.assessor=assessor
        self.geometry=CachedTerrainNavigator(GeometryOnlyPredictor(),resolution=oracle_navigator.resolution,
            threshold=oracle_navigator.threshold,geometry_cache=oracle_navigator.geometry_cache)

    def check(self,scene,embodiment,plan,*,direct_route=None,abstained=False):
        if abstained:return dict(emitted=False,capability_violation=None,geometry_violation=None,unknown=False,reasons=['abstained'])
        if isinstance(plan,dict):plan=ObjectMotionPlan.from_dict(plan)
        work=deepcopy(scene);reasons=[];capability=False;geometry=False;unknown=False;complete=True
        body=self.assessor.structure_to_body.get(digest(embodiment.structure_rows))
        if body is None or body not in self.assessor.push_table.tables:unknown=True;reasons.append('missing_body_push_evidence')
        for path in plan.paths:
            if not any(o['object_id']==path.object_id for o in scene['objects']):continue
            if body is not None and self.assessor.push_probability(scene,embodiment,path.object_id)<.5:
                capability=True;reasons.append('push_probability_below_half')

        def route_check(target):
            nonlocal geometry,capability,unknown
            navigation=self.oracle.analyze(work,embodiment)
            if navigation.route_to(target) is not None:return True
            if self.geometry.analyze(work,embodiment).route_to(target) is None:
                geometry=True;reasons.append('no_geometric_route')
            elif navigation.unknown_edges:
                unknown=True;reasons.append('unknown_traversal_route')
            else:
                capability=True;reasons.append('geometric_route_blocked_by_controller_capability')
            return False

        if direct_route is not None:
            points=np.asarray(direct_route)[:,:2]
            if len(points)<2:route_check(work['goal'][:2])
            else:
                a,b=points[:-1],points[1:]
                gaps=np.array([clearance(work,np.linspace(x,y,5)).min() for x,y in zip(a,b)])
                if np.any(gaps<=embodiment.footprint_radius_m):
                    geometry=True;reasons.append('direct_route_geometry_collision');complete=False
                else:
                    features=transition_features(work,a,b,embodiment.footprint_radius_m,gaps)
                    p=self.oracle.predictor.predict(features,embodiment)
                    if not np.isfinite(p).all():unknown=True;reasons.append('unknown_direct_route_capability')
                    if np.any(p<self.oracle.threshold):capability=True;reasons.append('direct_route_capability_threshold')
        else:
            for path in plan.paths:
                obj=next((o for o in work['objects'] if o['object_id']==path.object_id),None)
                if obj is None:
                    geometry=True;reasons.append('unknown_object');complete=False;break
                if np.linalg.norm(np.asarray(path.start[:2])-obj['pose'][:2])>.08 or abs(angle_delta(path.start[2],obj['pose'][2]))>.12:
                    geometry=True;reasons.append('path_start_mismatch');complete=False;break
                if path_collision(work,path):
                    geometry=True;reasons.append('object_path_collision');complete=False;break
                approach=approach_point(path)
                if approach is None:
                    geometry=True;reasons.append('path_has_no_translation');complete=False;break
                if not route_check(approach):complete=False;break
                obj['pose']=list(path.goal)
                work['start']=[*robot_after(path,work['world_size'],embodiment.footprint_radius_m),0.]
            if complete:route_check(work['goal'][:2])
        return dict(emitted=True,capability_violation=True if capability else (None if unknown or not complete else False),
            geometry_violation=geometry,unknown=unknown,incomplete_due_to_prior_rejection=not complete,
            reasons=sorted(set(reasons)),capability_source='external frozen-controller probe graph and push tables',
            body_part_scope='executor-selected; not a learned output')
