"""One morphology parameter set for traversal, ordering, and whole-path flow.

The legacy two-checkpoint path remains in navigation_cli. The shared path is
shared_cli and uses this model, one checkpoint, and fresh navigation contexts.
"""
import hashlib
import math
from collections import OrderedDict
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.model import OBJECT_DIM, ObjectMotionModel
from experiments.exp3.trajectory_v3.navigation import EDGE_FIELDS, TRAVERSAL_QUERY_DIM, EmbodimentSpec, traversal_query
from experiments.exp3.trajectory_v3.navigation_cache import CachedTerrainNavigator
from experiments.exp3.trajectory_v3.navigation_planner import NeuralObjectProposer, NavigationInteractionPlanner
from experiments.exp3.trajectory_v3.traversability import pack_probes
from clear.model.clear import EmbodimentConditionedAffordanceHead, EncoderConditionedAffordanceHead

SHARED_SCHEMA = "clear-shared-morphology-v1"


class BodyAdapter(nn.Module):
    """Per-body FiLM + low-rank residual on the post-trunk tokens and FiLM on z_B; identity at init."""
    def __init__(self, structures, dim, rank):
        super().__init__()
        from experiments.exp3.trajectory_v3.robot_id_encoder import CanonicalStructureLookup
        if rank < 1:
            raise ValueError('positive adapter rank required')
        self.lookup = CanonicalStructureLookup(structures)
        n = len(structures)
        self.token_gamma = nn.Parameter(torch.ones(n, dim)); self.token_beta = nn.Parameter(torch.zeros(n, dim))
        self.down = nn.Parameter(torch.randn(n, dim, rank) / math.sqrt(dim)); self.up = nn.Parameter(torch.zeros(n, rank, dim))
        self.emb_gamma = nn.Parameter(torch.ones(n, dim)); self.emb_beta = nn.Parameter(torch.zeros(n, dim))

    def forward(self, h, structure, structure_mask):
        i = self.lookup.indices(structure, structure_mask)
        tokens = h["tokens"]
        tokens = tokens * self.token_gamma[i][:, None] + self.token_beta[i][:, None]
        tokens = tokens + torch.einsum('bnd,bdr->bnr', tokens, self.down[i]).matmul(self.up[i])
        embodiment = h["embodiment"] * self.emb_gamma[i][:, None] + self.emb_beta[i][:, None]
        n = h["objects"].shape[1]
        return dict(h, tokens=tokens, objects=tokens[:, 1:1 + n], scene_tokens=tokens[:, 1 + n:], embodiment=embodiment)


from clear.model.clear import SharedEncoder as _SharedEncoder


class BodyAdaptedSharedEncoder(_SharedEncoder):
    """A SharedEncoder whose existing submodules keep their names (so CLEAR state dicts load unchanged) plus `adapter`."""
    def __init__(self, base, structures, rank, dim):
        nn.Module.__init__(self)
        for name in ("object_in", "structure_in", "scene_in", "navigation_in", "trunk"):
            setattr(self, name, getattr(base, name))
        self.adapter = BodyAdapter(structures, dim, rank)

    def forward(self, batch, no_embodiment=False):
        h = _SharedEncoder.forward(self, batch, no_embodiment)
        return self.adapter(h, batch["structure"], batch["structure_mask"])


class TraversalAffordanceHead(EmbodimentConditionedAffordanceHead):
    """Consumes z_B; owns no structural-row encoder."""
    def __init__(self, embodiment_dim, dim=64):
        super().__init__(embodiment_dim, len(EDGE_FIELDS), dim)


class SharedMorphologyModel(ObjectMotionModel):
    def __init__(self, dim=128, depth=4, heads=4, waypoints=8, no_embodiment=False,
                 causal=True, navigation_features=4, traversal_dim=64, trajectory_objective="flow",
                 affordance_guidance=True, robot_id_structures=None, get_encoder=None, cdgs=None,
                 flow_noise_std=1.0, traversal_head="edge", traversal_objects=False, scene_dim=9,
                 traversal_radius=0., navigation_norm=False, body_adapters=None):
        if navigation_features != 4 or traversal_dim < 1:
            raise ValueError("shared morphology requires four navigation features and a positive head dimension")
        if traversal_head not in ("edge", "encoder"):
            raise ValueError("traversal head must be edge or encoder")
        super().__init__(dim, depth, heads, waypoints, no_embodiment, causal, navigation_features,
                         scene_dim, navigation_norm)
        if not math.isfinite(flow_noise_std) or flow_noise_std<=0:
            raise ValueError('positive finite flow prior standard deviation required')
        if flow_noise_std!=1.0:
            if cdgs is not None or trajectory_objective!='flow':
                raise ValueError('flow prior scaling requires the CVF objective')
            self.config['flow_noise_std']=float(flow_noise_std)
        self.flow.noise_std=float(flow_noise_std)
        self.traversal_head = traversal_head
        if not math.isfinite(traversal_radius) or traversal_radius < 0:
            raise ValueError("nonnegative finite traversal crop radius required")
        if traversal_radius and (traversal_head != "encoder" or scene_dim != 13):
            raise ValueError("metric traversal crops require the raw 13-D encoder")
        self.traversal_radius = traversal_radius
        if traversal_radius:
            self.config["traversal_radius"] = traversal_radius
        self.traversal_objects = traversal_objects
        if traversal_objects:
            if traversal_head != "encoder":
                raise ValueError("traversal objects require the encoder head")
            self.config["traversal_objects"] = True
        self.traversal_affordance = (
            EncoderConditionedAffordanceHead(dim, TRAVERSAL_QUERY_DIM, traversal_dim)
            if traversal_head == "encoder" else TraversalAffordanceHead(dim, traversal_dim))
        self.config["traversal_dim"] = traversal_dim
        # Absent from config for the default head, so every existing checkpoint identity,
        # config-equality check and state-dict key stays exactly what it was.
        if traversal_head != "edge":
            self.config["traversal_head"] = traversal_head
        self.affordance_guidance = bool(affordance_guidance)
        if not self.affordance_guidance:
            self.config['affordance_guidance'] = False
        if robot_id_structures is not None:
            if no_embodiment:
                raise ValueError('Robot-ID and NoEmb are separate comparisons')
            from experiments.exp3.trajectory_v3.robot_id_encoder import RobotIDEncoder
            self.encoder.structure_in = RobotIDEncoder(robot_id_structures, dim)
            self.config['robot_id_structures'] = robot_id_structures
        if get_encoder is not None:
            if no_embodiment or robot_id_structures is not None:
                raise ValueError('GET, Robot-ID, and NoEmb are separate comparisons')
            from experiments.exp3.trajectory_v3.get_encoder import GETMorphologyEncoder
            self.encoder.structure_in = GETMorphologyEncoder(get_encoder, dim, heads)
            self.config['get_encoder'] = get_encoder
        if trajectory_objective not in ("flow", "regression"):
            raise ValueError("trajectory objective must be flow or regression")
        self.trajectory_objective = trajectory_objective
        # Preserve legacy flow checkpoint identities/config equality.
        if trajectory_objective != "flow":
            self.config["trajectory_objective"] = trajectory_objective
        if body_adapters is not None:
            # CLEAR + per-body adapter: one shared trunk, a few thousand body-specific parameters selected by the
            # exact canonical-structure lookup (unknown body -> refusal, like Robot-ID). Identity at init.
            if no_embodiment or robot_id_structures is not None or get_encoder is not None or cdgs is not None:
                raise ValueError('body adapters apply to the shared CLEAR encoder only')
            self.encoder = BodyAdaptedSharedEncoder(self.encoder, body_adapters['structures'], int(body_adapters.get('rank', 16)), dim)
            self.config['body_adapters'] = body_adapters
        self.cdgs = None
        if cdgs is not None:
            if no_embodiment or not affordance_guidance or robot_id_structures is not None or get_encoder is not None or trajectory_objective != 'flow':
                raise ValueError('CDGS is a separate planner comparison with shared perception/traversal')
            from experiments.exp3.trajectory_v3.cdgs import ObjectTransitionCDGS
            self.cdgs=ObjectTransitionCDGS(cdgs,dim,waypoints)
            self.config['cdgs']=cdgs
            del self.ordering, self.flow

    def loss(self, batch, generator=None):
        if self.cdgs is not None:
            return self.cdgs.loss(batch,self.encoder(batch),generator)
        return super().loss(batch,generator)

    def flow_loss(self, h, batch, generator=None):
        if self.trajectory_objective == "flow":
            return super().flow_loss(h, batch, generator)
        target, rank, mask = batch["target_code"], batch["rank"], batch["object_mask"]
        selected = mask & (rank >= 0) & (rank < rank.shape[1])
        if not selected.any():
            return h["objects"].sum()*0 + self.flow.head[-1].weight.sum()*0
        prediction = self.flow(h["objects"], h["embodiment"], h["scene"],
            torch.zeros_like(target), torch.zeros(target.shape[0],device=target.device),
            rank, selected, key_mask=self.flow_key_mask(h,mask))
        # Retain the historical loss key 'flow' for checkpoint-selection plumbing;
        # config identifies this value as full-waypoint regression MSE.
        return F.mse_loss(prediction[selected],target[selected])

    @torch.no_grad()
    def sample(self, batch, steps=30, generator=None, max_interactions=3, sample_selection=False):
        if self.cdgs is not None:
            if max_interactions != 2:raise ValueError('CDGS adaptation fixes H <= 2')
            return self.cdgs.sample(batch,self.encoder(batch),steps,generator)
        if self.trajectory_objective == "flow":
            return super().sample(batch,steps,generator,max_interactions,sample_selection)
        if steps < 1 or (max_interactions is not None and max_interactions < 0):
            raise ValueError("positive inference steps and nonnegative interaction limit required")
        h = self._encode(batch); mask = batch["object_mask"]
        rank, selected = self.ordering.sample(h["selection"],h["mu"],h["sigma"],mask,
            generator,max_interactions,sample_selection)
        # Advance the unused flow-noise draw to retain the same ordering RNG
        # stream across subsequent planner calls. Noise never enters regression.
        shape=(*h["objects"].shape[:2],self.flow.target_dim)
        noise=torch.randn(shape,device=h["objects"].device,dtype=h["objects"].dtype,generator=generator)
        prediction=self.flow(h["objects"],h["embodiment"],h["scene"],torch.zeros_like(noise),
            torch.zeros(shape[0],device=noise.device),rank,selected,key_mask=self.flow_key_mask(h,mask))
        return dict(rank=rank,selected=selected,path_code=torch.where(selected[...,None],prediction,torch.zeros_like(prediction)),
                    selection_logits=h["selection"])

    @property
    def morphology_encoder(self):
        return self.encoder.structure_in

    def encode_morphology(self, structure, mask):
        embedding = self.morphology_encoder.pool(structure, mask)
        return torch.zeros_like(embedding) if self.no_embodiment else embedding

    def traversal_from_embedding(self, embedding, edge_features):
        if self.no_embodiment:
            edge_features = edge_features.clone()
            edge_features[..., EDGE_FIELDS.index("footprint_radius_m")] = 0
        return self.traversal_affordance(embedding, edge_features)

    def traversal_logits(self, features, structure, structure_mask):
        if self.traversal_head != "edge":
            raise ValueError("encoder traversal needs scene observations; use traversal_probe_logits "
                             "or traversal_from_scene")
        return self.traversal_from_embedding(self.encode_morphology(structure, structure_mask), features)

    # -- encoder-backed traversal head ---------------------------------------------

    def initialize_traversal(self, seed):
        """Initialize the encoder trunk + query head from ONE fixed RNG stream.

        Called only for a new encoder training run, never after loading a checkpoint. Each
        method draws its other parameters in a different order (Robot-ID swaps structure_in,
        CDGS deletes ordering/flow), so without this the shared new modules would start from
        different values per method and the comparison would confound initialization.
        """
        from clear.model.clear import SharedEncoder
        if self.traversal_head != "encoder":
            raise ValueError("encoder traversal initialization required")
        c = self.config
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(seed)
            encoder = SharedEncoder(c["dim"], OBJECT_DIM, c.get("scene_dim", 9), 20,
                                    depth=c["depth"], heads=c["heads"])
            head = EncoderConditionedAffordanceHead(c["dim"], TRAVERSAL_QUERY_DIM, c["traversal_dim"])
        state = encoder.state_dict()
        # Robot-ID / GET replace structure_in wholesale; leave their module alone.
        if type(self.encoder.structure_in) is not type(encoder.structure_in):
            state = {k: v for k, v in state.items() if not k.startswith("structure_in.")}
        missing, unexpected = self.encoder.load_state_dict(state, strict=False)
        assert not unexpected, unexpected
        assert all(m.startswith(("navigation_in.", "structure_in.", "adapter.")) for m in missing), missing
        self.traversal_affordance.load_state_dict(head.state_dict())

    def traversal_scene_tokens(self, scene_features, scene_mask, structure, structure_mask,
                               object_features=None, object_mask=None):
        """Run the SHARED encoder over scene rows once. -> (tokens, key_mask, z_B).

        Navigation features are zero here: deriving them from this head would make the
        navigation context depend on itself. Ordering/flow still receive fresh navigation.
        """
        if self.traversal_head != "encoder":
            raise RuntimeError("traversal_head='encoder' required for scene tokens")
        b = len(scene_features)
        batch = dict(scene_features=scene_features, scene_mask=scene_mask,
                     structure=structure, structure_mask=structure_mask,
                     object_features=scene_features.new_zeros(b, 1, OBJECT_DIM),
                     object_mask=torch.zeros(b, 1, dtype=torch.bool, device=scene_features.device))
        if self.traversal_objects and object_features is not None:
            if object_mask is None or object_features.shape[:2] != object_mask.shape:
                raise ValueError("one object mask per traversal object required")
            batch.update(object_features=object_features, object_mask=object_mask)
        if self.encoder.navigation_in is not None:
            batch["navigation_features"] = scene_features.new_zeros(
                b, batch["object_features"].shape[1], self.encoder.navigation_in.in_features)
        h = self.encoder(batch, self.no_embodiment)
        return h["tokens"], h["key_mask"], h["embodiment"][:, 0]

    def traversal_from_scene(self, scene_features, scene_mask, structure, structure_mask, query,
                             object_features=None, object_mask=None, world_size=None):
        if self.traversal_radius:
            if world_size is None:
                raise ValueError("metric scene crop requires world_size")
            from experiments.exp3.trajectory_v3.data import traversal_crop
            scene_features, scene_mask, object_features, object_mask, query = traversal_crop(
                scene_features, scene_mask, object_features, object_mask, query,
                world_size, self.traversal_radius)
        tokens, key_mask, embodiment = self.traversal_scene_tokens(
            scene_features, scene_mask, structure, structure_mask, object_features, object_mask)
        return self.traversal_from_tokens(tokens, key_mask, embodiment, query)

    def traversal_from_tokens(self, tokens, key_mask, embodiment, query):
        if self.no_embodiment:
            query = query.clone()
            query[:, 3] = 0  # footprint_radius_m column of POSE_FIELDS
        return self.traversal_affordance(tokens, key_mask, embodiment, query)

    def traversal_probe_logits(self, probes):
        if self.traversal_head == "encoder":
            for field in ("scene_features", "scene_mask", "query"):
                if field not in probes:
                    raise ValueError("traversal_head='encoder' needs probe rows carrying scene "
                                     "geometry; run attach_probe_scenes over them first")
            return self.traversal_from_scene(probes["scene_features"], probes["scene_mask"],
                                             probes["structure"], probes["structure_mask"],
                                             probes["query"], probes.get("object_features"),
                                             probes.get("object_mask"), probes.get("world_size"))
        return self.traversal_logits(probes["features"], probes["structure"], probes["structure_mask"])

    def traversal_loss(self, probes):
        return F.binary_cross_entropy_with_logits(self.traversal_probe_logits(probes), probes["target"])

    def joint_loss(self, batch, probes, generator=None, affordance_weight=1.0):
        if not math.isfinite(affordance_weight) or affordance_weight <= 0:
            raise ValueError("joint training requires a positive finite affordance weight")
        object_loss, terms = self.loss(batch, generator)
        affordance = self.traversal_loss(probes)
        return object_loss + affordance_weight * affordance, dict(terms, affordance=float(affordance.detach()))


PROBE_SCENES = Path("experiments/exp3/data/probe_scenes")   # recordings referenced by the probe rows


def attach_probe_scenes(rows, scene_dim=9):
    """Give every probe row the scene geometry and query the encoder head needs.

    A probe row does not carry a scene dict, so the scene is recovered from the SAME source
    that produced that row's own edge features, and can therefore never describe different
    ground:

      * a measured boundary/subsegment attempt keeps its `recording`, whose input.jsonl holds
        the scene the attempt ran in, and `execution_evidence.start/end`, the very segment
        transition_features was called on -- its midpoint is the query location;
      * a synthetic tile probe keeps its `condition`, and traversal_probes rebuilds the tile;
      * a row that already carries a scene dict is used directly.

    Rows already carrying the derived fields at this width are left alone. The scene_hash
    recorded on the row is re-checked against the recovered scene, so a moved or rewritten
    recording fails here instead of silently training on the wrong ground. Returns the rows,
    mutated in place.
    """
    import json
    from experiments.exp3.trajectory_v3.data import scene_features as scene_rows, object_features
    from experiments.exp3.trajectory_v3.navigation import scene_hash
    recovered, built = {}, {}

    def derive(row, scene, midpoint):
        row["scene_rows"] = np.asarray(scene_rows(scene, scene_dim), np.float32)
        row["object_rows"] = np.asarray(object_features(scene), np.float32).reshape(-1, OBJECT_DIM)
        row["traversal_query"] = traversal_query([row["edge_features"]], [midpoint],
                                                 scene["world_size"])[0]
        row["scene_world_size"] = list(scene["world_size"])

    for row in rows:
        if ("scene_rows" in row and "traversal_query" in row
                and np.asarray(row["scene_rows"]).shape[1] == scene_dim):
            continue
        if "scene" in row:
            scene = row["scene"]
            evidence = row.get("execution_evidence", {})
            if "start" in evidence and "end" in evidence:
                midpoint = (np.asarray(evidence["start"], float) + np.asarray(evidence["end"], float)) / 2
            else:
                midpoint = np.asarray(row["midpoint"], float)
            derive(row, scene, midpoint)
            continue
        evidence = row.get("execution_evidence", {})
        if "recording" in row and "start" in evidence and "end" in evidence:
            key = row["recording"]
            if key not in recovered:
                scene = json.loads((PROBE_SCENES / Path(key).name / "input.jsonl").read_text())["scene"]
                if scene_hash(scene) != row["scene_hash"]:
                    raise ValueError("probe recording no longer holds the scene the row was measured in")
                recovered[key] = scene
            scene = recovered[key]
            midpoint = (np.asarray(evidence["start"], float) + np.asarray(evidence["end"], float)) / 2
            derive(row, scene, midpoint)
            continue
        if "condition" not in row:
            raise ValueError("probe row carries neither a scene, a recorded attempt, nor a tile condition")
        from experiments.exp3.trajectory_v3.traversal_probes import Condition, TILE, condition_scene, transition_span
        key = row["layout_group_id"]
        if key not in built:
            c = Condition(**row["condition"])
            scene = condition_scene(c)
            x0, x1, _, _ = transition_span(c)
            centre = x0 if c.kind in ("step_up", "step_down", "flat") else x0 + (x1 - x0) / 2
            built[key] = (scene, np.array([centre, TILE[1] / 2], float))
        scene, midpoint = built[key]
        derive(row, scene, midpoint)
    return rows


def collate_probes(rows, device="cpu"):
    if not rows:
        raise ValueError("nonempty traversal supervision required")
    features, structure, mask = pack_probes(rows, device)
    target = torch.tensor([r["success"] and not r["collision"] and not r["fell"] for r in rows],
                          dtype=torch.float32, device=device)
    batch = dict(features=features, structure=structure, structure_mask=mask, target=target)
    if all("scene_rows" in r and "traversal_query" in r for r in rows):
        geometry = [np.asarray(r["scene_rows"], np.float32) for r in rows]
        width, longest = geometry[0].shape[1], max(len(g) for g in geometry)
        scene = torch.zeros(len(rows), longest, width, device=device)
        scene_mask = torch.zeros(len(rows), longest, dtype=torch.bool, device=device)
        for i, g in enumerate(geometry):
            scene[i, :len(g)] = torch.as_tensor(g, device=device)
            scene_mask[i, :len(g)] = True
        batch["scene_features"] = scene
        batch["scene_mask"] = scene_mask
        batch["query"] = torch.as_tensor(np.stack([np.asarray(r["traversal_query"], np.float32)
                                                   for r in rows]), device=device)
        if all("scene_world_size" in r for r in rows):
            batch["world_size"] = torch.tensor([r["scene_world_size"] for r in rows],
                                               dtype=torch.float32, device=device)
        objects = [np.asarray(r.get("object_rows", []), np.float32).reshape(-1, OBJECT_DIM) for r in rows]
        longest = max(1, max(map(len, objects)))
        batch["object_features"] = torch.zeros(len(rows), longest, OBJECT_DIM, device=device)
        batch["object_mask"] = torch.zeros(len(rows), longest, dtype=torch.bool, device=device)
        for i, obj in enumerate(objects):
            batch["object_features"][i, :len(obj)] = torch.as_tensor(obj, device=device)
            batch["object_mask"][i, :len(obj)] = True
    return batch


def embodiment_from_row(row):
    context = row.get("navigation_context", {})
    values = {}
    for key in ("footprint_radius_m", "controller_hash"):
        if key in row and key in context and row[key] != context[key]:
            raise ValueError("conflicting embodiment metadata: " + key)
        values[key] = row[key] if key in row else context[key]
    return EmbodimentSpec(row["structure_rows"], **values)


class SharedTraversalPredictor:
    """A read-only view of the SAME model, invalidated by any traversal-weight update."""
    source = "learned_prediction"
    validation_status = "development_only; probability calibration pending"

    def __init__(self, model, controller_profiles, additional_frozen_controllers=()):
        if not isinstance(model, SharedMorphologyModel):
            raise TypeError("SharedMorphologyModel required")
        self.model = model
        if not model.affordance_guidance:
            self.source = 'geometry_only_permissive'
        self.profiles = dict(controller_profiles)
        self.controllers = set(self.profiles.values()) | set(additional_frozen_controllers)
        for value in [*self.profiles, *self.controllers]:
            if len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise ValueError("structure/controller SHA256 required")
        self._versions = self._parameter_versions()
        fingerprint = hashlib.sha256()
        fingerprint.update(digest(dict(config=model.config, profiles=self.profiles,
                                       controllers=sorted(self.controllers), schema=SHARED_SCHEMA)).encode())
        for name, tensor in self._traversal_state():
            fingerprint.update(name.encode())
            fingerprint.update(str((tensor.shape, tensor.dtype)).encode())
            fingerprint.update(tensor.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
        self._identity = fingerprint.hexdigest()
        self._embeddings = {}
        self._scene_tokens = OrderedDict()

    @property
    def needs_scene(self):
        """TerrainNavigator.scene_context reads this to decide whether to hand over the scene."""
        return self.model.traversal_head == "encoder"

    def _traversal_state(self):
        # Everything a traversal probability actually depends on. The encoder head routes through
        # the scene adapter and the shared trunk as well, so leaving those out would let a
        # training step change the answer without assert_current firing.
        prefixes = ["encoder.structure_in.", "traversal_affordance.", "encoder.adapter."]
        if self.model.traversal_head == "encoder":
            prefixes += ["encoder.scene_in.", "encoder.trunk.", "encoder.object_in.",
                         "encoder.navigation_in."]
        return ((name, value) for name, value in self.model.named_parameters()
                if name.startswith(tuple(prefixes)))

    def _parameter_versions(self):
        return tuple((name, id(p), p._version) for name, p in self._traversal_state())

    def assert_current(self):
        if self._versions != self._parameter_versions():
            raise RuntimeError("shared morphology/affordance changed; rebuild predictor and navigation contexts")

    @property
    def identity(self):
        self.assert_current()
        return self._identity

    def _encode_scene(self, scene, embodiment, device, capacity=16):
        """One trunk pass per (scene, body), reused across every edge of that scene.

        A 0.1 m navigation graph over one room is tens of thousands of directed edges; encoding
        the scene per edge instead of per scene is the whole cost of this head.
        """
        from experiments.exp3.trajectory_v3.data import scene_features as scene_rows, object_features
        from experiments.exp3.trajectory_v3.navigation import scene_hash
        key = (scene_hash(scene), digest(embodiment.structure_rows))
        if key not in self._scene_tokens:
            geometry = torch.as_tensor(
                np.asarray(scene_rows(scene, self.model.config.get("scene_dim", 9)), np.float32),
                device=device)[None]
            mask = torch.ones(geometry.shape[:2], dtype=torch.bool, device=device)
            rows = torch.tensor(embodiment.structure_rows, dtype=torch.float32, device=device)[None]
            structure_mask = torch.ones(rows.shape[:2], dtype=torch.bool, device=device)
            objects = torch.as_tensor(
                np.asarray(object_features(scene), np.float32).reshape(-1, OBJECT_DIM),
                device=device)[None]
            object_mask = torch.ones(objects.shape[:2], dtype=torch.bool, device=device)
            self._scene_tokens[key] = self.model.traversal_scene_tokens(
                geometry, mask, rows, structure_mask, objects, object_mask)
            if len(self._scene_tokens) > capacity:
                self._scene_tokens.popitem(last=False)
        self._scene_tokens.move_to_end(key)
        return self._scene_tokens[key]

    @torch.no_grad()
    def predict(self, features, embodiment, scene=None, midpoints=None):
        self.assert_current()
        features = np.asarray(features, dtype=np.float32)
        if features.shape != (len(features), len(EDGE_FIELDS)) or not np.isfinite(features).all():
            raise ValueError("finite directed edge features required")
        known = self.profiles.get(digest(embodiment.structure_rows))
        if embodiment.controller_hash not in self.controllers or (known and known != embodiment.controller_hash):
            return np.full(len(features), np.nan)
        if not self.model.affordance_guidance:
            # The no-affordance ablation keeps the auxiliary traversal loss but routes C_nav
            # through the geometry-only rule, so it never reaches the learned head below.
            from experiments.exp3.trajectory_v3.plan_audit import GeometryOnlyPredictor
            return GeometryOnlyPredictor().predict(features, embodiment)
        device = next(self.model.parameters()).device
        if self.needs_scene:
            if scene is None or midpoints is None:
                raise ValueError("traversal_head='encoder' needs the scene and one midpoint per "
                                 "edge; TerrainNavigator.scene_context supplies both")
            query = traversal_query(features, midpoints, scene["world_size"])
            if self.model.traversal_radius:
                # Trained on a metric crop centred on the queried edge, so inference must crop
                # the same way. Each edge sees a different window, so the per-scene token cache
                # below does not apply and the trunk runs per chunk of edges.
                from experiments.exp3.trajectory_v3.data import collate
                batch = collate([dict(scene=scene, structure_rows=embodiment.structure_rows)],
                                device=device, include_targets=False,
                                scene_dim=self.model.config["scene_dim"])
                world = torch.as_tensor(scene["world_size"], dtype=torch.float32, device=device)[None]
                results = []
                # Same chunk width as the uncached path below. Chunking is batching only: at
                # 2048 the probabilities match the 256-wide result to 1.2e-7 and the whole
                # graph is scored ~6x faster, which is the difference between a feasible and
                # an infeasible joint-training budget.
                for start in range(0, len(query), 2048):
                    q = torch.as_tensor(query[start:start + 2048], device=device)
                    wide = {k: v.expand(len(q), *v.shape[1:]) for k, v in batch.items()}
                    logits = self.model.traversal_from_scene(
                        wide["scene_features"], wide["scene_mask"], wide["structure"],
                        wide["structure_mask"], q, wide["object_features"], wide["object_mask"],
                        world.expand(len(q), -1))
                    results.append(torch.sigmoid(logits).cpu().numpy())
                return np.concatenate(results) if results else np.empty(0)
            tokens, key_mask, embedding = self._encode_scene(scene, embodiment, device)
            results = []
            for start in range(0, len(features), 2048):
                rows = torch.as_tensor(query[start:start + 2048], device=device)
                logits = self.model.traversal_from_tokens(tokens.expand(len(rows), -1, -1),
                                                          key_mask.expand(len(rows), -1),
                                                          embedding.expand(len(rows), -1), rows)
                results.append(torch.sigmoid(logits).cpu().numpy())
            return np.concatenate(results) if results else np.empty(0)
        key = digest(embodiment.structure_rows)
        if key not in self._embeddings:
            rows = torch.tensor(embodiment.structure_rows, dtype=torch.float32, device=device)[None]
            mask = torch.ones(rows.shape[:2], dtype=torch.bool, device=device)
            self._embeddings[key] = self.model.encode_morphology(rows, mask)
        embedding = self._embeddings[key]
        results = []
        for start in range(0, len(features), 2048):
            chunk = torch.as_tensor(features[start:start + 2048], device=device)
            logits = self.model.traversal_from_embedding(embedding.expand(len(chunk), -1), chunk)
            results.append(torch.sigmoid(logits).cpu().numpy())
        return np.concatenate(results) if results else np.empty(0)


def refresh_navigation_rows(rows, navigator):
    """Discard cached feature values and recompute them with this parameter snapshot."""
    fresh = []
    for row in rows:
        embodiment = embodiment_from_row(row)
        analysis = navigator.analyze(row["scene"], embodiment)
        fresh.append(dict(row, navigation_context=analysis.model_context()))
    return fresh


class SharedObjectProposer(NeuralObjectProposer):
    def __init__(self, model, predictor, candidates=8, flow_steps=30, seed=0, max_interactions=None,
                 path_decode="raw"):
        if path_decode not in ("raw", "chord"):
            raise ValueError("path_decode must be raw or chord")
        self.path_decode = path_decode
        if predictor.model is not model:
            raise ValueError("traversal and object proposal must reference the same model instance")
        if candidates < 1 or flow_steps < 1 or (max_interactions is not None and max_interactions < 0):
            raise ValueError("positive sampling budgets and nonnegative interaction limit required")
        self.model, self.predictor = model, predictor
        self.candidates, self.flow_steps = candidates, flow_steps
        self.device = next(model.parameters()).device
        self.max_interactions = max_interactions
        self.generator = torch.Generator(device=self.device).manual_seed(seed)

    def __call__(self, scene, embodiment, context):
        if context.get("predictor_hash") != self.predictor.identity:
            raise ValueError("navigation context belongs to a different shared-model snapshot")
        yield from super().__call__(scene, embodiment, context)


def checkpoint_record(model, controller_profiles, navigation, **training_metadata):
    return dict(training_metadata, schema=SHARED_SCHEMA, architecture="shared_morphology",
                model_config=dict(model.config), state_dict=model.state_dict(),
                controller_profiles=dict(controller_profiles), navigation=dict(navigation),
                edge_fields=list(EDGE_FIELDS))


def load_shared_checkpoint(checkpoint, device="cpu"):
    value = torch.load(Path(checkpoint), map_location=device, weights_only=True)
    if value.get("schema") != SHARED_SCHEMA or value.get("architecture") != "shared_morphology":
        raise ValueError("shared-morphology checkpoint required; legacy checkpoints are not automatically merged")
    if value.get("edge_fields") != list(EDGE_FIELDS):
        raise ValueError("directed edge schema mismatch")
    model = SharedMorphologyModel(**value["model_config"]).to(device)
    model.load_state_dict(value["state_dict"], strict=True)
    model.eval()
    return model, value


def load_shared_planner(checkpoint, device="cpu", candidates=8, flow_steps=30, seed=0,
                        max_interactions=None, assessor=None, additional_frozen_controllers=()):
    model, value = load_shared_checkpoint(checkpoint, device)
    predictor = SharedTraversalPredictor(model, value["controller_profiles"], additional_frozen_controllers)
    navigator = CachedTerrainNavigator(predictor, **value["navigation"])
    proposer = SharedObjectProposer(model, predictor, candidates, flow_steps, seed, max_interactions)
    return NavigationInteractionPlanner(navigator, proposer, assessor, candidates)
