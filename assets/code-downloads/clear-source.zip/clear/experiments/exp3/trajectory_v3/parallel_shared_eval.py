"""Shard independent shared-planner episodes while preserving per-episode random seeds."""
import concurrent.futures
import json
import multiprocessing
from pathlib import Path
import shutil

from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.exp3_protocol import empty_output


def _run_shard(payload):
    import torch
    from experiments.exp3.trajectory_v3.evaluate_shared import evaluate
    torch.set_num_threads(1)
    return evaluate(**payload)


def evaluate_parallel(rows, checkpoint, out, probe_summaries, push_summaries, rollout_seeds=(0, 1, 2),
                      candidates=8, flow_steps=30, device="cpu", include_oracle=False, provenance=None,
                      probe_rows=None, mode="exp3", policy="frozen", perturbation="nominal", workers=8):
    from experiments.exp3.trajectory_v3.evaluate_shared import summarize
    if workers < 1 or not rows:
        raise ValueError("positive workers and nonempty evaluation rows required")
    out = empty_output(out)
    count = min(workers, len(rows))
    payloads = [dict(rows=rows[i::count], checkpoint=checkpoint, out=out / "shards" / f"{i:03d}",
                     probe_summaries=probe_summaries, push_summaries=push_summaries,
                     rollout_seeds=rollout_seeds, candidates=candidates, flow_steps=flow_steps, device=device,
                     include_oracle=include_oracle, provenance=provenance, probe_rows=probe_rows if i == 0 else None,
                     mode=mode, policy=policy, perturbation=perturbation) for i in range(count)]
    reports = [None] * count
    with concurrent.futures.ProcessPoolExecutor(max_workers=count, mp_context=multiprocessing.get_context("spawn")) as pool:
        futures = {pool.submit(_run_shard, payload): i for i, payload in enumerate(payloads)}
        for future in concurrent.futures.as_completed(futures):
            index = futures[future]
            reports[index] = future.result()
            print(json.dumps(dict(shard=index, completed_shards=sum(r is not None for r in reports), total_shards=count)), flush=True)
    config = dict(reports[0]["config"])
    invariant = {k: v for k, v in config.items() if k not in ("rows", "data_hash")}
    if any({k: v for k, v in r["config"].items() if k not in ("rows", "data_hash")} != invariant for r in reports):
        raise ValueError("evaluation shards used different checkpoints or protocols")
    config.update(rows=len(rows), data_hash=digest(rows), execution_workers=count)
    episodes = []
    for payload in payloads:
        episodes.extend(json.loads(s) for s in (payload["out"] / "episodes.jsonl").read_text().splitlines() if s.strip())
    episodes.sort(key=lambda e: (e["method"], e["rollout_seed"], e["scene_id"], e["body_id"]))
    expected = len(rows) * len(rollout_seeds) * (2 if include_oracle else 1)
    if len(episodes) != expected:
        raise ValueError("incomplete episode shards")
    (out / "episodes.jsonl").write_text("".join(json.dumps(e) + "\n" for e in episodes))
    (out / "evaluation.json").write_text(json.dumps(config, indent=2) + "\n")
    for name in ("probe_metrics.json", "probe_predictions.jsonl"):
        source = payloads[0]["out"] / name
        if source.exists():
            shutil.copyfile(source, out / name)
    result = dict(config=config, groups=summarize(episodes), status="evaluation_completed")
    (out / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    return result
