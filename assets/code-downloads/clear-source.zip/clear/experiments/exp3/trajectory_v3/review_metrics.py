"""Explicit denominators for the revised Exp3/4 evaluation contract.

Missing physical evidence or complete reference-class annotations produces an
unavailable metric, never a fabricated zero or a proxy physical claim.
"""
from collections import defaultdict
import numpy as np


def rate(values, *, missing=0, reason=None):
    values=list(values)
    return dict(numerator=sum(bool(x) for x in values),denominator=len(values),
                mean=float(np.mean(values)) if values else None,missing=missing,reason=reason)


def reference_count(row):
    return row.get('k_ref',row.get('k_star'))


def plan_class(plan,route_class=None):
    # Execution-selected body parts are not predicted plan classes.
    return (tuple(p['object_id'] for p in plan.get('paths',[])),route_class)


def allowed_classes(row):
    if row.get('reference_plan_classes_complete') is not True:
        return None
    values=row.get('allowed_minimum_plan_classes')
    if values is None:return None
    return {(tuple(v['ordered_object_ids']),v.get('route_class')) for v in values}


def plan_switch_accuracy(rows):
    paired=defaultdict(list)
    for row in rows:
        paired[(row['scene_id'],row.get('rollout_seed',row.get('seed')),row.get('training_seed'))].append(row)
    values=[];missing=0;overlapping=0;unpaired=0
    for pair in paired.values():
        if len(pair)!=2 or len({r['body_id'] for r in pair})!=2:
            unpaired+=1;continue
        sets=[allowed_classes(r) for r in pair]
        if any(s is None or not s for s in sets):missing+=1;continue
        if sets[0]&sets[1]:overlapping+=1;continue
        classes=[plan_class(r['plan'],r.get('predicted_route_class')) for r in pair]
        correct=[]
        for r,c,allowed in zip(pair,classes,sets):
            count=reference_count(r)
            valid=r.get('plan_valid') is True or (count==0 and r.get('direct_route_valid') is True)
            correct.append(valid and count is not None and len(c[0])==count and c in allowed)
        values.append(all(correct) and classes[0]!=classes[1])
    return dict(rate(values,missing=missing,reason='complete disjoint allowed minimum plan classes required'),
                overlapping_reference_pairs=overlapping,unpaired_groups=unpaired)


def planner_refusal(row):
    """A documented no-action planning failure, never a simulated success."""
    return (row.get('backend')=='planner_refusal' and row.get('status')=='no_valid_plan_found'
        and row.get('task_success') is False and row.get('attempted_interactions')==0
        and row.get('plan',{}).get('paths')==[]
        and any(t.get('event')=='no_valid_plan_found' for t in row.get('decision_trace',[]))
        and all(isinstance(row.get(k),str) and len(row[k])==64
                and all(c in '0123456789abcdef' for c in row[k])
                for k in ('checkpoint_sha256','controller_hash')))


def strict_physical_success(row,displacement_limit=.2):
    if planner_refusal(row):return False
    if row.get('backend')!='dynamic_simulation':return None
    initial,final=row.get('initial_object_poses'),row.get('final_object_poses')
    attempts=row.get('interaction_attempts')
    if initial is None or final is None or attempts is None:return None
    attempted={str(a['object_id']) for a in attempts}
    initial={str(k):v for k,v in initial.items()};final={str(k):v for k,v in final.items()}
    if initial.keys()!=final.keys():return None
    collateral=all(np.linalg.norm(np.asarray(v[:2])-final[k][:2])<=displacement_limit
                   for k,v in initial.items() if k not in attempted)
    return bool(row['task_success'] and collateral)


def paired_reference_budget_success(rows,expected_pairs=None,expected_bodies=None):
    """Both strict physical successes, each using at most its own reference count.

    Missing rows/evidence leave the full-denominator estimate unavailable.
    A reference count is an independently established budget, not global optimality.
    """
    pairs=defaultdict(list)
    for row in rows:
        key=(row.get('method'),row['scene_id'],row.get('training_seed'),
             row.get('rollout_seed',row.get('seed')),row.get('perturbation'))
        pairs[key].append(row)
    denominator=len(pairs) if expected_pairs is None else expected_pairs
    if isinstance(denominator,bool) or not isinstance(denominator,int) or denominator<len(pairs):
        raise ValueError('expected pair count must cover every observed pair group')
    values=[];strict_values=[];reference_known=0;physical_known=0;outcome_known=0
    for pair in pairs.values():
        bodies={r['body_id'] for r in pair}
        if len(pair)!=2 or len(bodies)!=2 or (expected_bodies is not None and bodies!=set(expected_bodies)):
            continue
        counts=[reference_count(r) for r in pair]
        attempts=[r.get('attempted_interactions') for r in pair]
        for value in counts+attempts:
            if value is not None and (isinstance(value,bool) or not isinstance(value,(int,np.integer)) or value<0):
                raise ValueError('reference and attempted macro counts must be nonnegative integers')
        strict=[strict_physical_success(r) for r in pair]
        reference_known+=all(v is not None for v in counts)
        outcome_known+=all(v is not None for v in strict)
        physical_known+=all(v is not None and r.get('backend')=='dynamic_simulation' for r,v in zip(pair,strict))
        if all(v is not None for v in strict):strict_values.append(all(strict))
        if any(v is None for v in counts+attempts+strict):continue
        values.append(all(strict) and all(n<=k for n,k in zip(attempts,counts)))
    missing=denominator-len(values)
    return dict(numerator=sum(values),denominator=denominator,
        mean=sum(values)/denominator if denominator and not missing else None,
        missing=missing,evaluated_pairs=len(values),reference_known_pairs=reference_known,
        physical_evidence_pairs=physical_known,strict_outcome_known_pairs=outcome_known,complete=not missing,
        paired_strict_success=dict(numerator=sum(strict_values),denominator=denominator,
            mean=sum(strict_values)/denominator if denominator and len(strict_values)==denominator else None,
            missing=denominator-len(strict_values)),
        reason='both strict physical successes within independently verified per-body reference budgets')


def raw_capability_summary(rows):
    """Aggregate external raw-proposal audits; execution/contact never supplies CIR.

    The independent audit producer must establish condition support and split
    separation. This reducer checks identity and evidence-file integrity; it does
    not turn development probes or a straight-push label into a trajectory audit.
    """
    from experiments.exp3.trajectory_v3.calibration import digest
    from experiments.exp3.trajectory_v3.training_state import file_hash
    values=[];total=0;missing_logs=0;available=[];refusals=[];layouts=set();event_labels=defaultdict(list)
    for row in rows:
        proposals=row.get('raw_proposals')
        if proposals is None:missing_logs+=1;continue
        if not isinstance(proposals,list):raise ValueError('raw proposal list required')
        available.append(bool(proposals));refusals.append(planner_refusal(row))
        layouts.add(row.get('layout_group_id',row.get('scene_id')))
        audits=row.get('raw_proposal_audits',[None]*len(proposals))
        if len(audits)!=len(proposals):raise ValueError('one audit slot per actual raw proposal required')
        for proposal,audit in zip(proposals,audits):
            total+=1
            if audit is None:continue
            expected=dict(proposal_sha256=digest(proposal),body_id=row['body_id'],
                          controller_hash=row['controller_hash'],scene_id=row['scene_id'])
            if any(audit.get(k)!=v for k,v in expected.items()):
                raise ValueError('raw capability audit identity mismatch')
            if audit.get('split')!='held_out_audit':
                raise ValueError('training/development evidence cannot supply primary CIR')
            evidence=audit.get('evidence_files',{})
            if not evidence or any(file_hash(path)!=sha for path,sha in evidence.items()):
                raise ValueError('independent audit evidence files missing or changed')
            events=audit.get('events',[])
            labels=[event.get('capability_violation') for event in events]
            if proposal.get('schema')=='clear-invalid-raw-proposal-v1' and any(v is not None for v in labels):
                raise ValueError('invalid generated path has unknown physical capability')
            if any(v is not None and type(v) is not bool for v in labels):
                raise ValueError('event capability labels must be boolean or unknown')
            for event,label in zip(events,labels):
                if event.get('kind') not in ('traversal','manipulation'):
                    raise ValueError('audit event kind must identify traversal or manipulation')
                event_labels[event['kind']].append(label)
            if any(v is True for v in labels):values.append(True)
            elif labels and all(v is False for v in labels) and audit.get('required_events_complete') is True:
                values.append(False)
    known=len(values)
    return dict(cir=rate(values,missing=total-known,
            reason='incompatible / (incompatible + compatible); independent raw-proposal audit'),
        coverage=dict(numerator=known,denominator=total,mean=known/total if total and not missing_logs else None),
        by_event_type={kind:rate((v for v in labels if v is not None),missing=sum(v is None for v in labels))
                       for kind,labels in event_labels.items()},
        unknown_proposals=total-known,missing_raw_logs=missing_logs,
        proposal_availability=rate(available,missing=missing_logs),
        no_plan_rate=rate(refusals,missing=missing_logs),layout_groups=len(layouts),
        scope='initial object-planning trigger; direct navigation excluded; candidates are clustered within trials')


def contact_summary(rows):
    attempts=[];missing=0;selected=0
    for row in rows:
        evidence=row.get('contact_attempts')
        selected+=row.get('selected_interactions',row.get('attempted_interactions',0))
        if planner_refusal(row):continue
        if row.get('backend')!='dynamic_simulation' or evidence is None:
            missing+=1;continue
        for attempt in evidence:
            if attempt is None:missing+=1
            elif attempt['attempted']:
                if type(attempt.get('success')) is not bool:missing+=1
                else:attempts.append(attempt)
    contact=rate((a['success'] for a in attempts),missing=missing,
                 reason='native intended contact, progress and audited stability; no-command outcomes excluded')
    if missing:contact['observed_mean']=contact['mean'];contact['mean']=None
    if len(attempts)>selected:raise ValueError('contact attempts exceed selected interactions')
    return dict(contact_success=contact,
        contact_attempt_coverage=dict(numerator=len(attempts),denominator=selected,missing=missing,
            mean=len(attempts)/selected if selected and not missing else None),
        native_execution_coverage=rate(r.get('backend')=='dynamic_simulation' for r in rows))


def summarize_review(rows,bins=('1','2','3','4+')):
    rows=list(rows)
    known=[r for r in rows if reference_count(r) is not None]
    strict=[strict_physical_success(r) for r in rows]
    strict_known=[v for v in strict if v is not None]
    strict_rate=rate(strict_known,missing=len(rows)-len(strict_known),reason='measured final displacement of never-attempted objects')
    strict_rate['observed_denominator']=len(strict_known);strict_rate['denominator']=len(rows)
    if len(strict_known)!=len(rows):strict_rate['observed_mean']=strict_rate['mean'];strict_rate['mean']=None
    groups={}
    for label in bins:
        selected=[r for r in known if (reference_count(r)>=4 if label=='4+' else reference_count(r)==int(label))]
        groups[label]=rate(r['task_success'] for r in selected)
    means=[g['mean'] for g in groups.values()]
    eligible=[];missing_events=0
    for r in rows:
        if 'independent_event_assessments' not in r:
            missing_events+=bool(r.get('perturbation_configured'));continue
        if any(e.get('invalidated_remaining_plan') is True for e in r['independent_event_assessments']):
            eligible.append(r['task_success'])
    extra={}
    for label,success in (('successful_tasks',True),('failed_tasks',False)):
        values=[r['attempted_interactions']-reference_count(r) for r in known if bool(r['task_success'])==success]
        extra[label]=dict(denominator=len(values),mean=float(np.mean(values)) if values else None)
    paired=paired_reference_budget_success(rows);paired_strict=paired.pop('paired_strict_success')
    return dict(schema='clear-exp3-exp4-review-v2',episodes=len(rows),
        task_success=rate(r['task_success'] for r in rows),
        reference_count_success=rate((r['task_success'] and r['attempted_interactions']==reference_count(r) for r in known),
                                     missing=len(rows)-len(known),reason='reference-known denominator; no global optimality claim'),
        strict_physical_success=strict_rate,
        plan_switch_accuracy=plan_switch_accuracy(rows),
        paired_reference_budget_success=paired,paired_strict_success=paired_strict,
        success_by_initial_reference_count=groups,
        initial_reference_count_macro=dict(bins=list(bins),mean=float(np.mean(means)) if all(v is not None for v in means) else None,
                                           reason='equal weight per declared bin; undefined when any bin is missing'),
        independently_invalidated_episode_recovery=rate(eligible,missing=missing_events,
            reason='external oracle checker before/after event, independent of planner detection; proxy if backend is proxy'),
        extra_attempts=extra,
        raw_capability=raw_capability_summary(rows),
        **contact_summary(rows))
