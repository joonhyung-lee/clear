"""Official GET graph attention adapted to static G1/Spot joint morphology tokens.

This is an encoder comparison, not GET-Zero's hand-control or zero-shot protocol.
The internal index selects measured graph metadata; there is no learned body-ID token.
"""
import sys
from pathlib import Path
from types import SimpleNamespace

import torch
from torch import nn
from torch.nn import functional as F

from experiments.exp3.trajectory_v3.robot_id_encoder import CanonicalStructureLookup
from experiments.exp3.trajectory_v3.training_state import file_hash


class GETMorphologyEncoder(CanonicalStructureLookup):
    def __init__(self, config, dim, heads):
        graphs = config['graphs']
        super().__init__([g['structure_rows'] for g in graphs])
        from clear.paths import ROOT
        source = ROOT/'third_party/get_zero'
        if not {'get_zero/distill/models/embodiment_attention.py','get_zero/distill/utils/embodiment_util.py',
                'get_zero/distill/utils/generic.py'} <= set(config['source_files']):
            raise ValueError('official GET attention and graph utility source hashes required')
        for name, sha in config['source_files'].items():
            if file_hash(source/name) != sha:
                raise ValueError('official GET source changed: '+name)
        for path in (str(source),):
            if path not in sys.path:sys.path.insert(0, path)
        from get_zero.distill.models import embodiment_attention as official
        if Path(official.__file__).resolve() != source/'get_zero/distill/models/embodiment_attention.py':
            raise ValueError('GET imported from a different source checkout')
        properties = []; row_indices = []; counts = []
        for graph in graphs:
            parents = graph['joint_parents']; indices = graph['joint_row_indices']; n = len(parents)
            if not n or len(indices) != n or len(set(indices)) != n or any(
                    type(p) is not int or not -1 <= p < i for i,p in enumerate(parents)):
                raise ValueError('ordered acyclic joint graph required')
            if any(type(i) is not int or not 0 <= i < len(graph['structure_rows']) for i in indices):
                raise ValueError('joint feature row is outside the structure')
            adjacency = torch.zeros(n,n,dtype=torch.long); ancestors = torch.zeros_like(adjacency)
            for i,p in enumerate(parents):
                if p >= 0:adjacency[i,p]=adjacency[p,i]=1
                distance=1
                while p >= 0:
                    ancestors[i,p]=distance; distance+=1; p=parents[p]
            properties.append(SimpleNamespace(dof_count=n,adjacency_matrix=adjacency,
                compute_parent_and_child_matrix=lambda a=ancestors:(a,a.T)))
            row_indices.append(torch.tensor(indices)); counts.append(n)
        length=max(counts)
        self.register_buffer('joint_rows',torch.stack([F.pad(i,(0,length-len(i))) for i in row_indices]))
        self.register_buffer('joint_mask',torch.arange(length)[None]<torch.tensor(counts)[:,None])
        self.input = nn.Sequential(nn.Linear(20,dim),nn.GELU(),nn.Linear(dim,dim),nn.LayerNorm(dim))
        attention=dict(embedding_init=dict(type='normal',sigma=.02),bias_before_softmax=True,
            enable_spatial_encoding=True,enable_parent_encoding=True,enable_child_encoding=True,
            enable_edge_encoding=False,edge_encoding_size=8,edge_name_to_id={},longest_edge_path=length-1)
        self.layers=nn.ModuleList([official.SpatialEncodingTransformerEncoderLayer(properties,length,
            attention,dim,heads,dim_feedforward=2*dim,dropout=0.,batch_first=True)
            for _ in range(config['depth'])])
        if not self.layers:raise ValueError('positive GET encoder depth required')

    def pool(self, structure, structure_mask):
        ids=self.indices(structure,structure_mask); indices=self.joint_rows[ids];mask=self.joint_mask[ids]
        features=torch.gather(structure,1,indices[...,None].expand(-1,-1,structure.shape[-1]))
        tokens=self.input(features)
        for layer in self.layers:tokens=layer(ids,tokens,src_key_padding_mask=~mask)
        return (tokens*mask[...,None]).sum(1)/mask.sum(1,keepdim=True)
