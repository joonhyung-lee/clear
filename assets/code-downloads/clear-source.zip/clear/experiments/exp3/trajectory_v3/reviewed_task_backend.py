"""Read-only event assessment on the common proxy executor, independent of detection."""
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan
from experiments.exp3.trajectory_v3.navigation import scene_hash
from experiments.exp3.trajectory_v3.navigation_planner import validate_sequence
from experiments.exp3.trajectory_v3.task_backend import SimulatedTaskBackend


class ReviewedTaskBackend(SimulatedTaskBackend):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.evaluation_remaining=[]
        self.independent_event_assessments=[]
        self.interaction_attempts=[]

    def note_decision(self,decision):
        self.evaluation_remaining=list(decision.plan.paths)

    def interact_trajectory(self,path):
        result=super().interact_trajectory(path)
        self.interaction_attempts.append(dict(object_id=path.object_id,success=result['success'],time_s=self.t,
            failure_reason=result.get('info',{}).get('reason'),backend='kinematic_proxy'))
        if result['success'] and self.evaluation_remaining and self.evaluation_remaining[0].object_id==path.object_id:
            self.evaluation_remaining.pop(0)
        return result

    def apply_perturbation(self):
        plan=ObjectMotionPlan(tuple(self.evaluation_remaining))
        _,before=validate_sequence(self.scene,self.embodiment,plan,self.navigator,self.assessor)
        before_hash=scene_hash(self.scene)
        super().apply_perturbation()
        _,after=validate_sequence(self.scene,self.embodiment,plan,self.navigator,self.assessor)
        self.independent_event_assessments.append(dict(kind=self.perturbation['kind'],time_s=self.t,
            evaluator='independent_probe_oracle_sequence_validation',backend='kinematic_proxy',
            scene_before=before_hash,scene_after=scene_hash(self.scene),
            remaining_order=[p.object_id for p in plan.paths],valid_before=before is None,valid_after=after is None,
            invalidated_remaining_plan=before is None and after is not None,
            before_rejection=before,after_rejection=after,realized=self.events[-1]['realized']))
