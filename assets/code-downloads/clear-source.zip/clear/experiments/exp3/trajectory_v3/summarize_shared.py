"""Keep training-seed variation separate from rollout sampling variation."""
import argparse
import json
from pathlib import Path

import numpy as np

from experiments.exp3.trajectory_v3.exp3_protocol import empty_output


def summarize_runs(paths):
    reports = [json.loads(Path(p).read_text()) for p in paths]
    if not reports:
        raise ValueError("at least one completed evaluation required")
    keys = ("architecture", "rollout_seeds", "candidates", "flow_steps", "navigation", "rows", "model_config",
            "policy", "perturbation", "max_interactions", "max_time_s", "projection", "backend",
            "oracle_predictor", "push_source", "data_hash", "provenance")
    reference = {k: reports[0]["config"][k] for k in keys}
    seeds = [r["config"]["training_seed"] for r in reports]
    if None in seeds or len(set(seeds)) != len(seeds):
        raise ValueError("one evaluation per distinct training seed required")
    if any(r.get("status") != "evaluation_completed" or {k: r["config"][k] for k in keys} != reference for r in reports):
        raise ValueError("completed evaluations with identical datasets, protocol, and model config required")
    table = {}
    subsets = ["all", "reference_solved", "navigation_only", "interaction_required", "reference_unresolved"]
    if all("multi_interaction" in r["groups"]["clear_shared"] for r in reports):
        subsets.append("multi_interaction")
    for group in subsets:
        table[group] = {}
        for metric in ("task_success", "minimum_interaction_success"):
            values = [r["groups"]["clear_shared"][group][metric]["mean"] for r in reports]
            finite = [v for v in values if v is not None]
            table[group][metric] = dict(per_training_seed=dict(zip(map(str, seeds), values)),
                                       mean=float(np.mean(finite)) if finite else None,
                                       sd=float(np.std(finite, ddof=1)) if len(finite) > 1 else None,
                                       worst=float(min(finite)) if finite else None)
    bodies = sorted(reports[0]["groups"]["clear_shared"]["by_body"])
    for body in bodies:
        values = [r["groups"]["clear_shared"]["by_body"][body]["task_success"]["mean"] for r in reports]
        finite = [v for v in values if v is not None]
        table["body:" + body] = dict(task_success=dict(per_training_seed=dict(zip(map(str, seeds), values)),
            mean=float(np.mean(finite)) if finite else None,
            sd=float(np.std(finite, ddof=1)) if len(finite) > 1 else None,
            worst=float(min(finite)) if finite else None))
    return dict(training_seeds=seeds, rollout_seeds=reference["rollout_seeds"], protocol=reference,
                metrics=table, note="SD is across independently trained models; within-run CIs resample layout groups."
                " This report alone does not establish physical success or stability.")


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--metrics", nargs="+", required=True)
    p.add_argument("--out", required=True)
    args = p.parse_args(argv)
    report = summarize_runs(args.metrics)
    out = empty_output(args.out)
    (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    lines = ["# Shared CLEAR experiment 3", "", report["note"], "",
             "| Evaluation subset | Success mean | Training-seed SD | Worst training seed |", "|---|---:|---:|---:|"]
    for group, values in report["metrics"].items():
        m = values["task_success"]
        cells = ["N/A" if m[k] is None else f"{m[k]:.4f}" for k in ("mean", "sd", "worst")]
        lines.append("| " + " | ".join([group, *cells]) + " |")
    (out / "SUMMARY.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(report["metrics"], indent=2))


if __name__ == "__main__":
    main()
