"""Body-paired exp3/exp4 data with a teacher from exhaustive search over development-guide paths.

Teacher = oracle navigator (ProbeTablePredictor) + OracleAssessor; the learned model never sees
them. Rows are written WITHOUT navigation_context; `annotate` fills it from the frozen learned
traversability checkpoint. Unsolved (scene, body) pairs go to unsolved.jsonl, never into training.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, ObjectPath
from experiments.exp3.trajectory_v3.data import validate_dataset
from experiments.exp3.trajectory_v3.navigation import EmbodimentSpec, TerrainNavigator, scene_hash
from experiments.exp3.trajectory_v3.navigation_planner import validate_sequence
from experiments.exp3.trajectory_v3.navigation_scenes import make_navigation_scene
from experiments.exp3.trajectory_v3.oracle_capability import OracleAssessor, ProbeTablePredictor, PushTable
from experiments.exp3.trajectory_v3.scenes import path_collision
from experiments.exp3.trajectory_v3.task_backend import SimulatedTaskBackend

ROOT = Path(__file__).resolve().parents[3]
from clear.paths import ASSET

PROBES = ASSET / "experiments" / "exp3" / "probes"
CONTROLLERS = {"spot": ROOT/"asset/pretrained/spot/locomotion/spot_stance_model_13200.pt",
               "g1": ROOT/"asset/pretrained/g1/locomotion/g1_blind_stairs_ARCLIP2_model_22800.pt"}
TERRAINS, CONTROLS, HORIZONS = ("stairs", "slope", "cross", "flat"), ("interaction_required", "direct", "blocked"), (2, 3, 4)
BOX = [.9, .8, .6]
BEAM = 16   # teacher search beam width (64 made mid-episode generation ~3x slower than the budget allowed)
# ranges centred on the windows where the measured spot/g1 tables disagree (2026-09-09 smoke run):
# stairs rise .05-.28 (g1 fails >=.195, spot >.25), slope grade .1-.7, cross grade .05-.35 (spot fails >=.25,
# g1 always), heavy mass 2-9 kg (measured push: spot <=4, g1 <=6).


def bodies(ids=("spot", "g1")):
    from clear.maze.robots import configure
    from clear.maze.robots import get
    from clear.maze.robots import structure_for
    configure()
    out = {}
    for body in ids:
        rows = [[float(v) for v in r] for r in structure_for(body).rows]
        controller = hashlib.sha256(CONTROLLERS[body].read_bytes()).hexdigest()
        out[body] = EmbodimentSpec(rows, get(body).loco.width_m/2, controller)
    return out


def oracle(summary_paths=None, push_paths=None, probes=None):
    """probes: directory of traversal probe summaries to use instead of PROBES; push tables always
    come from PROBES (the manipulation probes are unaffected by the traversal tracking mode)."""
    traversal = Path(probes) if probes else PROBES
    summary_paths = summary_paths or {b: traversal/b/"summary.json" for b in ("spot", "g1")}
    predictor = ProbeTablePredictor(summary_paths)
    if push_paths is None and all((PROBES/f"push_{b}"/"summary.json").exists() for b in summary_paths):
        push_paths = {b: PROBES/f"push_{b}"/"summary.json" for b in summary_paths}
    push = PushTable.from_summaries(push_paths) if push_paths else PushTable.from_registry(tuple(summary_paths))
    return TerrainNavigator(predictor), OracleAssessor(push, predictor.bodies)


# ------------------------------------------------------------------ scenes
def make_family_scene(seed, terrain, control, rng, heavy_mass=(2., 9.)):
    if terrain not in TERRAINS or control not in CONTROLS:
        raise ValueError("unknown family cell")
    scene = make_navigation_scene(seed, {"stairs": "stairs", "cross": "stairs", "slope": "slope", "flat": "flat"}[terrain], control)
    mu = float(rng.uniform(.3, .8)); parameter = 0.
    if terrain == "stairs":
        parameter = float(rng.uniform(.05, .28))
        for k, tile in enumerate(scene["terrain"]):
            tile["height_m"] = parameter*[1, 2, 1][k]; tile["friction"] = mu
    elif terrain == "slope":
        parameter = float(rng.uniform(.10, .70))
        for tile in scene["terrain"]:
            l, b, r, t = tile["bounds"]; rise = parameter*(t-b)
            up = tile["start_height_m"] < tile["end_height_m"]
            tile.update(start_height_m=0. if up else rise, end_height_m=rise if up else 0., friction=mu)
    elif terrain == "cross":
        parameter = float(rng.uniform(.05, .35))
        l, _, r, _ = scene["terrain"][0]["bounds"]; half = parameter*(r-l)/2
        # centreline height 0 so the band is a pure cross-slope (no step at its edges); heights below 0 are
        # fine for the analytic surface, this scene is not exported to MJCF.
        scene["terrain"] = [dict(kind="ramp", bounds=[l, 4.9, r, 6.1], axis=0, start_height_m=-half, end_height_m=half, friction=mu)]
    scene["floor_friction"] = mu
    for obj in scene["objects"]:
        obj["mass_kg"] = float(rng.uniform(*heavy_mass)) if obj["object_id"] == 0 else float(rng.uniform(1, 3))
        obj["friction"] = float(rng.uniform(.3, .8))
    scene["navigation_condition"] = dict(terrain=terrain, control=control, parameter=parameter, friction=mu,
                                        heavy_mass_range=list(heavy_mass))
    scene["layout_group_id"] = digest(dict(layout=scene["layout_group_id"], terrain=terrain, blocked=control == "blocked"))
    scene["base_scene_id"] = f"{terrain}-{control}-"+scene_hash(scene)[:16]
    return scene


def make_horizon_scene(seed, horizon):
    """exp4: flat linked rooms (8x12), H gateway boxes on the single route, one access blocker D.
    Gate k sits in a full-width wall at y_k; its guide pushes it 1 m forward then .95 m sideways
    into the pocket by the near side wall. D waits in room 1 beside gate 1's approach."""
    if horizon not in HORIZONS:
        raise ValueError("horizon must be 2, 3 or 4")
    rng = np.random.default_rng(seed)
    walls = [[0, 0, .2, 12], [7.8, 0, 8, 12], [.2, 0, 7.8, .2], [.2, 11.8, 7.8, 12]]
    objects, guides, gates, sides = [], [], [], []
    first = int(rng.integers(2))
    for k in range(horizon):
        y = 2.+2.35*k; right = (k+first) % 2 == 1
        x = float(rng.uniform(5.4, 6.3)) if right else float(rng.uniform(1.7, 2.6))
        s = 1. if right else -1.
        walls += [[.2, y-.125, x-.63, y+.125], [x+.63, y-.125, 7.8, y+.125]]
        pose = [x, y, 0.]
        objects.append(dict(object_id=k, pose=pose, size=list(BOX), mass_kg=float(rng.uniform(1, 2)), friction=.4))
        guides.append(ObjectPath(k, ((x, y, 0.), (x, y+1., 0.), (x+s*.95, y+1., 0.))).to_dict())
        gates.append([x-.63, y-.125, x+.63, y+.125]); sides.append(s)
    x1, y1 = objects[1]["pose"][:2]; s1 = sides[1]
    d_pose = [x1-s1*1.5, y1-.62, 0.]
    objects.append(dict(object_id=horizon, pose=d_pose, size=list(BOX), mass_kg=float(rng.uniform(1, 2)), friction=.4))
    guides.append(ObjectPath(horizon, (tuple(d_pose), (d_pose[0]-s1*1., d_pose[1], 0.))).to_dict())
    scene = dict(schema="clear-maze-route-scene-v1", family="long_horizon_rooms", generation_seed=int(seed),
                 world_size=[8., 12.], start=[4., .8, 0.], goal=[4., 11.3], walls=walls, objects=objects, terrain=[],
                 gate_regions=gates, floor_friction=.8, mirrored=False, development_guides=guides,
                 candidate_orders=[list(range(horizon))], access_blocker_id=horizon,
                 navigation_condition=dict(terrain="flat", control="interaction_required", horizon=horizon),
                 capability_status="kinematic development geometry; no body-specific labels")
    scene["layout_group_id"] = digest(dict(world_size=scene["world_size"], walls=walls, gate_regions=gates))
    scene["base_scene_id"] = f"horizon{horizon}-"+scene_hash(scene)[:16]
    for g in guides:   # geometric sanity of the nominal guides in the initial scene
        if path_collision(scene, ObjectPath.from_dict(g)):
            raise RuntimeError("horizon guide collides: "+scene["base_scene_id"])
    return scene


def guide_path(scene, object_id):
    """Development guide re-based on the object's current pose (guides are relative motions)."""
    paths = guide_paths(scene, object_id)
    return paths[0] if paths else None


def guide_paths(scene, object_id):
    """All candidate object paths for one object: the development guide re-based on the current
    pose plus its mirror images (the sideways leg to the other side; a pure push along each axis
    direction). Collision filtering is the caller's job. Order: primary first."""
    guide = next((g for g in scene["development_guides"] if g["object_id"] == object_id), None)
    obj = next(o for o in scene["objects"] if o["object_id"] == object_id)
    if guide is None:
        return []
    poses = np.asarray(guide["poses"], float); shift = np.asarray(obj["pose"])-poses[0]
    poses = poses+shift; poses[:, 2] = (poses[:, 2]+np.pi) % (2*np.pi)-np.pi
    start = poses[0]
    rel = poses[1:, :2]-start[:2]
    variants = [rel, rel*np.array([-1., 1.]), rel*np.array([1., -1.])]      # mirror x, mirror y
    if len(rel) > 1:                                                             # swap the leg order
        variants.append(np.vstack([rel[-1]-rel[-2]+0*rel[0], rel[-1]]))
    for d in ((1., 0.), (-1., 0.), (0., 1.), (0., -1.)):                       # straight 1.5 m pushes
        variants.append(np.array([d])*1.5)
    out, seen = [], set()
    for v in variants:
        key = tuple(np.round(v.ravel(), 3))
        if key in seen or np.allclose(v[-1], 0):
            continue
        seen.add(key)
        pts = np.column_stack([start[0]+v[:, 0], start[1]+v[:, 1], np.full(len(v), start[2])])
        try:
            out.append(ObjectPath(object_id, (tuple(start), *map(tuple, pts))))
        except ValueError:
            continue
    return out


# ------------------------------------------------------------------ teacher
def teacher_search(scene, embodiment, navigator, assessor, max_len=None):
    """Breadth-first over ordered object subsets (guide paths), oracle-validated step by step.
    Returns dict(plan, k_star, route, steps) for the min-(K, path length) plan, or None."""
    analysis = navigator.analyze(scene, embodiment)
    if analysis.goal_route is not None:
        return dict(plan=ObjectMotionPlan(()), k_star=0, route=analysis.goal_route, steps=[])
    ids = [o["object_id"] for o in scene["objects"]]
    max_len = len(ids) if max_len is None else min(max_len, len(ids))
    frontier = [(scene, analysis, [])]
    for k in range(1, max_len+1):
        solutions, nxt = [], []
        for work, nav, prefix in frontier:
            used = {p.object_id for p in prefix}
            for oid in ids:
                if oid in used:
                    continue
                for path in guide_paths(work, oid):
                    if path_collision(work, path):
                        continue
                    a = assessor.assess(work, embodiment, path, nav)
                    if a.status != "candidate_feasible" or nav.route_to(a.approach_xy) is None:
                        continue
                    child = deepcopy(work)
                    next(o for o in child["objects"] if o["object_id"] == oid)["pose"] = list(path.goal)
                    child["start"] = [*a.predicted_robot_xy_after, 0.]
                    child_nav = navigator.analyze(child, embodiment)
                    if child_nav.goal_route is not None:
                        solutions.append(prefix+[path])
                    else:
                        nxt.append((child, child_nav, prefix+[path]))
        if solutions:
            length = lambda seq: sum(np.linalg.norm(np.diff(np.asarray(p.poses)[:, :2], axis=0), axis=1).sum() for p in seq)
            plan = ObjectMotionPlan(tuple(min(solutions, key=length)))
            validated, failure = validate_sequence(scene, embodiment, plan, navigator, assessor)
            if failure:
                raise RuntimeError("search solution failed re-validation: "+failure)
            return dict(plan=plan, k_star=k, route=validated["route"], steps=validated["steps"])
        # bounded search: with several guide variants per object the frontier grows as
        # (variants x objects)^k; keep the 64 shortest prefixes (ponytail: beam, not exhaustive)
        length_of = lambda prefix: sum(np.linalg.norm(np.diff(np.asarray(p.poses)[:, :2], axis=0), axis=1).sum() for p in prefix)
        frontier = sorted(nxt, key=lambda item: length_of(item[2]))[:BEAM]
        if not frontier:
            break
    return None


def navigation_evidence(scene, embodiment, route, navigator, assessor):
    backend = SimulatedTaskBackend(scene, embodiment, navigator, assessor, np.random.default_rng(0), deterministic=True)
    if backend.navigate(route) is not True:
        return None
    trajectory = [[float(v) for v in p] for p in backend.trajectory]
    evidence = dict(backend="dynamic_simulation", proxy="probe_table_kinematic", scene_hash=scene_hash(scene),
                    structure_hash=digest(embodiment.structure_rows), controller_hash=embodiment.controller_hash,
                    goal_settled=True, collision=False, fell=False, footprint_radius_m=embodiment.footprint_radius_m,
                    base_trajectory=trajectory)
    evidence["evidence_hash"] = digest(evidence)
    return evidence


def split_of(group):
    r = int(group[:8], 16) % 100
    return "train" if r < 70 else "val" if r < 85 else "test"


def make_row(scene, body_id, embodiment, navigator, assessor, max_len=None):
    found = teacher_search(scene, embodiment, navigator, assessor, max_len)
    if found is None:
        return None, "no_valid_sequence_within_search"
    plan, k = found["plan"], found["k_star"]
    row = dict(scene=deepcopy(scene), structure_rows=[list(r) for r in embodiment.structure_rows], body_id=body_id,
               split=split_of(scene["layout_group_id"]), plan=plan.to_dict(),
               task_status="solved_without_interaction" if k == 0 else "solved_with_interaction",
               footprint_radius_m=embodiment.footprint_radius_m, controller_hash=embodiment.controller_hash)
    if k == 0:
        evidence = navigation_evidence(scene, embodiment, found["route"], navigator, assessor)
        if evidence is None:
            return None, "deterministic_navigation_of_oracle_route_failed"
        row["navigation_evidence"] = evidence
        row["teacher"] = dict(source="navigation_execution", validation="dynamic_simulation", proxy="probe_table_kinematic",
                              evidence_hash=evidence["evidence_hash"], k_star=0)
    else:
        approaches = [[list(map(float, p)) for p in s["approach"]] for s in found["steps"]]
        row["teacher"] = dict(source="planner_object_path", validation="dynamic_simulation", proxy="probe_table_kinematic",
                              evidence_hash=digest(dict(scene=scene_hash(scene), structure=digest(embodiment.structure_rows),
                                                        plan=plan.to_dict(), approaches=approaches, route=[list(p) for p in found["route"]])),
                              k_star=k)
    return row, None


def robot_pose_variants(scene, embodiment, navigator, count, rng):
    """The canonical post-push pose plus reachable free positions.

    Without this the robot always stands right behind the object it just pushed, so
    "the nearest object is the one already executed" holds in every mid-episode row and the
    model learns that shortcut instead of reading the scene: measured 2026-09-09, the model
    scored -11 on the blocker it had to push and +10 on the object it had already moved as
    soon as the executor's back-off changed which object was nearest.
    """
    from experiments.exp3.trajectory_v3.navigation import clearance
    out = [tuple(float(v) for v in scene["start"][:2])]
    if count <= 1:
        return out
    analysis = navigator.analyze(scene, embodiment)
    points = analysis.xy[np.isfinite(analysis.distance)]
    if len(points):
        points = points[clearance(scene, points) > embodiment.footprint_radius_m + .05]
    if len(points):
        pick = rng.choice(len(points), size=int(min(count-1, len(points))), replace=False)
        out += [tuple(float(v) for v in points[i]) for i in np.atleast_1d(pick)]
    return out


def mid_episode_rows(scene, body_id, embodiment, row, navigator, assessor, max_len=None, poses=3, rng=None):
    """Rows for the states reached after executing each proper prefix of the teacher plan
    (objects at their path goals, robot at the assessor's predicted post-push position), each with
    a freshly searched teacher. These are the observed intermediate states a replanning policy
    plans from (STUDY_DESIGN: mid-episode relabels); without them the model never sees them."""
    plan = ObjectMotionPlan.from_dict(row["plan"])
    if len(plan.paths) < 2:
        return []
    validated, failure = validate_sequence(scene, embodiment, plan, navigator, assessor)
    if failure:
        return []
    rng = rng or np.random.default_rng(abs(hash((scene["base_scene_id"], body_id))) % 2**32)
    out, work = [], deepcopy(scene)
    for j, step in enumerate(validated["steps"][:-1], start=1):
        next(o for o in work["objects"] if o["object_id"] == step["path"].object_id)["pose"] = list(step["path"].goal)
        work["start"] = [*map(float, step["assessment"].predicted_robot_xy_after), 0.]
        mid = deepcopy(work)
        mid["base_scene_id"] = f"{scene['base_scene_id']}-mid{j}"
        mid["mid_episode_prefix"] = [p.object_id for p in plan.paths[:j]]
        states = [(mid, None)]
        if j == 1 and scene.get("access_blocker_id") is not None:
            # the STUDY_DESIGN access event: the blocker translated 1.4 m toward the next gate's
            # approach after the first interaction; a replanning policy must plan from this state
            shifted = access_shifted(mid, plan, scene["access_blocker_id"])
            if shifted is not None:
                shifted["base_scene_id"] = f"{scene['base_scene_id']}-mid{j}-access"
                states.append((shifted, "access_shift"))
        for state, event in states:
            for v, start in enumerate(robot_pose_variants(state, embodiment, navigator, poses, rng)):
                variant = deepcopy(state)
                variant["start"] = [start[0], start[1], 0.]
                if v:
                    variant["base_scene_id"] = f"{state['base_scene_id']}-pose{v}"
                limit = ((max_len or 0) + 1 or None) if event else max_len
                variant_row, _ = make_row(variant, body_id, embodiment, navigator, assessor, limit)
                if variant_row is None or not variant_row["plan"]["paths"]:
                    continue
                variant_row["mid_episode"] = j
                variant_row["robot_pose_variant"] = v
                if event:
                    variant_row["perturbed"] = event
                out.append(variant_row)
    return out


def access_shifted(scene, plan, blocker_id):
    """Translate the blocker toward the approach point of the plan's second object (evaluate_v3
    perturbation_for semantics), clipped against walls, objects and the robot footprint."""
    from experiments.exp3.trajectory_v3.oracle_capability import approach_point
    from experiments.exp3.trajectory_v3.scenes import overlap, rectangle_corners, wall_polygon
    if len(plan.paths) < 2:
        return None
    work = deepcopy(scene)
    blocker = next(o for o in work["objects"] if o["object_id"] == blocker_id)
    approach = np.asarray(approach_point(plan.paths[1]))
    origin = np.asarray(blocker["pose"][:2]); v = approach-origin
    if np.linalg.norm(v) < 1e-6:
        return None
    v = v/np.linalg.norm(v)*1.4
    obstacles = [wall_polygon(w) for w in work["walls"]]
    obstacles += [rectangle_corners(o["pose"], o["size"]) for o in work["objects"] if o["object_id"] != blocker_id]
    rx, ry = work["start"][:2]; rr = .25+.15
    obstacles.append(rectangle_corners([rx, ry, 0.], [2*rr, 2*rr, 0.]))
    w, h = work["world_size"]
    for f in np.linspace(1., 0., 21):
        pose = [origin[0]+f*v[0], origin[1]+f*v[1], blocker["pose"][2]]
        poly = rectangle_corners(pose, blocker["size"])
        if (poly >= 0).all() and (poly <= [w, h]).all() and not any(overlap(poly, o) for o in obstacles):
            if f == 0:
                return None
            blocker["pose"] = pose
            return work
    return None


def generate(out, scenes_per_cell, exp4=False, checkpoint=None, embodiments=None, navigator=None, assessor=None, device="cpu", cells=None,
             mid_episode=False, mid_poses=3, terrains=None, heavy_mass=(2., 9.), probes=None):
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    embodiments = embodiments or bodies()
    if navigator is None:
        navigator, assessor = oracle(probes=probes)
    rows, unsolved, per_scene = [], [], []
    cells = cells or ([(h,) for h in HORIZONS] if exp4 else [(t, c) for t in (terrains or TERRAINS) for c in CONTROLS])
    for ci, cell in enumerate(cells):
        for i in range(scenes_per_cell):
            seed = 1000*ci+i
            scene = make_horizon_scene(seed, cell[0]) if exp4 else make_family_scene(seed, *cell, np.random.default_rng(seed), heavy_mass)
            plans = {}
            for body, emb in embodiments.items():
                row, reason = make_row(scene, body, emb, navigator, assessor, max_len=cell[0]+1 if exp4 else None)
                if row is None:
                    unsolved.append(dict(base_scene_id=scene["base_scene_id"], body_id=body, split=split_of(scene["layout_group_id"]),
                                         reason=reason, scene=scene, structure_rows=[list(r) for r in emb.structure_rows],
                                         footprint_radius_m=emb.footprint_radius_m, controller_hash=emb.controller_hash))
                    plans[body] = None
                else:
                    rows.append(row); plans[body] = [p["object_id"] for p in row["plan"]["paths"]]
                    if mid_episode:
                        rows.extend(mid_episode_rows(scene, body, emb, row, navigator, assessor,
                                                     max_len=cell[0]+1 if exp4 else None, poses=mid_poses))
            per_scene.append(dict(base_scene_id=scene["base_scene_id"], cell=list(cell), condition=scene["navigation_condition"],
                                  split=split_of(scene["layout_group_id"]), plans=plans))
    if checkpoint:
        from experiments.exp3.trajectory_v3.traversability import LearnedTraversalPredictor
        annotate(rows, LearnedTraversalPredictor(checkpoint, device))
    summary = validate_dataset(rows) if rows else dict(examples=0)
    for split in ("train", "val", "test"):
        (out/f"{split}.jsonl").write_text("".join(json.dumps(r)+"\n" for r in rows if r["split"] == split))
    (out/"unsolved.jsonl").write_text("".join(json.dumps(r)+"\n" for r in unsolved))
    stats = dict(dataset=summary, unsolved=len(unsolved), exp4=exp4, scenes=len(per_scene), **paired_stats(per_scene))
    stats["per_scene"] = per_scene
    (out/"stats.json").write_text(json.dumps(stats, indent=1)+"\n")
    return stats


def paired_stats(per_scene):
    solved = [(s, b, p) for s in per_scene for b, p in s["plans"].items() if p is not None]
    k_hist = {}
    for _, _, p in solved:
        k_hist[str(len(p))] = k_hist.get(str(len(p)), 0)+1
    paired = [s for s in per_scene if sum(p is not None for p in s["plans"].values()) >= 1]
    differ = [s for s in paired if len({json.dumps(p) for p in s["plans"].values()}) > 1]
    return dict(solved_pairs=len(solved), fraction_solved_without_interaction=(sum(len(p) == 0 for _, _, p in solved)/len(solved)) if solved else None,
                k_star_histogram=k_hist, scenes_with_a_solved_body=len(paired),
                body_paired_plans_differ_fraction=(len(differ)/len(paired)) if paired else None,
                differing_scene_ids=[s["base_scene_id"] for s in differ])


def annotate(rows, predictor, resolution=.1, threshold=.8):
    navigator = TerrainNavigator(predictor, resolution, threshold)
    for row in rows:
        emb = EmbodimentSpec(row["structure_rows"], row["footprint_radius_m"], row["controller_hash"])
        row["navigation_context"] = navigator.analyze(row["scene"], emb).model_context()
    return rows


def main(argv=None):
    p = argparse.ArgumentParser(description="exp3/exp4 body-paired object-path teacher data (probe-table oracle)")
    p.add_argument("--out", required=True); p.add_argument("--scenes-per-cell", type=int, default=20)
    p.add_argument("--traversability-checkpoint"); p.add_argument("--exp4", action="store_true")
    p.add_argument("--probes", help="traversal probe directory for the teacher oracle (default: asset/experiments/exp3/probes)")
    p.add_argument("--device", default="cpu")
    p.add_argument("--mid-episode", action="store_true", help="also emit rows for the states after each teacher prefix")
    p.add_argument("--mid-poses", type=int, default=3, help="robot pose variants per mid-episode state")
    p.add_argument("--terrains", nargs="*", choices=TERRAINS, help="restrict the scene family cells")
    p.add_argument("--heavy-mass", type=float, nargs=2, default=(2., 9.), metavar=("LO", "HI"),
                   help="mass range of the heavy object; narrow it to the band that separates the bodies "
                        "(measured 2026-09-09: Spot pushes <= 4 kg, G1 <= 6 kg) to make manipulation, not terrain, the discriminator")
    args = p.parse_args(argv)
    stats = generate(args.out, args.scenes_per_cell, args.exp4, args.traversability_checkpoint, device=args.device, mid_episode=args.mid_episode, mid_poses=args.mid_poses,
                     terrains=args.terrains, heavy_mass=tuple(args.heavy_mass), probes=args.probes)
    print(json.dumps({k: v for k, v in stats.items() if k != "per_scene"}, indent=2))


if __name__ == "__main__":
    main()
