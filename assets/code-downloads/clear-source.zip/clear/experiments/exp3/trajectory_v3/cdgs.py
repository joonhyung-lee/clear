"""CDGS adapted to two object-interaction transitions, with official denoiser code.

Short transition: object poses, generated object/STOP skill + path, next poses.
Adjacent transitions share the intermediate state. No teacher skill sequence is
provided at inference. CLEAR contributes shared perception/traversal only.
Search follows CDGS denoise/re-noise and inversion-score pruning, not CVF sampling.
Sources: arxiv.org/abs/2601.00126 and UtkarshMishra04/CDGS_toydomain/inference_long.py.
"""
import importlib.util
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F

from experiments.exp3.trajectory_v3.training_state import file_hash


class ObjectTransitionCDGS(nn.Module):
    def __init__(self, config, context_dim, waypoints):
        super().__init__()
        self.config = config
        self.objects = config['max_objects']
        if self.objects != 3 or waypoints != 8:
            raise ValueError('this adaptation targets Exp3: three object slots, eight poses, H <= 2')
        self.state_dim = self.objects*4
        self.path_dim = (waypoints-1)*4
        self.action_dim = self.objects+1+self.path_dim
        self.transition_dim = 2*self.state_dim+self.action_dim
        stride = self.state_dim+self.action_dim
        self.views = ((0,self.transition_dim),(stride,stride+self.transition_dim))
        source = Path(config['repository'])
        if not {'model.py','inference_long.py'} <= set(config['source_files']):
            raise ValueError('official CDGS denoiser and search source hashes required')
        for name, sha in config['source_files'].items():
            if file_hash(source/name) != sha:raise ValueError('official CDGS source changed: '+name)
        spec = importlib.util.spec_from_file_location('exp3_cdgs_official_denoiser', source/'model.py')
        official = importlib.util.module_from_spec(spec);spec.loader.exec_module(official)
        self.denoiser = official.Simple2DUNet(input_dim=self.transition_dim+context_dim,
            hidden_dims=(128,256),time_embed_dim=128,num_blocks_per_level=1,dropout=0.)
        self.register_buffer('alpha',torch.cumprod(1-torch.linspace(.0001,.02,1000),0))
        if not 0 < config['keep_fraction'] <= 1 or not 0 <= config['prune_after'] < 1:
            raise ValueError('valid pruning fraction and start required')
        if type(config['resampling_steps']) is not int or config['resampling_steps'] < 2:
            raise ValueError('CDGS search requires at least two resampling steps')
        self.last_compute = {}

    @staticmethod
    def context(encoded):
        mask=encoded['key_mask']
        return (encoded['tokens']*mask[...,None]).sum(1)/mask.sum(1,keepdim=True)

    def initial_state(self, batch):
        observed=batch['object_features'][...,:4]
        if observed.shape[1] > self.objects:raise ValueError('scene exceeds declared CDGS object slots')
        return F.pad(observed,(0,0,0,self.objects-observed.shape[1])).flatten(1)

    def targets(self, batch):
        state=self.initial_state(batch);transitions=[];b,n=batch['rank'].shape
        for step in range(2):
            chosen=(batch['rank']==step)&batch['object_mask']
            if (chosen.sum(1)>1).any():raise ValueError('one skill per transition required')
            action=state.new_zeros(b,self.action_dim)
            action[:,:n]=chosen
            action[:,self.objects]=~chosen.any(1)
            path=(batch['path_code']*chosen[...,None]).sum(1)
            action[:,self.objects+1:]=path
            next_state=state.clone().reshape(b,self.objects,4)
            for slot in range(n):
                pose=torch.cat([state.reshape(b,self.objects,4)[:,slot,:2]+path[:,-4:-2],path[:,-2:]],1)
                next_state[:,slot]=torch.where(chosen[:,slot,None],pose,next_state[:,slot])
            next_state=next_state.flatten(1)
            transitions.append(torch.cat([state,action,next_state],1));state=next_state
        return torch.stack(transitions,1)

    def predict(self, x, t, context):
        self.last_compute['denoiser_calls']=self.last_compute.get('denoiser_calls',0)+1
        self.last_compute['denoiser_sample_evaluations']=self.last_compute.get('denoiser_sample_evaluations',0)+len(x)
        return self.denoiser(torch.cat([x,context],1),t)[:,:self.transition_dim]

    def loss(self, batch, encoded, generator=None):
        x0=self.targets(batch).flatten(0,1)
        context=self.context(encoded).repeat_interleave(2,0)
        t=torch.randint(len(self.alpha),(len(x0),),device=x0.device,generator=generator)
        noise=torch.randn(x0.shape,device=x0.device,generator=generator)
        a=self.alpha[t,None]
        loss=F.mse_loss(self.predict(a.sqrt()*x0+(1-a).sqrt()*noise,t,context),noise)
        # Historical selection plumbing reads `flow`; config and this term identify DDPM MSE.
        return loss,dict(flow=float(loss.detach()),diffusion_noise_mse=float(loss.detach()))

    def composed_noise(self, latent, t, context):
        noise=torch.zeros_like(latent);count=torch.zeros_like(latent)
        for start,end in self.views:
            noise[:,start:end]+=self.predict(latent[:,start:end],t.expand(len(latent)),context)
            count[:,start:end]+=1
        return noise/count

    def prune(self, x0, latent, times, context):
        """Rank by the temporal variation of short-model DDIM inversion scores."""
        inverted=torch.stack([x0[:,start:end] for start,end in self.views])
        noises=[];ascending=times.flip(0)
        for t,next_t in zip(ascending[:len(times)//2],ascending[1:len(times)//2+1]):
            a,an=self.alpha[t],self.alpha[next_t]
            eps=torch.stack([self.predict(x,t.expand(len(x)),context) for x in inverted])
            clean=((inverted-(1-a).sqrt()*eps)/a.sqrt()).clamp(-1,1)
            eps=(inverted-a.sqrt()*clean)/(1-a).sqrt()
            inverted=an.sqrt()*clean+(1-an).sqrt()*eps;noises.append(eps)
        derivative=torch.diff(torch.stack(noises,2),dim=2)
        score=derivative.flatten(2).norm(dim=2).mean(0)
        keep=max(1,int(len(latent)*self.config['keep_fraction']))
        indices=score.topk(keep,largest=False).indices
        indices=indices.repeat((len(latent)+keep-1)//keep)[:len(latent)]
        self.last_compute['pruning_events']=self.last_compute.get('pruning_events',0)+1
        return latent[indices]

    @torch.no_grad()
    def sample(self, batch, encoded, steps, generator=None):
        if not 4 <= steps <= len(self.alpha):raise ValueError('CDGS needs 4..1000 denoising steps')
        context=self.context(encoded);initial=self.initial_state(batch);b=len(initial)
        # Pruning may exchange particles only within the SAME planning problem.
        if not torch.allclose(context,context[:1].expand_as(context)) or not torch.equal(initial,initial[:1].expand_as(initial)):
            raise ValueError('CDGS particle population must share one observation and embodiment')
        self.last_compute=dict(population=b,denoising_steps=steps,resampling_steps=self.config['resampling_steps'],
                               denoiser_calls=0,denoiser_sample_evaluations=0,pruning_events=0)
        def noise_like(x):return torch.randn(x.shape,device=x.device,dtype=x.dtype,generator=generator)
        latent=noise_like(initial.new_zeros(b,self.views[-1][1]))
        times=torch.linspace(len(self.alpha)-1,0,steps,device=latent.device).long()
        for index,t in enumerate(times):
            prev=times[index+1] if index+1 < len(times) else None
            a=self.alpha[t];ap=self.alpha[prev] if prev is not None else latent.new_tensor(1.)
            for repeat in range(self.config['resampling_steps']):
                latent[:,:self.state_dim]=a.sqrt()*initial+(1-a).sqrt()*noise_like(initial)
                eps=self.composed_noise(latent,t,context)
                clean=((latent-(1-a).sqrt()*eps)/a.sqrt()).clamp(-1,1)
                beta=1-a/ap
                latent=ap.sqrt()*beta/(1-a)*clean+(a/ap).sqrt()*(1-ap)/(1-a)*latent
                if prev is not None:latent+=(((1-ap)/(1-a)*beta).clamp_min(0)).sqrt()*noise_like(latent)
                if repeat==self.config['resampling_steps']-2 and index/steps>self.config['prune_after']:
                    latent=self.prune(clean,latent,times,context)
                if repeat+1 < self.config['resampling_steps']:
                    # Forward diffusion back to the same noise level after a denoising move.
                    latent=(a/ap).sqrt()*latent+(1-a/ap).sqrt()*noise_like(latent)
            if prev is None:latent[:,:self.state_dim]=initial
        return self.decode(latent,batch)

    def decode(self, latent, batch):
        b,n=batch['rank'].shape
        rank=torch.full((b,n),-1,device=latent.device,dtype=torch.long)
        paths=latent.new_zeros(b,n,self.path_dim);active=torch.ones(b,device=latent.device,dtype=torch.bool)
        invalid=~torch.isfinite(latent).all(1)
        for step,(start,end) in enumerate(self.views):
            action=latent[:,start+self.state_dim:end-self.state_dim]
            choice=action[:,:self.objects+1].argmax(1)
            active &= choice!=self.objects
            for row in range(b):
                if not active[row]:continue
                slot=int(choice[row])
                if slot>=n or not batch['object_mask'][row,slot] or rank[row,slot]>=0:
                    invalid[row]=True;continue
                rank[row,slot]=step;paths[row,slot]=action[row,self.objects+1:]
        # Preserve an invalid raw draw through the common decoder; never repair a duplicate skill.
        for row in range(b):
            if invalid[row] and batch['object_mask'][row].any():rank[row,0]=0;paths[row,0]=torch.nan
        return dict(rank=rank,selected=rank>=0,path_code=paths,selection_logits=(rank>=0).float())
