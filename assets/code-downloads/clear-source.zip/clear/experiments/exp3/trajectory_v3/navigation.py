from dataclasses import dataclass
import math
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.scenes import public_scene

EDGE_FIELDS = ("step_up_m", "step_down_m", "uphill_grade", "downhill_grade",
               "cross_grade", "length_m", "direction_x", "direction_y",
               "footprint_radius_m", "clearance_m", "friction")
NAV_SCHEMA = "clear-navigation-context-v2"

# EDGE_FIELDS splits in two for the encoder-backed traversal head
# (shared_morphology.SharedMorphologyModel(traversal_head="encoder")). TERRAIN_FIELDS is what
# transition_features measured about the ground; that head is asked to recover it from scene
# tokens instead of being told, so its query carries only POSE_FIELDS -- facts about the
# segment and the body -- plus where on the scene the segment sits.
TERRAIN_FIELDS = ("step_up_m", "step_down_m", "uphill_grade", "downhill_grade", "cross_grade",
                  "friction")
POSE_FIELDS = ("length_m", "direction_x", "direction_y", "footprint_radius_m", "clearance_m")
TERRAIN_COLUMNS = tuple(EDGE_FIELDS.index(f) for f in TERRAIN_FIELDS)
POSE_COLUMNS = tuple(EDGE_FIELDS.index(f) for f in POSE_FIELDS)
TRAVERSAL_QUERY_DIM = len(POSE_FIELDS) + 2


def traversal_query(edge_features, midpoints, world_size):
    """(E, len(EDGE_FIELDS)) + (E, 2) metric midpoints -> (E, TRAVERSAL_QUERY_DIM) queries.

    One definition for both callers: the probe trainer builds it from a probe row's own r_e and
    the midpoint of the segment it crossed; TerrainNavigator.analyze builds it from a graph
    edge's r_e and the midpoint of that edge. If these ever drift, the head is trained on one
    convention and asked in another, which no test downstream would catch.
    """
    edge_features = np.asarray(edge_features, np.float32).reshape(-1, len(EDGE_FIELDS))
    midpoints = np.asarray(midpoints, np.float32).reshape(-1, 2)
    if len(edge_features) != len(midpoints):
        raise ValueError("one midpoint per edge required")
    w, h = world_size
    return np.column_stack([edge_features[:, POSE_COLUMNS],
                            midpoints[:, 0] / w, midpoints[:, 1] / h]).astype(np.float32)



@dataclass(frozen=True)
class EmbodimentSpec:
    structure_rows: tuple
    footprint_radius_m: float
    controller_hash: str

    def __post_init__(self):
        rows = np.asarray(self.structure_rows, float)
        if rows.ndim != 2 or rows.shape[1] != 20 or not len(rows) or not np.isfinite(rows).all():
            raise ValueError("finite actual structural rows [L,20] required")
        if not np.isfinite(self.footprint_radius_m) or self.footprint_radius_m <= 0:
            raise ValueError("positive conservative footprint radius required")
        if len(self.controller_hash) != 64 or any(c not in "0123456789abcdef" for c in self.controller_hash):
            raise ValueError("frozen controller SHA256 required")
        object.__setattr__(self, "structure_rows", tuple(map(tuple, rows.tolist())))

    @property
    def identity(self):
        return digest(dict(structure=self.structure_rows, radius=self.footprint_radius_m,
                           controller=self.controller_hash))


def scene_hash(scene):
    return digest(public_scene(scene))


def clearance(scene, points):
    points = np.asarray(points, float)
    w, h = scene["world_size"]
    result = np.minimum.reduce([points[..., 0], points[..., 1], w-points[..., 0], h-points[..., 1]])
    for l, b, r, t in scene["walls"]:
        dx = np.maximum(np.maximum(l-points[..., 0], points[..., 0]-r), 0)
        dy = np.maximum(np.maximum(b-points[..., 1], points[..., 1]-t), 0)
        result = np.minimum(result, np.hypot(dx, dy))
    for obj in scene["objects"]:
        xy = points-np.asarray(obj["pose"][:2])
        yaw = obj["pose"][2]; c, s = np.cos(yaw), np.sin(yaw)
        x, y = c*xy[..., 0]+s*xy[..., 1], -s*xy[..., 0]+c*xy[..., 1]
        result = np.minimum(result, np.hypot(np.maximum(abs(x)-obj["size"][0]/2, 0),
                                            np.maximum(abs(y)-obj["size"][1]/2, 0)))
    return result


def surface(scene, points):
    p = np.asarray(points, float)
    height = np.zeros(p.shape[:-1]); gradient = np.zeros_like(p)
    friction = np.full(p.shape[:-1], float(scene.get("floor_friction", .8)))
    for tile in scene["terrain"]:
        l, b, r, t = tile["bounds"]
        inside = (p[..., 0]>=l) & (p[..., 0]<=r) & (p[..., 1]>=b) & (p[..., 1]<=t)
        if tile.get("kind") == "ramp":
            axis = tile["axis"]
            if axis not in (0, 1):
                raise ValueError("ramp axis must be 0 or 1")
            low, high = (l, r) if axis == 0 else (b, t)
            rise = tile["end_height_m"]-tile["start_height_m"]
            value = tile["start_height_m"]+(p[..., axis]-low)*rise/(high-low)
            grad = np.zeros(2); grad[axis] = rise/(high-low)
        else:
            if tile.get("kind") not in ("stair_tread", "flat"):
                raise ValueError("unknown terrain kind")
            value, grad = tile["height_m"], np.zeros(2)
        height = np.where(inside, value, height)
        gradient = np.where(inside[..., None], grad, gradient)
        friction = np.where(inside, tile.get("friction", .8), friction)
    return height, gradient, friction


def transition_features(scene, start, end, radius, minimum_clearance):
    start, end = np.asarray(start, float), np.asarray(end, float)
    delta = end-start; length = np.linalg.norm(delta, axis=-1)
    direction = delta/length[:, None]
    samples = start[:, None]+delta[:, None]*np.linspace(0, 1, 9)[None, :, None]
    _, gradient, friction = surface(scene, samples)
    along = (gradient*direction[:, None]).sum(-1)
    across = gradient[..., 0]*direction[:, None, 1]-gradient[..., 1]*direction[:, None, 0]
    uphill,downhill,cross=np.maximum(along.max(1),0),np.maximum(-along.min(1),0),abs(across).max(1)
    up, down = np.zeros(len(start)), np.zeros(len(start))
    for tile in scene["terrain"]:
        for axis in (0, 1):
            for boundary in (tile["bounds"][axis], tile["bounds"][axis+2]):
                fraction = np.divide(boundary-start[:, axis], delta[:, axis],
                                     out=np.full(len(start), -2.), where=abs(delta[:, axis])>1e-12)
                valid = (fraction >= 0) & (fraction <= 1)
                other = 1-axis
                at = start+fraction[:, None]*delta
                valid &= (at[:, other]>=tile["bounds"][other]) & (at[:, other]<=tile["bounds"][other+2])
                before,gb,_ = surface(scene, at-1e-7*direction)
                after,ga,_ = surface(scene, at+1e-7*direction)
                for grad in (gb,ga):
                    projection=(grad*direction).sum(-1)
                    uphill=np.maximum(uphill,np.where(valid,projection,0))
                    downhill=np.maximum(downhill,np.where(valid,-projection,0))
                    cross=np.maximum(cross,np.where(valid,abs(grad[:,0]*direction[:,1]-grad[:,1]*direction[:,0]),0))
                jump = np.where(valid, after-before, 0)
                jump[abs(jump)<1e-5] = 0
                up = np.maximum(up, jump); down = np.maximum(down, -jump)
    return np.column_stack([up, down, uphill, downhill, cross, length,
                            direction, np.full(len(start), radius), minimum_clearance,
                            friction.min(1)]).astype(np.float32)


@dataclass
class NavigationAnalysis:
    scene: dict
    embodiment: EmbodimentSpec
    xy: np.ndarray
    free: np.ndarray
    distance: np.ndarray
    parent: np.ndarray
    resolution: float
    width: int
    predictor_hash: str
    source: str
    unknown_edges: int
    predictor: object
    threshold: float

    def connector_allowed(self, a, b):
        a,b=np.asarray(a[:2],float),np.asarray(b[:2],float)
        minimum=float(clearance(self.scene,np.linspace(a,b,9)).min())
        if minimum<=self.embodiment.footprint_radius_m:
            return False
        if np.linalg.norm(b-a)<1e-10:
            return True
        features=transition_features(self.scene,a[None],b[None],self.embodiment.footprint_radius_m,np.array([minimum]))
        # A connector is scored by the same predictor as a graph edge, so it owes the same
        # arguments; a scene-reading head asked without them would raise here instead of at
        # the one call site in analyze().
        context=dict(scene=self.scene,midpoints=(a+b)[None]/2) if getattr(self.predictor,"needs_scene",False) else {}
        probability=np.asarray(self.predictor.predict(features,self.embodiment,**context),float)
        if probability.shape!=(1,) or np.isinf(probability).any() or ((probability<0)|(probability>1)).any():
            raise ValueError("invalid connector probability")
        return bool(np.isfinite(probability[0]) and probability[0]>=self.threshold)

    def index(self, point):
        x, y = np.floor(np.asarray(point[:2])/self.resolution).astype(int)
        height = len(self.xy)//self.width
        return int(y*self.width+x) if 0<=x<self.width and 0<=y<height else None

    def route_to(self, point):
        node = self.index(point)
        if node is None or not np.isfinite(self.distance[node]):
            return None
        if not self.connector_allowed(self.xy[node],point):
            return None
        path = []
        while node != -1:
            path.append(tuple(self.xy[node])); node = int(self.parent[node])
        path.reverse()
        return (tuple(self.scene["start"][:2]), *path, tuple(point[:2]))

    @property
    def goal_route(self):
        return self.route_to(self.scene["goal"])

    def model_context(self):
        features = []
        fraction = float(np.isfinite(self.distance).sum()/max(1, self.free.sum()))
        scale = np.linalg.norm(self.scene["world_size"])
        direct = float(self.goal_route is not None)
        for obj in self.scene["objects"]:
            x, y, yaw = obj["pose"]
            a, b = np.asarray(obj["size"][:2])/2+self.embodiment.footprint_radius_m+.1
            offsets = np.array([[a, 0], [-a, 0], [0, b], [0, -b]])
            rotation = np.array([[np.cos(yaw), -np.sin(yaw)], [np.sin(yaw), np.cos(yaw)]])
            points = offsets@rotation.T+[x, y]
            distances = [self.distance[j] if (j := self.index(p)) is not None and self.route_to(p) is not None else np.inf for p in points]
            available = np.isfinite(distances)
            best = min([d for d in distances if np.isfinite(d)], default=scale)
            features.append([float(available.mean()), float(min(best/scale, 1)),
                             direct, fraction])
        return dict(schema=NAV_SCHEMA, scene_hash=scene_hash(self.scene), embodiment_hash=self.embodiment.identity,
                    structure_hash=digest(self.embodiment.structure_rows), controller_hash=self.embodiment.controller_hash,
                    footprint_radius_m=self.embodiment.footprint_radius_m, predictor_hash=self.predictor_hash,
                    source=self.source, object_features=features)


class TerrainNavigator:
    def __init__(self, predictor, resolution=.1, threshold=.8):
        if not np.isfinite([resolution, threshold]).all() or resolution<=0 or not 0<threshold<=1:
            raise ValueError("positive resolution and probability threshold required")
        if not callable(getattr(predictor, "predict", None)) or not hasattr(predictor, "identity"):
            raise TypeError("versioned edge predictor required")
        self.predictor, self.resolution, self.threshold = predictor, resolution, threshold

    def geometry(self, scene, embodiment):
        w, h = np.ceil(np.asarray(scene["world_size"])/self.resolution).astype(int)
        xx, yy = np.meshgrid((np.arange(w)+.5)*self.resolution, (np.arange(h)+.5)*self.resolution)
        xy = np.column_stack([xx.ravel(), yy.ravel()]); gap = clearance(scene, xy)
        free = gap > embodiment.footprint_radius_m+self.resolution/math.sqrt(2)
        ids = np.arange(w*h).reshape(h, w)
        a = np.concatenate([ids[:, :-1].ravel(), ids[:-1].ravel()])
        b = np.concatenate([ids[:, 1:].ravel(), ids[1:].ravel()])
        a, b = np.concatenate([a, b]), np.concatenate([b, a])
        keep = free[a] & free[b]; a, b = a[keep], b[keep]
        features = transition_features(scene, xy[a], xy[b], embodiment.footprint_radius_m, np.minimum(gap[a], gap[b]))
        return w, h, xy, free, a, b, features

    def scene_context(self, scene, xy, a, b):
        """Extra predict() arguments for a predictor that reads the scene itself.

        Empty for every edge-feature predictor, so their call is byte-identical to before this
        existed.
        """
        if not getattr(self.predictor, "needs_scene", False):
            return {}
        return dict(scene=scene, midpoints=(xy[a] + xy[b]) / 2)

    def analyze(self, scene, embodiment):
        from scipy.sparse import csr_matrix
        from scipy.sparse.csgraph import dijkstra
        w, h, xy, free, a, b, features = self.geometry(scene, embodiment)
        context = self.scene_context(scene, xy, a, b)
        probability = (np.asarray(self.predictor.predict(features, embodiment, **context), float)
                       if len(a) else np.empty(0))
        if probability.shape != (len(a),) or np.isinf(probability).any() or ((probability<0)|(probability>1)).any():
            raise ValueError("edge predictor must return probabilities or NaN for unknown")
        admitted = np.isfinite(probability) & (probability>=self.threshold)
        distance = np.full(len(xy), np.inf); parent = np.full(len(xy), -1, int)
        analysis = NavigationAnalysis(scene, embodiment, xy, free, distance, parent, self.resolution,
                                      int(w), self.predictor.identity, self.predictor.source,
                                      int(np.isnan(probability).sum()), self.predictor, self.threshold)
        start = analysis.index(scene["start"])
        roots, initial_costs = [], []
        if start is not None and free[start] and analysis.connector_allowed(scene["start"],xy[start]):
            roots.append(start); initial_costs.append(0.)
        elif start is not None:
            # A collision-free continuous start may fall inside a cell excluded
            # by the conservative half-diagonal inflation. Attach only to local
            # free neighbours whose exact connector passes the SAME geometry
            # and learned traversal checks. Never move/snap the actual start.
            row, col = divmod(start, int(w))
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    y, x = row+dy, col+dx
                    if not (0 <= y < h and 0 <= x < w):
                        continue
                    node = int(y*w+x)
                    if free[node] and analysis.connector_allowed(scene['start'], xy[node]):
                        length = float(np.linalg.norm(xy[node]-np.asarray(scene['start'][:2])))
                        roots.append(node); initial_costs.append(length)
        # A virtual source retains the exact costs of checked start connectors.
        source=len(xy)
        graph=csr_matrix((np.r_[features[admitted,5],initial_costs],
            (np.r_[a[admitted],np.full(len(roots),source)],
             np.r_[b[admitted],np.asarray(roots,dtype=int)])),shape=(source+1,source+1))
        costs, predecessors=dijkstra(graph,directed=True,indices=source,return_predecessors=True)
        distance[:]=costs[:-1]
        parent[:]=np.where((predecessors[:-1]<0)|(predecessors[:-1]==source),-1,predecessors[:-1])
        return analysis
