from copy import deepcopy
import json
import math
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, ObjectPath, angle_delta
from experiments.exp3.trajectory_v3.scenes import public_scene, path_collision


def validate_empty_reference(row):
    from experiments.exp3.trajectory_v3.navigation import clearance, scene_hash
    evidence = row.get("navigation_evidence", {})
    if row.get("task_status") != "solved_without_interaction" or row["teacher"]["source"] != "navigation_execution":
        raise ValueError("empty plan requires a successful no-interaction navigation reference")
    if evidence.get("backend") not in ("dynamic_simulation", "real_robot"):
        raise ValueError("empty teacher requires actual navigation execution evidence")
    if row["teacher"]["validation"] != evidence["backend"]:
        raise ValueError("empty teacher validation level conflicts with navigation evidence")
    if evidence.get("scene_hash") != scene_hash(row["scene"]) or evidence.get("structure_hash") != digest(row["structure_rows"]):
        raise ValueError("empty navigation evidence belongs to another scene or structure")
    for field in ("controller_hash", "evidence_hash"):
        value = evidence.get(field, "")
        if len(value)!=64 or any(c not in "0123456789abcdef" for c in value):
            raise ValueError("navigation evidence hash missing")
    if evidence.get("goal_settled") is not True or evidence.get("collision") is not False or evidence.get("fell") is not False:
        raise ValueError("empty reference must reach and settle safely at the goal")
    trajectory = np.asarray(evidence.get("base_trajectory", []), float)
    if trajectory.ndim!=2 or trajectory.shape[1]!=3 or len(trajectory)<2 or not np.isfinite(trajectory).all() or (np.diff(trajectory[:,0])<=0).any():
        raise ValueError("measured [time,x,y] navigation trace required")
    if np.linalg.norm(trajectory[0,1:]-row["scene"]["start"][:2])>.15 or np.linalg.norm(trajectory[-1,1:]-row["scene"]["goal"][:2])>.15:
        raise ValueError("navigation trace does not connect the scene start and goal")
    radius = evidence.get("footprint_radius_m",0)
    if not np.isfinite(radius) or radius<=0:
        raise ValueError("navigation reference footprint required")
    certificate=row['teacher'].get('execution_evidence')
    if certificate is not None:
        q=certificate.get('qualification',{})
        if (row['teacher']['validation']!='dynamic_simulation'
                or digest(certificate)!=row['teacher'].get('evidence_hash')
                or evidence['evidence_hash']!=row['teacher']['evidence_hash']
                or certificate.get('scene_hash')!=scene_hash(row['scene'])
                or certificate.get('controller_hash')!=evidence['controller_hash']
                or certificate.get('plan')!=ObjectMotionPlan(()).to_dict()
                or q.get('qualified_success') is not True or q.get('task_success') is not True
                or q.get('body')!=row['body_id'] or q.get('scene_id')!=row['scene']['base_scene_id']
                or q.get('whole_episode_wall_penetration') is not False
                or q.get('whole_episode_forbidden_nonarm_contact') is not False):
            raise ValueError('invalid native geometry certificate')
        # export_teacher/verify_reference re-audit the measured robot geometry.
        # Its conservative planning circle is not the physical success criterion.
        return
    for a,b in zip(trajectory[:-1,1:],trajectory[1:,1:]):
        points = np.linspace(a,b,max(2,int(np.ceil(np.linalg.norm(b-a)/.025))+1))
        if (clearance(row["scene"],points)<=radius).any():
            raise ValueError("navigation reference crosses object/wall geometry")


def validate_navigation_context(row):
    from experiments.exp3.trajectory_v3.navigation import NAV_SCHEMA, EmbodimentSpec, scene_hash
    context = row["navigation_context"]
    if context.get("schema")!=NAV_SCHEMA:
        raise ValueError(f"stale navigation context schema: expected {NAV_SCHEMA}; recompute with the current navigator")
    if context.get("source") not in ("learned_prediction", "geometry_only_permissive"):
        raise ValueError("model navigation context requires the frozen predictor or explicit geometry-only guidance ablation")
    embodiment = EmbodimentSpec(row["structure_rows"], context["footprint_radius_m"], context["controller_hash"])
    if context.get("scene_hash")!=scene_hash(row["scene"]) or context.get("embodiment_hash")!=embodiment.identity or context.get("structure_hash")!=digest(row["structure_rows"]):
        raise ValueError("stale navigation context or embodiment mismatch")
    identity = context.get("predictor_hash", "")
    if len(identity)!=64 or any(c not in "0123456789abcdef" for c in identity):
        raise ValueError("navigation predictor identity required")
    features = np.asarray(context["object_features"], np.float32).reshape(-1,4)
    if features.shape!=(len(row["scene"]["objects"]),4) or not np.isfinite(features).all() or (features<0).any() or (features>1).any():
        raise ValueError("four finite normalized navigation features per object required")
    return features


def validate_example(row, waypoints=8):
    for field in ("scene","structure_rows","body_id","split","teacher"):
        if field not in row:
            raise ValueError(f"demonstration missing {field}")
    if row["split"] not in ("train","val","test"):
        raise ValueError("demonstrations require an explicit train/val/test split")
    teacher=row["teacher"]
    if teacher.get("source") not in ("planner_object_path","executed_object_path","navigation_execution"):
        raise ValueError("endpoint interpolation is not a trajectory demonstration")
    if teacher.get("validation") not in ("geometric","kinematic","dynamic_simulation","real_robot"):
        raise ValueError("teacher validation level required")
    evidence=teacher.get("evidence_hash","")
    if len(evidence)!=64 or any(c not in "0123456789abcdef" for c in evidence):
        raise ValueError("teacher evidence SHA256 required")
    structure=np.asarray(row["structure_rows"],dtype=float)
    if structure.ndim!=2 or structure.shape[1]!=20 or not len(structure) or not np.isfinite(structure).all():
        raise ValueError("finite structural link rows [L,20] required; no capability labels")
    plan=ObjectMotionPlan.from_dict(row["plan"])
    if "navigation_context" in row:
        validate_navigation_context(row)
    if row.get("task_status", "solved_with_interaction") not in ("solved_with_interaction","solved_without_interaction"):
        raise ValueError("failed or unresolved task outcomes are not successful plan teachers")
    if not plan.paths:
        validate_empty_reference(row)
    elif row.get("task_status")=="solved_without_interaction" or teacher["source"]=="navigation_execution":
        raise ValueError("interaction plan conflicts with navigation-only teacher status")
    work=deepcopy(row["scene"])
    ids=[o["object_id"] for o in work["objects"]]
    if len(ids)!=len(set(ids)):
        raise ValueError("scene objects must have distinct IDs")
    for path in plan.paths:
        if path.object_id not in ids:
            raise ValueError("unknown object in teacher path")
        obj=next(o for o in work["objects"] if o["object_id"]==path.object_id)
        if not np.allclose(path.start[:2],obj["pose"][:2],atol=1e-5) or abs(angle_delta(path.start[2],obj["pose"][2]))>1e-5:
            raise ValueError("path start must match the scene state at its interaction rank")
        dense=path.densify(waypoints)
        if path_collision(work,dense):
            raise ValueError("teacher object path intersects scene geometry")
        obj["pose"]=list(path.goal)
    return plan


def validate_dataset(rows, waypoints=8, holdout_bodies=(), holdout_structure_hashes=()):
    groups,seen={},set()
    predictors = {r["navigation_context"]["predictor_hash"] for r in rows if "navigation_context" in r}
    if len(predictors)>1 or (predictors and any("navigation_context" not in r for r in rows)):
        raise ValueError("dataset requires one frozen navigation predictor and complete contexts")
    for row in rows:
        validate_example(row,waypoints)
        scene=row["scene"]
        group=scene.get("layout_group_id")
        if not group:
            raise ValueError("layout_group_id required to keep paired/mirrored scenes in one split")
        split=row["split"]
        if group in groups and groups[group]!=split:
            raise ValueError("layout group leaks across dataset splits")
        groups[group]=split
        structure_hash=digest(row["structure_rows"])
        if split in ("train","val") and (row["body_id"] in holdout_bodies or structure_hash in holdout_structure_hashes):
            raise ValueError("held-out embodiment/structure appears in training or validation selection")
        key=(digest(public_scene(scene)),row["body_id"],structure_hash,digest(row["plan"]))
        if key in seen:
            raise ValueError("duplicate demonstration")
        seen.add(key)
    return {"examples":len(rows),"layout_groups":len(groups),
            "split_counts":{s:sum(r["split"]==s for r in rows) for s in ("train","val","test")}}


def raw_scene_features(scene, *, with_metadata=False):
    """Raw per-primitive geometry rows, RAW_SCENE_DIM wide.

    scene_features below averages a ramp's two ends into one height and drops the ramp axis and
    the tile friction entirely, so `flat mu=0.2` and `flat mu=0.8` produce byte-identical rows.
    An encoder fed the public schema therefore cannot separate the friction pairs even in
    principle. This keeps the same row layout and restores the dropped fields.

    Columns: cx, cy, sx, sy, h_start, h_end, axis_x, axis_y, friction, wall, terrain, start, goal.
    """
    w, h = scene["world_size"]
    rows = [[.5, .5, 1., 1., 0., 0., 0., 0., scene.get("floor_friction", .8), 0., 1., 0., 0.]]
    metadata = [dict(source_id="floor", kind="floor", bounds=[0., 0., w, h])]
    for index, (l, b, r, t) in enumerate(scene["walls"]):
        rows.append([(l + r) / (2 * w), (b + t) / (2 * h), (r - l) / w, (t - b) / h,
                     .75, .75, 0, 0, scene.get("floor_friction", .8), 1, 0, 0, 0])
        metadata.append(dict(source_id=f"wall:{index}", kind="wall", bounds=[l,b,r,t]))
    for index, tile in enumerate(scene["terrain"]):
        l, b, r, t = tile["bounds"]
        if tile.get("kind") == "ramp":
            lo, hi = tile["start_height_m"], tile["end_height_m"]
            axis = [1, 0] if tile["axis"] == 0 else [0, 1]
        else:
            lo = hi = tile["height_m"]
            axis = [0, 0]
        # A zero-height patch with floor friction is the same observed surface as the floor.
        # Keep it only when it overrides an earlier overlapping tile.
        overlaps = any(l < c and a < r and b < d and y < t
                       for a, y, c, d in (q["bounds"] for q in scene["terrain"][:index]))
        if lo == hi == 0 and tile.get("friction", .8) == scene.get("floor_friction", .8) and not overlaps:
            continue
        rows.append([(l + r) / (2 * w), (b + t) / (2 * h), (r - l) / w, (t - b) / h,
                     lo / 2, hi / 2, *axis, tile.get("friction", .8), 0, 1, 0, 0])
        metadata.append(dict(source_id=f"terrain:{index}", kind="terrain", bounds=[l,b,r,t]))
    for key, flags in (("start", [1, 0]), ("goal", [0, 1])):
        x, y = scene[key][:2]
        rows.append([x / w, y / h, 0, 0, 0, 0, 0, 0, 0, 0, 0, *flags])
        metadata.append(dict(source_id=key, kind=key, position=[x,y,0.]))
    return (rows, metadata) if with_metadata else rows


def object_features(scene):
    """The object rows collate() writes, as a standalone list for scene-only callers."""
    w, h = scene["world_size"]
    return [[o["pose"][0] / w, o["pose"][1] / h, math.sin(o["pose"][2]), math.cos(o["pose"][2]),
             *o["size"], o["mass_kg"] / 20, o["friction"]] for o in scene["objects"]]


def traversal_crop(scene, scene_mask, objects, object_mask, query, world_size, radius):
    """Crop raw primitives to a metric observation window centred on the queried edge.

    This changes coordinates and clips geometry, as an image crop would; it computes no
    traversability features. Ramp endpoint heights are interpolated to the clipped bounds. The
    explicit floor token covers un-tiled ground, including scenes with no terrain rows.
    """
    import torch
    if scene.shape[-1] != 13 or not torch.isfinite(world_size).all() or (world_size <= 0).any():
        raise ValueError("raw 13-D scene primitives and positive world extents required")
    centre = query[:, None, -2:] * world_size[:, None]
    lower = (scene[..., :2] - scene[..., 2:4] / 2) * world_size[:, None] - centre
    upper = (scene[..., :2] + scene[..., 2:4] / 2) * world_size[:, None] - centre
    lo, hi = lower.clamp(-radius, radius), upper.clamp(-radius, radius)
    mask = scene_mask & (hi > lo).all(-1)
    cropped = scene.clone()
    cropped[..., :2] = ((lo + hi) / 2 + radius) / (2 * radius)
    cropped[..., 2:4] = (hi - lo) / (2 * radius)
    axis = scene[..., 6:8]
    span = ((upper - lower) * axis).sum(-1).clamp_min(1e-6)
    height_delta = scene[..., 5] - scene[..., 4]
    cropped[..., 4] = scene[..., 4] + height_delta * ((lo - lower) * axis).sum(-1) / span
    cropped[..., 5] = scene[..., 4] + height_delta * ((hi - lower) * axis).sum(-1) / span
    if objects is not None:
        objects = objects.clone()
        xy = objects[..., :2] * world_size[:, None] - centre
        # Bounding circle retains rotated boxes intersecting the crop; the encoder still sees
        # exact size and yaw. Hard collision clearance remains in TerrainNavigator.
        reach = objects[..., 4:6].norm(dim=-1, keepdim=True) / 2
        object_mask = object_mask & (xy.abs() < radius + reach).all(-1)
        objects[..., :2] = (xy + radius) / (2 * radius)
    query = query.clone()
    query[:, -2:] = .5
    query[:, 4] = 0  # clearance is read from local geometry, not the hand-built r_e field
    return cropped, mask, objects, object_mask, query


def scene_features(scene, dim=9, *, with_metadata=False):
    if dim == 13:
        return raw_scene_features(scene, with_metadata=with_metadata)
    if dim != 9:
        raise ValueError("scene feature dimension must be 9 or 13")
    w,h=scene["world_size"]
    features=[]; metadata=[]
    for index,(l,b,r,t) in enumerate(scene["walls"]):
        features.append([(l+r)/(2*w),(b+t)/(2*h),(r-l)/w,(t-b)/h,.75,1,0,0,0])
        metadata.append(dict(source_id=f"wall:{index}",kind="wall",bounds=[l,b,r,t]))
    for index,tile in enumerate(scene["terrain"]):
        l,b,r,t=tile["bounds"]
        height=(tile["start_height_m"]+tile["end_height_m"])/2 if tile.get("kind")=="ramp" else tile["height_m"]
        features.append([(l+r)/(2*w),(b+t)/(2*h),(r-l)/w,(t-b)/h,height/2,0,1,0,0])
        metadata.append(dict(source_id=f"terrain:{index}",kind="terrain",bounds=[l,b,r,t]))
    for key,flags in (("start",[1,0]),("goal",[0,1])):
        x,y=scene[key][:2]
        features.append([x/w,y/h,0,0,0,0,0,*flags])
        metadata.append(dict(source_id=key,kind=key,position=[x,y,0.]))
    return (features,metadata) if with_metadata else features


def collate(rows, waypoints=8, device="cpu", include_targets=True, scene_dim=9):
    import torch
    b,n,l,s=len(rows),max(1,max(len(r["scene"]["objects"]) for r in rows)),max(len(r["structure_rows"]) for r in rows),max(len(scene_features(r["scene"], scene_dim)) for r in rows)
    arrays=dict(object_features=np.zeros((b,n,9),np.float32),scene_features=np.zeros((b,s,scene_dim),np.float32),
                structure=np.zeros((b,l,20),np.float32),object_mask=np.zeros((b,n),bool),
                scene_mask=np.zeros((b,s),bool),structure_mask=np.zeros((b,l),bool),
                rank=np.full((b,n),-1,np.int64),path_code=np.zeros((b,n,(waypoints-1)*4),np.float32))
    navigation_present = ["navigation_context" in row for row in rows]
    if any(navigation_present):
        if not all(navigation_present):
            raise ValueError("mixed missing navigation contexts in batch")
        arrays["navigation_features"] = np.zeros((b,n,4),np.float32)
    for k,row in enumerate(rows):
        scene=row["scene"]; w,h=scene["world_size"]
        if all(navigation_present):
            arrays["navigation_features"][k,:len(scene["objects"])]=validate_navigation_context(row)
        for i,obj in enumerate(scene["objects"]):
            x,y,yaw=obj["pose"]
            arrays["object_features"][k,i]=[x/w,y/h,math.sin(yaw),math.cos(yaw),
                                             *obj["size"],obj["mass_kg"]/20,obj["friction"]]
            arrays["object_mask"][k,i]=True
        geometry=scene_features(scene, scene_dim); links=row["structure_rows"]
        arrays["scene_features"][k,:len(geometry)]=geometry; arrays["scene_mask"][k,:len(geometry)]=True
        arrays["structure"][k,:len(links)]=links; arrays["structure_mask"][k,:len(links)]=True
        if include_targets:
            plan=validate_example(row,waypoints)
            slots={o["object_id"]:i for i,o in enumerate(scene["objects"])}
            for rank,path in enumerate(plan.paths):
                i=slots[path.object_id]; arrays["rank"][k,i]=rank
                p=np.asarray(path.densify(waypoints).poses)[1:]
                # path code is RELATIVE to the observed object start (2026-09-09): the absolute
                # encoding made the flow regress world positions and miss narrow gates by ~0.5 m
                x0,y0=path.start[:2]
                code=np.column_stack([(p[:,0]-x0)/w,(p[:,1]-y0)/h,np.sin(p[:,2]),np.cos(p[:,2])])
                arrays["path_code"][k,i]=code.ravel()
    return {k:torch.as_tensor(v,device=device) for k,v in arrays.items()}


def decode_plan(scene, output, batch_index=0, straight=False):
    """Raw decode of the sampled path code, or the declared `chord` contract.

    straight=True keeps the sampled start and end pose of every selected object and replaces the
    intermediate waypoints by the straight densified chord between them. Every teacher path in
    this dataset is a straight push (lateral offset and yaw change identically zero), so the
    intermediate free waypoints carry no demonstrated information; on the frozen executors their
    residual curvature is what turns a correct endpoint into object_path_failed. Applied
    identically to every method; the raw decode is still recorded by the proposer.
    """
    selected=output["selected"][batch_index].cpu().numpy()
    rank=output["rank"][batch_index].cpu().numpy()
    codes=output["path_code"][batch_index].cpu().numpy()
    paths=[]
    w,h=scene["world_size"]
    for slot in sorted(np.where(selected)[0],key=lambda i:rank[i]):
        obj=scene["objects"][slot]; code=codes[slot].reshape(-1,4)
        if not np.isfinite(code).all() or (np.linalg.norm(code[:,2:],axis=1)<1e-6).any():
            raise ValueError("invalid raw generated path; no implicit repair")
        poses=np.column_stack([code[:,0]*w+obj["pose"][0],code[:,1]*h+obj["pose"][1],np.arctan2(code[:,2],code[:,3])])
        path=ObjectPath(obj["object_id"],(tuple(obj["pose"]),*map(tuple,poses)))
        if straight:
            path=ObjectPath(path.object_id,(path.start,path.goal),path.body_part).densify(len(path.poses))
        paths.append(path)
    return ObjectMotionPlan(tuple(paths))
