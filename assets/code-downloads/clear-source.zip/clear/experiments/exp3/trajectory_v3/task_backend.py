"""Simulated task backend for run_navigation_episode.

KINEMATIC PROXY, NOT DYNAMICS. Terrain transitions succeed with the probability the frozen
controller measured on the nearest probe condition (oracle_capability.ProbeTablePredictor);
pushes succeed with the push-table probability and then teleport the object to the path goal.
No contact, slip, tipping or timing is simulated. Time advances at fixed nominal speeds
(0.4 m/s walking, 0.15 m/s pushing). Use it to exercise the planner/executor contract and
to compare methods under one shared verifier; do not quote its success rates as physics.
"""
from copy import deepcopy
import numpy as np
from experiments.exp3.trajectory_v3.navigation import clearance, transition_features
from experiments.exp3.trajectory_v3.oracle_capability import approach_point
from experiments.exp3.trajectory_v3.scenes import overlap, rectangle_corners, wall_polygon

WALK_M_S, PUSH_M_S = .4, .15


class SimulatedTaskBackend:
    def __init__(self, scene, embodiment, oracle_navigator, oracle_assessor, rng, perturbation=None, deterministic=False):
        self.scene, self.embodiment = deepcopy(scene), embodiment
        self.navigator, self.assessor = oracle_navigator, oracle_assessor
        self.rng, self.deterministic = rng, deterministic
        self.perturbation, self.events, self.attempts = perturbation, [], 0
        self.pending = False   # perturbation armed after the matching attempt, applied at the next command
        self.t, self.trajectory = 0., []   # trajectory: [time, x, y] at every reached waypoint

    def _settle(self):
        """Apply an armed perturbation. Called at the start of the next command so the executor's
        own post-push report (checked by the driver) is unaffected: the object shifts afterwards."""
        if self.pending:
            self.pending = False; self.apply_perturbation()

    def _bernoulli(self, p):
        return bool(p >= .5) if self.deterministic else bool(self.rng.random() < p)

    def observe_task(self):
        return dict(scene=deepcopy(self.scene), time_s=self.t, linear_speed_m_s=0., angular_speed_rad_s=0., safe=True)

    def hold(self):
        self._settle(); self.t += .1

    def edge_probabilities(self, route):
        pts = np.asarray([p[:2] for p in route], float)
        a, b = pts[:-1], pts[1:]
        keep = np.linalg.norm(b-a, axis=1) > 1e-9
        prob = np.ones(len(a))
        if keep.any():
            gap = np.array([clearance(self.scene, np.linspace(x, y, 5)).min() for x, y in zip(a[keep], b[keep])])
            features = transition_features(self.scene, a[keep], b[keep], self.embodiment.footprint_radius_m, gap)
            prob[keep] = self.navigator.predictor.predict(features, self.embodiment)
        return pts, prob

    def navigate(self, route):
        """One Bernoulli draw per contiguous non-trivial transition (min edge probability), as the
        probes measured whole-transition success. Failure leaves the robot before the transition."""
        self._settle()
        started=self.t
        def finish(success):
            # A rejected/no-op command still consumes one proxy control tick.
            # Successful motion and failures after progress retain their exact
            # existing times, RNG draws and poses.
            if self.t<=started:self.t=started+.1
            return success
        pts, prob = self.edge_probabilities(route)
        if not self.trajectory:
            self.trajectory.append([self.t, float(pts[0][0]), float(pts[0][1])])

        blocked = []
        from experiments.exp3.trajectory_v3.navigation import clearance as _clearance
        radius = self.embodiment.footprint_radius_m

        def step(k):
            length = float(np.linalg.norm(pts[k+1]-pts[k]))
            if length < 1e-9:
                return
            # the route was planned on an earlier observation: a waypoint that is now inside an
            # object / wall footprint stops the robot instead of walking through it
            if float(_clearance(self.scene, pts[k+1][None])[0]) <= radius:
                blocked.append(k); return
            self.t += length/WALK_M_S
            self.scene["start"] = [float(pts[k+1][0]), float(pts[k+1][1]), 0.]
            self.trajectory.append([self.t, *self.scene["start"][:2]])
        i = 0
        while i < len(prob) and not blocked:
            if np.isfinite(prob[i]) and prob[i] >= 1.:
                step(i); i += 1; continue
            j = i
            while j < len(prob) and not (np.isfinite(prob[j]) and prob[j] >= 1.):
                j += 1
            p = float(prob[i:j].min()) if np.isfinite(prob[i:j]).all() else 0.
            if not self._bernoulli(p):
                self.events.append(dict(kind="navigation_failed", at=list(map(float, pts[i])), probability=p, time_s=self.t))
                return finish(False)
            for k in range(i, j):
                step(k)
                if blocked:
                    break
            i = j
        if blocked:
            # back off along the walked route to a spot the navigator can plan from (outside its
            # inflation radius + resolution/sqrt2); the halt and the retreat take time
            k = blocked[0]
            while k > 0 and float(_clearance(self.scene, pts[k][None])[0]) < radius + .1:
                k -= 1
            self.t += .1 + float(np.linalg.norm(pts[blocked[0]]-pts[k]))/WALK_M_S
            self.scene["start"] = [float(pts[k][0]), float(pts[k][1]), 0.]
            self.trajectory.append([self.t, *self.scene["start"][:2]])
            self.events.append(dict(kind="route_blocked_by_moved_geometry", at=list(map(float, pts[blocked[0]+1])),
                                    halted_at=self.scene["start"][:2], time_s=self.t))
        return finish(not blocked)

    def interact_trajectory(self, path):
        self._settle()
        obj = next(o for o in self.scene["objects"] if o["object_id"] == path.object_id)
        assessment = self.assessor.assess(self.scene, self.embodiment, path, self.navigator.analyze(self.scene, self.embodiment))
        self.attempts += 1
        poses = np.asarray(path.poses)
        length = float(np.linalg.norm(np.diff(poses[:, :2], axis=0), axis=1).sum())
        self.t += max(length, .1)/PUSH_M_S
        if assessment.status != "candidate_feasible":
            result = dict(success=False, info=dict(reason=assessment.evidence.get("reason", assessment.status)))
        elif self._bernoulli(assessment.evidence["push_probability"]):
            obj["pose"] = list(map(float, path.goal))
            self.scene["start"] = [*map(float, assessment.predicted_robot_xy_after), 0.]
            result = dict(success=True, info=dict(push_probability=assessment.evidence["push_probability"]))
        else:
            u = float(self.rng.uniform(.1, .9))*(len(poses)-1)
            k = int(u); a, b = poses[k], poses[min(k+1, len(poses)-1)]
            obj["pose"] = list(map(float, a+(b-a)*(u-k)))
            self.scene["start"] = [*map(float, approach_point(path)), 0.]
            result = dict(success=False, info=dict(reason="push_failed_midway"))
        if self.perturbation and self.perturbation["after_interaction_index"] == self.attempts-1:
            self.pending = True
        return result

    def apply_perturbation(self):
        p = self.perturbation
        obj = next(o for o in self.scene["objects"] if o["object_id"] == p["object_id"])
        obstacles = [wall_polygon(w) for w in self.scene["walls"]]
        obstacles += [rectangle_corners(o["pose"], o["size"]) for o in self.scene["objects"] if o["object_id"] != p["object_id"]]
        # the robot is part of the world: a declared translation cannot land the object on top of it
        # (STUDY_DESIGN clips against wall/object overlap; the robot footprint counts as an object)
        rx, ry = self.scene["start"][:2]; rr = self.embodiment.footprint_radius_m + .15
        obstacles.append(rectangle_corners([rx, ry, 0.], [2*rr, 2*rr, 0.]))
        x, y, yaw = obj["pose"]; w, h = self.scene["world_size"]
        realized = 0.
        for f in np.linspace(1., 0., 21):   # largest translation fraction that overlaps nothing
            pose = [x+f*p["dx"], y+f*p["dy"], yaw]
            poly = rectangle_corners(pose, obj["size"])
            if (poly >= 0).all() and (poly <= [w, h]).all() and not any(overlap(poly, o) for o in obstacles):
                obj["pose"] = pose; realized = f
                break
        self.events.append(dict(kind=p["kind"], object_id=p["object_id"], requested=[p["dx"], p["dy"]],
                                realized=[realized*p["dx"], realized*p["dy"]], time_s=self.t))
