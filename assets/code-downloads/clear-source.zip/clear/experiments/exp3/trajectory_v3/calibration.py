from collections import defaultdict
import hashlib
import json
import math


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def summarize_probes(records, min_trials=10):
    if min_trials < 1:
        raise ValueError("min_trials must be positive")
    groups, seen = defaultdict(list), set()
    for row in records:
        required = ("body_id", "structure_hash", "controller_hash", "scene_hash", "kind", "condition",
                    "execution_seed", "success", "collision", "fell", "backend", "evidence_hash")
        if any(k not in row for k in required):
            raise ValueError("probe record lacks provenance or outcome fields")
        if row["backend"] not in ("dynamic_simulation", "real_robot"):
            raise ValueError("nominal, geometric and abstract probes cannot calibrate physical capability")
        if not all(isinstance(row[k], bool) for k in ("success", "collision", "fell")):
            raise ValueError("probe outcomes must be booleans")
        for key in ("structure_hash", "controller_hash", "scene_hash", "evidence_hash"):
            value = row[key]
            if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise ValueError(f"{key} must be a SHA256 digest")
        group = tuple(row[k] for k in ("body_id", "structure_hash", "controller_hash", "backend", "kind")) + (digest(row["condition"]),)
        unit = group + (row["scene_hash"], row["execution_seed"])
        if unit in seen:
            raise ValueError("duplicate probe trial")
        seen.add(unit)
        groups[group].append(row)
    out = []
    for key, rows in sorted(groups.items()):
        n = len(rows)
        successes = sum(r["success"] and not r["collision"] and not r["fell"] for r in rows)
        p, z = successes / n, 1.959963984540054
        center = (p + z*z/(2*n)) / (1 + z*z/n)
        half = z * math.sqrt(p*(1-p)/n + z*z/(4*n*n)) / (1 + z*z/n)
        out.append(dict(body_id=key[0], structure_hash=key[1], controller_hash=key[2], backend=key[3],
                        kind=key[4], condition=rows[0]["condition"], trials=n, successes=successes,
                        success_rate=p, ci95=[center-half, center+half], sufficient_trials=n >= min_trials,
                        evidence_hashes=sorted({r["evidence_hash"] for r in rows})))
    return {"schema": "clear-probe-summary-v1", "min_trials": min_trials, "conditions": out,
            "scope": "observed conditions only; no monotonic mass/step limit inferred"}
