import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.navigation import EDGE_FIELDS
from clear.model.encoders import StructureEncoder

TRAVERSAL_SCHEMA = "clear-directed-traversability-v1"


class TraversabilityModel(nn.Module):
    """Legacy standalone predictor; shared_morphology.SharedMorphologyModel owns the joint path."""
    def __init__(self, dim=64, no_embodiment=False):
        super().__init__()
        self.config = dict(dim=dim, no_embodiment=no_embodiment)
        self.structure = StructureEncoder(20, dim)
        self.edge = nn.Sequential(nn.Linear(len(EDGE_FIELDS), dim), nn.GELU(), nn.Linear(dim, dim))
        self.classifier = nn.Sequential(nn.Linear(2*dim, dim), nn.GELU(), nn.Linear(dim, 1))

    def forward(self, features, structure, structure_mask):
        embodiment = self.structure.pool(structure, structure_mask)
        if self.config["no_embodiment"]:
            embodiment = torch.zeros_like(embodiment)
            features = features.clone(); features[..., 8] = 0
        return self.classifier(torch.cat([self.edge(features), embodiment], -1)).squeeze(-1)


def pack_probes(rows, device="cpu"):
    links = max(len(r["structure_rows"]) for r in rows)
    structure = torch.zeros(len(rows), links, 20, device=device)
    mask = torch.zeros(len(rows), links, dtype=torch.bool, device=device)
    for i, row in enumerate(rows):
        n = len(row["structure_rows"])
        structure[i, :n] = torch.tensor(row["structure_rows"], device=device)
        mask[i, :n] = True
    features = torch.tensor([r["edge_features"] for r in rows], dtype=torch.float32, device=device)
    return features, structure, mask


def validate_probes(rows):
    groups, seen, controllers = {}, set(), {}
    for row in rows:
        if row.get("schema") != TRAVERSAL_SCHEMA or row.get("backend") not in ("dynamic_simulation", "real_robot"):
            raise ValueError("actual directed traversal probe records required")
        if row.get("edge_fields") != list(EDGE_FIELDS):
            raise ValueError("directed transition feature schema mismatch")
        features, structure = np.asarray(row["edge_features"], float), np.asarray(row["structure_rows"], float)
        if features.shape != (len(EDGE_FIELDS),) or not np.isfinite(features).all():
            raise ValueError("finite directed edge features required")
        if structure.ndim != 2 or structure.shape[1] != 20 or not len(structure) or not np.isfinite(structure).all():
            raise ValueError("finite structure rows required")
        for name in ("structure_hash", "controller_hash", "scene_hash", "evidence_hash"):
            value = row.get(name, "")
            if len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise ValueError("probe SHA256 missing: "+name)
        if row["structure_hash"] != digest(row["structure_rows"]):
            raise ValueError("probe structure provenance mismatch")
        key = row["structure_hash"]
        if key in controllers and controllers[key] != row["controller_hash"]:
            raise ValueError("one frozen controller per structure required; controller variation is not a model feature")
        controllers[key] = row["controller_hash"]
        if any(not isinstance(row.get(k), bool) for k in ("success", "collision", "fell")):
            raise ValueError("measured boolean outcomes required")
        split, group = row.get("split"), row.get("layout_group_id")
        if split not in ("train", "val", "test") or not group:
            raise ValueError("explicit grouped split required")
        if group in groups and groups[group] != split:
            raise ValueError("traversal group leaks across splits")
        groups[group] = split
        key = (row["structure_hash"], row["controller_hash"], row["scene_hash"],
               digest(row["edge_features"]), row["execution_seed"])
        if key in seen:
            raise ValueError("duplicate physical traversal trial")
        seen.add(key)
    return {s: sum(r["split"] == s for r in rows) for s in ("train", "val", "test")}


def train_traversability(rows, output, steps=1000, batch_size=64, dim=64, seed=0,
                         device="cpu", no_embodiment=False, holdout_structures=()):
    counts = validate_probes(rows)
    if not counts["train"] or not counts["val"] or min(steps, batch_size)<1:
        raise ValueError("train/val and positive training budget required")
    if any(r["split"] in ("train", "val") and r["structure_hash"] in holdout_structures for r in rows):
        raise ValueError("held-out structure used for training or validation selection")
    output = Path(output)
    if output.exists():
        raise FileExistsError("traversability output already exists")
    output.mkdir(parents=True)
    training = [r for r in rows if r["split"] == "train"]
    validation = [r for r in rows if r["split"] == "val"]
    torch.manual_seed(seed)
    model = TraversabilityModel(dim, no_embodiment).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)
    rng = np.random.default_rng(seed); best = float("inf")
    for step in range(1, steps+1):
        batch = [training[int(i)] for i in rng.integers(len(training), size=batch_size)]
        target = torch.tensor([r["success"] and not r["collision"] and not r["fell"] for r in batch],
                              dtype=torch.float32, device=device)
        model.train(); optimizer.zero_grad(set_to_none=True)
        loss = F.binary_cross_entropy_with_logits(model(*pack_probes(batch, device)), target)
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite traversal loss")
        loss.backward(); optimizer.step()
        if step % max(1, steps//10) == 0 or step == steps:
            model.eval(); total = 0.
            with torch.no_grad():
                for i in range(0, len(validation), batch_size):
                    chunk = validation[i:i+batch_size]
                    target = torch.tensor([r["success"] and not r["collision"] and not r["fell"] for r in chunk],
                                          dtype=torch.float32, device=device)
                    total += float(F.binary_cross_entropy_with_logits(model(*pack_probes(chunk, device)), target))*len(chunk)
            score = total/len(validation)
            if not np.isfinite(score):
                raise FloatingPointError("non-finite traversal validation")
            if score < best:
                best = score
                torch.save(dict(schema=TRAVERSAL_SCHEMA, edge_fields=list(EDGE_FIELDS), config=model.config,
                                state_dict=model.state_dict(), step=step, validation_bce=score,
                                controller_hashes=sorted({r["controller_hash"] for r in training}),
                                controller_profiles={r["structure_hash"]:r["controller_hash"] for r in training},
                                validation_status="development_only; probability calibration pending"), output/"best.pt")
    report = dict(schema=TRAVERSAL_SCHEMA, split_counts=counts, steps=steps, seed=seed,
                  data_hash=digest(rows), best_validation_bce=best, physical_navigation_evaluated=False)
    (output/"training.json").write_text(json.dumps(report, indent=2)+"\n")
    return report


class LearnedTraversalPredictor:
    source = "learned_prediction"

    def __init__(self, checkpoint, device="cpu", additional_frozen_controllers=()):
        value = torch.load(checkpoint, map_location=device, weights_only=True)
        if value.get("schema") != TRAVERSAL_SCHEMA or value.get("edge_fields") != list(EDGE_FIELDS):
            raise ValueError("incompatible traversability checkpoint")
        self.model = TraversabilityModel(**value["config"]).to(device).eval()
        self.model.load_state_dict(value["state_dict"])
        self.device = device
        self.controllers = set(value["controller_hashes"]) | set(additional_frozen_controllers)
        self.profiles = value["controller_profiles"]
        self.identity = digest(dict(checkpoint=hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest(),
                                    frozen_controllers=sorted(self.controllers)))
        self.validation_status = value["validation_status"]

    @torch.no_grad()
    def predict(self, features, embodiment):
        if embodiment.controller_hash not in self.controllers:
            return np.full(len(features), np.nan)
        known_controller = self.profiles.get(digest(embodiment.structure_rows))
        if known_controller is not None and known_controller != embodiment.controller_hash:
            return np.full(len(features), np.nan)
        results = []
        for start in range(0, len(features), 2048):
            chunk = features[start:start+2048]
            rows = torch.tensor(embodiment.structure_rows, dtype=torch.float32, device=self.device)
            structure = rows[None].expand(len(chunk), -1, -1)
            mask = torch.ones(structure.shape[:2], dtype=torch.bool, device=self.device)
            x = torch.as_tensor(chunk, dtype=torch.float32, device=self.device)
            results.append(torch.sigmoid(self.model(x, structure, mask)).cpu().numpy())
        return np.concatenate(results) if results else np.empty(0)
