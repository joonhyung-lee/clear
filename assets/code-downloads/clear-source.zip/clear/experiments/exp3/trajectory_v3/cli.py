import argparse
import hashlib
import json
from pathlib import Path


def read_jsonl(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def train(args):
    import torch
    from experiments.exp3.trajectory_v3.model import ObjectMotionModel
    from experiments.exp3.trajectory_v3.data import collate, validate_dataset
    from experiments.exp3.trajectory_v3.contracts import SCHEMA
    config=json.loads(Path(args.config).read_text())
    model_config=config["model"]
    rows=read_jsonl(args.data)
    summary=validate_dataset(rows,model_config["waypoints"],config.get("holdout_bodies",()),
                             config.get("holdout_structure_hashes",()))
    if not args.allow_geometric_teacher and any(r["teacher"]["validation"]=="geometric" for r in rows):
        raise ValueError("geometric teacher requires --allow-geometric-teacher; it does not establish robot feasibility")
    training=[r for r in rows if r["split"]=="train"]
    validation=[r for r in rows if r["split"]=="val"]
    if not training or not validation:
        raise ValueError("disjoint nonempty train and validation sets required")
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()):
        raise FileExistsError("training output must be empty")
    settings=config["train"]
    if min(settings["steps"],settings["batch_size"],settings["eval_every"])<1:
        raise ValueError("positive steps, batch_size and eval_every required")
    torch.manual_seed(args.seed)
    model=ObjectMotionModel(**model_config).to(args.device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=settings["lr"])
    generator=torch.Generator(device=args.device).manual_seed(args.seed)
    sampling=torch.Generator().manual_seed(args.seed)
    best=float("inf")
    history=[]
    # Collate the whole split once and slice on the device: per-step collate was CPU-bound
    # (2026-09-09: < 2 steps/s with eight trainings sharing the host).
    full=collate(training,model_config["waypoints"],args.device)
    val_batches=[collate(validation[start:start+settings["batch_size"]],model_config["waypoints"],args.device)
                 for start in range(0,len(validation),settings["batch_size"])]
    for step in range(1,settings["steps"]+1):
        indices=torch.randint(len(training),(settings["batch_size"],),generator=sampling).to(args.device)
        batch={k:v[indices] for k,v in full.items()}
        model.train();optimizer.zero_grad(set_to_none=True)
        loss,terms=model.loss(batch,generator)
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite training loss")
        loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);optimizer.step()
        if step%settings["eval_every"]==0 or step==settings["steps"]:
            model.eval();total,count=0.,0
            val_rng=torch.Generator(device=args.device).manual_seed(0)
            with torch.no_grad():
                for vb in val_batches:
                    n=int(vb["object_mask"].shape[0])
                    val,_=model.loss(vb,val_rng)
                    total+=float(val)*n;count+=n
            score=total/count
            if not __import__("math").isfinite(score):
                raise FloatingPointError("non-finite validation loss")
            history.append(dict(step=step,train_loss=float(loss.detach()),val_loss=score,terms=terms))
            record=dict(schema=SCHEMA,model_config=model_config,state_dict=model.state_dict(),
                        step=step,seed=args.seed,validation_loss=score)
            torch.save(record,out/"last.pt")
            # --select flow: pick the checkpoint by the training flow term. The total validation
            # loss is dominated by selection/order noise on small datasets and stops improving
            # long before the path flow has converged (2026-09-09: best.pt at step 500 produced
            # paths that collided with every gate).
            criterion=terms["flow"] if getattr(args,"select","total")=="flow" else score
            if criterion<best:
                best=criterion
                torch.save(record,out/"best.pt")
            (out/"loss.json").write_text(json.dumps(history,indent=2)+"\n")
    report=dict(schema=SCHEMA,seed=args.seed,device=args.device,dataset=summary,
                data_sha256=hashlib.sha256(Path(args.data).read_bytes()).hexdigest(),
                config=config,teacher_validation_levels=sorted({r["teacher"]["validation"] for r in rows}),
                status="training_completed; physical performance not evaluated")
    (out/"training.json").write_text(json.dumps(report,indent=2)+"\n")
    return report


def infer(args):
    import torch
    from experiments.exp3.trajectory_v3.contracts import SCHEMA
    from experiments.exp3.trajectory_v3.model import ObjectMotionModel
    from experiments.exp3.trajectory_v3.data import collate, decode_plan
    checkpoint=torch.load(args.checkpoint,map_location=args.device,weights_only=True)
    if checkpoint.get("schema")!=SCHEMA:
        raise ValueError("legacy endpoint checkpoints cannot load into the object-path model")
    model=ObjectMotionModel(**checkpoint["model_config"]).to(args.device)
    model.load_state_dict(checkpoint["state_dict"],strict=True);model.eval()
    observation=json.loads(Path(args.observation).read_text())
    batch=collate([observation],checkpoint["model_config"]["waypoints"],args.device,include_targets=False)
    generator=torch.Generator(device=args.device).manual_seed(args.seed)
    output=model.sample(batch,steps=args.steps,generator=generator)
    plan=decode_plan(observation["scene"],output)
    result=dict(plan=plan.to_dict(),status="raw_prediction; feasibility and execution unverified")
    destination=Path(args.out)
    if destination.exists():
        raise FileExistsError("inference output already exists")
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(result,indent=2)+"\n")
    return result


def main(argv=None):
    parser=argparse.ArgumentParser(description="CLEAR experiment 3 object-path groundwork")
    commands=parser.add_subparsers(dest="command",required=True)
    p=commands.add_parser("pilot");p.add_argument("--out",required=True);p.add_argument("--per-family",type=int,default=10)
    p.add_argument("--seed",type=int,default=0);p.add_argument("--bodies",nargs="+",default=["husky","spot","spot_arm","g1"])
    p=commands.add_parser("primary-pilot");p.add_argument("--out",required=True);p.add_argument("--per-case",type=int,default=2)
    p.add_argument("--seed",type=int,default=0);p.add_argument("--bodies",nargs="+",default=["g1","spot_arm"])
    p=commands.add_parser("calibrate");p.add_argument("--records",required=True);p.add_argument("--out",required=True)
    p.add_argument("--min-trials",type=int,default=10)
    p=commands.add_parser("validate-data");p.add_argument("--data",required=True);p.add_argument("--waypoints",type=int,default=8)
    p.add_argument("--holdout-bodies",nargs="*",default=[]);p.add_argument("--holdout-structure-hashes",nargs="*",default=[])
    p=commands.add_parser("train");p.add_argument("--data",required=True);p.add_argument("--out",required=True)
    p.add_argument("--config",default="experiments/exp3/configs/trajectory_v3.json")
    p.add_argument("--device",default="cpu");p.add_argument("--seed",type=int,default=0)
    p.add_argument("--allow-geometric-teacher",action="store_true")
    p.add_argument("--select",choices=("total","flow"),default="total")
    p=commands.add_parser("infer");p.add_argument("--checkpoint",required=True);p.add_argument("--observation",required=True)
    p.add_argument("--out",required=True);p.add_argument("--device",default="cpu");p.add_argument("--seed",type=int,default=0)
    p.add_argument("--steps",type=int,default=30)
    args=parser.parse_args(argv)
    if args.command=="pilot":
        from experiments.exp3.trajectory_v3.scenes import write_pilot
        result=write_pilot(args.out,args.per_family,args.seed,args.bodies)
        result={k:v for k,v in result.items() if k!="audits"}
    elif args.command=="primary-pilot":
        from experiments.exp3.trajectory_v3.scenes import write_primary_pilot
        result=write_primary_pilot(args.out,args.per_case,args.seed,args.bodies)
        result={k:v for k,v in result.items() if k!="audits"}
    elif args.command=="calibrate":
        from experiments.exp3.trajectory_v3.calibration import summarize_probes
        result=summarize_probes(read_jsonl(args.records),args.min_trials)
        destination=Path(args.out)
        if destination.exists():
            raise FileExistsError("calibration output already exists")
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps(result,indent=2)+"\n")
    elif args.command=="validate-data":
        from experiments.exp3.trajectory_v3.data import validate_dataset
        result=validate_dataset(read_jsonl(args.data),args.waypoints,args.holdout_bodies,args.holdout_structure_hashes)
    elif args.command=="train":
        result=train(args)
    else:
        result=infer(args)
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
