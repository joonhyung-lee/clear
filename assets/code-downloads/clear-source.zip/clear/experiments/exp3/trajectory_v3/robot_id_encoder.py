"""Learned robot-ID baseline; structural rows identify an ID but are never encoded."""
import torch
from torch import nn
from torch.nn import functional as F


class CanonicalStructureLookup(nn.Module):
    """Resolve frozen structure metadata; never infer an ID from approximate features."""
    def __init__(self, structures):
        super().__init__()
        rows = [torch.as_tensor(s, dtype=torch.float32) for s in structures]
        if not rows or any(s.ndim != 2 or s.shape[1] != 20 or not len(s) or
                           not torch.isfinite(s).all() for s in rows):
            raise ValueError('nonempty finite canonical 20-D structures required')
        length = max(map(len, rows))
        values = torch.stack([F.pad(s, (0, 0, 0, length-len(s))) for s in rows])
        masks = torch.arange(length)[None] < torch.tensor(list(map(len, rows)))[:, None]
        if any(torch.equal(values[i], values[j]) and torch.equal(masks[i], masks[j])
               for i in range(len(rows)) for j in range(i)):
            raise ValueError('robot IDs need distinct canonical structures')
        self.register_buffer('canonical_rows', values)
        self.register_buffer('canonical_mask', masks)

    def indices(self, structure, structure_mask):
        length = max(structure.shape[1], self.canonical_rows.shape[1])
        values = F.pad(structure, (0, 0, 0, length-structure.shape[1]))
        masks = F.pad(structure_mask, (0, length-structure_mask.shape[1]))
        canonical = F.pad(self.canonical_rows, (0, 0, 0, length-self.canonical_rows.shape[1]))
        canonical_mask = F.pad(self.canonical_mask, (0, length-self.canonical_mask.shape[1]))
        same_rows = ((values[:, None] == canonical[None]) | ~masks[:, None, :, None]).all(-1).all(-1)
        matches = same_rows & (masks[:, None] == canonical_mask[None]).all(-1)
        if not (matches.sum(-1) == 1).all():
            raise ValueError('unknown or ambiguous robot ID; no morphology fallback')
        return matches.long().argmax(-1)


class RobotIDEncoder(CanonicalStructureLookup):
    def __init__(self, structures, dim):
        super().__init__(structures)
        self.embedding = nn.Embedding(len(structures), dim)

    def pool(self, structure, structure_mask):
        return self.embedding(self.indices(structure, structure_mask))
