"""Opt-in object-path research pipeline; legacy maze checkpoints are unchanged."""

from experiments.exp3.trajectory_v3.contracts import ObjectPath, ObjectMotionPlan

__all__ = [
    'ObjectPath',
    'ObjectMotionPlan',
]
