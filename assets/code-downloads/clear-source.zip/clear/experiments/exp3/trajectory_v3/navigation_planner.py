from copy import deepcopy
from dataclasses import dataclass, field
from itertools import islice
import math
import numpy as np
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, angle_delta
from experiments.exp3.trajectory_v3.navigation import scene_hash
from experiments.exp3.trajectory_v3.scenes import path_collision


@dataclass(frozen=True)
class InteractionAssessment:
    status: str
    approach_xy: tuple | None = None
    predicted_robot_xy_after: tuple | None = None
    source: str = "unavailable"
    evidence: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.status not in ("candidate_feasible", "rejected", "unknown"):
            raise ValueError("explicit interaction assessment status required")
        if self.status == "candidate_feasible":
            if self.source == "unavailable":
                raise ValueError("feasibility source required")
            for point in (self.approach_xy, self.predicted_robot_xy_after):
                if np.asarray(point).shape != (2,) or not np.isfinite(point).all():
                    raise ValueError("approach and predicted post-interaction robot positions required")


class UnavailableInteractionAssessor:
    def assess(self, scene, embodiment, path, navigation):
        return InteractionAssessment("unknown", evidence={"reason": "native path/contact validation not connected"})


@dataclass
class NavigationDecision:
    status: str
    scene_hash: str
    embodiment_hash: str
    plan: ObjectMotionPlan
    route: tuple | None
    trace: list
    planning_calls: int = 1


def validate_sequence(scene, embodiment, plan, navigator, assessor):
    work = deepcopy(scene); steps = []
    for path in plan.paths:
        obj = next((o for o in work["objects"] if o["object_id"] == path.object_id), None)
        if obj is None:
            return None, "UNKNOWN_OBJECT"
        if np.linalg.norm(np.asarray(path.start[:2])-obj["pose"][:2])>.08 or abs(angle_delta(path.start[2], obj["pose"][2]))>.12:
            return None, "PATH_START_MISMATCH"
        if path_collision(work, path):
            return None, "OBJECT_PATH_COLLISION"
        navigation = navigator.analyze(work, embodiment)
        assessment = assessor.assess(work, embodiment, path, navigation)
        if assessment.status != "candidate_feasible":
            return None, "INTERACTION_"+assessment.status.upper()
        approach = navigation.route_to(assessment.approach_xy)
        if approach is None:
            return None, "APPROACH_ROUTE_NOT_FOUND"
        obj["pose"] = list(path.goal)
        work["start"] = [*assessment.predicted_robot_xy_after, 0.]
        steps.append(dict(path=path, approach=approach, assessment=assessment))
    navigation = navigator.analyze(work, embodiment)
    if navigation.goal_route is None:
        return None, "POST_INTERACTION_GOAL_ROUTE_NOT_FOUND"
    return dict(steps=steps, route=navigation.goal_route), None


class NavigationInteractionPlanner:
    def __init__(self, navigator, proposer, assessor=None, max_candidates=8, *, validation_navigator=None):
        if max_candidates<1:
            raise ValueError("positive candidate budget required")
        self.navigator, self.proposer = navigator, proposer
        self.validation_navigator = navigator if validation_navigator is None else validation_navigator
        self.assessor = assessor or UnavailableInteractionAssessor()
        self.max_candidates = max_candidates

    def decide(self, scene, embodiment):
        navigation = self.navigator.analyze(scene, embodiment)
        trace = [dict(event="traversability", source=navigation.source,
                      predictor_hash=navigation.predictor_hash, unknown_edges=navigation.unknown_edges)]
        arguments = dict(scene_hash=scene_hash(scene), embodiment_hash=embodiment.identity, trace=trace)
        if navigation.goal_route is not None:
            trace.append(dict(event="zero_interaction_route", status="predicted_reachable"))
            return NavigationDecision("navigate", plan=ObjectMotionPlan(()), route=navigation.goal_route, **arguments)
        best, best_cost = None, (math.inf, math.inf)
        for i, plan in enumerate(islice(self.proposer(scene, embodiment, navigation.model_context()), self.max_candidates)):
            if not isinstance(plan, ObjectMotionPlan):
                raise TypeError("proposer must return ObjectMotionPlan candidates")
            if not plan.paths:
                trace.append(dict(candidate=i, rejection="EMPTY_WITHOUT_GOAL_ROUTE")); continue
            result, failure = validate_sequence(scene, embodiment, plan, self.validation_navigator, self.assessor)
            trace.append(dict(candidate=i, order=[p.object_id for p in plan.paths], rejection=failure))
            if failure:
                continue
            length = sum(np.linalg.norm(np.diff(np.asarray(p.poses)[:, :2], axis=0), axis=1).sum() for p in plan.paths)
            cost = (len(plan.paths), float(length))
            if cost<best_cost:
                best, best_cost = plan, cost
        if best is None:
            trace.append(dict(event="no_valid_plan_found", infeasibility_proven=False))
            return NavigationDecision("no_valid_plan_found", plan=ObjectMotionPlan(()), route=None, **arguments)
        return NavigationDecision("interact", plan=best, route=None, **arguments)


class NeuralObjectProposer:
    def __init__(self, checkpoint, candidates=8, flow_steps=30, seed=0, device="cpu", max_interactions=None):
        import torch
        from experiments.exp3.trajectory_v3.model import ObjectMotionModel
        from experiments.exp3.trajectory_v3.contracts import SCHEMA
        value = torch.load(checkpoint, map_location=device, weights_only=True)
        if value.get("schema") != SCHEMA or value["model_config"].get("navigation_features") != 4:
            raise ValueError("navigation-conditioned object-path checkpoint required; legacy model is not silently substituted")
        self.model = ObjectMotionModel(**value["model_config"]).to(device).eval()
        self.model.load_state_dict(value["state_dict"])
        self.candidates, self.flow_steps, self.device = candidates, flow_steps, device
        if max_interactions is not None and max_interactions<0:
            raise ValueError("max_interactions must be nonnegative")
        self.max_interactions = max_interactions
        self.generator = torch.Generator(device=device).manual_seed(seed)

    path_decode = "raw"  # or "chord": see data.decode_plan(straight=True)

    def __call__(self, scene, embodiment, context):
        import json
        from experiments.exp3.trajectory_v3.data import collate, decode_plan
        row = dict(scene=scene, structure_rows=embodiment.structure_rows, navigation_context=context)
        batch = collate([row], self.model.config["waypoints"], self.device, include_targets=False,
                        scene_dim=self.model.config.get("scene_dim", 9))
        # One batched sample instead of `candidates` sequential calls: every candidate row draws
        # independent selection/flow noise from the same generator, so the proposal distribution is
        # unchanged, but the transformer runs once over a (candidates, ...) batch.
        # ponytail: batched-RNG draw order differs from the old per-candidate loop, so exact
        # numbers shift under a fixed seed (Monte-Carlo proposer, distribution identical); re-run
        # eval sweeps rather than comparing to pre-batch aggregate_metrics.json line-by-line.
        batch = {k: v.repeat(self.candidates, *([1] * (v.dim() - 1))) for k, v in batch.items()}
        limit = len(scene["objects"]) if self.max_interactions is None else self.max_interactions
        output = self.model.sample(batch, steps=self.flow_steps, generator=self.generator,
                                   sample_selection=True, max_interactions=limit)
        self.last_raw_proposals=[]
        for i in range(self.candidates):
            try:
                plan=decode_plan(scene, output, batch_index=i)
            except ValueError as error:
                raw={key:output[key][i].detach().cpu().tolist() for key in ('selected','rank','path_code')}
                # Preserve invalid draws as invalid, rather than logging a fictitious H0.
                # JSON strings retain NaN/Infinity distinctions without nonstandard JSON numbers.
                raw=json.loads(json.dumps(raw),parse_constant=lambda value:value)
                self.last_raw_proposals.append(dict(schema='clear-invalid-raw-proposal-v1',
                    decoder_error=str(error),raw_output=raw))
                yield ObjectMotionPlan(())
            else:
                # The raw decode is what is recorded; the declared contract is what is executed.
                self.last_raw_proposals.append(plan.to_dict())
                if self.path_decode == "chord":
                    plan = decode_plan(scene, output, batch_index=i, straight=True)
                yield plan


def run_navigation_episode(planner, embodiment, backend, policy="frozen", max_planning_calls=8,
                           max_interactions=8, max_time_s=120., goal_tolerance=.15, settle_s=.3, goal_settle_timeout_s=None):
    if policy not in ("frozen", "replan_after_interaction"):
        raise ValueError("explicit frozen or replan_after_interaction policy required")
    if min(max_planning_calls, max_interactions)<1 or not np.isfinite([max_time_s, goal_tolerance, settle_s]).all() or min(max_time_s, goal_tolerance, settle_s)<=0:
        raise ValueError("positive finite common episode budgets required")
    if goal_settle_timeout_s is not None and (not np.isfinite(goal_settle_timeout_s) or goal_settle_timeout_s < settle_s):
        raise ValueError("goal settle timeout must cover the required stopped interval")
    for method in ("observe_task", "navigate", "interact_trajectory", "hold"):
        if not callable(getattr(backend, method, None)):
            raise TypeError("task backend missing "+method)
    trace, calls, interactions = [], 0, 0
    observations = []
    started, last_time = None, None

    def observe():
        nonlocal started, last_time
        state = backend.observe_task()
        values = [state["time_s"], state["linear_speed_m_s"], state["angular_speed_rad_s"], *state["scene"]["start"][:2]]
        if not np.isfinite(values).all() or not isinstance(state["safe"], bool):
            raise ValueError("finite measured task observation and safety flag required")
        if started is None:
            started = state["time_s"]
        elif state["time_s"]<=last_time:
            raise RuntimeError("backend must advance simulation time after each command")
        last_time = state["time_s"]
        observations.append(dict(time_s=float(state["time_s"]),robot_pose=list(state["scene"]["start"]),
                                 linear_speed_m_s=float(state["linear_speed_m_s"]),angular_speed_rad_s=float(state["angular_speed_rad_s"]),safe=state["safe"],
                                 object_poses={str(o["object_id"]):list(o["pose"]) for o in state["scene"]["objects"]}))
        return state

    def finish(status, state):
        return dict(status=status, task_success=status=="goal_reached", planning_calls=calls,
                    attempted_interactions=interactions, elapsed_s=state["time_s"]-started,
                    final_scene_hash=scene_hash(state["scene"]), trace=trace,
                    measured_boundary_observations=observations)

    state = observe(); remaining = None
    for _ in range(10000):
        if not state["safe"]:
            return finish("execution_unsafe", state)
        if state["time_s"]-started>max_time_s:
            return finish("time_budget_exhausted", state)
        if remaining is None:
            if calls>=max_planning_calls:
                return finish("planning_budget_exhausted", state)
            decision = planner.decide(state["scene"], embodiment); calls += 1
            trace.append(dict(event="plan", status=decision.status, details=decision.trace))
            if decision.status == "no_valid_plan_found":
                return finish(decision.status, state)
            remaining = list(decision.plan.paths)
        if not remaining:
            route = planner.navigator.analyze(state["scene"], embodiment).goal_route
            if route is None:
                if policy == "replan_after_interaction":
                    remaining = None; continue
                return finish("goal_route_invalidated", state)
            success = backend.navigate(route); state = observe()
            if success is not True:
                return finish("navigation_failed", state)
            settling_start = state["time_s"]
            settle_deadline = state["time_s"] + (goal_settle_timeout_s or 0.)
            for _ in range(1000):
                scene = state["scene"]
                at_goal = np.linalg.norm(np.asarray(scene["start"][:2])-scene["goal"][:2])<=goal_tolerance
                still = abs(state["linear_speed_m_s"])<=.05 and abs(state["angular_speed_rad_s"])<=.1
                if not state["safe"] or not at_goal:
                    return finish("goal_not_reached_or_settled", state)
                if not still:
                    if goal_settle_timeout_s is None:
                        return finish("goal_not_reached_or_settled", state)
                    settling_start = None
                elif settling_start is None:
                    settling_start = state["time_s"]
                if goal_settle_timeout_s is not None and state["time_s"]>settle_deadline:
                    return finish("goal_not_reached_or_settled", state)
                if state["time_s"]-started>max_time_s:
                    return finish("time_budget_exhausted", state)
                if settling_start is not None and state["time_s"]-settling_start>=settle_s:
                    return finish("goal_reached", state)
                backend.hold(); state = observe()
            return finish("settling_update_budget_exhausted", state)
        if interactions>=max_interactions:
            return finish("interaction_budget_exhausted", state)
        validated, failure = validate_sequence(state["scene"], embodiment, ObjectMotionPlan(tuple(remaining)),
                                               planner.validation_navigator, planner.assessor)
        if failure:
            if policy == "replan_after_interaction":
                trace.append(dict(event="remaining_plan_invalidated",reason=failure))
                remaining = None; continue
            return finish("remaining_plan_invalidated:"+failure, state)
        step = validated["steps"][0]
        # A dispatched macro starts with approach, including approaches that fail.
        # Candidate generation/validation above does not consume an attempt.
        interactions += 1
        trace.append(dict(event="macro_attempt_started",attempt=interactions,
                          object_id=remaining[0].object_id,time_s=state["time_s"]))
        success = backend.navigate(step["approach"]); state = observe()
        trace.append(dict(event="macro_approach_finished",attempt=interactions,
                          success=success is True,time_s=state["time_s"]))
        if success is not True or not state["safe"]:
            if policy == "replan_after_interaction" and state["safe"]:
                # the observed world changed under the plan (e.g. an object now blocks the approach):
                # a replanning policy plans again from the measured state; frozen policies end here
                trace.append(dict(event="approach_failed_replanning"))
                remaining = None; continue
            return finish("approach_failed", state)
        if state["time_s"]-started>max_time_s:
            return finish("time_budget_exhausted", state)
        if np.linalg.norm(np.asarray(state["scene"]["start"][:2])-step["assessment"].approach_xy)>.15:
            if policy == "replan_after_interaction":
                trace.append(dict(event="approach_not_reached_replanning"))
                remaining = None; continue
            return finish("approach_not_reached", state)
        rechecked, failure = validate_sequence(state["scene"], embodiment, ObjectMotionPlan(tuple(remaining)),
                                               planner.validation_navigator, planner.assessor)
        if failure:
            if policy == "replan_after_interaction":
                trace.append(dict(event="scene_changed_during_approach",reason=failure))
                remaining = None; continue
            return finish("scene_changed_during_approach:"+failure, state)
        if np.linalg.norm(np.asarray(state["scene"]["start"][:2])-rechecked["steps"][0]["assessment"].approach_xy)>.15:
            return finish("approach_changed_after_validation", state)
        pending_hook=getattr(backend,'set_pending_paths',None)
        if callable(pending_hook):pending_hook(tuple(remaining))
        result = backend.interact_trajectory(remaining[0])
        state = observe()
        success = result.get("success") if isinstance(result, dict) else result.success
        trace.append(dict(event="interaction", object_id=remaining[0].object_id, success=success,
                          execution_info=result.get("info",{}) if isinstance(result,dict) else getattr(result,"info",{}),
                          measured_scene_hash=scene_hash(state["scene"])))
        if success is not True:
            if policy == "replan_after_interaction" and state["safe"]:
                remaining = None; continue
            return finish("interaction_failed", state)
        obj = next(o for o in state["scene"]["objects"] if o["object_id"]==remaining[0].object_id)
        path = remaining[0]
        if np.linalg.norm(np.asarray(obj["pose"][:2])-path.goal[:2])>.08 or abs(angle_delta(obj["pose"][2], path.goal[2]))>.12:
            return finish("object_goal_not_reached", state)
        remaining.pop(0)
        if policy == "replan_after_interaction":
            remaining = None
    return finish("task_update_budget_exhausted", state)
