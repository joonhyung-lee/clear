"""Atomic checkpoints and a step-indexed schedule for reproducible shared training."""
import math
import hashlib
import subprocess
import torch


def file_hash(path):
    checksum = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def source_revision():
    from clear.provenance import package_revision
    return package_revision()



def learning_rate(settings, step):
    base = float(settings["lr"])
    schedule = settings.get("schedule", "constant")
    if schedule == "constant":
        return base
    if schedule != "cosine":
        raise ValueError("schedule must be constant or cosine")
    warmup = int(settings.get("lr_warmup_steps", 0))
    minimum = float(settings.get("min_lr_ratio", .1))
    if not 0 <= warmup < settings["steps"] or not 0 <= minimum <= 1:
        raise ValueError("invalid cosine schedule settings")
    if step <= warmup:
        return base * step / max(warmup, 1)
    progress = (step - warmup) / (settings["steps"] - warmup)
    return base * (minimum + (1 - minimum) * .5 * (1 + math.cos(math.pi * progress)))


def atomic_save(record, path):
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(record, temporary)
    temporary.replace(path)


def rng_state(generator, sampling):
    return dict(noise=generator.get_state(), sampling=sampling.get_state(), cpu=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])


def restore_rng(state, generator, sampling):
    generator.set_state(state["noise"].cpu())
    sampling.set_state(state["sampling"].cpu())
    torch.set_rng_state(state["cpu"].cpu())
    if state["cuda"] and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([s.cpu() for s in state["cuda"]])
