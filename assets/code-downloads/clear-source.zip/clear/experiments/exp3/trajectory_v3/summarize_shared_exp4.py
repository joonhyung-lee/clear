"""Paired frozen/replan results for six exp4 cells, with independent training seeds."""
import argparse
from itertools import product
import json
from pathlib import Path

import numpy as np

from experiments.exp3.trajectory_v3.exp3_protocol import empty_output

POLICIES = ("frozen", "replan_after_interaction")
EVENTS = ("nominal", "placement_shift", "access_shift")


def fraction(values):
    values = list(values)
    return dict(n=len(values), mean=float(np.mean(values)) if values else None)


def summarize_seed(run, split):
    cells, configs = {}, []
    for policy, event in product(POLICIES, EVENTS):
        directory = Path(run) / f"eval_{split}_{policy}_{event}"
        report = json.loads((directory / "metrics.json").read_text())
        config = report["config"]
        if report.get("status") != "evaluation_completed" or config["mode"] != "exp4":
            raise ValueError("six completed shared exp4 evaluations required")
        if (config["policy"], config["perturbation"]) != (policy, event):
            raise ValueError("evaluation cell label mismatch")
        if config["provenance"]["split"] != split:
            raise ValueError("evaluation split mismatch")
        configs.append({k: v for k, v in config.items() if k not in ("policy", "perturbation", "execution_workers")})
        rows = [json.loads(s) for s in (directory / "episodes.jsonl").read_text().splitlines() if s.strip()]
        rows = [e for e in rows if e["method"] == "clear_shared"]
        indexed = {(e["scene_id"], e["body_id"], e["rollout_seed"]): e for e in rows}
        if len(indexed) != len(rows) or len(rows) != config["rows"] * len(config["rollout_seeds"]):
            raise ValueError("duplicate or missing paired episodes")
        cells[policy, event] = indexed
    if any(c != configs[0] for c in configs[1:]):
        raise ValueError("paired cells require identical checkpoint, data, and sampling budgets")
    keys = set(cells["frozen", "nominal"])
    if any(set(c) != keys for c in cells.values()):
        raise ValueError("paired episode identities differ")
    if any(len({c[key]["rng_seed"] for c in cells.values()}) != 1 for key in keys):
        raise ValueError("paired cells require common episode random seeds")
    metrics = {}
    for (policy, event), rows in cells.items():
        metrics[f"{policy}|{event}|success"] = fraction(e["task_success"] for e in rows.values())
        metrics[f"{policy}|{event}|actual_displacement"] = fraction(
            any(t["kind"] == event and any(abs(v) > 1e-9 for v in t.get("realized", []))
                for t in e["backend_events"]) for e in rows.values())
        for horizon in sorted({e["horizon"] for e in rows.values() if e.get("horizon") is not None}):
            metrics[f"{policy}|{event}|horizon{horizon}_success"] = fraction(
                e["task_success"] for e in rows.values() if e.get("horizon") == horizon)
    nominal = cells["frozen", "nominal"]
    for event in EVENTS:
        frozen, replan = cells["frozen", event], cells["replan_after_interaction", event]
        metrics[f"{event}|paired_success_gain"] = fraction(
            int(replan[k]["task_success"]) - int(frozen[k]["task_success"]) for k in keys)
        metrics[f"{event}|nominal_success_retention"] = fraction(
            replan[k]["task_success"] for k in keys if nominal[k]["task_success"])
        metrics[f"{event}|recovery_after_frozen_failure"] = fraction(
            replan[k]["task_success"] for k in keys if nominal[k]["task_success"] and not frozen[k]["task_success"])
    return dict(config=configs[0], metrics=metrics)


def summarize_runs(runs, split):
    reports = [summarize_seed(run, split) for run in runs]
    if not reports:
        raise ValueError("at least one training run required")
    seeds = [r["config"]["training_seed"] for r in reports]
    if None in seeds or len(set(seeds)) != len(seeds):
        raise ValueError("distinct training seeds required")
    varying = {"checkpoint_sha256", "checkpoint_step", "training_seed", "learned_predictor"}
    protocol = {k: v for k, v in reports[0]["config"].items() if k not in varying}
    if any({k: v for k, v in r["config"].items() if k not in varying} != protocol for r in reports[1:]):
        raise ValueError("training runs require identical data and evaluation protocol")
    metrics = {}
    for name in reports[0]["metrics"]:
        values = {str(seed): r["metrics"][name] for seed, r in zip(seeds, reports)}
        valid = [v["mean"] for v in values.values() if v["mean"] is not None]
        metrics[name] = dict(per_training_seed=values, mean=float(np.mean(valid)) if valid else None,
                             sd=float(np.std(valid, ddof=1)) if len(valid) > 1 else None)
    return dict(protocol=protocol, training_seeds=seeds, metrics=metrics,
                note="Primary success uses every initial task. Conditional retention/recovery are diagnostics,"
                     " with their own denominators. SD is across training seeds; proxy execution is not physics.")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True)
    parser.add_argument("--split", choices=("val", "test"), required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args(argv)
    result = summarize_runs(args.runs, args.split)
    out = empty_output(args.out)
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["# Shared experiment 4", "", result["note"], "",
             "| Metric | Mean | Training-seed SD |", "|---|---:|---:|"]
    for name, record in result["metrics"].items():
        values = ["N/A" if record[k] is None else f"{record[k]:.4f}" for k in ("mean", "sd")]
        lines.append("| " + " | ".join([name.replace("|", " / "), *values]) + " |")
    (out / "SUMMARY.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
