"""Unseen-embodiment registry: bodies that never appear in exp3 training (spot, g1).

Structural descriptions come from the MuJoCo Menagerie MJCFs (go1, go2, h1; the g1 "shoulder
unused" body is the pre-existing derived `g1_shoulder_locked`).  `go1` points at the mjlab
asset_zoo copy of the Menagerie go1.xml because that is the body the frozen Go1 walker actually
drives; `go1_menagerie` is the untouched Menagerie file, kept so the two can be compared.

`go1` and `go2` are described from the ENTITY mjlab compiles for the walker (Menagerie MJCF +
mjlab's position actuators), because that is the body the frozen walker drives; the seen bodies'
native assets (spot_deployment/*.xml, g1_pos_native.xml) likewise carry their actuators.  The raw
MJCFs are kept as diagnostics: `go1_mjlab_xml` (mjlab asset_zoo copy, <motor> block removed, so
actuator_gear/damping columns read 0), `go1_menagerie` and `go2_menagerie` (untouched Menagerie).

Only phi_B (structure rows), the root body and a nominal footprint width are needed for the
traversal-affordance probes; BodyPart entries are nominal placeholders (no manipulation is
probed for these bodies) and are never read by the traversal code.

    PYTHONPATH=. .venv/bin/python -m experiments.exp3.trajectory_v3.unseen_bodies --out <dir>
"""
from __future__ import annotations

import argparse
import json
import os
from dataclasses import replace
from pathlib import Path

from clear.maze import robots as R
from clear.maze.robots import BodyPart, LocomotionLimits, RobotEntry

from clear.paths import MENAGERIE
MJLAB_GO1 = Path(os.environ.get("CLEAR_MJLAB_GO1", Path(__file__).resolve().parents[3] / "third_party/mjlab/src/mjlab/asset_zoo/robots/unitree_go1/xmls/go1.xml"))

_body = lambda name, h0, h1: (BodyPart(name, "body", max_mass_kg=4.0, max_extent_m=0.8, h_min=h0, h_max=h1),)
_NOM = "nominal"


def limits(body, step, slope):
    return LocomotionLimits(step, slope, WIDTH_M[body],
                            {"max_step_m": _NOM, "max_slope_deg": _NOM, "width_m": "datasheet_nominal"})


# Nominal body widths (m) from the manufacturers' datasheets; the seen bodies use the same kind of
# nominal value (spot .50, g1 .46).  Only the footprint radius (width/2) is derived from these.
WIDTH_M = {"go1": .293, "go2": .310, "h1": .510}


MASS_FACTORS = (0.6, 0.8, 1.25, 1.5)
WIDTH_M["a1"] = .30


def variant_entries():
    """a1 and the mass-scaled variants of go1/go2/a1 (same frozen walker as the base body)."""
    out = {"a1": RobotEntry("a1", "mjlab:clear.low_level.task_quadrupeds a1 <- " + str(MENAGERIE / "unitree_a1/a1.xml"), "trunk",
                            _body("trunk", .25, .35), limits("a1", .15, 20.), color="#a6cee3")}
    for base in ("go1", "go2", "a1"):
        for f in MASS_FACTORS:
            key = f"{base}_m{f:g}".replace(".", "p")
            out[key] = RobotEntry(key, f"mjlab:clear.low_level.task_quadrupeds {base} mass x{f:g}", "trunk", _body("trunk", .25, .35),
                                  limits(base, .15, 20.), base_id=base)
    return out


def entries():
    go1_menagerie = MENAGERIE / "unitree_go1/go1.xml"
    go2 = MENAGERIE / "unitree_go2/go2.xml"
    h1 = MENAGERIE / "unitree_h1/h1.xml"
    return {
        "go1": RobotEntry("go1", "mjlab:Entity(get_go1_robot_cfg()) <- " + str(MJLAB_GO1), "trunk", _body("trunk", .25, .35),
                          limits("go1", .15, 20.), color="#66a61e"),
        "go2": RobotEntry("go2", "mjlab:Entity(get_go2_robot_cfg()) <- " + str(go2), "trunk", _body("trunk", .25, .35),
                          limits("go2", .15, 20.), color="#e6ab02"),
        "h1": RobotEntry("h1", str(h1), "pelvis", _body("torso", .6, 1.), limits("h1", .3, 20.), color="#666666"),
        # diagnostics: raw MJCF descriptions of the same robots
        "go1_mjlab_xml": RobotEntry("go1_mjlab_xml", str(MJLAB_GO1), "trunk", _body("trunk", .25, .35), limits("go1", .15, 20.)),
        "go1_menagerie": RobotEntry("go1_menagerie", str(go1_menagerie), "trunk", _body("trunk", .25, .35), limits("go1", .15, 20.)),
        "go2_menagerie": RobotEntry("go2_menagerie", str(go2), "base", _body("base", .25, .35), limits("go2", .15, 20.)),
    }


def configure():
    """Add the unseen bodies to the live registry (idempotent; never overwrites a seen body)."""
    for key, entry in {**entries(), **variant_entries()}.items():
        if key in R.REGISTRY and R.REGISTRY[key].asset != entry.asset:
            raise KeyError(f"{key} already registered with a different asset")
        R.REGISTRY.setdefault(key, entry)
    return tuple(entries()) + tuple(variant_entries())


def main(argv=None):
    p = argparse.ArgumentParser(); p.add_argument("--out", required=True)
    a = p.parse_args(argv)
    from clear.maze.robots import configure as configure_seen
    from clear.maze.robots import structure_for, write_structure_file
    configure_seen(); configure()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    report = {}
    for body in ("spot", "g1", "g1_shoulder_locked", "go1", "go2", "h1", "go1_mjlab_xml", "go1_menagerie", "go2_menagerie", *variant_entries()):
        desc = structure_for(body); entry = R.get(body)
        write_structure_file(desc, out / f"{body}.json")
        report[body] = dict(asset=entry.asset, root_body=entry.root_body, n_links=desc.n_links,
                            structure_hash=desc.structure_hash, rows_digest=None, width_m=entry.loco.width_m,
                            footprint_radius_m=entry.loco.width_m / 2, locked_joints=list(entry.locked_joints),
                            total_mass_kg=round(float(sum(l["mass"] for l in desc.links)), 3))
        from experiments.exp3.trajectory_v3.calibration import digest
        report[body]["rows_digest"] = digest([[float(v) for v in r] for r in desc.rows])
    (out / "bodies.json").write_text(json.dumps(report, indent=1) + "\n")
    for body, r in report.items():
        print(f"{body:20s} links={r['n_links']:3d} mass={r['total_mass_kg']:7.2f} width={r['width_m']:.3f} hash={r['structure_hash'][:12]} rows={r['rows_digest'][:12]}")


if __name__ == "__main__":
    main()
