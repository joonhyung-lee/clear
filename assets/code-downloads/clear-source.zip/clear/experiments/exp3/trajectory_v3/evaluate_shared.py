"""Single-checkpoint CLEAR evaluation for experiments 3/4 on a kinematic proxy backend."""
import argparse
from collections import Counter
import json
from pathlib import Path
import time

import numpy as np
import torch

from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.cli import read_jsonl
from experiments.exp3.trajectory_v3.evaluate_v3 import RecordingPlanner, bootstrap, search_proposer, perturbation_for, PERTURBATIONS
from experiments.exp3.trajectory_v3.exp3_protocol import empty_output, load_prepared
from experiments.exp3.trajectory_v3.navigation import scene_hash
from experiments.exp3.trajectory_v3.navigation_cache import CachedTerrainNavigator
from experiments.exp3.trajectory_v3.navigation_planner import run_navigation_episode, validate_sequence
from experiments.exp3.trajectory_v3.oracle_capability import OracleAssessor, ProbeTablePredictor, PushTable
from experiments.exp3.trajectory_v3.shared_morphology import SharedObjectProposer, SharedTraversalPredictor, embodiment_from_row, collate_probes, load_shared_checkpoint
from experiments.exp3.trajectory_v3.reviewed_task_backend import ReviewedTaskBackend
from experiments.exp3.trajectory_v3.review_metrics import summarize_review
from experiments.exp3.trajectory_v3.training_state import file_hash


def episode_seed(row, rollout_seed):
    """Independent of Python hash salt, row ordering, model seed, and evaluation method."""
    return int(digest(dict(scene=scene_hash(row["scene"]), body=row["body_id"],
                           structure=row["structure_rows"], seed=rollout_seed))[:15], 16)


def proposal_seed(row,rollout_seed):
    """Matched sampling stream across bodies; execution retains its own stream."""
    return int(digest(dict(scene=scene_hash(row['scene']),seed=rollout_seed,stream='object_proposals_v2'))[:15],16)


def metrics(items):
    result = dict(episodes=len(items), status_histogram=dict(Counter(e["status"] for e in items)))
    result["candidate_rejection_histogram"] = dict(Counter(t["rejection"] for e in items
                                                           for t in e.get("decision_trace", []) if t.get("rejection")))
    result["perturbation_triggered_episodes"] = sum(any(t["kind"] == e.get("perturbation")
                                                       for t in e.get("backend_events", [])) for e in items)
    result["perturbation_displaced_episodes"] = sum(any(t["kind"] == e.get("perturbation")
                                                       and any(abs(v) > 1e-9 for v in t.get("realized", []))
                                                       for t in e.get("backend_events", [])) for e in items)
    for name in ("task_success", "minimum_interaction_success", "plan_valid", "attempted_interactions"):
        by_layout = {}
        for item in items:
            value = item[name]
            if value is not None:
                by_layout.setdefault(item["layout_group_id"], []).append(float(value))
        result[name] = bootstrap(by_layout)
    return result


def summarize(episodes):
    groups = {}
    for method in sorted({e["method"] for e in episodes}):
        items = [e for e in episodes if e["method"] == method]
        groups[method] = {
            "all": metrics(items),
            "reference_solved": metrics([e for e in items if e["k_star"] is not None]),
            "navigation_only": metrics([e for e in items if e["k_star"] == 0]),
            "interaction_required": metrics([e for e in items if e["k_star"] is not None and e["k_star"] > 0]),
            "multi_interaction": metrics([e for e in items if e["k_star"] is not None and e["k_star"] >= 2]),
            "reference_unresolved": metrics([e for e in items if e["k_star"] is None]),
            "by_body": {b: metrics([e for e in items if e["body_id"] == b]) for b in sorted({e["body_id"] for e in items})},
            "by_rollout_seed": {str(s): metrics([e for e in items if e["rollout_seed"] == s])
                                for s in sorted({e["rollout_seed"] for e in items})},
            "by_horizon": {str(h): metrics([e for e in items if e.get("horizon") == h])
                           for h in sorted({e["horizon"] for e in items if e.get("horizon") is not None})},
        }
        pairs = {}
        for item in items:
            pairs.setdefault((item["scene_id"], item["rollout_seed"]), []).append(item)
        switches, differing_switches = {}, {}
        for pair in pairs.values():
            if len(pair) != 2 or len({e["body_id"] for e in pair}) != 2:
                continue
            signatures = {(e["decision"], tuple(sorted(p["object_id"] for p in e["plan"]["paths"]))) for e in pair}
            switches.setdefault(pair[0]["layout_group_id"], []).append(
                float(len(signatures) > 1 and all(e["task_success"] for e in pair)))
            if all(e["k_star"] is not None for e in pair) and len({tuple(e["reference_objects"]) for e in pair}) > 1:
                differing_switches.setdefault(pair[0]["layout_group_id"], []).append(float(
                    all(e["task_success"] for e in pair) and pair[0]["decision_objects"] != pair[1]["decision_objects"]))
        groups[method]["body_paired_plan_switch"] = bootstrap(switches)
        groups[method]["teacher_differing_plan_switch"] = bootstrap(differing_switches)
        # Legacy diagnostics are explicitly named by what they measure. They
        # cannot establish optimal Plan-Switch accuracy without reference sets.
        groups[method]['body_paired_unordered_set_change_with_success_rate']=groups[method].pop('body_paired_plan_switch')
        groups[method]['teacher_differing_order_change_with_success_rate']=groups[method].pop('teacher_differing_plan_switch')
        bins=('2','3','4') if items and all(e.get('horizon') is not None for e in items) else ('1','2','3','4+')
        groups[method]['review_v2']=summarize_review(items,bins=bins)
    return groups


@torch.no_grad()
def probe_diagnostics(model, rows, threshold, out):
    device = next(model.parameters()).device
    predictions = []
    for start in range(0, len(rows), 256):
        chunk = rows[start:start + 256]
        batch = collate_probes(chunk, device)
        probabilities = model.traversal_logits(batch["features"], batch["structure"], batch["structure_mask"]).sigmoid().cpu().tolist()
        for row, probability, target in zip(chunk, probabilities, batch["target"].cpu().tolist()):
            predictions.append(dict(body_id=row.get("body_id", row["structure_hash"]), kind=row.get("kind", "unknown"),
                                    condition=row.get("condition"), layout_group_id=row["layout_group_id"],
                                    evidence_hash=row["evidence_hash"], execution_seed=row["execution_seed"],
                                    probability=probability, target=bool(target)))

    def score(items):
        if not items:
            return dict(n=0)
        p = np.asarray([x["probability"] for x in items]).clip(1e-7, 1 - 1e-7)
        y = np.asarray([x["target"] for x in items], bool)
        accepted = p >= threshold
        return dict(n=len(items), positives=int(y.sum()), negatives=int((~y).sum()),
                    bce=float(-(y * np.log(p) + ~y * np.log1p(-p)).mean()),
                    brier=float(((p - y) ** 2).mean()),
                    false_positive_rate=float(accepted[~y].mean()) if (~y).any() else None,
                    false_negative_rate=float((~accepted[y]).mean()) if y.any() else None)

    result = dict(threshold=threshold, all=score(predictions),
                  by_body_kind={f"{body}|{kind}": score([x for x in predictions if x["body_id"] == body and x["kind"] == kind])
                                for body, kind in sorted({(x["body_id"], x["kind"]) for x in predictions})})
    (out / "probe_predictions.jsonl").write_text("".join(json.dumps(x) + "\n" for x in predictions))
    (out / "probe_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def evaluate(rows, checkpoint, out, probe_summaries, push_summaries, rollout_seeds=(0, 1, 2),
             candidates=8, flow_steps=30, device="cpu", include_oracle=False, provenance=None, probe_rows=None,
             mode="exp3", policy="frozen", perturbation="nominal"):
    if mode not in ("exp3", "exp4") or policy not in ("frozen", "replan_after_interaction") or perturbation not in PERTURBATIONS:
        raise ValueError("explicit experiment mode, policy, and perturbation required")
    if mode == "exp3" and (policy != "frozen" or perturbation != "nominal"):
        raise ValueError("experiment 3 uses frozen planning and nominal conditions")
    if not rows or candidates < 1 or flow_steps < 1 or not rollout_seeds or len(set(rollout_seeds)) != len(rollout_seeds):
        raise ValueError("nonempty evaluation rows, distinct rollout seeds, and positive budgets required")
    model, record = load_shared_checkpoint(checkpoint, device)
    predictor = SharedTraversalPredictor(model, record["controller_profiles"])
    learned_nav = CachedTerrainNavigator(predictor, **record["navigation"])
    oracle_predictor = ProbeTablePredictor(probe_summaries)
    push = PushTable.from_summaries(push_summaries)
    oracle_nav = CachedTerrainNavigator(oracle_predictor, **record["navigation"])
    assessor = OracleAssessor(push, oracle_predictor.bodies)
    for row in rows:
        embodiment = embodiment_from_row(row)
        body = oracle_predictor.bodies.get(digest(embodiment.structure_rows))
        if body != row["body_id"] or oracle_predictor.controllers.get(body) != embodiment.controller_hash:
            raise ValueError("evaluation probes must match each row's structure, body, and frozen controller")
    out = empty_output(out)
    configuration = dict(architecture="shared_morphology", checkpoint_sha256=file_hash(checkpoint),
                         training_seed=record.get("seed"), checkpoint_step=record.get("step"),
                         rollout_seeds=list(rollout_seeds), candidates=candidates, flow_steps=flow_steps,
                         navigation=record["navigation"], rows=len(rows), model_config=model.config,
                         mode=mode, policy=policy, perturbation=perturbation,
                         max_interactions="(horizon or 5) + 3" if mode == "exp4" else 8,
                         max_time_s=240. if mode == "exp4" else 120.,
                         projection=False, backend="kinematic probe-grounded proxy; not physics",
                         learned_predictor=predictor.identity, oracle_predictor=oracle_predictor.identity,
                         push_source=push.source, data_hash=digest(rows), provenance=provenance)
    configuration.update(metric_protocol='clear-exp3-exp4-review-v2',
        proposal_rng='scene and rollout seed, shared across bodies and methods; independent execution generator',
        canonical_metrics='groups.<method>.review_v2; legacy aggregates retained for old reports',
        declared_exp4_macro_bins=['2','3','4'],
        recovery_checker='independent probe-oracle validation before and after each realized event')
    (out / "evaluation.json").write_text(json.dumps(configuration, indent=2) + "\n")
    if probe_rows is not None:
        probe_diagnostics(model, probe_rows, record["navigation"]["threshold"], out)
    episodes = []
    methods = ["clear_shared"] + (["oracle_search"] if include_oracle else [])
    with (out / "episodes.jsonl").open("w") as stream:
        for method in methods:
            for seed in rollout_seeds:
                for row in rows:
                    rng_seed = episode_seed(row, seed)
                    planning_seed=proposal_seed(row,seed)
                    embodiment = embodiment_from_row(row)
                    if method == "clear_shared":
                        proposer = SharedObjectProposer(model, predictor, candidates, flow_steps, planning_seed)
                        navigator = learned_nav
                    else:
                        proposer, navigator = search_proposer(oracle_nav, assessor), oracle_nav
                    event = perturbation_for(perturbation, row)
                    backend = ReviewedTaskBackend(row["scene"], embodiment, oracle_nav, assessor,
                                                   np.random.default_rng(rng_seed), event)
                    planner = RecordingPlanner(navigator, proposer, assessor, candidates,decision_observer=backend.note_decision)
                    started = time.perf_counter()
                    horizon = row["scene"].get("navigation_condition", {}).get("horizon")
                    result = run_navigation_episode(planner, embodiment, backend, policy=policy,
                                                    max_interactions=(horizon or 5) + 3 if mode == "exp4" else 8,
                                                    max_time_s=configuration["max_time_s"])
                    wall_s = time.perf_counter() - started
                    decision = planner.decisions[0]
                    k_star = row.get("teacher", {}).get("k_star")
                    valid = None
                    if decision.status == "interact":
                        valid = validate_sequence(row["scene"], embodiment, decision.plan, oracle_nav, assessor)[1] is None
                    episode = dict(scene_id=row["scene"]["base_scene_id"], layout_group_id=row["scene"]["layout_group_id"],
                                   body_id=row["body_id"], method=method, training_seed=record.get("seed"), rollout_seed=seed,
                                   seed=seed, policy=policy, perturbation=perturbation, perturbation_configured=event is not None,
                                   perturbation_triggered=any(e["kind"] == perturbation for e in backend.events),
                                   perturbation_applied=any(e["kind"] == perturbation
                                                           and any(abs(v) > 1e-9 for v in e.get("realized", []))
                                                           for e in backend.events),
                                   rng_seed=rng_seed, k_star=k_star, horizon=horizon, status=result["status"],
                                   task_success=bool(result["task_success"]), plan_valid=valid,
                                   decision=decision.status, decision_trace=decision.trace,
                                   decision_objects=[p.object_id for p in decision.plan.paths],
                                   reference_objects=[p["object_id"] for p in row.get("plan", {}).get("paths", [])],
                                   plan=decision.plan.to_dict(), route=decision.route, planning_calls=result["planning_calls"],
                                   planning_history=[dict(status=d.status, plan=d.plan.to_dict(), trace=d.trace) for d in planner.decisions],
                                   observations=result["measured_boundary_observations"],
                                   navigation_trajectory=backend.trajectory, execution_trace=result["trace"],
                                   attempted_interactions=result["attempted_interactions"],
                                   proxy_elapsed_s=result["elapsed_s"], wall_s=wall_s,
                                   minimum_interaction_success=bool(result["task_success"]) and k_star is not None
                                   and result["attempted_interactions"] == k_star, backend_events=backend.events)
                    episode.update(backend='kinematic_proxy',proposal_rng_seed=planning_seed,
                        reference_count_success=(bool(result['task_success']) and result['attempted_interactions']==k_star) if k_star is not None else None,
                        independent_event_assessments=backend.independent_event_assessments,
                        interaction_attempts=backend.interaction_attempts,
                        metric_protocol='clear-exp3-exp4-review-v2')
                    stream.write(json.dumps(episode) + "\n")
                    stream.flush()
                    episodes.append(episode)
                print(json.dumps(dict(method=method, rollout_seed=seed, completed_episodes=len(episodes))), flush=True)
    report = dict(config=configuration, groups=summarize(episodes), status="evaluation_completed")
    (out / "metrics.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--prepared", required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--split", choices=("val", "test"), default="val")
    p.add_argument("--final-test", action="store_true", help="explicitly evaluate the frozen test split after development")
    p.add_argument("--rollout-seeds", type=int, nargs="+", default=[0, 1, 2])
    p.add_argument("--candidates", type=int, default=8)
    p.add_argument("--flow-steps", type=int, default=30)
    p.add_argument("--include-oracle", action="store_true")
    p.add_argument("--device", default="cuda")
    p.add_argument("--cpu-threads", type=int, default=2)
    p.add_argument("--workers", type=int, default=1, help="independent episode workers on the selected device")
    p.add_argument("--mode", choices=("exp3", "exp4"), default="exp3")
    p.add_argument("--policy", choices=("frozen", "replan_after_interaction"), default="frozen")
    p.add_argument("--perturbation", choices=PERTURBATIONS, default="nominal")
    p.add_argument("--initial-only", action="store_true", help="exclude generated -mid suffix supervision states from task evaluation")
    args = p.parse_args(argv)
    if (args.split == "test") != args.final_test:
        p.error("test evaluation requires --split test --final-test; development uses --split val")
    torch.set_num_threads(args.cpu_threads)
    manifest = load_prepared(args.prepared)
    files = manifest["files"]
    _, checkpoint = load_shared_checkpoint(args.checkpoint, "cpu")
    identity = checkpoint.get("training_state", {}).get("identity", {})
    expected = dict(data=files["development"]["sha256"], probes=files["probes"]["sha256"])
    if identity.get("input_hashes") != expected or checkpoint.get("config") != json.loads(Path(files["config"]["path"]).read_text()):
        raise ValueError("checkpoint was not trained on this prepared experiment/config")
    rows = read_jsonl(files[args.split]["path"])
    rows += [r for r in read_jsonl(files["unsolved"]["path"]) if r["split"] == args.split]
    if args.initial_only:
        rows = [r for r in rows if "-mid" not in r["scene"]["base_scene_id"]]
    evaluator, extra = evaluate, {}
    if args.workers != 1:
        from experiments.exp3.trajectory_v3.parallel_shared_eval import evaluate_parallel
        evaluator, extra = evaluate_parallel, dict(workers=args.workers)
    result = evaluator(rows, args.checkpoint, args.out,
                      {b: files["traversal_" + b]["path"] for b in ("spot", "g1")},
                      {b: files["push_" + b]["path"] for b in ("spot", "g1")},
                      args.rollout_seeds, args.candidates, args.flow_steps, args.device, args.include_oracle,
                      provenance=dict(split=args.split, manifest_sha256=file_hash(Path(args.prepared) / "manifest.json"),
                                      initial_only=args.initial_only),
                      probe_rows=[r for r in read_jsonl(files["probes"]["path"]) if r["split"] == args.split],
                      mode=args.mode, policy=args.policy, perturbation=args.perturbation, **extra)
    print(json.dumps(result["groups"]["clear_shared"]["all"], indent=2))


if __name__ == "__main__":
    main()
