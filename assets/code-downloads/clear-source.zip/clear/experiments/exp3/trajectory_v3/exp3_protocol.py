"""Prepare immutable experiment-3 inputs, then train on the user's compute server."""
import argparse
from collections import Counter
import json
from pathlib import Path
from types import SimpleNamespace

from experiments.exp3.trajectory_v3.cli import read_jsonl
from experiments.exp3.trajectory_v3.shared_cli import train, validate_training_data
from experiments.exp3.trajectory_v3.training_state import file_hash

PROTOCOL_SCHEMA = "clear-exp3-shared-protocol-v1"


def file_record(path):
    path = Path(path).resolve()
    return dict(path=str(path), sha256=file_hash(path))


def empty_output(path):
    path = Path(path)
    if path.exists() and any(path.iterdir()):
        raise FileExistsError("output directory must be empty")
    path.mkdir(parents=True, exist_ok=True)
    return path


def load_prepared(path):
    path = Path(path)
    manifest = json.loads((path / "manifest.json").read_text())
    if manifest.get("schema") != PROTOCOL_SCHEMA:
        raise ValueError("experiment-3 prepared manifest required")
    for key, value in manifest["files"].items():
        if file_hash(value["path"]) != value["sha256"]:
            raise ValueError("input changed after preparation: " + key)
    return manifest


def prepare(dataset, probes, config, out):
    dataset, probes = Path(dataset), Path(probes)
    source = {s: dataset / f"{s}.jsonl" for s in ("train", "val", "test", "unsolved")}
    source.update(probes=probes / "probes_all.jsonl")
    for body in ("spot", "g1"):
        source["traversal_" + body] = probes / body / "summary.json"
        source["push_" + body] = probes / ("push_" + body) / "summary.json"
    files = {name: file_record(path) for name, path in source.items()}
    splits = {s: read_jsonl(source[s]) for s in ("train", "val", "test")}
    for split, rows in splits.items():
        if not rows or any(r["split"] != split for r in rows):
            raise ValueError("nonempty, correctly labeled " + split + " file required")
    cfg = json.loads(Path(config).read_text())
    rows = [r for split in splits.values() for r in split]
    _, _, summary = validate_training_data(rows, read_jsonl(source["probes"]), cfg)
    groups, seen = {}, set()
    unsolved = read_jsonl(source["unsolved"])
    for r in [*rows, *unsolved]:
        group, split = r["scene"]["layout_group_id"], r["split"]
        if split not in splits or (group in groups and groups[group] != split):
            raise ValueError("layout split conflict in solved/unsolved examples")
        groups[group] = split
        key = (r["scene"]["base_scene_id"], r["body_id"])
        if key in seen:
            raise ValueError("duplicate scene/body evaluation unit")
        seen.add(key)
    if any(r.get("teacher", {}).get("k_star") is not None for r in unsolved):
        raise ValueError("unsolved rows must not claim a reference interaction count")
    out = empty_output(out)
    (out / "development.jsonl").write_text("".join(json.dumps(r) + "\n" for r in splits["train"] + splits["val"]))
    (out / "config.json").write_text(json.dumps(cfg, indent=2) + "\n")
    files.update(development=file_record(out / "development.jsonl"), config=file_record(out / "config.json"))
    counts = {}
    for split, values in splits.items():
        counts[split] = dict(solved=len(values), unresolved=sum(r["split"] == split for r in unsolved),
                             body_k=dict(Counter(f"{r['body_id']}|K={len(r['plan']['paths'])}" for r in values)))
    manifest = dict(schema=PROTOCOL_SCHEMA, files=files, counts=counts, validation=summary,
                    teacher_provenance=dict(Counter(r["teacher"].get("proxy", r["teacher"]["validation"]) for r in rows)),
                    training_seeds=[0, 1, 2], rollout_seeds=[0, 1, 2],
                    checkpoint_selection="minimum " + cfg["train"].get("checkpoint_selection", "total")
                                         + " validation loss within each training seed",
                    backend="kinematic proxy grounded on probe tables; physical execution is a later stage",
                    status="prepared; no performance result")
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("prepare")
    p.add_argument("--dataset", required=True)
    p.add_argument("--probes", required=True, help="directory containing probes_all.jsonl and measured summaries")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p = commands.add_parser("train")
    p.add_argument("--prepared", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--device", default="cuda")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--stop-after", type=int)
    p.add_argument("--allow-geometric-teacher", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "prepare":
        result = prepare(args.dataset, args.probes, args.config, args.out)
        print(json.dumps(dict(status=result["status"], counts=result["counts"]), indent=2))
    else:
        manifest = load_prepared(args.prepared)
        values = vars(args).copy()
        values.update(data=manifest["files"]["development"]["path"],
                      probes=manifest["files"]["probes"]["path"], config=manifest["files"]["config"]["path"])
        train(SimpleNamespace(**values))


if __name__ == "__main__":
    main()
