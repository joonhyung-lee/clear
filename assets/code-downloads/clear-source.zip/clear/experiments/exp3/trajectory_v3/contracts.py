from dataclasses import dataclass
import math
import numpy as np

SCHEMA = "clear-object-path-v3"


def angle_delta(a, b):
    return (np.asarray(a) - np.asarray(b) + math.pi) % (2 * math.pi) - math.pi


@dataclass(frozen=True)
class ObjectPath:
    object_id: int
    poses: tuple
    body_part: str | None = None

    def __post_init__(self):
        p = np.asarray(self.poses, dtype=float)
        if p.ndim != 2 or p.shape[1] != 3 or len(p) < 2 or not np.isfinite(p).all():
            raise ValueError("object path requires at least two finite [x_m, y_m, yaw_rad] poses")
        if isinstance(self.object_id, bool) or not isinstance(self.object_id, (int, np.integer)):
            raise ValueError("object_id must be an integer")
        if np.any(np.abs(p[:, 2]) > math.pi + 1e-8):
            raise ValueError("yaw must lie in [-pi, pi]")
        if np.allclose(p[:, :2], p[0, :2]) and np.allclose(angle_delta(p[:, 2], p[0, 2]), 0):
            raise ValueError("a selected interaction must move the object")
        object.__setattr__(self, "poses", tuple(tuple(float(v) for v in q) for q in p))

    @property
    def start(self):
        return self.poses[0]

    @property
    def goal(self):
        return self.poses[-1]

    def densify(self, count):
        if count < len(self.poses):
            raise ValueError("downsampling could remove a required corner; simplify with collision checks first")
        poses = list(self.poses)
        while len(poses) < count:
            p = np.asarray(poses)
            length = np.linalg.norm(np.diff(p[:, :2], axis=0), axis=1)
            length += 0.25 * np.abs(angle_delta(p[1:, 2], p[:-1, 2]))
            k = int(np.argmax(length))
            a, b = p[k], p[k + 1]
            mid = (a + b) / 2
            mid[2] = float(angle_delta(a[2] + 0.5 * angle_delta(b[2], a[2]), 0))
            poses.insert(k + 1, tuple(mid))
        return ObjectPath(self.object_id, tuple(poses), self.body_part)

    def to_dict(self):
        return {"object_id": int(self.object_id), "poses": [list(p) for p in self.poses],
                "body_part": self.body_part}

    @classmethod
    def from_dict(cls, value):
        return cls(value["object_id"], value["poses"], value.get("body_part"))


@dataclass(frozen=True)
class ObjectMotionPlan:
    paths: tuple

    def __post_init__(self):
        if not all(isinstance(p, ObjectPath) for p in self.paths):
            raise ValueError("paths must contain ObjectPath instances")
        ids = [p.object_id for p in self.paths]
        if len(set(ids)) != len(ids):
            raise ValueError("one interaction per selected object; duplicate IDs are unsupported")
        object.__setattr__(self, "paths", tuple(self.paths))

    def to_dict(self):
        return {"schema": SCHEMA, "units": "metres-radians", "parameter": "path_progress",
                "paths": [p.to_dict() for p in self.paths]}

    @classmethod
    def from_dict(cls, value):
        if (value.get("schema"), value.get("units"), value.get("parameter")) != (
                SCHEMA, "metres-radians", "path_progress"):
            raise ValueError("unsupported object-path contract")
        return cls(tuple(ObjectPath.from_dict(p) for p in value["paths"]))

    def to_prediction(self):
        from experiments.common.interfaces import PlanPrediction
        return PlanPrediction([p.object_id for p in self.paths], [list(p.goal) for p in self.paths],
                              scores={"object_motion_plan": self.to_dict(), "requires_trajectory_executor": True},
                              body_parts=[p.body_part for p in self.paths])


def execute_plan(executor, plan):
    method = getattr(executor, "interact_trajectory", None)
    if not callable(method):
        raise TypeError("trajectory execution requires interact_trajectory(ObjectPath); endpoint fallback is forbidden")
    results = []
    for path in plan.paths:
        result = method(path)
        results.append(result)
        success = result.get("success") if isinstance(result, dict) else result.success
        if not success:
            break
    return results
