from copy import deepcopy
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.navigation import scene_hash
from experiments.exp3.trajectory_v3.scenes import make_scene, write_mjcf


def make_navigation_scene(seed=0, terrain="stairs", control="interaction_required"):
    if terrain not in ("stairs", "slope", "flat") or control not in ("interaction_required", "direct", "blocked"):
        raise ValueError("unknown navigation pilot condition")
    scene = make_scene("manipulation_switch" if terrain=="flat" else "traversal_switch", seed)
    if terrain=="slope":
        bounds = scene["terrain"][0]["bounds"]
        l, r = bounds[0], bounds[2]
        rise = scene["terrain"][1]["height_m"]
        scene["terrain"] = [dict(kind="ramp", bounds=[l,4.9,r,5.5], axis=1,
                                 start_height_m=0., end_height_m=rise, friction=.8),
                            dict(kind="ramp", bounds=[l,5.5,r,6.1], axis=1,
                                 start_height_m=rise, end_height_m=0., friction=.8)]
    if control=="direct":
        scene["objects"][0]["pose"] = list(scene["development_guides"][0]["poses"][-1])
        scene["development_guides"] = scene["development_guides"][1:]
        scene["candidate_orders"] = [[],[1,2]]
    elif control=="blocked":
        scene["walls"].append([.2,6.5,7.8,6.7])
    scene["schema"] = "clear-maze-route-scene-v1"
    scene["navigation_condition"] = dict(terrain=terrain, control=control)
    scene["base_scene_id"] = f"{terrain}-{control}-"+scene_hash(scene)[:16]
    scene["capability_status"] = "physical_calibration_pending; no body-specific route labels"
    return scene


def write_navigation_mjcf(scene, destination):
    simple = deepcopy(scene)
    ramps = [tile for tile in scene["terrain"] if tile.get("kind")=="ramp"]
    simple["terrain"] = [tile for tile in scene["terrain"] if tile.get("kind")!="ramp"]
    write_mjcf(simple, destination)
    root = ET.parse(destination).getroot()
    floor = root.find("worldbody/geom[@name='floor']")
    floor.set("friction", f"{scene.get('floor_friction',.8)} .005 .0001")
    negative = [tile for tile in ramps if min(tile['start_height_m'],tile['end_height_m']) < 0.]
    if negative:
        # A plane at z=0 would hide the below-zero half of a signed cross-slope.
        # Tile the surrounding floor, leaving exactly those ramp rectangles open.
        world=root.find('worldbody');world.remove(floor)
        # Thin slabs can eject deeply penetrating foot contacts downwards. Keep
        # solid support below the lowest ramp without covering its opening.
        depth=max(1.,.1-min(min(t['start_height_m'],t['end_height_m']) for t in negative))
        width,height=scene['world_size']
        xs=sorted({-2.,width+2.,*(v for tile in negative for v in (tile['bounds'][0],tile['bounds'][2]))})
        ys=sorted({-2.,height+2.,*(v for tile in negative for v in (tile['bounds'][1],tile['bounds'][3]))})
        index=0
        for l,r in zip(xs[:-1],xs[1:]):
            for b,t in zip(ys[:-1],ys[1:]):
                x,y=(l+r)/2,(b+t)/2
                if any(a<=x<=c and d<=y<=e for a,d,c,e in (tile['bounds'] for tile in negative)):continue
                patch=deepcopy(floor)
                patch.attrib.update(name=f'floor_patch_{index}',type='box',pos=f'{x} {y} {-depth/2}',size=f'{(r-l)/2} {(t-b)/2} {depth/2}')
                world.append(patch);index+=1
    if ramps:
        asset = ET.SubElement(root, "asset")
        world = root.find("worldbody")
        for i, tile in enumerate(ramps):
            l,b,r,t = tile["bounds"]
            corners = [(l,b),(r,b),(r,t),(l,t)]
            base=min(0.,tile['start_height_m'],tile['end_height_m'])
            if base<0.:base-=.1
            vertices = [(x,y,base) for x,y in corners]
            axis = tile["axis"]; low,high = (l,r) if axis==0 else (b,t)
            for x,y in corners:
                z = tile["start_height_m"]+((x,y)[axis]-low)/(high-low)*(tile["end_height_m"]-tile["start_height_m"])
                vertices.append((x,y,z))
            vertices = list(dict.fromkeys(vertices))
            name = f"ramp_{i}"
            ET.SubElement(asset,"mesh",name=name,vertex=" ".join(str(v) for p in vertices for v in p))
            ET.SubElement(world,"geom",name=name,type="mesh",mesh=name,friction=f"{tile.get('friction',.8)} .005 .0001",rgba=".35 .55 .75 1")
    ET.indent(root)
    ET.ElementTree(root).write(destination,encoding="unicode")


def write_navigation_pilot(output, seed=0):
    output = Path(output)
    if output.exists():
        raise FileExistsError("navigation pilot output already exists")
    output.mkdir(parents=True)
    records=[]
    for terrain in ("stairs","slope","flat"):
        for control in ("interaction_required","direct","blocked"):
            scene=make_navigation_scene(seed,terrain,control)
            stem=output/scene["base_scene_id"]
            stem.with_suffix(".json").write_text(json.dumps(scene,indent=2)+"\n")
            write_navigation_mjcf(scene,stem.with_suffix(".xml"))
            records.append(dict(scene_file=stem.with_suffix(".json").name,scene_hash=scene_hash(scene),
                                layout_group_id=scene["layout_group_id"],**scene["navigation_condition"]))
    report=dict(schema="clear-navigation-pilot-v1",seed=seed,scenes=records,
                scope="robot-free geometry and control conditions; no measured embodiment success labels")
    (output/"manifest.json").write_text(json.dumps(report,indent=2)+"\n")
    return report
