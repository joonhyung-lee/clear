"""Ground-truth capability proxies built from the measured controller probes.

Used by the SIMULATED task backend and by the teacher search only; the learned model never
reads these. Every number here is a measured success rate of a frozen controller on one probe
condition (probes_20260909/<body>/summary.json). Lookup is nearest-condition, conservative
(magnitude above the largest probed condition -> 0). This is not a physics model.
"""
import json
from pathlib import Path
import numpy as np
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.navigation import clearance
from experiments.exp3.trajectory_v3.navigation_planner import InteractionAssessment

# EDGE_FIELDS column -> probe kind for the five magnitude axes
AXES = ((0, "step_up"), (1, "step_down"), (2, "ramp_up"), (3, "ramp_down"), (4, "cross"))
APPROACH_M = .95


def _nearest(rows, magnitude, friction):
    """rows: array [n,3] of (magnitude, friction, rate). Nearest magnitude, friction breaks ties."""
    score = abs(rows[:, 0]-magnitude)+1e-3*abs(rows[:, 1]-friction)
    return float(rows[int(np.argmin(score)), 2])


class ProbeTablePredictor:
    source = "probe_table_oracle"

    def __init__(self, summary_paths):
        self.tables, self.bodies, self.footprints, self.controllers = {}, {}, {}, {}
        for body_id, path in sorted(summary_paths.items()):
            summary = json.loads(Path(path).read_text())
            table = {}
            for c in summary["conditions"]:
                cond = c["condition"]
                table.setdefault(cond["kind"], []).append([cond["magnitude"], cond["friction"], c["success_rate"]])
            key = summary["structure_hash"]
            self.tables[key] = {k: np.asarray(v, float) for k, v in table.items()}
            self.bodies[key] = body_id
            self.footprints[body_id] = float(summary["footprint_radius_m"])
            self.controllers[body_id] = summary["controller_hash"]
        self.identity = digest(dict(source=self.source, tables={k: {kind: v.tolist() for kind, v in t.items()}
                                                                 for k, t in self.tables.items()}))

    def predict(self, features, embodiment):
        table = self.tables.get(digest(embodiment.structure_rows))
        features = np.asarray(features, float)
        if table is None:
            return np.full(len(features), np.nan)
        prob = np.ones(len(features))
        for i, row in enumerate(features):
            mu = row[10]
            p = _nearest(table["flat"], 0., mu) if "flat" in table else 1.
            for col, kind in AXES:
                m = row[col]
                if m <= 1e-4:
                    continue
                rows = table.get(kind)
                p *= 0. if rows is None or m > rows[:, 0].max()+1e-9 else _nearest(rows, m, mu)
            prob[i] = p
        return prob


class PushTable:
    def __init__(self, tables, source):
        self.tables = {b: np.asarray(sorted(v), float) for b, v in tables.items()}  # body -> [n,3] mass, friction, rate
        self.source = source

    @classmethod
    def from_summaries(cls, summary_paths):
        tables = {}
        for body_id, path in summary_paths.items():
            summary = json.loads(Path(path).read_text())
            tables[body_id] = [[c["condition"]["mass_kg"], c["condition"].get("friction", .4), c["success_rate"]]
                               for c in summary["conditions"]]
        return cls(tables, "measured_push_probes")

    @classmethod
    def from_registry(cls, bodies=("spot", "g1")):
        from clear.maze import robots as robot_registry
        tables = {b: [[max(p.max_mass_kg for p in robot_registry.get(b).parts), .4, 1.]] for b in bodies}
        return cls(tables, "nominal_registry")

    def can_push(self, body_id, mass_kg, friction):
        rows = self.tables.get(body_id)
        if rows is None or mass_kg > rows[:, 0].max()+1e-9:
            return 0.
        return _nearest(rows, mass_kg, friction)


def approach_point(path, distance=None):
    """Robot stands APPROACH_M behind the object, opposite to the first translating segment."""
    poses = np.asarray(path.poses)
    for a, b in zip(poses[:-1, :2], poses[1:, :2]):
        d = b-a
        if np.linalg.norm(d) > 1e-6:
            return tuple(a-(APPROACH_M if distance is None else distance)*d/np.linalg.norm(d))
    return None


def robot_after(path, world_size, radius, distance=None):
    poses = np.asarray(path.poses)
    for a, b in zip(poses[-2::-1, :2], poses[::-1, :2]):
        d = b-a
        if np.linalg.norm(d) > 1e-6:
            xy = b-(APPROACH_M if distance is None else distance)*d/np.linalg.norm(d)
            return tuple(np.clip(xy, radius, np.asarray(world_size)-radius))
    return None


class OracleAssessor:
    source = "probe_table_oracle"

    def __init__(self, push_table, structure_to_body, *, surface_standoff=None):
        if surface_standoff is not None and (not np.isfinite(surface_standoff) or surface_standoff<=0):
            raise ValueError('positive finite surface standoff required')
        self.push_table, self.structure_to_body = push_table, structure_to_body
        self.surface_standoff = surface_standoff

    def push_probability(self, scene, embodiment, object_id):
        body = self.structure_to_body.get(digest(embodiment.structure_rows))
        obj = next(o for o in scene["objects"] if o["object_id"] == object_id)
        return 0. if body is None else self.push_table.can_push(body, obj["mass_kg"], obj["friction"])

    def assess(self, scene, embodiment, path, navigation):
        prob = self.push_probability(scene, embodiment, path.object_id)
        if prob < .5:
            return InteractionAssessment("rejected", source=self.source, evidence=dict(reason="push_probability_below_half", push_probability=prob))
        obj = next(o for o in scene['objects'] if o['object_id']==path.object_id)
        distance = None if self.surface_standoff is None else max(obj['size'][:2])/2+self.surface_standoff
        approach = approach_point(path, distance)
        radius = embodiment.footprint_radius_m
        if approach is None:
            return InteractionAssessment("rejected", source=self.source, evidence=dict(reason="path_has_no_translation"))
        w, h = scene["world_size"]
        if not (radius < approach[0] < w-radius and radius < approach[1] < h-radius) or clearance(scene, [approach])[0] <= radius:
            return InteractionAssessment("rejected", source=self.source, evidence=dict(reason="approach_point_blocked"))
        if navigation.route_to(approach) is None:
            return InteractionAssessment("rejected", source=self.source, evidence=dict(reason="approach_unreachable"))
        after = robot_after(path, scene["world_size"], radius, distance)
        return InteractionAssessment("candidate_feasible", approach, after, self.source,
                                     dict(push_probability=prob, push_source=self.push_table.source))


class PermissiveAssessor(OracleAssessor):
    """Geometry only: an approach point that exists, is clear and is routable is accepted, whatever
    the body can actually push. Used to ask who supplies the body-dependence — with the capability
    check removed from the shared verifier, a plan is body-appropriate only if the model made it so.
    Execution still runs against the measured push tables, so an infeasible choice fails physically.
    """
    source = "geometry_only_permissive"

    def push_probability(self, scene, embodiment, object_id):
        return 1.0
