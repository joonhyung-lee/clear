"""Training for `clear`, `clear_noemb` and `specialist` (spec 8.2-8.4).

Identical data, identical architecture, identical optimiser and update count for all
three; the ONLY differences are the ones the spec prescribes:

    clear        emb_mode='morph'   one shared model, phi_B in the embodiment token
    clear_noemb  emb_mode='none'    one shared model, body-independent context token
    specialist   emb_mode='none'    one model PER BODY, trained on that body's rows only

On this CPU host `--steps` is a smoke number (hundreds).  The paper-scale command is in
REPORT.md; nothing here changes between the two except the config.
"""
from __future__ import annotations

import json
import os
import time

import numpy as np
import torch

from clear.maze.robots import REGISTRY
from experiments.exp3.model import EmbodimentMazePAMO, build_model, collate, load_examples

EMB_MODE = {"clear": "morph", "clear_noemb": "none", "specialist": "none"}


def save_checkpoint(path, model, cfg, extra=None):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "model_config": model.config(),
                "config": cfg, "extra": {"selected_step": getattr(model, 'selected_step', None),
                                             **dict(extra or {})}}, path)
    return path


def load_checkpoint(path, device="cpu"):
    ck = torch.load(path, map_location=device, weights_only=False)
    mc = ck["model_config"]
    if "contract_version" in mc:
        # Serialized architecture is authoritative, even if the caller's YAML changes.
        config = {"model": mc}
    else:
        old = ck["config"].get("model", ck["config"])
        # The old factory ignored dim_head/cond/p_drop/n_obj in YAML. Reproduce
        # what it built, not what an unused config key might have requested.
        keys = ("dim", "depth", "heads", "percept_dim", "percept_depth", "cap_dim", "drop_obj")
        config = {"model": {**{k: old[k] for k in keys if k in old}, "contract_version": 1}}
    model = build_model(config, mc["emb_mode"], grid_hw=tuple(mc["grid_hw"]))
    model.load_state_dict(ck["state_dict"])
    model.to(device).eval()
    return model, ck


@torch.no_grad()
def evaluate_loss(model, examples, batch=32, device="cpu"):
    training = model.training
    model.eval()
    # Independent replayed stream: evaluation must not alter training randomness.
    generator = torch.Generator(device=device).manual_seed(0)
    tot, n = {}, 0
    for i in range(0, len(examples), batch):
        chunk = examples[i:i + batch]
        _, bd = model.loss(collate(chunk, device), generator=generator)
        for k, v in bd.items():
            tot[k] = tot.get(k, 0.0) + v * len(chunk)
        n += len(chunk)
    model.train(training)
    return {k: v / max(n, 1) for k, v in tot.items()}


def train_one(examples, val, cfg, emb_mode, seed, steps, batch, lr, eval_every, device="cpu",
              grid_hw=(12, 12), log=None, verbose=True):
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = build_model(cfg, emb_mode, grid_hw=grid_hw).to(device)
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    rng = np.random.default_rng(seed)
    history = []
    best_loss, best_state, best_step = float('inf'), None, None
    t0 = time.time()
    for step in range(1, steps + 1):
        idx = rng.integers(0, len(examples), size=min(batch, len(examples)))
        loss, bd = model.loss(collate([examples[i] for i in idx], device))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if step == 1 or step % eval_every == 0 or step == steps:
            row = {"step": step, "train": bd,
                   "val": evaluate_loss(model, val, batch, device) if val else {}}
            history.append(row)
            if cfg.get('train', {}).get('checkpoint_selection') == 'val_loss' and val:
                if row['val']['loss'] < best_loss:
                    best_loss, best_step = row['val']['loss'], step
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            if verbose:
                v = row["val"].get("loss", float("nan"))
                print(f"  step {step:6d}  train {bd['loss']:.4f}  val {v:.4f}  "
                      f"edge_acc {bd['edge_acc']:.3f}  ({time.time() - t0:.0f}s)", flush=True)
    if best_state is not None:
        model.load_state_dict(best_state)
    model.selected_step = best_step if best_state is not None else steps
    return model, history


def run(method: str, cfg: dict, data_root: str, run_dir: str, seed: int = 0, device="cpu",
        steps=None, verbose=True) -> dict:
    """-> {'checkpoints': {'shared'|body: path}, 'history': ...}."""
    assert method in EMB_MODE, f"trainable methods: {sorted(EMB_MODE)}"
    tr = dict(cfg.get("train", {}))
    steps = int(steps if steps is not None else tr.get("steps", 200))
    batch, lr = int(tr.get("batch", 32)), float(tr.get("lr", 3e-4))
    eval_every = int(tr.get("eval_every", max(1, steps // 4)))
    grid = int(cfg.get("dataset", {}).get("grid", 12))
    holdout = set(tr.get("holdout_bodies", []) or [])
    train_ex = load_examples(os.path.join(data_root, "train", "examples.npz"))
    val_ex = load_examples(os.path.join(data_root, "val", "examples.npz"))
    if holdout:
        train_ex = [e for e in train_ex if e.embodiment_id not in holdout]
        val_ex = [e for e in val_ex if e.embodiment_id not in holdout]
    # Structural-variant examples (bodies named `<base>@lock=...`) are all LESS capable than their
    # base, so an unweighted family shifts the mover / feasibility prior towards "cannot" and the
    # planner abstains on the four main bodies (family v1: NO_PLAN 52 % vs 27 %, 297 of them with no
    # mover selected). `train.variant_fraction` keeps that fraction of the variant examples
    # (deterministic per seed); 1.0 = family v1, 0.0 = the four bases only.
    vf = tr.get("variant_fraction", None)
    if vf is not None:
        from clear.maze.robots import VARIANT_SEP
        rng = np.random.default_rng(int(seed) + 7919)
        keep = lambda e: VARIANT_SEP not in e.embodiment_id or rng.random() < float(vf)
        train_ex = [e for e in train_ex if keep(e)]
    os.makedirs(run_dir, exist_ok=True)
    out = {"method": method, "seed": seed, "steps": steps, "checkpoints": {}, "history": {},
           "n_train": len(train_ex), "n_val": len(val_ex), "holdout_bodies": sorted(holdout)}
    if method == "specialist":
        bodies = sorted({e.embodiment_id for e in train_ex} & set(REGISTRY))
        for b in bodies:
            tr_b = [e for e in train_ex if e.embodiment_id == b]
            va_b = [e for e in val_ex if e.embodiment_id == b]
            if verbose:
                print(f"[specialist:{b}] {len(tr_b)} train / {len(va_b)} val", flush=True)
            model, hist = train_one(tr_b, va_b, cfg, "none", seed, steps, batch, lr, eval_every,
                                    device, (grid, grid), verbose=verbose)
            out["checkpoints"][b] = save_checkpoint(os.path.join(run_dir, f"checkpoint_{b}.pt"),
                                                    model, cfg, {"method": method, "body": b, "seed": seed})
            out["history"][b] = hist
    else:
        if verbose:
            print(f"[{method}] {len(train_ex)} train / {len(val_ex)} val", flush=True)
        model, hist = train_one(train_ex, val_ex, cfg, EMB_MODE[method], seed, steps, batch, lr,
                                eval_every, device, (grid, grid), verbose=verbose)
        out["checkpoints"]["shared"] = save_checkpoint(os.path.join(run_dir, "checkpoint.pt"),
                                                       model, cfg, {"method": method, "seed": seed})
        out["history"]["shared"] = hist
    with open(os.path.join(run_dir, "train_summary.json"), "w") as f:
        json.dump(out, f, indent=1)
    return out
