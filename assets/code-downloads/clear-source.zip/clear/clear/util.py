"""util: placement, ranking, schedule, shift, validity, qd_cem.

placement: Snap a learned placement onto a feasible one, using the oracle's own predicate.

`CausalVelocityField` has no hard constraint on where an object may be parked --
only a soft `wall_oob_penalty` in training -- so off-family it parks 14-21% of
objects inside a wall, and in the physical executor the hand-off to the SECOND
object stalls (first push succeeds 81% in ~8 s, the second 33% in ~150 s: a
parked object blocking the route to the next one).

The oracle already answers exactly that question, per cell:
`oracle.park_valid(scene, emb, positions, i, pending, cand)` -- with i parked at
`cand`, is every pending object still reachable in sequence, does the goal open
at the end, and does the straight-line push clip neither a wall nor another
object. It is the reason the oracle's own plans score identically under the
strict rule. So nothing here re-derives it:

    keep the model's cell when the oracle would accept it,
    otherwise take the cell the oracle would have chosen.

Two predicate calls per object, both already in the codebase, ~6-10 ms per
scene. Two richer variants were measured and rejected:

  * sorting ALL of `find_parking`'s candidates by distance to the model's cell
    scores higher on `mix` (0.590 vs 0.488) but validates dozens of cells per
    object and needs an argument added to the oracle;
  * accepting the nearest cell within one ring of the model's proposal that
    merely passes `park_valid` is WORSE than both (rooms 0.773, mix 0.277) --
    `find_parking` is not just a validity filter, it carries tie-breaks
    (goal-ward ring order, axis-forward for flanked objects, push-path clip
    checks) that a locally-valid neighbour throws away. Measured, strict rule,
single rollout: mix 0.059 -> 0.590, rooms 0.734 -> 0.867, rooms_fork
0.832 -> 0.949.

ranking: Plackett-Luce ranking likelihood, shared by Stage A's supervised objective
(model/clear.py, --order_objective plackett_luce) and the FPO fine-tuner
(train_pamo_fpo.py). Lived in the latter until 2026-08-31; moved here so the
model package can use it without importing a training script.

schedule: Flow-rate allocation -- the core of this design.

Instead of a per-object activation time tau_i plus an annealed gate, each object
carries its own path time s_i in [0,1] advancing at a network-predicted rate:

    ds_i/dt = w_i(t),    w_i >= 0,    sum_{i in movable} w_i(t) = B

where B = |movable| is the per-scene budget. Consequences:

* Conservation. Total work to do is sum_i (1 - s_i(0)) = B, delivered at rate B,
  so every movable object reaches s_i = 1 at t = 1 -- for *any* allocation
  policy, sequential or simultaneous. Ordering is free to vary; completion is not.
* No collapse. w is a softmax over the movable set, so it cannot vanish. The
  regularizer now *encourages* peakedness (one object at a time) rather than
  fighting a collapse -- the opposite sign from a tau-based gate.
* Vanilla CFM. The velocity head regresses the object's own path velocity at
  s_i, which is schedule-independent. All ordering signal lives in the scalar
  rate head; the flow loss never sees w.
* Causal for free. Object i's pose at time t already reflects everything that
  moved before it, because it is the same ODE. No causal attention mask.

Poses are (..., 3) = (x, y, theta). Rotation integrates as an SO(2) geodesic.
# ponytail: SO(2) because the toy scene is planar. The only change for SE(3) is
# swapping wrap_angle/interp_pose for so3 log/exp -- callers are unaffected.

shift: Scene-family shift detection, post-hoc, for a trained PriorityHead.

Measured motivation (docs/EXPERIMENT_ordering_modes_2026-08-31.md): the head's
ordering distribution is right to be sharp on the family it trained on -- first
-pick accuracy is 1.00 in every confidence quartile there -- and wrong to be
sharp off-family, where the same accuracy is 0.37 in its least-confident
quartile. Softening the argsort with a fixed temperature therefore helps only
off-family and costs in-distribution, so the temperature has to be a function
of how far the scene is from what the head was trained on.

The detector is the standard post-hoc one: a Gaussian fitted to the pooled
scene-token embedding on training-family scenes, scored by Mahalanobis distance
(Lee et al. 2018, arXiv:1807.03888 -- same construction, one layer, no
adversarial tuning). It needs no retraining and no labels, only a bag of
in-family scenes.

    fitter = ShiftScorer.fit(model, examples_in_family, device)
    d = fitter.score(model, batch)             # (b,) Mahalanobis distance
    T = fitter.temperature(d)                  # (b,) >= 1

validity: Endpoint validity penalty for the velocity field's auxiliary loss.

flow_loss (velocity MSE) never sees whether the position it implies is
physically valid -- a small per-step drift that lands the object's final
pose in a wall or on top of another object's target cell still gets a small
MSE, but fails the whole scene at scoring time (see execute_plan). These two
penalties give that a gradient directly, in the object's own xy plane.

qd_cem: Cross-entropy method over spline control knots with quality-diversity elite selection.

Vendored, numpy-only, from two sources so the mjlab executor does not import judo:
  - judo `judo/optimizers/cem.py` (RAI Institute, MIT): sample knots = nominal + sigma * N(0,1),
    keep sample 0 = nominal, elites -> mean / clipped std (`update_nominal_knots`).
  - this repo's `third-party/sumo/sumo/controller/qd_cem.py` (`QDCrossEntropyMethod`): the three
    elite selectors `topk` (judo's), `dpp` (greedy MAP of a quality-diversity DPP over all
    rollouts) and `laqdpp` (locally approximated QD-DPP: top-4k prefilter, RBF bandwidth halved
    and truncated at 2 bandwidths, novelty against the nearest already-selected elite only).
Knots live in normalized [-1, 1] coordinates; `denormalize` maps them to the command bounds. The
spline is piecewise-linear over `num_nodes` knots spanning `horizon_s` seconds (judo default
`spline_order="linear"`). `shift(dt)` re-samples the nominal spline `dt` later for warm starts.
"""
from __future__ import annotations

# ---- placement ----
import numpy as np

from clear.data.capability import WALL
from clear.data.oracle import find_parking, park_valid


class NoFeasiblePlacement(ValueError):
    """The proposed order cannot be projected to feasible object placements."""


def snap(scene, emb, order, final):
    """Return projected cells, or raise NoFeasiblePlacement when projection fails.
    Sequential by construction: `positions` accumulates as objects are placed,
    exactly as `oracle.assign_goal_cells` does it, so each decision sees the
    world the previous one left behind."""
    h, w = scene.terrain.shape
    positions = [o.cell for o in scene.objects]
    out = {}
    for k, i in enumerate(order):
        pending = list(order[k + 1:])
        want = final.get(i, positions[i])
        want = (int(np.clip(want[0], 0, h - 1)), int(np.clip(want[1], 0, w - 1)))
        occupied = {p for j, p in enumerate(positions) if j != i}
        admissible = (int(scene.terrain[want]) != WALL and want not in occupied
                      and want not in (scene.start, scene.goal))
        if admissible and park_valid(scene, emb, positions, i, pending, want):
            out[i] = want
        else:
            candidate = find_parking(scene, emb, positions, i, pending)
            if candidate is None or not park_valid(scene, emb, positions, i, pending, candidate):
                raise NoFeasiblePlacement(f'no feasible placement for object {i} at step {k}')
            out[i] = candidate
        positions[i] = out[i]
    return out


def final_cells(plan, i, order):
    """The (r, c) a sampled plan puts each mover in -- the same round-and-swap
    `eval.success_rate` scores with, in one place."""
    x = plan['x'][i].detach().cpu().numpy() if hasattr(plan['x'], 'detach') else plan['x'][i]
    return {j: (int(round(float(x[j, 1]))), int(round(float(x[j, 0])))) for j in order}


# ---- ranking ----
import torch


def plackett_luce_logp(scores, orders, movable):
    """Exact log-prob of the FULL ranking `orders` (movable-only index
    tuples, one per example -- same convention as orders_from_u's own
    output) under a Plackett-Luce model with per-object preference `scores`
    (b, n), via the standard sequential-softmax factorization:
        logp(order) = sum_k [ scores[order[k]] - logsumexp(scores[order[k:]]) ]

    This is EXACT (not a surrogate) when the order was sampled by
    argsort_ascending(mu - Gumbel(0,1)) with `scores = -mu` and CONSTANT
    sigma across objects -- priority_head.py's own noise='gumbel' mode
    (see its sample_noise() docstring: "argmin(mu - G) is a Plackett-Luce
    sample with scores -mu"). Per-object sigma is dropped here (scores use
    mu/temperature only, not sigma) -- a deliberate simplification: exact
    Thurstonian order statistics for INDEPENDENT-scale Gumbels have no
    closed form this simple, and every checkpoint measured so far
    (SS37-42) keeps sigma pinned near its floor and roughly uniform across
    objects, so the constant-sigma assumption costs little in practice.
    ponytail: if a future run pushes sigma far off the floor AND highly
    non-uniform across objects, this stops being a good approximation --
    would need a per-object-scale generalization (no simple closed form,
    likely MC estimation) at that point.

    Reused (2026-08-22, PLAN doc SS43) as the Stage A objective in place of
    _order_logp's Gaussian-on-u approximation -- see module docstring's
    STAGE A OBJECTIVE section for why: _order_logp's ratio measures "how
    likely was this exact continuous u", which is only weakly correlated
    with "how likely is this DISCRETE order" near an argsort decision
    boundary (confirmed empirically: aggressive Gaussian-objective runs
    that finally forced order[0] to flip did so in essentially random
    directions, net negative on held-out p_success). This function scores
    the discrete outcome directly, so credit assignment lands on whichever
    ranking the reward actually depended on. -> (b,)."""
    b = scores.shape[0]
    out = scores.new_zeros(b)
    for i, order in enumerate(orders):
        if not order:
            continue
        idx = torch.as_tensor(order, dtype=torch.long, device=scores.device)
        s = scores[i, idx]  # (m,), in the order's own commit sequence
        # suffix logsumexp at each position k: logsumexp(s[k:]) -- computed
        # via logcumsumexp on the reversed sequence then flipped back,
        # O(m) instead of an O(m^2) python double-loop (m<=4 in practice
        # either way, but this is the standard trick and just as simple).
        lse_suffix = torch.flip(torch.logcumsumexp(torch.flip(s, dims=[0]), dim=0), dims=[0])
        out[i] = (s - lse_suffix).sum()
    return out


# ---- schedule ----
POSE = 3  # x, y, theta


def wrap_angle(a):
    """Map angle(s) to (-pi, pi]."""
    pi = np.pi
    if isinstance(a, torch.Tensor):
        return (a + pi) % (2 * pi) - pi
    return (a + pi) % (2 * pi) - pi


def path_velocity(x0, x1):
    """Constant velocity along object's own path time s. Geodesic in theta."""
    v = x1 - x0
    v[..., 2] = wrap_angle(x1[..., 2] - x0[..., 2])
    return v


def interp_pose(x0, x1, s):
    """Pose at path time s in [0,1]. s broadcasts against the leading dims."""
    v = path_velocity(x0, x1)
    out = x0 + s[..., None] * v
    out[..., 2] = wrap_angle(out[..., 2])
    return out


def path_pose_velocity(path_cells, theta0, theta1, s):
    """Pose + velocity at path-time s in [0,1], following a cell-to-cell path
    (grid.cell_path -- diagonal allowed, but never through a wall corner)
    instead of a straight line that can cut through walls. Segments are
    weighted by their actual length (cardinal 1, diagonal sqrt2) so s
    advances at constant speed along the path; theta interpolates
    independently (geodesic, path-shape-agnostic) same as before.

    path_cells: [(r0,c0), (r1,c1), ...] from grid.cell_path.
    -> (pose (3,), velocity (3,)) float32 arrays, x/y/theta."""
    s = float(np.clip(s, 0.0, 1.0))
    dtheta = wrap_angle(theta1 - theta0)
    theta = wrap_angle(theta0 + s * dtheta)

    k = len(path_cells) - 1
    if k <= 0:
        r, c = path_cells[0]
        pose = np.array([c, r, theta], dtype=np.float32)
        vel = np.array([0.0, 0.0, dtheta], dtype=np.float32)
        return pose, vel

    seg_len = [
        ((path_cells[i + 1][0] - path_cells[i][0]) ** 2
         + (path_cells[i + 1][1] - path_cells[i][1]) ** 2) ** 0.5
        for i in range(k)
    ]
    total = sum(seg_len)
    frac = [0.0]
    for L in seg_len:
        frac.append(frac[-1] + L / total)
    frac[-1] = 1.0  # guard float drift

    m = k - 1
    for i in range(k):
        if s <= frac[i + 1]:
            m = i
            break
    span = frac[m + 1] - frac[m]
    u = (s - frac[m]) / span if span > 0 else 0.0
    r0, c0 = path_cells[m]
    r1, c1 = path_cells[m + 1]
    pose = np.array([c0 + u * (c1 - c0), r0 + u * (r1 - r0), theta], dtype=np.float32)
    vel_scale = 1.0 / span if span > 0 else 0.0
    vel = np.array([(c1 - c0) * vel_scale, (r1 - r0) * vel_scale, dtheta], dtype=np.float32)
    return pose, vel


def allocate(logits, s, movable, eps=1e-6):
    """Per-object flow rate. logits/s/movable are (..., N). Returns (..., N).

    Rate sums to the movable budget over objects still in flight; objects that
    are done or immovable get exactly zero.
    """
    budget = movable.sum(-1, keepdim=True).to(logits.dtype)
    active = movable & (s < 1.0 - eps)
    any_active = active.any(-1, keepdim=True)
    w = torch.softmax(logits.masked_fill(~active, -torch.inf), dim=-1)
    w = torch.where(any_active, w, torch.zeros_like(w))
    return w * budget


def advance(s, w, dt):
    """Integrate path progress one step, clamped at completion."""
    return (s + w * dt).clamp(0.0, 1.0)


def oracle_progress(order, n_objects: int, t: float):
    """Ground-truth schedule: object `order[k]` owns the time slot
    [k/B, (k+1)/B) and moves at rate B during it.

    Returns (s, active_index) where s is (n_objects,) float32. Objects outside
    `order` (immovable for this embodiment) stay at s = 0.
    """
    b = len(order)
    s = np.zeros(n_objects, dtype=np.float32)
    if b == 0:
        return s, -1
    slot = min(int(t * b), b - 1)
    for k, i in enumerate(order[:slot]):
        s[i] = 1.0
    s[order[slot]] = np.clip(t * b - slot, 0.0, 1.0)
    return s, order[slot]


def decode_order(w_trace):
    """Recover a discrete move order from a rollout's rate trace.

    w_trace: (T, N). Objects sorted by the first timestep they received the
    largest share; never-dominant objects go last by total mass.
    """
    w = np.asarray(w_trace)
    first = {}
    for t in range(w.shape[0]):
        i = int(w[t].argmax())
        first.setdefault(i, t)
    totals = w.sum(0)
    return sorted(range(w.shape[1]), key=lambda i: (first.get(i, 10**9), -totals[i]))


# ---- shift ----
def scene_embedding(model, batch):
    """Pooled scene tokens as the head itself sees them -- mean over the token
    axis of `scene_encoder(grid)`. This is the representation the ordering
    decision is actually conditioned on, which is why it, and not the raw grid,
    is what gets a density fitted to it."""
    with torch.no_grad():
        return model.priority_head.scene_encoder(batch['grid']).mean(dim = 1)


class ShiftScorer:
    def __init__(self, mean, prec, d_ref, scale = 1.0):
        self.mean, self.prec, self.d_ref, self.scale = mean, prec, d_ref, scale

    @classmethod
    def fit(cls, model, batches, quantile = 0.95, shrink = 1e-3):
        """`batches`: iterable of in-family batches. Shrinkage on the covariance
        because the embedding dimension (128-256) is close to the number of
        scenes anyone fits this on."""
        feats = torch.cat([scene_embedding(model, b) for b in batches]).double()
        mean = feats.mean(0)
        x = feats - mean
        cov = (x.T @ x) / max(len(x) - 1, 1)
        cov = cov + shrink * torch.eye(cov.shape[0], dtype = cov.dtype,
                                        device = cov.device) * cov.diagonal().mean()
        prec = torch.linalg.pinv(cov)
        d = torch.einsum('bi,ij,bj->b', x, prec, x).sqrt()
        return cls(mean, prec, float(torch.quantile(d, quantile)))

    def score(self, model, batch):
        x = scene_embedding(model, batch).double() - self.mean
        return torch.einsum('bi,ij,bj->b', x, self.prec, x).sqrt()

    def temperature(self, d, t_max = 128.0):
        """1 in family, rising once the distance passes the in-family 95th
        percentile. Geometric in the excess so the knob is one number: T = 1 at
        d_ref, t_max at `scale` * d_ref."""
        excess = (d / max(self.d_ref, 1e-6)).clamp(min = 1.0) - 1.0
        return (1.0 + excess * self.scale).clamp(max = t_max)


# ---- validity ----
import torch.nn.functional as F


def wall_oob_penalty(xy_norm: torch.Tensor, wall_channel: torch.Tensor) -> torch.Tensor:
    """xy_norm: (b, n, 2) grid_sample-normalized (x, y) in roughly [-1, 1].
    wall_channel: (b, 1, H, W) WALL occupancy in {0, 1}.
    -> (b, n) bilinear WALL occupancy at the point, plus an out-of-bounds hinge
    (grid_sample's zero-padding alone would not penalize leaving the canvas)."""
    grid = xy_norm[:, :, None, :]  # (b, n, 1, 2)
    occ = F.grid_sample(wall_channel, grid, align_corners=True, padding_mode="zeros")
    occ = occ[:, 0, :, 0]  # (b, n)
    oob = F.relu(xy_norm.abs() - 1.0).sum(-1)
    return occ + oob


def overlap_penalty(pred_xy: torch.Tensor, target_xy: torch.Tensor, margin: float = 0.85) -> torch.Tensor:
    """pred_xy, target_xy: (b, n, 2). target_xy is every object's final
    position under the sampled order (x1_eff -- x0 for non-movers, so
    immovable/parked objects are obstacles too). -> (b, n) mean squared
    hinge distance from object i's predicted endpoint to every OTHER
    object's target cell (self pair excluded)."""
    d = (pred_xy[:, :, None, :] - target_xy[:, None, :, :]).norm(dim=-1)  # (b, n, n)
    eye = torch.eye(d.shape[-1], dtype=torch.bool, device=d.device)
    hinge = F.relu(margin - d) ** 2
    hinge = hinge.masked_fill(eye, 0.0)
    return hinge.mean(-1)


# ---- qd_cem ----
from dataclasses import dataclass



@dataclass
class CEMConfig:
    num_rollouts: int = 24        # judo Spot override
    num_nodes: int = 3            # judo Spot override
    num_elites: int = 3           # judo Spot override
    sigma_min: float = 0.1        # normalized units (judo defaults 0.1 / 1.0)
    sigma_max: float = 1.0
    horizon_s: float = 2.0        # judo Spot override
    selector: str = "laqdpp"      # topk | dpp | laqdpp
    sigma_init: float | tuple = 0.5   # scalar, or one value per command dimension

    def __post_init__(self):
        if self.selector not in ("topk", "dpp", "laqdpp"):
            raise ValueError(f"unknown selector {self.selector!r}")
        if self.num_rollouts < 2 or self.num_nodes < 2 or self.num_elites < 1:
            raise ValueError("need >= 2 rollouts, >= 2 nodes, >= 1 elite")
        if not (0 < self.sigma_min <= self.sigma_max):
            raise ValueError("0 < sigma_min <= sigma_max required")
        if not np.all(np.asarray(self.sigma_init, float) > 0):
            raise ValueError("sigma_init must be positive")


def pick_qd(Z: np.ndarray, q: np.ndarray, k: int, local: bool) -> np.ndarray:
    """Greedy RBF DPP selection, or a nearest-selected local QD heuristic.

    The local branch is not exact DPP MAP or DPP sampling. It truncates
    similarities and approximates novelty using only the nearest selected item.
    """
    n = len(q)
    if local:
        m = min(n, 4 * k)
        cand = np.argsort(-q)[:m]
    else:
        cand = np.arange(n)
    Zc, qc = Z[cand], q[cand]
    d2 = ((Zc[:, None, :] - Zc[None, :, :]) ** 2).sum(-1)
    off = d2[np.triu_indices(len(cand), 1)]
    ell = float(np.sqrt(np.median(off))) if off.size and np.median(off) > 0 else 1.0
    if local:
        ell *= 0.5
    S = np.exp(-d2 / (2 * ell * ell))
    if local:
        S[d2 > (2 * ell) ** 2] = 0.0
    picks = [int(np.argmax(qc))]
    while len(picks) < min(k, len(cand)):
        C = np.array(picks)
        if local:
            nov = 1.0 - S[:, C].max(axis=1) ** 2
        else:
            S_cc = S[np.ix_(C, C)] + 1e-6 * np.eye(len(C))
            S_xc = S[:, C]
            nov = 1.0 - np.einsum("ic,ic->i", S_xc @ np.linalg.inv(S_cc), S_xc)
        gain = qc ** 2 * np.clip(nov, 0.0, None)
        gain[C] = -np.inf
        picks.append(int(np.argmax(gain)))
    return cand[np.array(picks)]


class QDCEM:
    """One optimiser instance per interaction phase. `lo`/`hi`: (nu,) command bounds."""

    def __init__(self, cfg: CEMConfig, lo, hi, rng: np.random.Generator, nominal=None):
        self.cfg = cfg
        self.lo = np.asarray(lo, float)
        self.hi = np.asarray(hi, float)
        if self.lo.shape != self.hi.shape or np.any(self.hi <= self.lo):
            raise ValueError("bounds must be (nu,) with hi > lo")
        self.nu = len(self.lo)
        self.rng = rng
        self.times = np.linspace(0.0, cfg.horizon_s, cfg.num_nodes)
        self.nominal = np.zeros((cfg.num_nodes, self.nu)) if nominal is None else self.normalize(np.asarray(nominal, float))
        self.nominal = np.broadcast_to(self.nominal, (cfg.num_nodes, self.nu)).copy()
        self.sigma = np.broadcast_to(np.asarray(cfg.sigma_init, float), (cfg.num_nodes, self.nu)).copy()
        self.last = {}

    # -- coordinates ------------------------------------------------------------------------
    def normalize(self, u):
        return 2.0 * (np.asarray(u, float) - self.lo) / (self.hi - self.lo) - 1.0

    def denormalize(self, x):
        return self.lo + (np.clip(x, -1.0, 1.0) + 1.0) / 2.0 * (self.hi - self.lo)

    # -- judo CEM -----------------------------------------------------------------------------
    def sample(self, guide=None) -> np.ndarray:
        """(num_rollouts, num_nodes, nu) normalized knots; sample 0 is the nominal. `guide`, if
        given, is a normalized (nu,) command held constant over the horizon and placed in sample 1
        (a guided CEM: the teacher's open-loop command competes with the noise samples for the
        elite set, so the optimiser never scores below the teacher it was given)."""
        c = self.cfg
        noise = self.rng.standard_normal((c.num_rollouts - 1, c.num_nodes, self.nu))
        knots = np.concatenate([self.nominal[None], self.nominal[None] + self.sigma[None] * noise])
        if guide is not None:
            if c.num_rollouts < 3:
                raise ValueError("a guide sample needs >= 3 rollouts")
            knots[1] = np.broadcast_to(np.asarray(guide, float), (c.num_nodes, self.nu))
        return np.clip(knots, -1.0, 1.0)

    def controls(self, knots: np.ndarray, n_steps: int, dt: float) -> np.ndarray:
        """Piecewise-linear evaluation of every rollout's knots at t = 0, dt, ..., (n-1) dt,
        in COMMAND units -> (num_rollouts, n_steps, nu)."""
        t = np.arange(n_steps) * dt
        out = np.empty((knots.shape[0], n_steps, self.nu))
        for r in range(knots.shape[0]):
            for j in range(self.nu):
                out[r, :, j] = np.interp(t, self.times, knots[r, :, j])
        return self.denormalize(out)

    def update(self, knots: np.ndarray, rewards: np.ndarray) -> None:
        """Elite mean -> nominal, clipped elite std -> sigma (judo), elites picked by the selector."""
        c = self.cfg
        r = np.asarray(rewards, float)
        finite = np.isfinite(r)
        if finite.sum() < 2:
            return
        r = np.where(finite, r, np.nanmin(r[finite]))
        k = min(c.num_elites, len(r))
        if c.selector == "topk" or k >= len(r):
            elite = np.flip(np.argsort(r))[:k]
        else:
            tau = float(np.std(r)) + 1e-9
            q = np.exp((r - r.max()) / tau)
            Z = (knots / (self.sigma[None] + 1e-9)).reshape(len(r), -1)
            elite = pick_qd(Z, q, k, local=(c.selector == "laqdpp"))
        ek = knots[elite]
        self.nominal = ek.mean(0)
        self.sigma = np.clip(np.sqrt(ek.var(0)), c.sigma_min, c.sigma_max)
        self.last = dict(elite=elite.tolist(), best_reward=float(r.max()), elite_reward=float(r[elite].mean()),
                         sigma_mean=float(self.sigma.mean()))

    def shift(self, dt: float) -> None:
        """Warm start: the nominal spline evaluated `dt` later becomes the new nominal (judo
        `_pre_optimization`: `self.spline(self._new_times)`)."""
        t_new = np.clip(self.times + dt, self.times[0], self.times[-1])
        self.nominal = np.stack([np.interp(t_new, self.times, self.nominal[:, j]) for j in range(self.nu)], axis=1)

    def first_command(self) -> np.ndarray:
        return self.denormalize(self.nominal[0])


def _self_check():
    rng = np.random.default_rng(0)
    # (1) topk is judo's rule; (2) with three near-duplicate top rollouts and one good-but-
    # different rollout, dpp/laqdpp include the different one and topk does not (sumo self-check).
    cfg = CEMConfig(num_rollouts=12, num_nodes=3, num_elites=3, selector="topk")
    lo, hi = -np.ones(3), np.ones(3)
    base = QDCEM(cfg, lo, hi, rng)
    knots = rng.normal(size=(12, 3, 3)) * 0.3
    knots[1] = knots[0] + 1e-3
    knots[2] = knots[0] - 1e-3
    knots[3] = np.clip(knots[0] + 0.9, -1, 1)
    rewards = rng.normal(size=12) - 5
    rewards[[0, 1, 2]] = [10.0, 9.9, 9.8]
    rewards[3] = 9.5
    base.update(knots.copy(), rewards.copy())
    ref = base.nominal.copy()
    assert np.allclose(ref, knots[[0, 1, 2]].mean(0)), "topk must equal judo's elite mean"
    for sel in ("dpp", "laqdpp"):
        opt = QDCEM(CEMConfig(num_rollouts=12, num_nodes=3, num_elites=3, selector=sel), lo, hi, rng)
        opt.update(knots.copy(), rewards.copy())
        assert 3 in opt.last["elite"], f"{sel} must keep the different rollout"
        assert not np.allclose(opt.nominal, ref), sel
    # (3) controls interpolate the knots: first step == first knot, last step -> last knot
    c = base.controls(knots, n_steps=41, dt=cfg.horizon_s / 40)
    assert c.shape == (12, 41, 3)
    assert np.allclose(c[:, 0], base.denormalize(knots[:, 0])) and np.allclose(c[:, -1], base.denormalize(knots[:, -1]))
    # (4) CEM descends a quadratic: 15 iterations from sigma 0.5 land within 0.1 of the optimum
    target = np.array([0.3, -0.4])
    opt = QDCEM(CEMConfig(num_rollouts=32, num_nodes=2, num_elites=4, selector="laqdpp"), -np.ones(2), np.ones(2), rng)
    for _ in range(15):
        k = opt.sample()
        opt.update(k, -((opt.denormalize(k) - target) ** 2).sum((1, 2)))
    assert np.abs(opt.first_command() - target).max() < 0.1, opt.first_command()
    # (5) guide sample occupies row 1 verbatim; per-dimension sigma_init broadcasts over knots
    opt = QDCEM(CEMConfig(num_rollouts=8, num_nodes=3, num_elites=2, sigma_init=(0.5, 0.1)), -np.ones(2), np.ones(2), rng)
    assert opt.sigma.shape == (3, 2) and np.allclose(opt.sigma[:, 1], 0.1)
    k = opt.sample(guide=np.array([0.7, -0.2]))
    assert np.allclose(k[1], [0.7, -0.2]) and np.allclose(k[0], 0.0)
    print("qd_cem self-check OK")
