"""Evaluation metrics for the PAMO planner -- order accuracy (with the
multimodal validity / coverage variants), sliced accuracy, scene-level
success, and pose error. Model-agnostic scoring lives here so model/ holds
networks only.

Honest-scoring rules preserved from the original metrics section:
n_moved == 0 scenes are excluded (free hits), success is judged by executing
the sampled plan (oracle-free), and multimodal scenes are scored against the
full oracle mode set.
"""

import numpy as np
import torch

from clear.model.clear import PAMO
from clear.util import wrap_angle

def order_accuracy(model: PAMO, examples, batch, k = 1, generator = None, reject = False):
    """Fraction whose FIRST sampled order matches some oracle order on the
    objects that actually move. n_moved == 0 scenes are excluded (they score
    free hits). Extra samples feed the multimodal metrics:
      validity - fraction of samples matching ANY oracle prefix
      coverage - distinct valid prefixes found / oracle prefixes
    """
    sampled = model.sample_orders(batch, k = k, generator = generator,
                                  examples = examples if reject else None)
    scored = [(i, ex) for i, ex in enumerate(examples) if ex.n_moved > 0]
    hits = sum(
        any(sampled[0][i][:ex.n_moved] == o[:ex.n_moved] for o in ex.orders)
        for i, ex in scored
    )
    acc = hits / len(scored) if scored else float('nan')

    multi = [(i, ex) for i, ex in enumerate(examples) if ex.n_moved > 0 and len(ex.orders) > 1]
    validity = coverage = float('nan')
    if multi and k > 1:
        vals, covs = [], []
        for i, ex in multi:
            prefixes = {o[:ex.n_moved] for o in ex.orders}
            got = [sampled[s][i][:ex.n_moved] for s in range(k)]
            valid = [g for g in got if g in prefixes]
            vals.append(len(valid) / k)
            covs.append(len(set(valid)) / len(prefixes))
        validity, coverage = float(np.mean(vals)), float(np.mean(covs))

    return acc, len(scored), validity, coverage, len(multi)


def order_acc_by(model: PAMO, examples, batch, generator = None):
    """First-sample order accuracy sliced by embodiment and by n_moved.
    The aggregate hides the rare embodiments (wheel is ~6% of examples) and
    the deep scenes the ordering claim rests on -- these slices don't."""
    sampled = model.sample_orders(batch, k = 1, generator = generator)[0]
    hits, counts = {}, {}
    for i, ex in enumerate(examples):
        if ex.n_moved == 0:
            continue
        hit = any(sampled[i][:ex.n_moved] == o[:ex.n_moved] for o in ex.orders)
        for key in (f'emb_{ex.emb_name}', f'depth_{min(ex.n_moved, 4)}'):
            hits[key] = hits.get(key, 0) + hit
            counts[key] = counts.get(key, 0) + 1
    return {k: (hits[k] / counts[k], counts[k]) for k in counts}


@torch.no_grad()
def success_rate(model: PAMO, examples, batch, n_steps = 30, generator = None, reject = False,
                 smoothness_cond = None, k = 1, jitter = 0.0, snap_placement = False):
    """Scene-level success, the oracle-free scoring rule: snap final poses to
    cells, execute the sampled plan, and ask whether the goal actually opened.
    Judges cross-set modes fairly at the ORDER level -- any executable plan
    that opens the path counts, oracle-matching or not.

    `k = 1` (default): -> (sr, scored, plan), EXACTLY as before this
    parameter existed -- single sample, byte-identical numbers and return
    shape for every existing caller.

    `k > 1`: draws k independent samples (same `generator`, so each draw
    advances its state -- deterministic given the outer seed, no separate
    per-draw seeding needed) and additionally reports, as a 4th return value,
    `sr_any` -- the fraction of scenes where AT LEAST ONE of the k samples
    succeeds. This is the scene-level analogue of `order_accuracy`'s own
    k-sample `validity`/`coverage`: a model that reliably finds SOME valid
    mode across a few tries is not penalized by a single unlucky sample the
    way `sr` (still reported, still the k=1-equivalent single-sample number)
    would. `sr` and `plan` are always computed from draw 0 only, regardless
    of k, so they mean the same thing at any k -- `sr_any` is what changes.

    Returning a 4-tuple only when k > 1 (rather than always padding with a
    fifth NaN field) is deliberate: this function has exactly one caller in
    this codebase today (train_clear.py, always at the k=1 default), so there
    is nothing to keep byte-compatible for k > 1 -- the shape only has to
    stay stable for k = 1, which it does.

    `smoothness_cond`: forwarded to model.sample() -- required (non-None) if
    `model` was built with condition_smoothness=True, ignored otherwise."""
    from clear.data.capability import EMBODIMENTS
    from clear.data.data import embodiment_of, example_scene
    from clear.data.oracle import plan_success

    assert k >= 1
    scored_examples = [(i, ex) for i, ex in enumerate(examples) if ex.n_moved > 0]
    any_hit = [False] * len(examples)
    sr_first = scored = None
    plan_first = None

    for draw in range(k):
        plan = model.sample(batch, n_steps = n_steps, generator = generator,
                            examples = examples if reject else None,
                            smoothness_cond = smoothness_cond, jitter = jitter)
        x = plan['x'].cpu().numpy()
        hits = 0
        for i, ex in scored_examples:
            scene = example_scene(ex)
            order = plan['orders'][i]
            final = {j: (int(round(float(x[i, j, 1]))), int(round(float(x[i, j, 0])))) for j in order}
            if snap_placement:
                from clear.util import NoFeasiblePlacement, snap
                try:
                    final = snap(scene, embodiment_of(ex), list(order), final)
                except NoFeasiblePlacement:
                    continue  # This proposal fails; later draws may still succeed.
            ok = plan_success(scene, embodiment_of(ex), order, final)
            hits += ok
            any_hit[i] = any_hit[i] or ok
        if draw == 0:
            plan_first = plan
            scored = len(scored_examples)
            sr_first = hits / scored if scored else float('nan')

    if k == 1:
        return sr_first, scored, plan_first

    sr_any = (sum(any_hit[i] for i, ex in scored_examples) / scored) if scored else float('nan')
    return sr_first, scored, plan_first, sr_any


def pose_error(plan, batch):
    """Mean translation / rotation error of movable objects at t = 1."""
    movable = batch['movable']
    diff = plan['x'] - batch['x1']
    trans = diff[..., :2].norm(dim = -1)[movable].mean().item()
    rot = wrap_angle(diff[..., 2]).abs()[movable].mean().item()
    return trans, rot


def _self_check():
    """success_rate's k contract: k=1 (default) must return the exact same
    3-tuple, byte-identical, as the pre-k version of this function. k>1 must
    return a 4-tuple whose 4th value (sr_any) is a fraction >= the 1st
    (sr_first, draw-0-only) -- "at least one of k succeeded" can never be
    less likely than "the first one succeeded" -- and, on a genuinely
    stochastic model/scene mix, strictly greater on at least one repeat
    (otherwise k>1 would be measuring nothing new, the E4PAMO dead-input bug
    one level up: an aggregate that never differs from its own first term is
    exactly as useless as a feature nothing reads)."""
    from clear.data.data import build_examples, collate

    examples = build_examples(24, h = 8, w = 8, n_objects = 4, seed = 3)
    rng = np.random.default_rng(0)
    batch = collate(examples, rng)
    torch.manual_seed(0)
    model = PAMO(grid_hw = (8, 8), dim = 32, depth = 2, heads = 2, dim_head = 16)

    gen = torch.Generator().manual_seed(0)
    sr1, scored1, plan1 = success_rate(model, examples, batch, generator = gen)
    assert isinstance(plan1, dict) and 'x' in plan1 and 'orders' in plan1

    gen = torch.Generator().manual_seed(0)
    result_k = success_rate(model, examples, batch, generator = gen, k = 4)
    assert len(result_k) == 4, "k>1 must return a 4-tuple"
    sr4, scored4, plan4, sr_any = result_k
    assert scored4 == scored1, "scored count must not depend on k"
    # draw 0 under the SAME generator seed must reproduce k=1 exactly -- the
    # first draw of a k=4 call is not a different computation from a k=1 call.
    assert sr4 == sr1, (sr4, sr1)
    assert torch.equal(plan4['x'], plan1['x']), "draw 0's plan must match the k=1 plan exactly"

    assert sr_any >= sr4 - 1e-9, f"sr_any ({sr_any}) must be >= sr_first ({sr4})"
    assert sr_any > sr4 + 1e-9, (
        "sr_any never exceeded sr_first across k=4 draws on an untrained (near-random) "
        "model/24-scene mix -- k-sample aggregation isn't finding anything a single "
        "sample didn't, which means it isn't measuring anything new")
    print(f"ok success_rate k=1 unchanged (sr={sr1:.3f}), k=4 draw-0 matches exactly, "
         f"sr_any={sr_any:.3f} > sr_first={sr4:.3f} (k-sampling finds real additional hits)")


if __name__ == "__main__":
    _self_check()
