"""encoders: scene_encoder, perception_encoder, capability_encoder, structure_encoder, kappa_set_encoder.

scene_encoder: Scene encoder + object tokenizer: raw scene inputs -> tokens.

ein notation:
  b - batch
  n - objects
  s - scene tokens
  d - model dimension

perception_encoder: Perception encoder: metric terrain + embodiment -> per-cell features.

This is the box the grid pipeline skipped. There, `project.classify_terrain`
thresholded heights into FLAT/STEP/WALL with two global constants and the
network saw only the one-hot result, so it could not represent "0.29 m ledge"
at all, and every body shared one classification.

Here the encoder consumes metres and is conditioned on the body, because
traversability is a joint function of the two. The conditioning is FiLM rather
than a concatenated token: a wheel and a humanoid looking at the same ledge
must produce *different features for the same pixel*, which is a per-location
modulation, not a global summary another layer has to route.

What is handed over and what is learned, deliberately:

  handed over   the signed step-up to each 4-neighbour (`edge_deltas`). It is
                an exact finite difference of the input, so making a 3x3 conv
                rediscover it only adds an approximation error right where the
                decision boundary is.

  learned       the comparison of that step-up against the body's climb limit.
                Feeding `limit - delta` directly would make the auxiliary head
                trivial and measure nothing; leaving it to FiLM means the head's
                accuracy is evidence that capability conditioning works, and
                that evidence transfers to bodies with limits never trained on.

ein notation:
  b - batch      d - channels
  h, w - grid    e - edge directions (4)

capability_encoder: LEGACY capability encoder: the spec-sheet path. Superseded by KappaSetEncoder.

This encodes capability.feature_vector -- a fixed table of limits (terrain
classes, mass / extent caps, arms) handed to the model as ground truth. That
framing is retired (2026-09-02): kappa is now a MEASURED behavioral profile --
(probe, outcome, provenance) rows produced by the calibration instruments in
experiments/kappa_measure/ (rendered in experiments/kappa_arena/) and encoded
by model/kappa_set_encoder.py, which is the default in PAMO and train_clear.

This class stays only so pre-kappa checkpoints keep loading
(capability_encoder='vector'). Do not reach for it in new work: a spec sheet
cannot say "untested", cannot carry a success RATE, and cannot grow a row
without a retrain -- the three properties the measured set was built for.

structure_encoder: Row MLP and masked pooling, with the original Sequential checkpoint keys.

kappa_set_encoder: KappaSetEncoder: a SET of probe observations -> one capability token.

Drop-in for CapabilityEncoder (same (b, 1, dim) output) but the input is
`(probe_set (b, P, 3), probe_mask (b, P) bool)` from data.probes, not a fixed
vector. Per-probe token = Embedding(probe_id) + MLP([query, outcome]);
masked mean + max pooling (DeepSets) -> Linear. Permutation-invariant by
construction, and any subset of probes is a valid input -- that is what lets a
measured robot with a missing probe, or a test-time ablation of probes, reach
the same planner.

Training-time probe dropout: each probe dropped with p_drop, never all of them.
Eval keeps every probe the mask allows.

    python -m clear.model.kappa_set_encoder   # self-check
"""

# ---- scene_encoder ----
import torch
from einops import rearrange
from torch import nn
from torch.nn import Module

# constants

SCENE_CHANS = 5  # flat / step / wall / start / goal
OBJ_COLS = ('x', 'y', 'cos', 'sin', 'mass', 'extent', 's', 't', 'can_move')
OBJ_FEAT = len(OBJ_COLS)

# Columns a run can withhold, to make the model work something out instead of
# being told it.
#
#   'can_move'  the ANSWER to the manipulation half of the capability question.
#   'mass'      the harder one. can_move is just mass <= max_mass, both of which
#               are handed over, so withholding only can_move leaves a
#               comparison between two given numbers -- which is why removing it
#               cost about one standard deviation. Withhold mass as well and the
#               model has to read weight off the object's shape, which the
#               generator makes possible because crate mass is density times
#               volume.
DROPPABLE = ('mass', 'can_move')


def obj_feat_dim(drop = (), include_reachable = False):
    return OBJ_FEAT - len(set(drop)) + int(include_reachable)


def object_features(poses, mass, extent, s, t, movable, grid_hw, drop = (), reachable0 = None):
    """Assemble (b, n, obj_feat_dim(drop, reachable0 is not None)) object features.

    poses is (b, n, 3) = x, y, theta. `drop` names columns to withhold; see
    DROPPABLE. `reachable0`: optional (b, n) bool -- is object i's own cell
    reachable from scene.start with every OTHER object at its initial cell
    (Example.reachable0, see data.py's own docstring on that field for why
    this is missing signal, not decoration). None (default, every existing
    call site) omits the column entirely -- byte-identical to before this
    was added; only a model constructed with use_reachable=True passes it.
    """
    h, w = grid_hw
    scale = poses.new_tensor([w - 1, h - 1])
    xy = poses[..., :2] / scale * 2 - 1
    theta = poses[..., 2]
    t = torch.as_tensor(t, dtype = poses.dtype, device = poses.device)
    t = (t[:, None] if t.dim() == 1 else t).expand(s.shape)
    cols = [
        xy[..., 0],
        xy[..., 1],
        torch.cos(theta),
        torch.sin(theta),
        torch.log1p(mass) / 3.,
        extent,
        s,
        t,
        movable.to(poses.dtype),
    ]
    drop = set(drop)
    assert drop <= set(DROPPABLE), f'cannot drop {drop - set(DROPPABLE)}'
    feats = [c for name, c in zip(OBJ_COLS, cols) if name not in drop]
    if reachable0 is not None:
        feats.append(reachable0.to(poses.dtype))
    return torch.stack(feats, dim = -1)

# scene encoder


class SceneEncoder(Module):
    """Terrain / occupancy grid -> a small set of spatial tokens."""

    def __init__(self, dim, grid_hw, channels = SCENE_CHANS, stride = 2):
        """stride 2 (default): one token per 2x2 patch. stride 1: one token per CELL -- so a
        terrain token is a single cell's ground, not a pooled patch (PriorityHead scene_stride)."""
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(channels, dim // 2, 3, padding = 1),
            nn.GELU(),
            nn.Conv2d(dim // 2, dim, 3, stride = stride, padding = 1),
            nn.GELU(),
        )
        h, w = grid_hw
        self.stride = stride
        self.num_tokens = ((h + stride - 1) // stride) * ((w + stride - 1) // stride)
        self.pos_emb = nn.Parameter(torch.zeros(1, self.num_tokens, dim))

    def forward(self, grid):
        tokens = rearrange(self.net(grid), 'b d h w -> b (h w) d')
        return tokens + self.pos_emb


def grow_scene_channels(state_dict, new_channels, prefixes = ("priority_head.scene_encoder",
                                                              "velocity_field.scene_encoder")):
    """Widen a checkpoint's scene-encoder input conv from C to `new_channels`.

    The extra channels are initialised to ZERO, so the grown model computes
    EXACTLY what the original did on its first forward pass and then learns to
    use the new inputs -- the same reason CrossTracer initialises its FiLM
    layers near identity. A random init here would instead throw away the
    trained representation the moment the ego channels are attached, which is
    indistinguishable from "the ego channels hurt" when the run is scored.

    Relies on the channel contract in `data/ego_project.py`: the five class
    channels stay FIRST, so `w[:, :C]` keeps its meaning. Reordering them would
    silently mis-wire every grown checkpoint.

    -> (state_dict, [names of the tensors that were widened]). Mutates a copy.
    """
    out, grown = dict(state_dict), []
    for pre in prefixes:
        key = f"{pre}.net.0.weight"
        if key not in out:
            continue
        w = out[key]
        c = w.shape[1]
        if c == new_channels:
            continue
        if c > new_channels:
            raise ValueError(f"{key} has {c} channels, cannot shrink to {new_channels}")
        wide = w.new_zeros((w.shape[0], new_channels) + tuple(w.shape[2:]))
        wide[:, :c] = w
        out[key] = wide
        grown.append(key)
    return out, grown


class MetricSceneEncoder(Module):
    """Perception features -> spatial tokens, for the metric-terrain path.

    SceneEncoder above takes the 5-channel class grid and is what the grid
    experiments train on. This one takes what PerceptionEncoder produced --
    per-cell features that already know the height field AND the body looking
    at it -- and only does the pooling into tokens.

    Keeping the two separate rather than adding a flag: they consume different
    worlds, and a shared class whose first line branches on which is a merge
    conflict waiting for the day the class grid is deleted.
    """

    def __init__(self, dim, grid_hw, in_dim):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv2d(in_dim, dim, 3, stride = 2, padding = 1),
            nn.GELU(),
        )
        h, w = grid_hw
        self.num_tokens = ((h + 1) // 2) * ((w + 1) // 2)
        self.pos_emb = nn.Parameter(torch.zeros(1, self.num_tokens, dim))

    def forward(self, features):
        tokens = rearrange(self.proj(features), 'b d h w -> b (h w) d')
        return tokens + self.pos_emb


# ---- perception_encoder ----
from clear.data.terrain import EDGES, OFF_GRID_STEP

# input channel budget: height, 4 edge deltas, occupancy, start, goal
PERCEPT_CHANS = 1 + len(EDGES) + 3

# metres; real terrain tops out at 1.0 m (mj_maze wall slabs). Off-grid edges
# arrive as a large sentinel -- clamping keeps them distinctly "unclimbable"
# without letting one channel dominate the input scale.
HEIGHT_CLAMP = 1.5


def edge_deltas_torch(heights):
    """(b, h, w) metric heights -> (b, 4, h, w) signed step-up per neighbour.

    Mirrors data.terrain.edge_deltas exactly (same EDGES order, same off-grid
    sentinel) so labels and inputs cannot drift apart; tests/test_perception.py
    asserts they agree elementwise.
    """
    b, h, w = heights.shape
    out = heights.new_empty((b, len(EDGES), h, w))
    for k, (dr, dc) in enumerate(EDGES):
        nb = heights.new_full((b, h, w), OFF_GRID_STEP)
        r0, r1 = max(0, -dr), h - max(0, dr)
        c0, c1 = max(0, -dc), w - max(0, dc)
        nb[:, r0:r1, c0:c1] = heights[:, r0 + dr:r1 + dr, c0 + dc:c1 + dc]
        out[:, k] = nb - heights
    return out


def perception_input(heights, occupancy, start, goal):
    """Assemble (b, PERCEPT_CHANS, h, w). All inputs are (b, h, w)."""
    deltas = edge_deltas_torch(heights).clamp(-HEIGHT_CLAMP, HEIGHT_CLAMP)
    return torch.cat([
        (heights / HEIGHT_CLAMP)[:, None],
        deltas / HEIGHT_CLAMP,
        occupancy[:, None].to(heights.dtype),
        start[:, None].to(heights.dtype),
        goal[:, None].to(heights.dtype),
    ], dim = 1)


class FiLM(Module):
    """Per-channel affine modulation from the capability vector.

    Zero-initialised so the encoder starts as the unconditioned network and
    conditioning is something it acquires -- the same reason the AdaLN blocks
    in the dynamics flow start at identity. A randomly initialised FiLM
    multiplies early features by noise that depends on the body, which reads
    to the optimiser as label noise.
    """

    def __init__(self, cap_dim, channels):
        super().__init__()
        self.to_scale_shift = nn.Linear(cap_dim, channels * 2)
        nn.init.zeros_(self.to_scale_shift.weight)
        nn.init.zeros_(self.to_scale_shift.bias)

    def forward(self, x, cap):
        scale, shift = self.to_scale_shift(cap).chunk(2, dim = -1)
        return x * (1.0 + scale[..., None, None]) + shift[..., None, None]


class PerceptionEncoder(Module):
    """(heights, occupancy, start, goal, capability) -> (b, dim, h, w) features
    plus per-edge traversability logits.

    The auxiliary head is not decoration. Scene success is a single number at
    the end of a long pipeline; per-edge traversability is dense, exactly
    supervised, and fails loudly the moment capability conditioning stops
    working. Train with it, read it, and only then trust the rest.
    """

    def __init__(self, dim, cap_dim, depth = 3, in_chans = PERCEPT_CHANS,
                 cond = 'film'):
        super().__init__()
        assert cond in ('film', 'concat'), cond
        # 'concat' is the ablation: the same capability vector broadcast as
        # constant input channels, i.e. told once at the input instead of at
        # every layer and location. Keeping it here rather than in a fork means
        # the two share every other line, so a difference is the conditioning.
        self.cond = cond
        self.cap_dim = cap_dim
        self.stem = nn.Conv2d(in_chans + (cap_dim if cond == 'concat' else 0),
                              dim, 3, padding = 1)
        self.blocks = nn.ModuleList()
        self.films = nn.ModuleList()
        self.norms = nn.ModuleList()
        for _ in range(depth):
            self.blocks.append(nn.Conv2d(dim, dim, 3, padding = 1))
            self.norms.append(nn.GroupNorm(min(8, dim), dim))
            self.films.append(FiLM(cap_dim, dim))
        self.act = nn.GELU()
        self.stem_film = FiLM(cap_dim, dim)
        self.edge_head = nn.Conv2d(dim, len(EDGES), 1)

    def forward(self, heights, occupancy, start, goal, cap):
        inp = perception_input(heights, occupancy, start, goal)
        if self.cond == 'concat':
            b, _, h, w = inp.shape
            inp = torch.cat([inp, cap[:, :, None, None].expand(b, self.cap_dim, h, w)], 1)
            x = self.act(self.stem(inp))
            for conv, norm in zip(self.blocks, self.norms):
                x = x + self.act(norm(conv(x)))
        else:
            x = self.act(self.stem_film(self.stem(inp), cap))
            for conv, norm, film in zip(self.blocks, self.norms, self.films):
                x = x + self.act(film(norm(conv(x)), cap))
        return x, self.edge_head(x)


# ---- capability_encoder ----
from clear.data.capability import FEATURE_DIM, PHYSICAL_DIM


class CapabilityEncoder(Module):
    def __init__(self, dim, feature_dim = FEATURE_DIM):
        super().__init__()
        self.to_token = nn.Linear(feature_dim, dim)

    def forward(self, capability):
        """(b, feature_dim) -> (b, 1, d) embodiment token."""
        return self.to_token(capability)[:, None, :]


class SensitivityHead(Module):
    """Hard-example reweighting for physical-cost loss terms -- iteration 2,
    superseding the CrossTracer-style learned-per-embodiment-MLP version
    (arXiv 2601's "Embodiment Sensitivity Head" -- see
    docs/RESEARCH_coins_crosstracer_ordering.md for the full history).

    Read by PAMO.forward() (learned_loss_weight=True) to replace the single
    hand-tuned endpoint_weight/validity_weight constant, shared across every
    example, with a per-object multiplier -- see clear.py's own comment on
    those constants pulling in opposite directions for discrete vs
    continuous.

    **Why this isn't `alpha_e = f(emb_feat)` any more.** Two iterations of
    that design (unbounded Softplus, then bounded-via-tanh to [0.5, 1.5])
    both collapsed to the SAME degenerate pattern in every seed tested: two
    of the three embodiments pinned at the minimum weight, one at the
    maximum. Root cause, confirmed by measuring per-embodiment endpoint
    error directly on an unbiased checkpoint (`runs/llw_ablation/
    llw_base_seed0`): wheel=0.0501, quadruped=0.0173, humanoid=0.0042 --
    the head was upweighting whichever embodiment ALREADY had the LOWEST
    error, not the highest. This is not a tuning problem, it's structural:
    for a normalized weighted mean `L = sum(alpha_i * err_i) / sum(alpha_i)`,
    `dL/d(alpha_i) ~ (err_i - L)`, so gradient descent on `alpha` (however
    it's parameterized, learned from emb_feat or anything else) always
    increases weight on below-average-error terms and decreases it on
    above-average ones -- exactly backwards from "pay more attention to
    what's hard", regardless of how tightly alpha is bounded.

    **This version has no learned parameters at all**, precisely because a
    learned function of anything, trained end-to-end against this same
    normalized loss, inherits the same backwards incentive. Instead, alpha
    is a direct, monotonically INCREASING function of each object's own
    CURRENT error, ALREADY-DETACHED by the caller before it reaches here --
    the classic hard-example-reweighting / OHEM / focal-loss recipe. With
    no free parameters, there is nothing left for gradient descent to game.
    """
    MAX_DEV = 0.5  # alpha in [1 - MAX_DEV, 1 + MAX_DEV] -- same bound as the superseded
    # learned version, kept for comparability; not itself what fixes the incentive here.

    def forward(self, err, movable):
        """err: (b, n) per-object error the caller has ALREADY detached (this
        function never calls .detach() itself -- the caller decides what
        "error" means, endpoint error today). movable: (b, n) bool.
        -> (b, n) alpha in [1 - MAX_DEV, 1 + MAX_DEV], centered on the
        batch's own mean movable-object error (an average-error object gets
        alpha == 1.0; above-average gets > 1.0; below-average gets < 1.0)."""
        mv = movable.to(err.dtype)
        n = mv.sum().clamp(min = 1.0)
        mean = (err * mv).sum() / n
        var = (((err - mean) ** 2) * mv).sum() / n
        std = var.clamp(min = 1e-8).sqrt()
        z = (err - mean) / std
        return 1.0 + self.MAX_DEV * torch.tanh(z)


class MorphCapabilityEncoder(Module):
    """Link rows -> (conditioning vector, token): kappa = e(morphology) for the
    metric front end (docs/PREREGISTRATION_learned_ccor_2026-09-02.md follow-up).

    Same output contract as PhysicalCapabilityEncoder -- a cap_dim vector that
    FiLMs perception and a (b, 1, dim) token for the transformer -- but the
    input is (morph_rows, morph_mask) from data/morphology.py, so the body's
    STRUCTURE is the only capability channel; no limit is ever handed over.
    The token comes from the adopted v1 set-attention MorphologyEncoder
    (EXPERIMENT_morph_kappa_2026-09-02.md); the conditioning vector is a linear
    read of that token.
    """

    def __init__(self, dim, cap_dim = 64, hidden = 128, depth = 2, heads = 4,
                 p_drop = 0.15):
        super().__init__()
        from clear.model.morphology_encoder import MorphologyEncoder
        self.enc = MorphologyEncoder(dim, hidden = hidden, depth = depth,
                                     heads = heads, p_drop = p_drop)
        self.to_cap = nn.Linear(dim, cap_dim)
        self.cap_dim = cap_dim

    def forward(self, capability):
        """((b, L, F) rows, (b, L) mask) -> ((b, cap_dim), (b, 1, dim))."""
        tok = self.enc(capability)
        return self.to_cap(tok[:, 0]), tok


class PhysicalCapabilityEncoder(Module):
    """Metric descriptor -> (conditioning vector, token).

    Separate from CapabilityEncoder above because it answers a different
    question. That one summarises a body for the ordering transformer, where a
    single token attended over is enough. This one drives FiLM inside the
    perception encoder, where the body has to change how a *pixel* is read --
    so it produces a vector consumed at every spatial location, and a token for
    the transformer as a by-product.

    The input is capability.physical_vector: metres and kilograms, no class
    membership. That is what makes an unseen climb limit a valid input rather
    than an out-of-vocabulary one.
    """

    def __init__(self, dim, cap_dim = 64, feature_dim = PHYSICAL_DIM):
        super().__init__()
        # climb is in metres and everything else is already O(1); normalise the
        # first channel here rather than at every call site.
        self.register_buffer('scale', torch.tensor(
            [1.0 / HEIGHT_CLAMP] + [1.0] * (feature_dim - 1), dtype = torch.float32))
        self.net = nn.Sequential(
            nn.Linear(feature_dim, cap_dim), nn.GELU(),
            nn.Linear(cap_dim, cap_dim),
        )
        self.to_token = nn.Linear(cap_dim, dim)
        self.cap_dim = cap_dim

    def forward(self, physical):
        """(b, feature_dim) -> ((b, cap_dim) conditioning, (b, 1, dim) token)."""
        cap = self.net(physical * self.scale)
        return cap, self.to_token(cap)[:, None, :]


# ---- structure_encoder ----
class StructureEncoder(nn.Sequential):
    def __init__(self, input_dim, dim):
        super().__init__(nn.Linear(input_dim, dim), nn.GELU(), nn.Linear(dim, dim))

    def pool(self, structure, structure_mask):
        rows = self(structure)
        mask = structure_mask[..., None].to(rows.dtype)
        return (rows * mask).sum(1) / mask.sum(1).clamp(min=1)


# ---- kappa_set_encoder ----
class KappaSetEncoder(Module):
    def __init__(self, dim, n_probes = 10, p_drop = 0.3, hidden = 64):
        super().__init__()
        self.p_drop = p_drop
        self.id_embed = nn.Embedding(n_probes, hidden)
        self.val_mlp = nn.Sequential(nn.Linear(2, hidden), nn.GELU(), nn.Linear(hidden, hidden))
        self.to_token = nn.Linear(2 * hidden, dim)

    def forward(self, capability):
        """capability = (probe_set (b, P, 3), probe_mask (b, P) bool) -> (b, 1, dim)."""
        probes, mask = capability
        mask = mask.bool()
        if self.training and self.p_drop > 0:
            keep = torch.rand(mask.shape, device = mask.device) >= self.p_drop
            keep = keep & mask
            # never drop every probe: fall back to the original mask for those rows
            empty = ~keep.any(dim = 1, keepdim = True)
            mask = torch.where(empty, mask, keep)
        tok = self.id_embed(probes[..., 0].long()) + self.val_mlp(probes[..., 1:3])  # (b, P, h)
        m = mask[..., None].to(tok.dtype)
        mean = (tok * m).sum(1) / m.sum(1).clamp(min = 1.0)
        mx = tok.masked_fill(~mask[..., None], float('-inf')).amax(1)
        mx = torch.where(torch.isfinite(mx), mx, torch.zeros_like(mx))  # all-masked row -> 0
        return self.to_token(torch.cat([mean, mx], dim = -1))[:, None, :]


def _self_check():
    torch.manual_seed(0)
    enc = KappaSetEncoder(32, n_probes = 10, p_drop = 0.3).eval()
    b, P = 4, 10
    probes = torch.stack([torch.arange(P).float(), torch.rand(P), torch.rand(P).round()], -1)[None].repeat(b, 1, 1)
    mask = torch.ones(b, P, dtype = torch.bool)
    out = enc((probes, mask))
    assert out.shape == (b, 1, 32), out.shape
    perm = torch.randperm(P)
    out_p = enc((probes[:, perm], mask[:, perm]))
    assert torch.allclose(out, out_p, atol = 1e-5), "not permutation invariant"
    # mask handling: masking probe 3 == physically removing it
    mask2 = mask.clone(); mask2[:, 3] = False
    keep = [i for i in range(P) if i != 3]
    a = enc((probes, mask2)); c = enc((probes[:, keep], mask[:, keep]))
    assert torch.allclose(a, c, atol = 1e-5), "masked probe leaks into the token"
    assert not torch.allclose(a, out, atol = 1e-3), "removing a probe changed nothing"
    # training drop never empties a row
    enc.train()
    for _ in range(20):
        o = enc((probes, mask))
        assert torch.isfinite(o).all()
    print("ok KappaSetEncoder: shape (b,1,dim), permutation-invariant, mask == removal, drop finite")
