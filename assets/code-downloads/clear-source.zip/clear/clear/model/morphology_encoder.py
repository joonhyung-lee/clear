"""MorphologyEncoder: the body's link rows -> one kappa token.

Drop-in for KappaSetEncoder (same (b, 1, dim) output, same (rows, mask) input
convention) but the rows are data/morphology.py's per-link structure rows, not
probe outcomes. Two attention blocks over the links, then a learned pooling
query reads the set out -- links interact (a leg is a CHAIN of rows; gear on
one joint matters relative to the mass it carries), which is what plain
mean/max pooling cannot express and why this is not just KappaSetEncoder with
a different row width.

Permutation-invariant by construction (attention + a pooling query, no
positional encoding), and any subset of links is a valid input -- same
contract as the probe set, so masking/dropout falsifications carry over.

    python -m clear.model.morphology_encoder   # self-check
"""
import torch
from torch import nn
from torch.nn import Module

from clear.data.morphology import feat_dim


class _SetBlock(Module):
    def __init__(self, dim, heads = 4):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, heads, batch_first = True)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(nn.Linear(dim, dim * 2), nn.GELU(), nn.Linear(dim * 2, dim))

    def forward(self, x, pad):
        h = self.norm1(x)
        a, _ = self.attn(h, h, h, key_padding_mask = pad)
        x = x + a
        return x + self.ff(self.norm2(x))


class MorphologyEncoder(Module):
    def __init__(self, dim, hidden = 128, depth = 2, heads = 4, p_drop = 0.15, in_dim = None):
        super().__init__()
        self.p_drop = p_drop
        self.embed = nn.Sequential(nn.Linear(in_dim or feat_dim(), hidden), nn.GELU(),
                                   nn.Linear(hidden, hidden))
        self.blocks = nn.ModuleList([_SetBlock(hidden, heads) for _ in range(depth)])
        self.pool_q = nn.Parameter(torch.randn(1, 1, hidden) * 0.02)
        self.pool = nn.MultiheadAttention(hidden, heads, batch_first = True)
        self.to_token = nn.Linear(hidden, dim)

    def link_tokens(self, capability):
        """(b, L, dim) per-link tokens after the set-attention blocks, plus the (b, L) valid mask --
        for a planner that attends the BODY'S PARTS directly (PriorityHead kappa_links) instead of one
        pooled summary. Same dropout contract as forward()."""
        rows, mask = capability
        mask = mask.bool()
        if self.training and self.p_drop > 0:
            keep = torch.rand(mask.shape, device = mask.device) >= self.p_drop
            keep = keep & mask
            empty = ~keep.any(dim = 1, keepdim = True)
            mask = torch.where(empty, mask, keep)
        pad = ~mask
        x = self.embed(rows)
        for blk in self.blocks:
            x = blk(x, pad)
        return self.to_token(x), mask

    def forward(self, capability):
        """capability = (rows (b, L, N_MORPH_FEAT), mask (b, L) bool) -> (b, 1, dim)."""
        rows, mask = capability
        mask = mask.bool()
        if self.training and self.p_drop > 0:
            keep = torch.rand(mask.shape, device = mask.device) >= self.p_drop
            keep = keep & mask
            empty = ~keep.any(dim = 1, keepdim = True)
            mask = torch.where(empty, mask, keep)
        pad = ~mask                                    # True = ignore
        x = self.embed(rows)
        for blk in self.blocks:
            x = blk(x, pad)
        q = self.pool_q.expand(x.shape[0], -1, -1)
        out, _ = self.pool(q, x, x, key_padding_mask = pad)
        return self.to_token(out)                      # (b, 1, dim)


def _self_check():
    torch.manual_seed(0)
    from clear.data.morphology import morph_rows
    enc = MorphologyEncoder(32).eval()
    names = ('wheel', 'quadruped', 'humanoid')
    L = 64
    rows = torch.zeros(3, L, feat_dim())
    mask = torch.zeros(3, L, dtype = torch.bool)
    for i, n in enumerate(names):
        r, m = morph_rows(n)
        rows[i, :len(r)] = torch.tensor(r)
        mask[i, :len(r)] = True
    out = enc((rows, mask))
    assert out.shape == (3, 1, 32)
    # permutation invariance over links
    perm = torch.randperm(L)
    out_p = enc((rows[:, perm], mask[:, perm]))
    assert torch.allclose(out, out_p, atol = 1e-5), 'not permutation invariant'
    # masking a link == removing it
    m2 = mask.clone(); m2[1, 3] = False
    keep = [q for q in range(L) if q != 3]
    a = enc((rows[1:2], m2[1:2]))
    b = enc((rows[1:2, keep], mask[1:2, keep]))
    assert torch.allclose(a, b, atol = 1e-5), 'masked link leaks'
    # bodies produce distinct tokens
    assert not torch.allclose(out[0], out[1], atol = 1e-3)
    assert not torch.allclose(out[1], out[2], atol = 1e-3)
    # training drop never empties
    enc.train()
    for _ in range(10):
        assert torch.isfinite(enc((rows, mask))).all()
    print('ok MorphologyEncoder: (b,1,dim), permutation-invariant, mask == removal, '
          'bodies distinct, drop finite')


if __name__ == '__main__':
    _self_check()
