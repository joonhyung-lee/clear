"""causalflownet: causal_velocity_field, target_flow.

causal_velocity_field: Causal velocity field (Stage B): tau-ordered attention -> path velocity.

Once the priority head has committed an ordering, object i may read only
objects that move at-or-before its own turn; the embodiment token, scene
tokens and immovable objects are static context readable by everyone. The
head regresses velocity in each object's OWN path time, so the regression
target is schedule-independent (vanilla conditional flow matching).

The mask rule that matters (learned the hard way, kept as a gradient test):
context tokens may NOT read movable objects. If they could, a later object's
pose would reach an earlier object through a 2-hop path -- late object ->
context token at layer L -> early object at layer L+1.

ein notation:
  b - batch
  n - objects
  t - tokens (1 capability + n objects + s scene)

target_flow: CLEAR's task-independent selected-object, order-conditioned target flow.

Flow time is generative time, not controller execution time. Static observations
are available at every rank; later generated targets are not. Domain adapters
provide object/context tokens and interpret/project the final configuration code.
"""

# ---- causal_velocity_field ----
import torch
from torch import nn
from torch.nn import Module

from clear.model.affordancenet import AffordanceTransformer
from clear.model.encoders import CapabilityEncoder
from clear.model.encoders import SCENE_CHANS, SceneEncoder, obj_feat_dim
from clear.util import wall_oob_penalty

from clear.model.affordancenet import StageBAuxHeads

# causal mask


def causal_mask(rank, movable, n_scene, causal = True):
    """(b, t, t) bool, True = blocked.

    A movable object key may be read ONLY by a movable object query with an
    equal-or-later rank. Every other token may read anything EXCEPT movable
    objects (the 2-hop rule above).

    causal=False = OBSERVATION-CONSISTENT attention (2026-08-26, adopted after
    experiments/ordering_ablation: abstract plan success 0.30 -> 0.86 at k=3,
    physical nocausal_s0 0.920 vs 0.884, PLAN sect95/97): every movable object
    reads every movable object regardless of rank. This is not a leak of future
    information: under the slot schedule (util.schedule.oracle_progress) a
    later-ranked object sits at its current pose x0 while an earlier one moves,
    i.e. exactly what the robot observes at that moment; earlier-ranked objects
    are read at their parked pose, which is what the robot will observe once they
    have been executed. clear.PAMO.forward asserts that invariant
    (_assert_observation_consistent). The context rule (cap/scene/immovable
    tokens never read movable objects) is kept as is. causal=True is the legacy
    rank-causal mask, kept for the ablation and for older checkpoints.
    """
    b, n = rank.shape
    t = 1 + n + n_scene
    mask = torch.zeros(b, t, t, dtype = torch.bool, device = rank.device)

    key_is_movable = torch.zeros(b, t, dtype = torch.bool, device = rank.device)
    key_is_movable[:, 1:1 + n] = movable
    mask |= key_is_movable[:, None, :]

    allowed = movable[:, :, None] & movable[:, None, :]
    if causal:
        key_is_later = rank[:, None, :] > rank[:, :, None]
        allowed = allowed & ~key_is_later
    mask[:, 1:1 + n, 1:1 + n] &= ~allowed
    return mask


def causal_bias(rank, movable, n_scene, slope):
    """(b, t, t) float, additive attention-logit penalty for the SOFT causal
    variant (2026-09-12): rather than hard-blocking a later-ranked movable
    key (causal=True) or leaving it fully open (causal=False, the existing
    no_causal_mask ablation, checked in RESULTS.md and NOT found necessary --
    held-out CI [-1.83, +4.92]), grade the penalty by how much later it is.
    slope=0 reduces to causal=False exactly; used with causal=False so the
    2-hop context rule (context tokens never read movable objects) stays the
    one hard invariant causal_mask always enforces. Caller passes the SAME
    `rank`/`movable` (selected) tensors given to causal_mask(..., causal=False).
    """
    b, n = rank.shape
    t = 1 + n + n_scene
    bias = rank.new_zeros(b, t, t, dtype = torch.float32)
    allowed = movable[:, :, None] & movable[:, None, :]
    rank_gap = (rank[:, None, :] - rank[:, :, None]).clamp(min = 0).to(torch.float32)
    bias[:, 1:1 + n, 1:1 + n] = torch.where(allowed, -slope * rank_gap, torch.zeros_like(rank_gap))
    return bias

# causal velocity field


class CausalVelocityField(StageBAuxHeads, Module):
    def __init__(self, grid_hw = (8, 8), dim = 128, depth = 4, heads = 4, dim_head = 32,
                 drop_obj = (), obj_extra_dim = 0, predict_robot_path = False,
                 condition_smoothness = False, include_reachable = False,
                 predict_feasibility = False, predict_affordance = False, causal = True,
                 capability_encoder = None,
                 scene_channels = SCENE_CHANS):
        super().__init__()
        self.causal = causal  # False = no_causal_mask ablation, see causal_mask()
        self.to_object_tokens = nn.Linear(obj_feat_dim(drop_obj, include_reachable) + obj_extra_dim, dim)
        # capability_encoder: optional module replacing the default vector
        # encoder (e.g. kappa_set_encoder.KappaSetEncoder); must map its own
        # `capability` input to a (b, 1, dim) token.
        self.capability_encoder = capability_encoder if capability_encoder is not None else CapabilityEncoder(dim)
        self.scene_encoder = SceneEncoder(dim, grid_hw, channels = scene_channels)
        # OPT-IN, same contract as predict_robot_path below: condition_smoothness=False
        # (the default) leaves this class byte-for-byte the old CausalVelocityField --
        # no extra params, forward()'s signature accepts `smoothness` but ignores it.
        # When on, a scalar in [0, 1] biases the capability token via a small additive
        # projection (not a new token -- inserting one would shift every index the
        # causal mask and the `tokens[:, 1:1+n]` slicing below already hardcode).
        # `clear/data/data.py`'s `collate(..., smoothness=True)` supplies the matching
        # TRAINING label: pose/v_target blended toward a Chaikin-smoothed path by the
        # same scalar, so the network learns what "more smoothness" should look like
        # rather than only being told to reproduce it post-hoc (see
        # PAMO.sample_robot_path's own, unrelated, post-hoc EMA `smoothness` param --
        # deliberately named `smoothness_cond` everywhere in this class to not collide).
        self.condition_smoothness = condition_smoothness
        if condition_smoothness:
            self.smoothness_to_bias = nn.Linear(1, dim)
        self.transformer = AffordanceTransformer(dim, depth = depth, heads = heads, dim_head = dim_head)
        self.to_velocity = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Linear(dim, 3),
        )
        # Second head off the same trunk: where does this object END UP,
        # globally (x1 - current pose) -- not just its local path velocity.
        # flow_loss alone only ever sees the next instant; this is the signal
        # that lets training penalize an invalid *resulting* world (see
        # util/validity.py), which the velocity head has no way to express.
        self.to_endpoint = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Linear(dim, 3),
        )

        # Third pair of heads, OPT-IN (predict_robot_path=False leaves this
        # class byte-for-byte the old CausalVelocityField -- both existing
        # call sites in clear.py unpack exactly 2 return values and must not
        # break). Reads the SAME per-object transformer output as
        # to_velocity/to_endpoint -- no new token, no rank/mask change, so
        # none of the causal-mask correctness work above is touched. The
        # physical quantity is different (the ROBOT's own path to reach this
        # object, not the object's own placement) but the object's token
        # already carries everything the mask says it may see (earlier-turn
        # objects' outcomes, capability, scene) -- see module docstring in
        # clear/data/waypoint_data.py for what supplies the training label
        # (Roadmap.path_points, not this repo's grid cell_path -- that labels
        # OBJECT motion, this labels ROBOT motion, a different quantity that
        # happens to reuse the same pose/velocity CFM parameterisation).
        #
        # Robot position between phases is approximated as the causally
        # PREVIOUS object's own endpoint (where the robot just finished
        # pushing it to) -- or the scene's start pose for the first-ranked
        # object. This needs no new input signal (rank + x1 already exist in
        # the sequence); it is an approximation, not measured, and is the
        # first thing to revisit if predicted robot paths look wrong at a
        # phase boundary. See experiments/e4/HANDOFF_sumo_executor.md
        # "스물일곱 번째 후속".
        self.predict_robot_path = predict_robot_path
        if predict_robot_path:
            self.to_robot_velocity = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, 3))
            self.to_robot_endpoint = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, 3))

        # Fourth head, OPT-IN (predict_feasibility=False leaves this class
        # byte-for-byte the old CausalVelocityField, same contract as
        # predict_robot_path/condition_smoothness above -- forward()'s
        # existing 2-value return is untouched, only forward_with_feasibility
        # below uses this). 2026-08-23, PLAN doc S54-62 / experiments/
        # stageb_clearance_signal/RESULTS.md sect9-10: an RL reward built
        # from the SAME validated signal (order_index/push_distance/n_movers/
        # wall-occupancy, sect4-6's v4/v5 feature set) made real placement
        # accuracy WORSE, not better (miss rate 17.2% -> 41.6%, sect9) --
        # consistent overoptimization of an imperfect frozen critic via
        # noisy policy gradient. This head instead trains the SAME kind of
        # signal via ordinary supervised backprop, directly into the shared
        # trunk, alongside flow_loss/endpoint_loss -- no policy-gradient
        # variance, no frozen numpy critic to game. Takes the trunk's own
        # per-object hidden state PLUS 4 scalars the trunk alone cannot see
        # (they depend on the CANDIDATE endpoint this same forward pass just
        # produced, not just the pre-placement context the trunk attends
        # over): push_distance (from endpoint_delta, literally free --
        # already computed for endpoint_loss), wall_occ (reuses
        # wall_oob_penalty's own differentiable bilinear sample, not a new
        # geometry channel), order_index/n_movers (from `rank`/`movable`,
        # already in every batch -- v4/v5's single strongest and third-
        # strongest univariate features, sect6, never before given to any
        # head as an explicit input). Outputs a per-object SUCCESS LOGIT,
        # trained with BCEWithLogitsLoss against real physical phase-level
        # outcomes (the same ~3-4k-row corpus feasibility_critic.py already
        # builds) -- see clear.py's feasibility_forward for the loss, only
        # meaningful on batches carrying real labels (see
        # data/real_corpus.py's build_feasibility_batches).
        self.predict_feasibility = predict_feasibility
        if predict_feasibility:
            self.to_feasibility = nn.Sequential(nn.Linear(dim + 4, dim), nn.GELU(), nn.Linear(dim, 1))
            # Residual refinement head (2026-08-23, PLAN doc S54-62 sect16 --
            # experiments/stageb_clearance_signal/RESULTS.md): the actual
            # CE-Adapter/CrossTracer mechanism (T_e = T_init + Delta_e), which
            # sect10's feasibility head alone did NOT implement -- confirmed
            # directly by reading PAMO.sample()'s own ODE loop: it integrates
            # `velocity` only and DISCARDS endpoint_delta entirely (`_` in
            # `velocity, _ = self.velocity_field(...)`), so nothing built in
            # sect10 could ever have reached actual sampled behavior except
            # indirectly, through gradient shared with the trunk that also
            # produces `velocity` -- a real, but diffuse and unconstrained,
            # coupling, consistent with sect12/15's small, seed-noisy effect.
            # Same `feas_in` input as to_feasibility (same 4 context scalars
            # + trunk state); output is a BOUNDED xy correction (delta_max,
            # tanh-squashed -- CrossTracer's own bounding, and this
            # project's own S54-62 audit (sect8) already found an unbounded
            # correction path is exactly how a reward gets gamed).
            self.delta_max = 1.5  # grid cells -- generously covers sect6's push_distance
            # dose-response finding (the "sweet spot" sat around 2 cells, the cliff past ~4;
            # 1.5 lets the residual meaningfully relocate a placement without being able to
            # single-handedly walk it out to the danger zone sect6 found)
            self.to_residual = nn.Sequential(nn.Linear(dim + 4, dim), nn.GELU(), nn.Linear(dim, 2))

        # Fifth head pair, OPT-IN (predict_affordance=False leaves this class
        # byte-for-byte the old one, same contract as every flag above).
        # 2026-08-24, RESULTS.md sect22-23: embodiment-conditioned AFFORDANCE
        # MAP -- per-object (h, w) logits over park cells, supervised by
        # clear/data/affordance.py's dense oracle labels (oracle.park_valid,
        # 12 maps/scene, unlimited volume -- the label starvation that sank
        # sect10-22's per-object-scalar heads does not apply). Standalone
        # Phase-1 net already cleared the pre-stated gates (held-out per-cell
        # AUC 0.988, every embodiment >= 0.984 -- train_affordance.py); this
        # head asks whether the SAME signal can flow through PAMO's own
        # trunk. Mechanism: object token (query) x scene token (key) dot
        # product -> coarse (4,4) map in the scene encoder's own token
        # layout, bilinearly upsampled and refined by a small conv decoder
        # that re-reads the raw class grid (full-res wall structure the 16
        # coarse tokens can't carry). The causal mask already lets every
        # object token read every scene token, and scene tokens never read
        # movable objects -- so the affordance query is object-conditioned
        # while the keys stay object-independent, and NOTHING about the mask
        # changes.
        self.predict_affordance = predict_affordance
        if predict_affordance:
            self.to_afford_q = nn.Linear(dim, dim)
            self.to_afford_k = nn.Linear(dim, dim)
            self.afford_decoder = nn.Sequential(
                nn.Conv2d(1 + 5, dim // 2, 3, padding = 1), nn.GELU(),
                nn.Conv2d(dim // 2, dim // 2, 3, padding = 1), nn.GELU(),
                nn.Conv2d(dim // 2, 1, 1),
            )

    def forward(self, grid, object_features, capability, rank, movable, context = None,
                smoothness_cond = None):
        """-> (velocity, endpoint_delta), each (b, n, 3). velocity is in each
        object's own path time; endpoint_delta estimates x1 - pose (used only
        as an auxiliary training signal -- sample() ignores it, the rollout
        is still pure CFM integration).

        `context`: see PriorityHead.forward. The mask reads the scene-token
        count off the tensor rather than off self.scene_encoder, so a front end
        with a different token count cannot silently mis-mask.

        `smoothness_cond`: (b,) in [0, 1], only read when condition_smoothness=True
        (required then -- see __init__).
        """
        out = self._trunk_out(grid, object_features, capability, rank, movable, context, smoothness_cond)
        return self.to_velocity(out), self.to_endpoint(out)

    def _trunk_out(self, grid, object_features, capability, rank, movable, context = None,
                   smoothness_cond = None):
        full, n = self._trunk_full(grid, object_features, capability, rank, movable, context,
                                   smoothness_cond)
        return full[:, 1:1 + n]

    def _trunk_full(self, grid, object_features, capability, rank, movable, context = None,
                    smoothness_cond = None):
        """-> (all transformer token outputs (b, 1+n+s, d), n). _trunk_out is
        the [1:1+n] object slice of this -- one shared implementation so the
        affordance head's scene-token reads can never drift from what the
        object heads were computed with."""
        objects = self.to_object_tokens(object_features)
        cap_token, scene_tokens = context if context is not None else (
            self.capability_encoder(capability), self.scene_encoder(grid))
        if self.condition_smoothness:
            assert smoothness_cond is not None, "condition_smoothness=True requires smoothness_cond"
            cap_token = cap_token + self.smoothness_to_bias(smoothness_cond.view(-1, 1))[:, None, :]
        tokens = torch.cat([cap_token, objects, scene_tokens], dim = 1)

        mask = causal_mask(rank, movable, scene_tokens.shape[1], causal = self.causal)
        return self.transformer(tokens, mask = mask), objects.shape[1]

    # forward_with_{robot_path,feasibility,affordance} live in stageb_aux_heads.py (mixin)


def _self_check():
    import torch

    from clear.data.capability import FEATURE_DIM
    from clear.model.encoders import obj_feat_dim

    torch.manual_seed(0)
    b, n, dim = 2, 4, 32
    grid = torch.zeros(b, 5, 8, 8)
    object_features = torch.randn(b, n, obj_feat_dim(()))
    capability = torch.randn(b, FEATURE_DIM)
    rank = torch.stack([torch.randperm(n) for _ in range(b)])
    movable = torch.ones(b, n, dtype = torch.bool)

    # predict_robot_path=False (the default, and what PAMO/MazePAMO's existing
    # 2 call sites unpack) must be byte-for-byte the pre-extension class.
    plain = CausalVelocityField(grid_hw = (8, 8), dim = dim, depth = 2, heads = 2, dim_head = 16)
    assert not hasattr(plain, "to_robot_velocity"), "default field must not carry robot heads at all"
    v, e = plain.forward(grid, object_features, capability, rank, movable)
    assert v.shape == (b, n, 3) and e.shape == (b, n, 3)
    print("ok predict_robot_path=False: no robot heads, forward() shape unchanged")

    reachable_feats = torch.randn(b, n, obj_feat_dim((), include_reachable = True))
    with_reachable = CausalVelocityField(grid_hw = (8, 8), dim = dim, depth = 2, heads = 2,
                                         dim_head = 16, include_reachable = True)
    v, e = with_reachable.forward(grid, reachable_feats, capability, rank, movable)
    assert v.shape == (b, n, 3) and e.shape == (b, n, 3)
    print("ok include_reachable=True: to_object_tokens sized for the extra column")

    vf = CausalVelocityField(grid_hw = (8, 8), dim = dim, depth = 2, heads = 2, dim_head = 16,
                             predict_robot_path = True)
    v2, e2, rv, re = vf.forward_with_robot_path(grid, object_features, capability, rank, movable)
    assert rv.shape == (b, n, 3) and re.shape == (b, n, 3)
    assert torch.isfinite(rv).all() and torch.isfinite(re).all()
    v3, e3 = vf.forward(grid, object_features, capability, rank, movable)
    assert torch.allclose(v2, v3) and torch.allclose(e2, e3), (
        "forward() and forward_with_robot_path() must share the identical trunk output")
    print("ok predict_robot_path=True: robot heads present, shared trunk output matches forward()")

    (rv.sum() + re.sum()).backward()
    print("ok gradients reach the robot-path heads")

    # condition_smoothness=False (default) must stay byte-for-byte identical too,
    # and =True must actually change the output when the scalar changes.
    assert not hasattr(plain, "smoothness_to_bias"), "default field must not carry the smoothness bias at all"
    sv = CausalVelocityField(grid_hw = (8, 8), dim = dim, depth = 2, heads = 2, dim_head = 16,
                             condition_smoothness = True)
    lo = torch.zeros(b)
    hi = torch.ones(b)
    v_lo, _ = sv.forward(grid, object_features, capability, rank, movable, smoothness_cond = lo)
    v_hi, _ = sv.forward(grid, object_features, capability, rank, movable, smoothness_cond = hi)
    assert not torch.allclose(v_lo, v_hi), "smoothness_cond=0 vs 1 produced identical output"
    try:
        sv.forward(grid, object_features, capability, rank, movable)
        raise AssertionError("condition_smoothness=True must require smoothness_cond, not silently default it")
    except AssertionError as e:
        if "requires smoothness_cond" not in str(e):
            raise
    print("ok condition_smoothness=True: output actually depends on the scalar, and is required")


# ---- target_flow ----
import math




def selection_mask(logits, available):
    return available & (logits > 0)


def priority_scale(raw, minimum=0.05, maximum=0.5):
    """Smooth bounded Gaussian scale; no hard-clamp dead zone."""
    return minimum + (maximum - minimum) * torch.sigmoid(raw)


def selected_ranks(rank, available):
    n = rank.shape[-1]
    selected = available & (rank >= 0) & (rank < n)
    # zeros_like+n rather than full_like(rank, n): identical result, but the NPU
    # compiler's tvm frontend mishandles full_like with a scalar fill.
    return torch.where(selected, rank, torch.zeros_like(rank) + n), selected


def rank_selected(priority, selected, limit=None):
    """Ascending sampled priorities; omitted objects use the N sentinel."""
    n = priority.shape[-1]
    if limit is not None and limit < 0:
        raise ValueError("interaction limit must be nonnegative")
    order = priority.masked_fill(~selected, float('inf')).argsort(dim=-1, stable=True)
    rank = torch.empty_like(order).scatter_(
        1, order, torch.arange(n, device=order.device).expand_as(order))
    active = selected & (rank < (n if limit is None else limit))
    return torch.where(active, rank, torch.full_like(rank, n)), active


def time_embedding(t, dim):
    half = dim // 2
    freqs = torch.exp(-math.log(1000.0) * torch.arange(half, device=t.device, dtype=t.dtype) / max(1, half - 1))
    a = t[..., None] * freqs
    return torch.cat([a.sin(), a.cos()], dim=-1)


def target_velocity(static, context, scene, g_t, t, rank, available,
                    cfg_in, trunk, head, time_dim, causal=True, key_mask=None,
                    causal_bias_slope=0.0):
    """Shared Stage B implementation; modules remain owned by each checkpoint.

    `key_mask` (b, 1 + n + s + n) bool marks keys that exist: padded object or
    scene slots are never read. None keeps the fixed-size behaviour unchanged.

    `causal_bias_slope`: soft-causal ablation (see causal_velocity_field.
    causal_bias). Only meaningful with causal=False -- it grades the
    movable-to-movable penalty instead of leaving it at zero. 0.0 (default)
    is a no-op, byte-for-byte the pre-existing behaviour.
    """
    rank, selected = selected_ranks(rank, available)
    g_t = torch.where(selected[..., None], g_t, torch.zeros_like(g_t))
    b, n, _ = static.shape
    te = time_embedding(t, time_dim)[:, None].expand(b, n, time_dim)
    obj = cfg_in(torch.cat([static, g_t, te], dim=-1))
    # A rank restriction applies to generated decisions, never to currently
    # observed geometry. Separate read-only copies expose ALL observed objects,
    # including selected objects whose generated targets must remain hidden.
    observed = cfg_in(torch.cat([static, torch.zeros_like(g_t), te], dim=-1))
    tokens = torch.cat([context, obj, scene, observed], dim=1)
    mask = causal_mask(rank, selected, scene.shape[1] + n, causal=causal)
    bias = (causal_bias(rank, selected, scene.shape[1] + n, causal_bias_slope)
            if causal_bias_slope else None)
    if key_mask is not None:
        if key_mask.shape != mask.shape[:2]:
            raise ValueError("key_mask must cover context, objects, scene and observed copies")
        mask = mask | ~key_mask[:, None, :]
    return head(trunk(tokens, mask=mask, bias=bias)[:, 1:1 + n])


class RankCausalTargetFlow(nn.Module):
    def __init__(self, dim, target_dim, depth=4, heads=4, dim_head=32, causal=True,
                 causal_bias_slope=0.0):
        super().__init__()
        if dim % 4:
            raise ValueError("target flow dim must be divisible by 4")
        self.dim, self.target_dim, self.causal = dim, target_dim, causal
        self.noise_std = 1.0
        self.causal_bias_slope = float(causal_bias_slope)  # soft-causal ablation, see causal_velocity_field.causal_bias
        self.cfg_in = nn.Sequential(nn.Linear(dim + target_dim + dim // 2, dim),
                                    nn.GELU(), nn.Linear(dim, dim))
        self.trunk = AffordanceTransformer(dim, depth=depth, heads=heads, dim_head=dim_head)
        self.head = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim), nn.GELU(),
                                  nn.Linear(dim, target_dim))

    def forward(self, static, context, scene, g_t, t, rank, selected, key_mask=None):
        return target_velocity(static, context, scene, g_t, t, rank, selected,
                               self.cfg_in, self.trunk, self.head, self.dim // 2, self.causal,
                               key_mask=key_mask, causal_bias_slope=self.causal_bias_slope)

    @torch.no_grad()
    def sample(self, static, context, scene, rank, selected, n_steps=30, generator=None,
               key_mask=None, trace=None):
        """`trace`, if a list, receives (t, state) at every Euler step and at t=1.

        The states are the generator's own intermediates. They exist so a figure
        can show the flow evolving instead of an interpolation of its endpoint;
        nothing in the planner reads them and the default path is unchanged.
        """
        if n_steps <= 0:
            raise ValueError("n_steps must be positive")
        rank, selected = selected_ranks(rank, selected)
        g = torch.randn(*static.shape[:2], self.target_dim, device=static.device,
                        dtype=static.dtype, generator=generator) * self.noise_std
        g = torch.where(selected[..., None], g, torch.zeros_like(g))
        for k in range(n_steps):
            t = torch.full((static.shape[0],), k / n_steps, device=static.device, dtype=static.dtype)
            if trace is not None:
                trace.append((k / n_steps, g.detach().clone()))
            v = self(static, context, scene, g, t, rank, selected, key_mask=key_mask)
            g = g + torch.where(selected[..., None], v, torch.zeros_like(v)) / n_steps
        if trace is not None:
            trace.append((1.0, g.detach().clone()))
        return g
