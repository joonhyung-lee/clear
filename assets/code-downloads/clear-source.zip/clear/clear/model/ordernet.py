"""ordernet: ordering_ablation_heads, priority_head, ordering_loss.

ordering_ablation_heads: Quarantined ordering-ablation heads: 'score' and 'pointer'.

These are the structural ablations of PriorityHead's ordering model
(experiments/ordering_ablation), NOT the paper's head:

  score    one scalar per object, MSE onto the oracle's normalized rank;
           deterministic argsort, no distribution at all.
  pointer  autoregressive: re-encode with a learned "placed" offset, softmax
           over the remaining movable objects, CE against the oracle's next
           pick; Gumbel-max sampling step by step.

Moved out of priority_head.py (2026-09-02, Stage-1 simplification): the paper
head is 'gauss' and the two ablations were 40% of that file. This is a mixin,
so parameter names (`to_score`, `placed_embed`) and therefore every existing
checkpoint's state_dict keys are unchanged -- runs/rooms_kappa_v1/
setK_{score,pointer}_seed0 load byte-identically.

priority_head: Priority head (Stage A): order-agnostic attention -> per-object activation
time distribution.

Every object attends every object (plus scene and capability tokens) -- no
order is assumed yet. The head emits a Gaussian over an activation LOGIT u_i
per object; tau_i = sigmoid(u_i), and smaller tau moves first. Sampling u once
at t = 0 commits one ordering mode for the whole rollout, which is how
multimodal valid orderings stay reachable without a per-step tug-of-war.

ein notation:
  b - batch
  n - objects
  d - model dimension

ordering_loss: Pairwise objective shared by the structural maze and placement planners.
"""

# ---- ordering_ablation_heads ----
import torch
import torch.nn.functional as F


class OrderingAblationHeads:
    """Mixin for PriorityHead. Everything here assumes self.order_head is
    'score' or 'pointer' and self.to_score / self.placed_embed exist."""

    def order_loss(self, grid, object_features, capability, movable, rank, context = None):
        """Training loss replacing PAMO.forward's pairwise rank loss for the
        score / pointer heads. `rank` is data.collate's convention: position in
        the (sampled oracle order + movable non-mover tail), sentinel n for
        immovable objects."""
        if self.order_head == 'score':
            s, _ = self(grid, object_features, capability, context = context)
            n_mov = movable.sum(-1, keepdim = True).clamp(min = 1)
            target = rank.float() / (n_mov - 1).clamp(min = 1).float()  # normalized rank in [0, 1]
            return F.mse_loss(s[movable], target[movable]) if movable.any() else s.sum() * 0.
        assert self.order_head == 'pointer'
        b, n = rank.shape
        if context is None:
            context = (self.capability_encoder(capability), self.scene_encoder(grid))
        # teacher forcing, all n steps batched along the batch dim: at step t the
        # objects with rank < t are placed, the one with rank == t is the target.
        steps = torch.arange(n, device = rank.device)
        placed = rank[None] < steps[:, None, None]          # (T, b, n)
        target = rank[None] == steps[:, None, None]         # (T, b, n), one-hot where t < n_movable
        valid = target.any(-1)                              # (T, b)
        remaining = movable[None] & ~placed
        rep = lambda x: x[None].expand(n, *x.shape).reshape(n * b, *x.shape[1:])
        ctx = (rep(context[0]), rep(context[1]))
        out = self._encode(None, rep(object_features), None, ctx, placed = placed.reshape(n * b, n))
        logits = self.to_score(out).squeeze(-1).view(n, b, n)
        # finite fill (not -inf): fully-masked rows (t >= n_movable) would go NaN
        # through log_softmax's backward even though they are never selected
        logits = logits.masked_fill(~remaining, -1e9)
        ce = -(F.log_softmax(logits, dim = -1) * target.float()).sum(-1)  # (T, b)
        return ce[valid].mean() if valid.any() else logits.sum() * 0.

    @torch.no_grad()
    def pointer_u(self, grid, object_features, capability, movable, generator = None,
                  context = None, greedy = False):
        """Autoregressive selection -> u (b, n): selection step index for the
        chosen objects, +inf elsewhere, so orders_from_u's argsort recovers the
        order. Each step samples from softmax(logits over remaining movable
        objects) via Gumbel-max under `generator` (greedy=True: argmax)."""
        b, n = movable.shape
        if context is None:
            context = (self.capability_encoder(capability), self.scene_encoder(grid))
        placed = torch.zeros_like(movable)
        u = torch.full(movable.shape, torch.inf, dtype = object_features.dtype,
                       device = movable.device)
        for step in range(n):
            remaining = movable & ~placed
            active = remaining.any(-1)
            if not active.any():
                break
            logits = self.to_score(self._encode(None, object_features, None, context,
                                                placed = placed)).squeeze(-1)
            if not greedy:
                tiny = torch.finfo(logits.dtype).tiny
                un = torch.rand(logits.shape, device = logits.device, generator = generator)
                logits = logits - torch.log((-torch.log(un.clamp_min(tiny))).clamp_min(tiny))
            pick = logits.masked_fill(~remaining, -torch.inf).argmax(-1)
            rows = active.nonzero(as_tuple = True)[0]
            u[rows, pick[rows]] = float(step)
            placed[rows, pick[rows]] = True
        return u


# ---- priority_head ----
import numpy as np
from torch import nn
from torch.nn import Module

from clear.model.affordancenet import AffordanceTransformer
from clear.model.encoders import CapabilityEncoder
from clear.model.encoders import SCENE_CHANS, SceneEncoder, obj_feat_dim


def orders_from_u(u, movable, infer_movable):
    """argsort u ascending (smallest tau first) -> one order tuple per
    example. infer_movable=True sorts every object (the head has to put
    ones it can't move last on its own); otherwise only movable indices are
    ranked at all -- matches sample_u's own inf-fill for the rest. Shared by
    PAMO.sample_orders (inference) and train_pamo_fpo's rollout (needs the
    SAME order both heads see, consistent with whichever `u` it was drawn
    from)."""
    us = u.detach().cpu().numpy()
    if infer_movable:
        return [tuple(np.argsort(us[i])) for i in range(len(us))]
    return [
        tuple(mov[np.argsort(us[i, mov])])
        for i, mov in enumerate(np.flatnonzero(m.cpu().numpy()) for m in movable)
    ]


class PriorityHead(OrderingAblationHeads, Module):
    SIGMA_MIN = 0.05
    # 2026-08-23: softplus had no ceiling -- live in deep_500k FPO training
    # (step ~28546+, sigma_A/mean pinned at SIGMA_MIN for 28k steps then
    # escaped to oscillate 0.05..1.0+, sigma_A/max hit ~9.9, ~200x SIGMA_MIN,
    # kl_div_A_mean spiked 20x in lockstep) sigma ran away once the weak
    # kl_beta_a anchor stopped holding it, well past any exploration range
    # this project's own sweeps ever found useful (SS42's best deliberate
    # widening only reached 0.13). Caps the pathological tail without
    # touching the floor or the exploration range sweeps already covered.
    SIGMA_MAX = 0.5

    def __init__(self, grid_hw = (8, 8), dim = 128, depth = 4, heads = 4, dim_head = 32,
                 drop_obj = (), noise = 'gaussian',
                 obj_extra_dim = 0, include_reachable = False, order_head = 'gauss',
                 capability_encoder = None,
                 scene_channels = SCENE_CHANS, mover_head = False, kappa_links = False, trav_head = False,
                 scene_stride = 2, ego_only_scene = False):
        super().__init__()
        assert noise in ('gaussian', 'gumbel')
        # kappa_links: the planner attends the body's LINK tokens directly (MorphologyEncoder.link_tokens)
        # instead of one pooled kappa token. The pooled read-out has one fixed query, so 'which part of the
        # body matters' cannot depend on the object or the terrain; with link tokens in the same transformer
        # each object token chooses which links to read -- arms for a push, legs for a step (2026-09-03,
        # user's concept). Opt-in; needs a MorphologyEncoder capability_encoder.
        self.kappa_links = bool(kappa_links)
        # trav_head: one logit per SCENE token, 'can this body cross this patch' (Example.trav pooled to the
        # token grid). Without it the scene tokens have no target of their own and no reason to read the
        # body; with it, terrain-vs-legs attention has something to earn (2026-09-03).
        self.trav_head = bool(trav_head)
        # ego_only_scene: blank the privileged terrain class channels (flat / step / wall = grid[:, :3])
        # before the scene encoder, keeping start / goal and whatever ego channels are appended. The
        # planner then knows the terrain only through what THIS body's camera saw (plus kappa). The
        # velocity field still receives the full grid (its validity loss reads the wall channel).
        self.ego_only_scene = bool(ego_only_scene)
        # mover_head: one extra logit per object, "this body moves it in this
        # scene" (rank < n). The pairwise rank loss only orders movers ahead of
        # the rest; nothing in it says WHERE the mover/non-mover split falls, so
        # an infer_movable model had no principled mover SET at inference
        # (export_kappa_learned.py used the largest gap in sorted mu). Opt-in;
        # False leaves every existing checkpoint's parameter set unchanged.
        self.mover_head = bool(mover_head)
        # Structural ablation of the ordering model (experiments/ordering_ablation):
        #   gauss   -- (mu, sigma) per object, sampled u = mu + sigma*eps, argsort. The paper's head.
        #   score   -- one scalar per object, MSE-regressed onto the oracle's normalized rank;
        #              no sampling, order = argsort(score).
        #   pointer -- autoregressive: re-encode with a learned "placed" offset on already-chosen
        #              objects, softmax over the remaining movable ones, CE vs the oracle's next
        #              pick (teacher forcing). Inference samples (Gumbel-max) step by step.
        assert order_head in ('gauss', 'score', 'pointer')
        self.order_head = order_head
        self.noise = noise
        self.infer_movable = 'can_move' in drop_obj
        assert order_head == 'gauss' or not self.infer_movable, \
            "score/pointer heads rank movable objects only (no movable-vs-immovable supervision)"
        self.to_object_tokens = nn.Linear(obj_feat_dim(drop_obj, include_reachable) + obj_extra_dim, dim)
        # capability_encoder: optional module replacing the default vector
        # encoder (e.g. kappa_set_encoder.KappaSetEncoder) -> (b, 1, dim) token.
        self.capability_encoder = capability_encoder if capability_encoder is not None else CapabilityEncoder(dim)
        self.scene_encoder = SceneEncoder(dim, grid_hw, channels = scene_channels, stride = scene_stride)
        self.transformer = AffordanceTransformer(dim, depth = depth, heads = heads, dim_head = dim_head)
        if order_head == 'gauss':
            self.to_mu_sigma = nn.Linear(dim, 2)
        else:
            self.to_score = nn.Linear(dim, 1)
        if self.mover_head:
            self.to_mover = nn.Linear(dim, 1)
        if self.trav_head:
            self.to_trav = nn.Linear(dim, 1)
        if order_head == 'pointer':
            # zero-init: at step 0 the pointer head is exactly the score head's encoder
            self.placed_embed = nn.Parameter(torch.zeros(dim))

    def _encode(self, grid, object_features, capability, context = None, placed = None):
        """-> per-object transformer outputs (b, n, d). `placed` (b, n) bool
        (pointer head only) adds a learned offset to already-chosen objects."""
        objects = self.to_object_tokens(object_features)
        if placed is not None:
            objects = objects + placed[..., None].to(objects.dtype) * self.placed_embed
        n = objects.shape[1]
        if self.ego_only_scene and grid is not None:
            grid = grid.clone(); grid[:, :3] = 0.0
        if self.kappa_links and context is None:
            links, lmask = self.capability_encoder.link_tokens(capability)   # (b, L, d), (b, L)
            scene_tokens = self.scene_encoder(grid)
            tokens = torch.cat([links, objects, scene_tokens], dim = 1)
            L, t = links.shape[1], tokens.shape[1]
            mask = torch.zeros(tokens.shape[0], t, t, dtype = torch.bool, device = tokens.device)
            mask[:, :, :L] = ~lmask[:, None, :]                            # padded links: never a key
            self._n_link_tokens = L
            out = self.transformer(tokens, mask = mask)
            self._scene_out = out[:, L + n:]
            return out[:, L:L + n]
        cap_token, scene_tokens = context if context is not None else (
            self.capability_encoder(capability), self.scene_encoder(grid))
        tokens = torch.cat([cap_token, objects, scene_tokens], dim = 1)
        self._n_link_tokens = 1
        out = self.transformer(tokens)
        self._scene_out = out[:, 1 + n:]
        return out[:, 1:1 + n]

    def forward(self, grid, object_features, capability, context = None, return_mover = False):
        """-> (mu, sigma), each (b, n): the activation-logit Gaussian per object.
        return_mover=True (requires mover_head) appends the (b, n) mover logit.

        `context` is an optional pre-built (capability token, scene tokens)
        pair. Passing it swaps the front end -- the metric maze perception
        stack instead of the class-grid encoders -- without this head growing a
        branch on which world it is looking at. `grid` and `capability` are
        then unused.

        score/pointer heads: mu is the scalar score (pointer: the step-0
        selection logits), sigma a constant SIGMA_MIN placeholder so callers
        that plot/regularize sigma keep working; neither head samples from it.
        """
        out = self._encode(grid, object_features, capability, context)
        if self.order_head != 'gauss':
            s = self.to_score(out).squeeze(-1)
            return s, torch.full_like(s, self.SIGMA_MIN)
        mu, raw_sigma = self.to_mu_sigma(out).unbind(dim = -1)
        sigma = F.softplus(raw_sigma).clamp(max = self.SIGMA_MAX - self.SIGMA_MIN) + self.SIGMA_MIN
        if return_mover:
            assert self.mover_head, 'return_mover needs mover_head=True'
            return mu, sigma, self.to_mover(out).squeeze(-1)
        return mu, sigma

    def trav_logits(self):
        """(b, S) traversability logit per scene token from the LAST forward (requires trav_head)."""
        assert self.trav_head, 'trav_logits needs trav_head=True'
        return self.to_trav(self._scene_out).squeeze(-1)

    # score / pointer ablation heads live in ordering_ablation_heads.py (mixin)

    def sample_noise(self, like, generator = None):
        """Draw one reparameterization sample shaped/typed/placed like `like`,
        per `self.noise`. Split out of sample_u() so PAMO.forward()'s
        TRAINING-time draw can share it -- forward() used to hardcode
        `torch.randn_like(sigma)` regardless of `self.noise`, so a
        noise='gumbel' head would sample Gumbel at inference (via sample_u())
        but Gaussian during training: a real train/sample mismatch on top of
        (not the same thing as) the sampler-vs-loss mismatch this docstring
        goes on to describe. Gaussian stays the default -- and, since
        `noise='gaussian'` was already every training run to date, this split
        changes nothing for any existing checkpoint.

        Which noise this is decides what ordering model the head implements.
        Gaussian perturb-then-argsort is Thurstonian. Gumbel makes argsort(mu +
        noise) exactly a Plackett-Luce sample -- the correspondence holds if and
        only if the perturbations are i.i.d. Gumbel -- which matches the
        Bradley-Terry logistic pairwise loss the rank term already uses. As it
        stands the sampler and the loss are maximum likelihood for different
        models; nothing breaks, but neither has a name.
        """
        if self.noise == 'gumbel':
            # NEGATIVE Gumbel, because sample_orders sorts u ASCENDING and takes
            # the smallest first. Plackett-Luce is repeated argMAX of
            # score + Gumbel, so argmin(mu - G) is a Plackett-Luce sample with
            # scores -mu. Adding +G here would sort the right distribution
            # backwards and look almost right.
            tiny = torch.finfo(like.dtype).tiny
            un = torch.rand(like.shape, device = like.device, generator = generator)
            # parenthesised deliberately: unary minus binds looser than the
            # method call, so -x.log().clamp_min(t) clamps the NEGATIVE log to a
            # positive floor and the outer log is NaN for every element
            return torch.log((-torch.log(un.clamp_min(tiny))).clamp_min(tiny))
        return torch.randn(like.shape, device = like.device, generator = generator)

    def sample_u(self, grid, object_features, capability, movable, generator = None,
                 context = None):
        """Reparameterized draw of the activation logits; immovable -> +inf
        (they sort last and never activate). See sample_noise() for which
        noise model this actually is.

        score head: u = score, no noise (deterministic). pointer head: u =
        selection step (see pointer_u); mu/sigma returned are then placeholders."""
        if self.order_head == 'pointer':
            u = self.pointer_u(grid, object_features, capability, movable, generator, context)
            return u, u, torch.full_like(u, self.SIGMA_MIN)
        mu, sigma = self(grid, object_features, capability, context = context)
        if self.order_head == 'score':
            u = mu
        else:
            u = mu + sigma * self.sample_noise(mu, generator = generator)
        if self.infer_movable:
            # no mask: the head has to put objects it cannot move last on its
            # own, which is only learnable because the rank loss now supervises
            # movable-vs-immovable pairs (see PAMO.forward)
            return u, mu, sigma
        return u.masked_fill(~movable, torch.inf), mu, sigma


# ---- ordering_loss ----
def sampled_priority_rank_loss(priority, rank, valid, temperature=1.0):
    """Ascending priorities; rank N marks objects outside the reference plan.

    Callers reparameterize their Gaussian before calling this function. The loss
    weights adjacent reference decisions more heavily and includes selected vs
    unselected pairs. It does not guarantee validity of sampled permutations.
    """
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    n = rank.shape[-1]
    distance = rank[:, None, :].to(priority.dtype) - rank[:, :, None].to(priority.dtype)
    pairs = (distance > 0) & (rank[:, :, None] < n) & valid[:, :, None] & valid[:, None, :]
    weights = (1.0 / distance.clamp(min=1.0))[pairs]
    gap = priority[:, None, :] - priority[:, :, None]
    values = F.softplus(-gap[pairs] / temperature)
    return (values * weights).sum() / weights.sum() if values.numel() else priority.sum() * 0.0
