"""clear: clear_core, affordance_conditioned_core, plan_code, pamo.

clear_core: CLEAR shared core: one token encoder, three heads.

    tokens = [ embodiment | o_1 .. o_n | scene_1 .. scene_s ]      (paper: [c | o | scene])

    SharedEncoder    feature adapters + ONE AffordanceTransformer with key padding.
                     Ordering and trajectory heads both read its output, so the
                     encoder receives gradient from every head.
    OrderingHead     per-object selection logit + Gaussian priority (mu, sigma).
    AffordanceHead   optional per-scene-token logits (traversability / capability
                     evidence). Trained when the batch carries labels; never read
                     by the other heads.
    flow             RankCausalTargetFlow over a task-specific interaction code xi:
                     grid cell target, placement configuration, whole object path.

Conventions shared by every task adapter
    rank      (b, n) long, -1 = object not in the plan (the N sentinel is accepted too)
    selected  = object_mask & (rank >= 0)
    flow time is generative time, never controller time. Observed geometry of
    every object stays visible at every rank; only the generated codes of
    later-ranked objects are hidden (clear.model.causal_velocity_field.causal_mask).

Batch keys
    object_features (b,n,Fo)  object_mask (b,n)
    scene_features  (b,s,Fs)  scene_mask  (b,s)     or scene_tokens (b,s,dim) when scene_dim=None
    structure       (b,l,Fst) structure_mask (b,l)  embodiment rows; a fixed agent is one row
    navigation_features (b,n,Fn)                      optional, navigation_dim > 0
    rank (b,n)  target_code (b,n,target_dim)          training only
    affordance_target (b,s,k)  affordance_mask (b,s)  optional, affordance_dim = k

affordance_conditioned_core: Shared morphology -> learned affordance -> ordering -> rank-causal target flow.

Affordance queries contain observations only. Labels are required at training
and never consumed at inference. Scores condition planning softly: an object
unavailable now may become available after an earlier interaction.

plan_code: Plan codes (CLEAR v5): enumerable skeletons over objects, purposes and modes.

A skeleton is (which objects, in what order, for what purpose, and which mode per segment).
K learned code vectors modulate the node tokens (FiLM) and each decodes one skeleton
deterministically. Supervision is a set-to-set matching between the K codes and ALL valid
minimal plans of an example:

    L_cover  = mean_p  min_k  L(k, p)      every valid plan is reachable from some code
    L_commit = mean over winning k of L(k, p*(k))
    L_prior  = multi-label BCE(prior_logits, 1[k wins some plan])

where L(k, p) = selection BCE + pairwise rank loss + purpose CE (selected objects) + mode CE
(segments with a labelled mode). Enumeration = codes in prior order, decoded, de-duplicated;
no external sampler. `FSQPosterior` keeps the alternative (posterior over an implicit FSQ
codebook) under the same interface for the ablation.

pamo: PAMO: capability-aware ordering flow matching, as one model.

    model = PAMO(grid_hw = (8, 8))

    loss, breakdown = model(batch)          # batch from data.collate
    loss.backward()

    # after much training

    plan = model.sample(batch)              # orders committed at t = 0,
    plan['orders'], plan['x']               # poses integrated under them

Two networks inside, trained jointly:
  PriorityHead        (Stage A)  who moves when   -- tau distribution, sampled once
  CausalVelocityField (Stage B)  where things go  -- flow matching in path time

Ordering supervision comes from batch['rank'] -- the oracle in M1, the
oracle-free search (wam.plan_search) in M2. The model cannot tell the
difference; that is the point.

ein notation:
  b - batch
  n - objects
  k - order samples
"""
from __future__ import annotations

# ---- clear_core ----
import torch
from torch import nn
from torch.nn import functional as F

from clear.model.affordancenet import AffordanceTransformer
from clear.model.ordernet import sampled_priority_rank_loss
from clear.model.causalflownet import RankCausalTargetFlow, priority_scale, rank_selected
from clear.model.encoders import StructureEncoder


def _mlp(inp, dim):
    return nn.Sequential(nn.Linear(inp, dim), nn.GELU(), nn.Linear(dim, dim))


def _zero_like_loss(*tensors):
    """A finite zero that still touches the graph, for empty supervision."""
    return sum(t.sum() * 0 for t in tensors)


class NormalizedNavigation(nn.Module):
    """Navigation context added to object tokens at a learned, initially small scale.

    The plain nn.Linear branch adds a 4-D context whose contribution (norm ~2.7 on trained
    checkpoints) exceeds the object token it is added to (~2.0), so any noise in the navigation
    context outweighs the object's own identity. LayerNorm fixes the branch's scale and the gate
    starts at 0.1, so the trunk first sees objects, then learns how much navigation to admit.
    """

    def __init__(self, navigation_dim, dim, gate=0.1):
        super().__init__()
        self.in_features = navigation_dim
        self.linear = nn.Linear(navigation_dim, dim, bias=False)
        self.norm = nn.LayerNorm(dim)
        self.gate = nn.Parameter(torch.full((1,), float(gate)))

    def forward(self, navigation):
        return self.gate * self.norm(self.linear(navigation))


class SharedEncoder(nn.Module):
    def __init__(self, dim, object_dim, scene_dim, structure_dim, depth=4, heads=4,
                 dim_head=None, navigation_dim=0, navigation_norm=False):
        super().__init__()
        dim_head = dim_head or dim // heads
        self.object_in = _mlp(object_dim, dim)
        self.structure_in = StructureEncoder(structure_dim, dim)
        self.scene_in = _mlp(scene_dim, dim) if scene_dim else None
        if not navigation_dim:
            self.navigation_in = None
        elif navigation_norm:
            self.navigation_in = NormalizedNavigation(navigation_dim, dim)
        else:
            self.navigation_in = nn.Linear(navigation_dim, dim, bias=False)
        self.trunk = AffordanceTransformer(dim, depth=depth, heads=heads, dim_head=dim_head)

    def forward(self, batch, no_embodiment=False):
        objects = self.object_in(batch["object_features"])
        if self.navigation_in is not None:
            navigation = batch["navigation_features"]
            if no_embodiment:
                navigation = torch.zeros_like(navigation)
            objects = objects + self.navigation_in(navigation)
        embodiment = self.structure_in.pool(batch["structure"], batch["structure_mask"])[:, None]
        if no_embodiment:
            embodiment = torch.zeros_like(embodiment)
        scene = self.scene_in(batch["scene_features"]) if self.scene_in is not None else batch["scene_tokens"]
        b, n, _ = objects.shape
        ones = torch.ones(b, 1, dtype=torch.bool, device=objects.device)
        scene_mask = batch.get("scene_mask")
        if scene_mask is None:
            scene_mask = torch.ones(b, scene.shape[1], dtype=torch.bool, device=objects.device)
        key_mask = torch.cat([ones, batch["object_mask"], scene_mask], 1)
        tokens = torch.cat([embodiment, objects, scene], 1)
        blocked = (~key_mask)[:, None, :].expand(-1, key_mask.shape[1], -1)
        encoded = self.trunk(tokens, mask=blocked)
        return dict(tokens=encoded, objects=encoded[:, 1:1 + n], scene_tokens=encoded[:, 1 + n:],
                    embodiment=embodiment, scene=scene, scene_mask=scene_mask, key_mask=key_mask)


class OrderingHead(nn.Module):
    """Row 0 of `priority` is the selection logit, rows 1-2 are (mu, raw sigma)."""

    def __init__(self, dim, sigma_min=0.05, sigma_max=0.5):
        super().__init__()
        self.priority = nn.Linear(dim, 3)
        self.sigma_min, self.sigma_max = sigma_min, sigma_max

    def forward(self, objects):
        selection, mu, raw = self.priority(objects).unbind(-1)
        return selection, mu, priority_scale(raw, self.sigma_min, self.sigma_max)

    def loss(self, selection, mu, sigma, rank, object_mask, generator=None, rank_selected_only=False):
        n = rank.shape[1]
        selected = object_mask & (rank >= 0) & (rank < n)
        if not object_mask.any():
            zero = _zero_like_loss(selection, mu, sigma)
            return dict(selection=zero, order=zero, kl=zero)
        selection_loss = F.binary_cross_entropy_with_logits(selection[object_mask], selected[object_mask].float())
        u = mu + sigma * torch.randn(mu.shape, device=mu.device, generator=generator)
        sentinel = torch.where(selected, rank, torch.full_like(rank, n))
        # Alternative valid subsets can contradict selected-vs-unselected priority pairs.
        order = sampled_priority_rank_loss(u, sentinel, selected if rank_selected_only else object_mask)
        kl = .5 * (mu ** 2 + sigma ** 2 - 1) - sigma.log()
        return dict(selection=selection_loss, order=order, kl=kl[object_mask].mean())

    def sample(self, selection, mu, sigma, object_mask, generator=None, max_interactions=None,
               sample_selection=False):
        if sample_selection:
            draw = torch.rand(selection.shape, device=selection.device, generator=generator)
            selected = (draw < torch.sigmoid(selection)) & object_mask
        else:
            selected = (selection > 0) & object_mask
        u = mu + sigma * torch.randn(mu.shape, device=mu.device, generator=generator)
        rank, active = rank_selected(u, selected, max_interactions)
        return rank.masked_fill(~active, -1), active


class AffordanceHead(nn.Module):
    def __init__(self, dim, n_out):
        super().__init__()
        self.net = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, n_out))

    def forward(self, tokens):
        return self.net(tokens)

    @staticmethod
    def loss(logits, target, mask):
        if not mask.any():
            return _zero_like_loss(logits)
        return F.binary_cross_entropy_with_logits(logits[mask], target[mask].to(logits.dtype))


class CLEARCore(nn.Module):
    def __init__(self, dim, object_dim, scene_dim, structure_dim, target_dim, depth=4, heads=4,
                 dim_head=None, navigation_dim=0, affordance_dim=0, causal=True, no_embodiment=False,
                 kl_weight=1e-3, affordance_weight=1.0, causal_bias_slope=0.0,
                 navigation_norm=False):
        super().__init__()
        if dim % heads:
            raise ValueError("dim must be divisible by heads")
        dim_head = dim_head or dim // heads
        self.no_embodiment = bool(no_embodiment)
        self.kl_weight, self.affordance_weight = kl_weight, affordance_weight
        self.encoder = SharedEncoder(dim, object_dim, scene_dim, structure_dim, depth, heads, dim_head,
                                     navigation_dim, navigation_norm=navigation_norm)
        self.ordering = OrderingHead(dim)
        self.affordance = AffordanceHead(dim, affordance_dim) if affordance_dim else None
        self.flow = RankCausalTargetFlow(dim, target_dim, depth, heads, dim_head, causal,
                                         causal_bias_slope=causal_bias_slope)

    # -- shared encoding -----------------------------------------------------------
    def _encode(self, batch):
        h = self.encoder(batch, self.no_embodiment)
        h["selection"], h["mu"], h["sigma"] = self.ordering(h["objects"])
        if self.affordance is not None:
            h["affordance_logits"] = self.affordance(h["scene_tokens"])
        return h

    def encode(self, batch):
        """Public view; adapters may override it, the losses use `_encode`."""
        return self._encode(batch)

    @staticmethod
    def flow_key_mask(h, object_mask):
        # [context | objects | scene | observed object copies]
        return torch.cat([h["key_mask"], object_mask], 1)

    # -- training --------------------------------------------------------------------
    def loss(self, batch, generator=None):
        h = self._encode(batch)
        object_mask, rank = batch["object_mask"], batch["rank"]
        parts = self.ordering.loss(h["selection"], h["mu"], h["sigma"], rank, object_mask, generator)
        parts["flow"] = self.flow_loss(h, batch, generator)
        total = parts["selection"] + parts["order"] + parts["flow"] + self.kl_weight * parts["kl"]
        if self.affordance is not None and "affordance_target" in batch:
            parts["affordance"] = self.affordance.loss(h["affordance_logits"], batch["affordance_target"],
                                                       batch["affordance_mask"])
            total = total + self.affordance_weight * parts["affordance"]
        return total, {k: float(v.detach()) for k, v in parts.items()}

    def flow_loss(self, h, batch, generator=None):
        object_mask, rank, target = batch["object_mask"], batch["rank"], batch["target_code"]
        n = rank.shape[1]
        selected = object_mask & (rank >= 0) & (rank < n)
        if not selected.any():
            return _zero_like_loss(h["objects"], self.flow.head[-1].weight)
        noise = torch.randn(target.shape, device=target.device, generator=generator) * self.flow.noise_std
        t = torch.rand(target.shape[0], device=target.device, generator=generator)
        target = torch.where(selected[:, :, None], target, torch.zeros_like(target))
        mixed = (1 - t[:, None, None]) * noise + t[:, None, None] * target
        velocity = self.flow(h["objects"], h["embodiment"], h["scene"], mixed, t, rank, selected,
                             key_mask=self.flow_key_mask(h, object_mask))
        return F.mse_loss(velocity[selected], (target - noise)[selected])

    # -- inference -------------------------------------------------------------------
    @torch.no_grad()
    def sample(self, batch, steps=30, generator=None, max_interactions=None, sample_selection=False,
               trace=None):
        """`trace`, if a list, is forwarded to the flow and receives its Euler
        intermediates as (t, state). Default None leaves inference untouched."""
        if max_interactions is not None and max_interactions < 0:
            raise ValueError("max_interactions must be nonnegative")
        h = self._encode(batch)
        object_mask = batch["object_mask"]
        rank, selected = self.ordering.sample(h["selection"], h["mu"], h["sigma"], object_mask, generator,
                                              max_interactions, sample_selection)
        code = self.flow.sample(h["objects"], h["embodiment"], h["scene"], rank, selected, steps, generator,
                                key_mask=self.flow_key_mask(h, object_mask), trace=trace)
        out = dict(rank=rank, selected=selected, code=code, selection_logits=h["selection"])
        if "affordance_logits" in h:
            out["affordance_logits"] = h["affordance_logits"]
        return out


# ---- affordance_conditioned_core ----
class EmbodimentConditionedAffordanceHead(nn.Module):
    def __init__(self, embodiment_dim, feature_dim, dim=64):
        super().__init__()
        self.embodiment_projection = nn.Linear(embodiment_dim, dim, bias=False)
        self.edge = nn.Sequential(nn.Linear(feature_dim, dim), nn.GELU(), nn.Linear(dim, dim))
        self.classifier = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, 1))

    def forward(self, embodiment, features):
        return self.classifier(torch.cat([self.edge(features),
                                          self.embodiment_projection(embodiment)], -1)).squeeze(-1)


class EncoderConditionedAffordanceHead(nn.Module):
    """Affordance read off the SHARED encoder's tokens instead of hand-built edge features.

    EmbodimentConditionedAffordanceHead above is TOLD what the ground does (an edge-feature
    vector somebody computed) and only has to weigh it against z_B. This one is told WHERE on
    the scene it is being asked about, and has to work the ground out of the encoder's scene
    tokens.

    It deliberately does NOT own the encoder. The caller passes tokens already encoded, so
    (a) the parameters stay registered once, on the model, and (b) a planner scoring tens of
    thousands of graph edges over one scene encodes that scene once and broadcasts, instead
    of re-running the trunk per edge.

    tokens     (b, t, dim)  SharedEncoder output, or a single scene's expanded to b
    key_mask   (b, t) bool  True = real token
    embodiment (b, dim)     z_B
    query      (b, q)       navigation.traversal_query rows
    """

    def __init__(self, dim, query_dim, hidden=64, depth=2, heads=4):
        super().__init__()
        if dim % heads:
            raise ValueError("dim must be divisible by heads")
        self.query_in = nn.Sequential(nn.Linear(query_dim, dim), nn.GELU(), nn.Linear(dim, dim))
        self.fuse = AffordanceTransformer(dim, depth=depth, heads=heads, dim_head=dim // heads)
        self.embodiment_projection = nn.Linear(dim, hidden, bias=False)
        self.classifier = nn.Sequential(nn.Linear(dim + hidden, hidden), nn.GELU(),
                                        nn.Linear(hidden, 1))

    def forward(self, tokens, key_mask, embodiment, query):
        if tokens.shape[:2] != key_mask.shape or len(tokens) != len(query):
            raise ValueError("one token mask and one query row per example required")
        q = self.query_in(query)[:, None]
        ones = torch.ones(len(q), 1, dtype=torch.bool, device=q.device)
        mask = torch.cat([ones, key_mask], 1)
        blocked = (~mask)[:, None, :].expand(-1, mask.shape[1], -1)
        fused = self.fuse(torch.cat([q, tokens], 1), mask=blocked)[:, 0]
        return self.classifier(torch.cat([fused, self.embodiment_projection(embodiment)],
                                         -1)).squeeze(-1)


class AffordanceConditionedCore(CLEARCore):
    architecture = "clear-affordance-order-causal-v1"

    def __init__(self, dim, object_dim, scene_dim, structure_dim, target_dim,
                 affordance_input_dim, depth=4, heads=4, affordance_hidden=64, causal=True,
                 causal_bias_slope=0.0):
        super().__init__(dim, object_dim, scene_dim, structure_dim, target_dim,
                         depth=depth, heads=heads, navigation_dim=1, causal=causal,
                         causal_bias_slope=causal_bias_slope)
        self.interaction_affordance = EmbodimentConditionedAffordanceHead(
            dim, affordance_input_dim, affordance_hidden)

    def _encode(self, batch):
        embodiment = self.encoder.structure_in.pool(batch['structure'], batch['structure_mask'])
        queries = batch['affordance_features']
        logits = self.interaction_affordance(embodiment[:, None].expand(-1, queries.shape[1], -1), queries)
        conditioned = dict(batch, navigation_features=torch.sigmoid(logits)[..., None])
        h = super()._encode(conditioned)
        h['interaction_affordance_logits'] = logits
        return h

    def flow_loss(self, h, batch, generator=None):
        target, rank, mask = batch['target_code'], batch['rank'], batch['object_mask']
        selected = mask & (rank >= 0) & (rank < rank.shape[1])
        slots = batch.get('target_code_mask', torch.ones_like(target, dtype=torch.bool))
        supervised = selected[..., None] & slots
        if not supervised.any():
            return h['objects'].sum() * 0 + self.flow.head[-1].weight.sum() * 0
        noise = torch.randn(target.shape, device=target.device, generator=generator)
        noise = torch.where(supervised, noise, torch.zeros_like(noise))
        target = torch.where(supervised, target, torch.zeros_like(target))
        t = torch.rand(target.shape[0], device=target.device, generator=generator)
        mixed = (1 - t[:, None, None]) * noise + t[:, None, None] * target
        velocity = self.flow(h['objects'], h['embodiment'], h['scene'], mixed, t, rank,
                             selected, key_mask=self.flow_key_mask(h, mask))
        return F.mse_loss(velocity[supervised], (target - noise)[supervised])

    def loss(self, batch, generator=None):
        if 'affordance_target' not in batch:
            raise ValueError('affordance labels required; regenerate the training dataset')
        h = self._encode(batch)
        mask = batch['object_mask']
        parts = self.ordering.loss(h['selection'], h['mu'], h['sigma'], batch['rank'], mask, generator,
                                   rank_selected_only=getattr(self, 'rank_selected_only', False))
        parts['flow'] = self.flow_loss(h, batch, generator)
        logits = h['interaction_affordance_logits']
        labels = batch['affordance_target']
        if labels.shape != mask.shape or not torch.isfinite(labels).all() or ((labels < 0) | (labels > 1)).any():
            raise ValueError('one finite binary affordance label per object is required')
        parts['affordance'] = (F.binary_cross_entropy_with_logits(logits[mask], labels[mask])
                               if mask.any() else logits.sum() * 0)
        total = parts['selection'] + parts['order'] + parts['flow'] + self.kl_weight * parts['kl'] + parts['affordance']
        count_weight = getattr(self, 'cardinality_weight', 0.)
        if count_weight:
            selected = mask & (batch['rank'] >= 0) & (batch['rank'] < mask.shape[1])
            parts['cardinality'] = F.mse_loss((h['selection'].sigmoid() * mask).sum(-1),
                                             selected.sum(-1).to(h['selection'].dtype))
            total = total + count_weight * parts['cardinality']
        return total, {k: float(v.detach()) for k, v in parts.items()}

    @torch.no_grad()
    def generate_targets(self, h, batch, rank, selected, steps=30, generator=None, trace=None):
        """`trace`, if a list, receives (t, code) at every Euler step and at t=1; inference is
        unchanged. The visualisations read it to show the flow being integrated."""
        if steps < 1:
            raise ValueError('flow steps must be positive')
        shape = (*h['objects'].shape[:2], self.flow.target_dim)
        slots = batch.get('target_code_mask', torch.ones(shape, dtype=torch.bool, device=rank.device))
        active = selected[..., None] & slots
        code = torch.randn(shape, device=rank.device, generator=generator)
        code = torch.where(active, code, torch.zeros_like(code))
        for k in range(steps):
            if trace is not None:
                trace.append((k / steps, code.detach().clone()))
            t = torch.full((shape[0],), k / steps, device=code.device, dtype=code.dtype)
            velocity = self.flow(h['objects'], h['embodiment'], h['scene'], code, t, rank, selected,
                                 key_mask=self.flow_key_mask(h, batch['object_mask']))
            code = code + torch.where(active, velocity, torch.zeros_like(velocity)) / steps
        if trace is not None:
            trace.append((1.0, code.detach().clone()))
        return code

    @torch.no_grad()
    def sample(self, batch, steps=30, generator=None, max_interactions=None, sample_selection=False,
               trace=None):
        h = self._encode(batch)
        rank, selected = self.ordering.sample(h['selection'], h['mu'], h['sigma'], batch['object_mask'],
                                              generator, max_interactions, sample_selection)
        code = self.generate_targets(h, batch, rank, selected, steps, generator, trace=trace)
        return dict(rank=rank, selected=selected, code=code, selection_logits=h['selection'],
                    affordance_logits=h['interaction_affordance_logits'])


# ---- plan_code ----
import torch.nn.functional as F

from clear.data.modes import PURPOSES

N_PURPOSES = len(PURPOSES)


def per_example_rank_loss(priority, rank, valid):
    n = rank.shape[-1]
    distance = rank[:, None, :].to(priority.dtype) - rank[:, :, None].to(priority.dtype)
    pairs = (distance > 0) & (rank[:, :, None] < n) & valid[:, :, None] & valid[:, None, :]
    weights = (1.0 / distance.clamp(min=1.0)) * pairs
    values = F.softplus(-(priority[:, None, :] - priority[:, :, None])) * weights
    return values.sum((1, 2)) / weights.sum((1, 2)).clamp(min=1e-6)


def decode_skeleton(selection_logit, priority, object_mask, max_interactions=None):
    selected = (selection_logit > 0) & object_mask
    n = priority.shape[-1]
    order = priority.masked_fill(~selected, float("inf")).argsort(dim=-1, stable=True)
    rank = torch.empty_like(order).scatter_(1, order, torch.arange(n, device=order.device).expand_as(order))
    active = selected & (rank < (n if max_interactions is None else max_interactions))
    return torch.where(active, rank, torch.full_like(rank, -1)), active


class PlanCodes(nn.Module):
    def __init__(self, dim=128, n_codes=16):
        super().__init__()
        self.K = n_codes
        self.codes = nn.Parameter(torch.randn(n_codes, dim) * 0.02)
        self.film = nn.Linear(dim, 2 * dim)
        self.obj_head = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, 2 + N_PURPOSES))
        self.seg_proj = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim))
        self.prior = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, n_codes))

    def _film(self, tokens):
        scale, shift = self.film(self.codes).chunk(2, -1)
        return tokens[:, None] * (1 + scale[None, :, None]) + shift[None, :, None]     # (b,K,T,d)

    def decode_all(self, objects, segments, cap, mode_mask):
        """objects (b,N,d), segments (b,S,d), cap (b,Mn,d) -> selection (b,K,N), priority (b,K,N),
        purpose logits (b,K,N,P), mode logits (b,K,S,Mn)."""
        o = self.obj_head(self._film(objects))
        s = self.seg_proj(self._film(segments))                                            # (b,K,S,d)
        mode_logits = torch.einsum("bksd,bmd->bksm", s, cap) / cap.shape[-1] ** 0.5
        mode_logits = mode_logits.masked_fill(~mode_mask[:, None, None, :], -1e4)
        return o[..., 0], o[..., 1], o[..., 2:], mode_logits

    def prior_logits(self, body_summary, scene_summary):
        return self.prior(torch.cat([body_summary, scene_summary], -1))

    # ------------------------------------------------------------------ losses
    def loss(self, objects, object_mask, segments, seg_mask, cap, mode_mask, plans, plan_mask, purposes, seg_modes,
             body_summary, scene_summary):
        """plans (b,P,N) ranks with N = not in plan; purposes (b,P,N) long, -1 = not in plan;
        seg_modes (b,P,S) long slot index, -1 = unlabelled."""
        b, N, _ = objects.shape
        K, P, S = self.K, plans.shape[1], segments.shape[1]
        sel, prio, purp, modl = self.decode_all(objects, segments, cap, mode_mask)
        def ex(x, extra_dims):                     # (b,K,...) -> (b*K*P, ...)
            return x[:, :, None].expand(b, K, P, *extra_dims).reshape(b * K * P, *extra_dims)
        def ep(x, extra_dims):                     # (b,P,...) -> (b*K*P, ...)
            return x[:, None].expand(b, K, P, *extra_dims).reshape(b * K * P, *extra_dims)
        sel_f, prio_f, rank_f = ex(sel, (N,)), ex(prio, (N,)), ep(plans, (N,))
        omask_f = object_mask[:, None, None].expand(b, K, P, N).reshape(-1, N)
        selected = (rank_f < N) & omask_f
        sel_loss = F.binary_cross_entropy_with_logits(sel_f, selected.float(), reduction="none")
        sel_loss = (sel_loss * omask_f).sum(-1) / omask_f.sum(-1).clamp(min=1)
        order_loss = per_example_rank_loss(prio_f, rank_f, omask_f)
        purp_f, purp_t = ex(purp, (N, N_PURPOSES)), ep(purposes, (N,))
        pv = selected & (purp_t >= 0)
        purpose_loss = torch.zeros(b * K * P, device=objects.device)
        if pv.any():
            ce = F.cross_entropy(purp_f[pv], purp_t[pv], reduction="none")
            purpose_loss = purpose_loss.index_add(0, pv.nonzero()[:, 0], ce) / pv.sum(-1).clamp(min=1)
        mod_f, mod_t = ex(modl, (S, modl.shape[-1])), ep(seg_modes, (S,))
        mv = (mod_t >= 0) & seg_mask[:, None, None].expand(b, K, P, S).reshape(-1, S)
        mode_loss = torch.zeros(b * K * P, device=objects.device)
        if mv.any():
            ce = F.cross_entropy(mod_f[mv], mod_t[mv], reduction="none")
            mode_loss = mode_loss.index_add(0, mv.nonzero()[:, 0], ce) / mv.sum(-1).clamp(min=1)
        L = (sel_loss + order_loss + purpose_loss + mode_loss).view(b, K, P).masked_fill(~plan_mask[:, None, :], float("inf"))
        best_code_per_plan, winner = L.min(1)                                              # (b,P)
        cover = best_code_per_plan.masked_fill(~plan_mask, 0).sum(1) / plan_mask.sum(1).clamp(min=1)
        # scatter_add over VALID plans only: padded plans (all-inf rows) have winner == 0 and must not clobber code 0
        wins = torch.zeros(b, K, device=objects.device).scatter_add_(1, winner, plan_mask.float())
        wins = (wins > 0).float()
        best_plan_per_code, _ = L.min(2)
        commit = (best_plan_per_code.masked_fill(wins == 0, 0) * wins).sum(1) / wins.sum(1).clamp(min=1)
        prior = F.binary_cross_entropy_with_logits(self.prior_logits(body_summary, scene_summary), wins.detach())
        return dict(cover=cover.mean(), commit=commit.mean(), prior=prior, code_usage=wins.mean(0).detach())

    # ------------------------------------------------------------------ enumeration
    @torch.no_grad()
    def enumerate(self, objects, object_mask, segments, cap, mode_mask, body_summary, scene_summary, k_max=8,
                  max_interactions=None, extra_logits=None):
        """Per example: list of dict(code, rank (N,), selected (N,), purpose (N,), seg_mode (S,)) in prior order,
        distinct by (rank, purpose, seg_mode)."""
        logits = self.prior_logits(body_summary, scene_summary)
        if extra_logits is not None:
            logits = logits + extra_logits
        sel, prio, purp, modl = self.decode_all(objects, segments, cap, mode_mask)
        out = []
        for i in range(objects.shape[0]):
            seen, props = set(), []
            for k in logits[i].argsort(descending=True).tolist():
                rank, active = decode_skeleton(sel[i, k][None], prio[i, k][None], object_mask[i][None], max_interactions)
                purpose = torch.where(active[0], purp[i, k].argmax(-1), torch.full_like(rank[0], -1))
                seg_mode = modl[i, k].argmax(-1)
                key = (tuple(rank[0].tolist()), tuple(purpose.tolist()), tuple(seg_mode.tolist()))
                if key in seen:
                    continue
                seen.add(key)
                props.append(dict(code=k, rank=rank[0], selected=active[0], purpose=purpose, seg_mode=seg_mode))
                if len(props) >= k_max:
                    break
            out.append(props)
        return out


# ---------------------------------------------------------------------------- FSQ variant
class FSQ(nn.Module):
    def __init__(self, levels=(5, 5, 5)):
        super().__init__()
        self.register_buffer("levels", torch.tensor(levels))
        self.register_buffer("basis", torch.cumprod(torch.tensor([1] + list(levels[:-1])), 0))
        self.codebook_size = int(torch.prod(self.levels))

    def bound(self, z):
        half_l = (self.levels - 1) * (1 + 1e-3) / 2
        offset = torch.where(self.levels % 2 == 0, 0.5, 0.0)
        shift = (offset / half_l).atanh()
        return (z + shift).tanh() * half_l - offset

    def forward(self, z):
        zq = self.bound(z)
        zq = zq + (zq.round() - zq).detach()
        half_width = self.levels // 2
        idx = ((zq + half_width) * self.basis).sum(-1).long()
        return zq / half_width, idx

    def indices_to_codes(self, idx):
        half_width = self.levels // 2
        digits = (idx[..., None] // self.basis) % self.levels
        return (digits - half_width) / half_width


class FSQPosterior(nn.Module):
    def __init__(self, dim=128, levels=(5, 5, 5), max_rank=8):
        super().__init__()
        self.rank_embed = nn.Embedding(max_rank + 2, dim)
        self.max_rank = max_rank
        self.enc = nn.TransformerEncoder(nn.TransformerEncoderLayer(dim, 4, 2 * dim, batch_first=True, norm_first=True, dropout=0.0), 2)
        self.to_z = nn.Linear(dim, len(levels))
        self.fsq = FSQ(levels)
        self.to_code = nn.Linear(len(levels), dim)

    def forward(self, objects, object_mask, rank):
        r = torch.where(rank < 0, torch.full_like(rank, self.max_rank + 1), rank.clamp(max=self.max_rank))
        h = self.enc(objects + self.rank_embed(r), src_key_padding_mask=~object_mask)
        pooled = (h * object_mask[..., None]).sum(1) / object_mask.sum(1, keepdim=True).clamp(min=1)
        codes, idx = self.fsq(self.to_z(pooled))
        return self.to_code(codes), idx


# ---- pamo ----
import numpy as np
from torch.nn import Module

from clear.model.causalflownet import CausalVelocityField
from clear.model.ordernet import PriorityHead, orders_from_u
from clear.model.encoders import SCENE_CHANS, object_features
from clear.util import plackett_luce_logp
from clear.util import oracle_progress, path_velocity, wrap_angle
from clear.util import overlap_penalty, wall_oob_penalty

# helpers


def exists(v):
    return v is not None


def _order_from_rank(rank, movable):
    """(b, n) rank tensor, immovable at sentinel rank n (data.collate's own
    convention, see PAMO.forward's own comment on it) -> one movable-only
    order tuple per example, ascending rank -- the exact inverse of the rank
    assignment collate() performs when it builds a batch from a SPECIFIC
    known order. Used by feasibility_forward/sample(refine_on='ode') to
    re-run the ODE loop under the SAME order the batch's rank/mask already
    commit to, instead of sample_orders' own continuous-u redraw (which
    would be free to pick a DIFFERENT order than the one the rest of the
    batch -- and, for real-corpus batches, the physically-recorded outcome
    -- is conditioned on).

    Deliberately independent of priority_head.orders_from_u: that helper's
    infer_movable=True branch sorts EVERY object (including immovable ones,
    by design, for a head that has to infer movability itself) rather than
    dropping them -- correct for its own caller (a freshly SAMPLED u), but
    would silently overwrite rank's own sentinel-n convention for immovable
    objects if reused here on an already-fixed rank label.
    """
    orders = []
    for i in range(rank.shape[0]):
        idx = [j for j in range(rank.shape[1]) if movable[i, j]]
        idx.sort(key = lambda j: rank[i, j].item())
        orders.append(tuple(idx))
    return orders

# main class



def _assert_observation_consistent(batch, rank, movable, atol = 1e-5):
    """Invariant behind observation-consistent attention (causal_velocity_field.causal_mask,
    causal=False): along the rank order every object's progress s is non-increasing
    (1...1, one partial, 0...0) and every object with s == 0 sits exactly at its current pose
    x0. If a future schedule ever presents a later-ranked object away from x0, this fires
    instead of silently leaking that object's placement into earlier ones."""
    s = batch['s']
    order = torch.argsort(rank, dim = 1)                       # ranks ascending; sentinel n last
    s_sorted = torch.gather(s, 1, order)
    assert bool((s_sorted[:, 1:] <= s_sorted[:, :-1] + atol).all()), \
        "slot schedule violated: progress must be non-increasing along the rank order"
    at_rest = s <= atol
    if at_rest.any():
        dev = (batch['pose'][at_rest] - batch['x0'][at_rest]).abs().max()
        assert float(dev) <= 1e-4, f"object with s=0 not at x0 (max dev {float(dev):.2e}) -- future pose leak"


def _orders_from_rank(rank, movable, infer_movable):
    """collate's `rank` (position in the sampled oracle order, sentinel n for
    non-movers) -> one index tuple per example, in commit sequence. This is the
    same convention orders_from_u emits and _plackett_luce_logp expects."""
    n = rank.shape[1]
    r = rank.detach().cpu().numpy()
    mv = movable.detach().cpu().numpy()
    out = []
    for i in range(len(r)):
        idx = [j for j in range(n) if r[i, j] < n and (infer_movable or mv[i, j])]
        out.append(tuple(sorted(idx, key = lambda j: r[i, j])))
    return out


class PAMO(Module):
    def __init__(
        self,
        grid_hw = (8, 8),
        dim = 128,
        depth = 4,
        heads = 4,
        dim_head = 32,
        rank_loss = 'logistic',   # 'hinge' kept for the ablation
        order_objective = 'pairwise',   # 'plackett_luce': see _pl_rank_loss
        drop_obj = (),
        obj_extra_dim = 0,
        noise = 'gaussian',
        rank_temp = 0.25,
        rank_margin = 0.5,
        sigma_weight = 0.01,
        endpoint_weight = 0.15,
        validity_weight = 0.03,
        overlap_margin = 0.85,
        predict_robot_path = False,
        robot_flow_weight = 1.0,
        robot_endpoint_weight = 0.15,
        condition_smoothness = False,
        use_reachable = False,
        predict_feasibility = False,
        feasibility_pos_weight = 0.45,
        predict_affordance = False,
        learned_loss_weight = False,
        order_head = 'gauss',      # 'score' / 'pointer': experiments/ordering_ablation
        mover_head = False,        # PriorityHead.mover_head: learned mover/non-mover split
        mover_weight = 0.3,
        kappa_links = False,       # PriorityHead.kappa_links: attend the body's link tokens, not one pooled kappa
        trav_head = False,         # PriorityHead.trav_head: per-scene-token 'can this body cross it' (Example.trav)
        trav_weight = 0.3,
        trav_balanced = False,     # class-balanced BCE: ~96 % of tiles are traversable, so the plain loss sits at the prior
        scene_cell_tokens = False, # PriorityHead scene tokens per CELL (8x8 = 64) instead of per 2x2 patch (16)
        ego_only_scene = False,    # PriorityHead sees no privileged terrain classes -- only start/goal + ego channels
        causal_mask = True,        # False: Stage B reads every movable object regardless of rank
        capability_encoder = 'set',   # 'set' = KappaSetEncoder(measured probe rows) -- the paper's
        # kappa. 'vector' = legacy CapabilityEncoder(feature_vector spec sheet), kept only so
        # pre-kappa checkpoints still load; new runs should not use it.
        probe_drop = 0.3,
        n_probes = None,   # None = data.probes.N_PROBES (10). 11 for a tipping run,
        # whose bodies carry the extra push_height row (data/probes.py PROBES_TIP).
        # Width of batch['grid']. The default is the 5-channel class grid; the
        # ego pipeline (data/ego_project.py) appends EGO_CHANS more and keeps
        # the class channels first, so a checkpoint trained at 5 can be grown
        # with scene_encoder.grow_scene_channels rather than retrained.
        scene_channels = SCENE_CHANS,
    ):
        super().__init__()
        assert rank_loss in ('logistic', 'hinge')
        assert order_objective in ('pairwise', 'plackett_luce')
        self.order_objective = order_objective
        assert capability_encoder in ('vector', 'set', 'morph')
        self.capability_encoder = capability_encoder
        self.scene_channels = scene_channels
        # each head keeps its OWN encoder instance, exactly as with the default vector path
        def _make_cap_encoder():
            if capability_encoder == 'vector':
                return None  # heads build their default CapabilityEncoder
            if capability_encoder == 'morph':
                from clear.model.morphology_encoder import MorphologyEncoder
                return MorphologyEncoder(dim)
            from clear.model.encoders import KappaSetEncoder
            from clear.data.probes import N_PROBES
            return KappaSetEncoder(dim, n_probes or N_PROBES, probe_drop)
        self.grid_hw = grid_hw
        self.drop_obj = tuple(drop_obj)
        self.obj_extra_dim = obj_extra_dim
        self.infer_movable = 'can_move' in self.drop_obj
        self.mover_head, self.mover_weight = bool(mover_head), float(mover_weight)
        self.kappa_links = bool(kappa_links)
        self.trav_head, self.trav_weight = bool(trav_head), float(trav_weight)
        self.trav_balanced = bool(trav_balanced)
        self.scene_cell_tokens = bool(scene_cell_tokens)
        self.ego_only_scene = bool(ego_only_scene)
        assert not self.kappa_links or capability_encoder == 'morph', 'kappa_links needs capability_encoder=morph'
        # Opt-in extra object-feature column: is this object's own cell
        # reachable from scene.start with every OTHER object still at its
        # initial cell (Example.reachable0 -- see data.py's own docstring on
        # that field). False (default) leaves object_features's column count
        # byte-identical to before this existed.
        self.use_reachable = use_reachable
        self.priority_head = PriorityHead(grid_hw, dim = dim, depth = depth, heads = heads,
                                          dim_head = dim_head, drop_obj = self.drop_obj,
                                          noise = noise,
                                          obj_extra_dim = obj_extra_dim,
                                          include_reachable = use_reachable,
                                          order_head = order_head,
                                          capability_encoder = _make_cap_encoder(),
                                          scene_channels = scene_channels,
                                          mover_head = self.mover_head, kappa_links = self.kappa_links,
                                          trav_head = self.trav_head,
                                          scene_stride = 1 if self.scene_cell_tokens else 2,
                                          ego_only_scene = self.ego_only_scene)
        # predict_robot_path=False (the default) leaves velocity_field
        # byte-identical to before -- see causal_velocity_field.py's own
        # opt-in contract. Track (1a)'s robot-approach-path loss
        # (robot_path_forward, below) is the only thing that reads the extra
        # heads this unlocks; forward()/sample() are completely unaffected.
        self.velocity_field = CausalVelocityField(grid_hw, dim = dim, depth = depth,
                                                 heads = heads, dim_head = dim_head,
                                                 drop_obj = self.drop_obj,
                                                 obj_extra_dim = obj_extra_dim,
                                                 predict_robot_path = predict_robot_path,
                                                 condition_smoothness = condition_smoothness,
                                                 include_reachable = use_reachable,
                                                 predict_feasibility = predict_feasibility,
                                                 predict_affordance = predict_affordance,
                                                 causal = causal_mask,
                                                 capability_encoder = _make_cap_encoder(),
                                                 scene_channels = scene_channels)
        self.feasibility_pos_weight = feasibility_pos_weight
        self.robot_flow_weight = robot_flow_weight
        self.robot_endpoint_weight = robot_endpoint_weight
        self.rank_loss = rank_loss
        self.rank_temp = rank_temp
        self.rank_margin = rank_margin
        self.sigma_weight = sigma_weight
        # ponytail: these class defaults are the discrete-safe values. 0.5/0.05
        # measurably helped continuous (trans_err 0.581->0.543) but regressed
        # discrete (scene_success 0.711->0.643) -- the extra heads compete with
        # flow_loss for the shared trunk, and discrete didn't need the help
        # (already near-exact on-lattice). Confirmed the two modes pull in
        # opposite directions on one constant: dropping further to 0.15/0.03
        # recovered discrete (0.675, close to original) but let continuous's
        # gain evaporate back to baseline (trans_err 0.572). train_clear.py's
        # --continuous flag now picks the mode-appropriate weight instead of
        # sharing one; these __init__ defaults only matter for direct/test use.
        self.endpoint_weight = endpoint_weight
        self.validity_weight = validity_weight
        self.overlap_margin = overlap_margin
        # learned_loss_weight=False (default) leaves forward() computing
        # endpoint_loss/validity_loss exactly as before -- that code path is
        # untouched, not just numerically equivalent. True adds a per-example
        # multiplier on top of endpoint_weight/validity_weight (see
        # capability_encoder.SensitivityHead's own docstring for why it starts
        # at exactly 1.0 and can't destabilize an already-tuned run).
        self.learned_loss_weight = learned_loss_weight
        if learned_loss_weight:
            from clear.model.encoders import SensitivityHead
            self.sensitivity_head = SensitivityHead()

    def _cap(self, batch):
        """The capability input each head's encoder expects: emb_feat for the
        vector path, (probe_set, probe_mask) for the set path (data/probes.py)."""
        if self.capability_encoder == 'set':
            return (batch['probe_set'], batch['probe_mask'])
        if self.capability_encoder == 'morph':
            assert 'morph_rows' in batch, \
                "capability_encoder='morph' needs morphology rows in the batch -- every body " \
                "must resolve through data.morphology (registered variant or BODY_XML)"
            return (batch['morph_rows'], batch['morph_mask'])
        return batch['emb_feat']

    # training

    def object_features(self, batch, poses, s, t, movable, time = None):
        """Per-object token inputs, in ONE place so a new column cannot reach
        three of the four call sites and miss the fourth.

        `obj_extra` is whatever a front end wants to attach per object -- for
        the metric maze that is the privileged object cloud, encoded to a short
        vector. E4PAMO built that encoder and then never called it, so the
        object clouds were collated, moved to the GPU and dropped on the floor:
        neither their shape nor, once material became the carrier of mass,
        their colour ever reached the model.
        """
        feat = object_features(poses, batch['mass'], batch['extent'], s,
                               t if time is None else time, movable,
                               self.grid_hw, drop = self.drop_obj,
                               reachable0 = batch['reachable0'] if self.use_reachable else None)
        extra = batch.get('obj_extra')
        if extra is None:
            return feat
        return torch.cat([feat, extra.to(feat.dtype)], dim = -1)

    def forward(self, batch, context = None):
        """-> (loss, breakdown). Teacher-forced on the batch's sampled order.

        `context` is an optional pre-built (capability token, scene tokens)
        pair shared by both heads -- see PriorityHead.forward. MazePAMO uses it
        to feed metric terrain through the same heads without a second copy of
        this function."""
        movable, rank = batch['movable'], batch['rank']

        # priority head: ranking on SAMPLED u (reparameterized, t = 0 view).
        # Bradley-Terry logistic is strictly convex in the gap with a unique
        # minimum at a tie, so conflicting multimodal supervision produces ties
        # + sampling noise instead of freezing inside a hinge's flat valley.

        feat0 = self.object_features(
            batch, batch['x0'], torch.zeros_like(batch['s']), 0., movable)
        if self.priority_head.order_head != 'gauss':
            # score / pointer ablation heads: their own supervised loss, no sampling
            rank_loss = self.priority_head.order_loss(batch['grid'], feat0, self._cap(batch),
                                                      movable, rank, context = context)
            sigma = rank_loss.new_full(movable.shape, self.priority_head.SIGMA_MIN)
        else:
            if self.mover_head:
                mu, sigma, mover_logit = self.priority_head(batch['grid'], feat0, self._cap(batch),
                                                            context = context, return_mover = True)
            else:
                mu, sigma = self.priority_head(batch['grid'], feat0, self._cap(batch),
                                               context = context)
            # was hardcoded torch.randn_like(sigma) -- always Gaussian regardless of
            # self.priority_head.noise, a real train/sample mismatch for a
            # noise='gumbel' head (see PriorityHead.sample_noise's own docstring).
            # No-op for noise='gaussian' (every checkpoint trained so far).
            u = mu + sigma * self.priority_head.sample_noise(sigma)

            gap = u[:, None, :] - u[:, :, None]  # (b, i, j) = u_j - u_i
            n = rank.shape[1]
            rank_f = rank.float()
            dist = rank_f[:, None, :] - rank_f[:, :, None]  # (b, i, j) > 0 when j is after i
            # Immovable objects carry sentinel rank n. Normally both ranks must be
            # real, which drops every movable-vs-immovable pair -- so nothing ever
            # teaches the head to put unmovable objects last, and masked_fill(inf)
            # does it instead. Inferring movability means that supervision has to
            # come from here.
            ordered = (dist > 0) & (rank[:, :, None] < n)
            if not self.infer_movable:
                ordered = ordered & (rank[:, None, :] < n)
            # Deep chains have far more long-range pairs (1-vs-5) than adjacent
            # ones (4-vs-5) -- a flat mean lets the easy long-range pairs drown
            # out the adjacent pairs that actually decide the sequencing, which
            # is exactly where order_acc was falling off on depth_2/3 scenes.
            # Weight by 1/rank-distance so the immediate-neighbor pairs dominate.
            pair_weight = 1.0 / dist.clamp(min = 1.0)

            if self.order_objective == 'plackett_luce':
                # A LIKELIHOOD, not a margin. The pairwise surrogate below is
                # softplus (convex) of a Gaussian gap, so its expectation is
                # nondecreasing in sigma at every mu -- it can only ever push
                # sigma down, whatever the labels say (docs/RESEARCH_ordering_
                # 2026-08-31.md SS2.3). Under Plackett-Luce with scores
                # -mu/sigma, sigma IS the temperature, and the MLE temperature
                # is set by the entropy of the labels: zero if the order is
                # deterministic given the scene, strictly positive if the same
                # scene carries several valid orders (which is what
                # --mode_labels supplies). Exactness caveat, already documented
                # at train_pamo_fpo.py:229-238: the PL factorisation is exact
                # for a scale SHARED across objects; per-object sigma makes
                # this an approximation.
                scores = -mu / sigma.clamp(min = self.priority_head.SIGMA_MIN)
                orders = _orders_from_rank(rank, movable, self.infer_movable)
                logp = plackett_luce_logp(scores, orders, movable)
                lens = torch.as_tensor([max(len(o), 1) for o in orders], dtype = logp.dtype,
                                       device = logp.device)
                rank_loss = -(logp / lens).mean()          # per-decision, so depth does not scale it
            elif self.rank_loss == 'logistic':
                pair_all = F.softplus(-gap / self.rank_temp)
                pair, w = pair_all[ordered], pair_weight[ordered]
                rank_loss = (pair * w).sum() / w.sum() if pair.numel() else u.sum() * 0.
            else:
                pair_all = F.relu(self.rank_margin - gap)
                pair, w = pair_all[ordered], pair_weight[ordered]
                rank_loss = (pair * w).sum() / w.sum() if pair.numel() else u.sum() * 0.
        sigma_loss = (sigma[movable] ** 2).mean() if movable.any() else sigma.sum() * 0.
        # mover head: BCE over EVERY object (movable or not) against "moved in the
        # sampled order" (rank < n). Unmasked on purpose -- inferring movability
        # means the immovable ones are the negatives that matter.
        if self.mover_head and self.priority_head.order_head == 'gauss':
            mover_target = (rank < rank.shape[1]).to(mover_logit.dtype)
            mover_loss = F.binary_cross_entropy_with_logits(mover_logit, mover_target)
        else:
            mover_loss = sigma_loss * 0.
        # traversability head: BCE per scene token vs Example.trav average-pooled to the token grid
        # (SceneEncoder = stride-2 conv: token (i, j) covers cells 2i..2i+1, 2j..2j+1).
        if self.trav_head and 'trav' in batch and self.priority_head.order_head == 'gauss':
            logit = self.priority_head.trav_logits()
            tr = batch['trav']
            tgt = (tr.flatten(1) if logit.shape[1] == tr.shape[1] * tr.shape[2]
                   else F.avg_pool2d(tr[:, None], 2, ceil_mode = True).flatten(1)).to(logit.dtype)
            if self.trav_balanced:
                # per-batch class balance: the (rare) non-traversable tiles get weight n_pos / n_neg, so
                # predicting 'traversable everywhere' stops being a cheap minimum (v8: BCE 0.29 at the prior)
                neg = (tgt < 0.5)
                n_neg, n_pos = neg.sum().clamp(min = 1).float(), (~neg).sum().clamp(min = 1).float()
                w = torch.where(neg, (n_pos / n_neg).clamp(max = 50.0), torch.ones_like(tgt))
                trav_loss = (F.binary_cross_entropy_with_logits(logit, tgt, reduction = 'none') * w).sum() / w.sum()
            else:
                trav_loss = F.binary_cross_entropy_with_logits(logit, tgt)
        else:
            trav_loss = sigma_loss * 0.

        # velocity field: vanilla CFM. Attention is observation-consistent (2026-08-26, user
        # decision, PLAN sect97): object i reads every other object at the state the robot would
        # observe while i is being moved -- earlier-ranked objects at their parked pose, the
        # active one mid-motion, later-ranked and non-mover objects at their CURRENT pose x0.
        # The slot schedule guarantees later objects are at x0, so no future placement can
        # leak; the invariant is asserted here so a schedule change cannot silently reopen it.
        _assert_observation_consistent(batch, rank, movable)
        feat = self.object_features(batch, batch['pose'], batch['s'], batch['t'],
                                    movable)
        robot_flow_loss = velocity_placeholder = None
        if self.velocity_field.predict_robot_path and 'robot_v_target' in batch:
            velocity, delta, robot_vel, robot_end = self.velocity_field.forward_with_robot_path(
                batch['grid'], feat, self._cap(batch), rank, movable, context = context,
                smoothness_cond = batch.get('smoothness'))
            # PER-OBJECT robot label: each mover token carries its OWN approach
            # leg (phase k -> order[k]'s token), so the whole embodiment path is
            # learned across the sequence, not just phase 0. Loss over the masked
            # movers only (robot_mask marks which tokens have a real leg).
            rmask = batch['robot_mask']                                   # (b, n)
            if rmask.any():
                robot_flow_loss = F.mse_loss(robot_vel[rmask], batch['robot_v_target'][rmask])
                robot_endpoint_loss_r = F.mse_loss(
                    robot_end[rmask],
                    (batch['robot_endpoint_target'] - batch['robot_start_pose'])[rmask])
            else:
                robot_flow_loss = robot_vel.sum() * 0.
                robot_endpoint_loss_r = robot_end.sum() * 0.
        else:
            velocity, delta = self.velocity_field(batch['grid'], feat, self._cap(batch), rank,
                                                  movable, context = context,
                                                  smoothness_cond = batch.get('smoothness'))
        flow_loss = F.mse_loss(velocity[movable], batch['v_target'][movable])

        # Endpoint + validity: flow_loss only ever supervises the NEXT
        # instant's velocity, so a network that is locally right can still
        # drift into an invalid resulting world by t=1 (the trans_err
        # plateau this was added for). `delta` is a second, independent
        # prediction of x1 - pose from the same trunk, always well-defined
        # (unlike v_target, it doesn't depend on path segmentation) --
        # supervised directly against the known-valid oracle target, and
        # also used to penalize landing on a wall/off-grid/another object's
        # cell. Not used at inference (sample() still integrates velocity
        # only) -- this only shapes what the trunk represents.
        target_delta = path_velocity(batch['pose'].clone(), batch['x1'])

        pred_end_xy = batch['pose'][..., :2] + delta[..., :2]
        h, w = self.grid_hw
        scale = pred_end_xy.new_tensor([w - 1, h - 1])
        pred_xy_norm = pred_end_xy / scale * 2 - 1
        target_xy_norm = batch['x1'][..., :2] / scale * 2 - 1
        wall_channel = batch['grid'][:, 2:3]  # WALL is channel index 2 (flat/step/wall/start/goal)
        invalid = wall_oob_penalty(pred_xy_norm, wall_channel) \
            + overlap_penalty(pred_xy_norm, target_xy_norm, margin = self.overlap_margin)

        if not self.learned_loss_weight:
            # untouched: byte-identical to every checkpoint trained before
            # this flag existed, not just numerically equivalent to the
            # alpha-weighted path below.
            endpoint_loss = F.mse_loss(delta[movable], target_delta[movable]) if movable.any() else delta.sum() * 0.
            validity_loss = invalid[movable].mean() if movable.any() else invalid.sum() * 0.
        else:
            # mean(-1), not sum(-1): dividing by n_movable_objects (not
            # n_movable_objects * 3) is what makes alpha==1-everywhere
            # reproduce F.mse_loss's own flatten-mean exactly.
            delta_err = ((delta - target_delta) ** 2).mean(-1)  # (b, n)
            # SensitivityHead reads the CURRENT error, detached -- see its own
            # docstring on why a learned function here (of emb_feat or anything
            # else) inherits a backwards incentive that this avoids by having
            # no free parameters to learn one with.
            alpha = self.sensitivity_head(delta_err.detach(), movable)  # (b, n)
            mv = movable.to(alpha.dtype)
            w = mv * alpha  # (b, n)
            wsum = w.sum().clamp(min = 1e-8)
            endpoint_loss = (delta_err * w).sum() / wsum if movable.any() else delta_err.sum() * 0.
            validity_loss = (invalid * w).sum() / wsum if movable.any() else invalid.sum() * 0.

        loss = (flow_loss + rank_loss + self.sigma_weight * sigma_loss
                + self.endpoint_weight * endpoint_loss + self.validity_weight * validity_loss
                + self.mover_weight * mover_loss + self.trav_weight * trav_loss)
        if robot_flow_loss is not None:
            loss = loss + self.robot_flow_weight * robot_flow_loss \
                        + self.robot_endpoint_weight * robot_endpoint_loss_r
        breakdown = dict(
            flow = flow_loss.item(),
            rank = rank_loss.item(),
            mover = mover_loss.item(),
            trav = trav_loss.item(),
            sigma = sigma[movable].mean().item() if movable.any() else 0.,
            endpoint = endpoint_loss.item(),
            valid = validity_loss.item(),
        )
        if robot_flow_loss is not None:
            breakdown['robot_flow'] = robot_flow_loss.item()
            breakdown['robot_endpoint'] = robot_endpoint_loss_r.item()
        if self.learned_loss_weight:
            breakdown['sensitivity'] = alpha[movable].mean().item() if movable.any() else 1.0
        return loss, breakdown

    def feasibility_forward(self, batch, context = None, condition_on = 'x0', n_steps = 30):
        """-> (loss, breakdown). Supervised auxiliary loss for the
        feasibility head (2026-08-23, PLAN doc S54-62 / experiments/
        stageb_clearance_signal/RESULTS.md sect9-10 -- see
        CausalVelocityField.forward_with_feasibility's own docstring for the
        full rationale: this replaces the RL-reward delivery mechanism that
        was found to make placement accuracy WORSE, with ordinary supervised
        backprop of the same signal).

        Needs `batch['feasibility_label']` (b, n) float in {0, 1} and
        `batch['feasibility_mask']` (b, n) bool (True where a real physical
        phase-level outcome exists for that object -- most objects in most
        batches have none, this is a SMALL real-corpus-only batch, not the
        large synthetic BC corpus forward() trains on). See
        clear/data/real_corpus.py's build_feasibility_batches for how these
        are built from runs/*/physical_eval.json.

        Uses the SAME object/grid setup as forward() (unlike
        robot_path_forward's stripped-down single-object batch) since
        feasibility scoring needs full scene context -- same
        object_features/movable/rank, just a different head+loss off the
        same trunk.

        `condition_on` (2026-08-24, RESULTS.md sect17-18's open question --
        sect16-18's mechanism ALWAYS anchored the residual on `batch['pose']`
        (== batch['x0'] for every real-corpus batch, since
        real_corpus.build_feasibility_batches collates at t=0.0): a fresh
        t=0 single-shot estimate that `sample(refine=True)` (sect16) then
        used to REPLACE (per refine_weight) the separately-integrated,
        already-validated ODE trajectory -- a bigger, less CE-Adapter-like
        bet than intended, and sect18's N=1000 sweep found no refine_weight
        on that mechanism clears significance.
          'x0' (default): byte-identical to sect16-18, unchanged.
          'ode': anchor on THIS model's own current ODE rollout (`sample()`,
        no_grad, under the SAME order `batch['rank']` already commits to --
        see `_order_from_rank`) instead of x0. `target_delta` is still
        `oracle_x1 - anchor` (whatever anchor is) weighted by the SAME real
        success/fail label -- correct regardless of anchor's identity, since
        the label only ever says whether pushing THIS object to the ORACLE
        x1 succeeded, never anything about anchor itself. The resulting
        correction is a true CE-Adapter-style small delta on top of an
        already-good trace, and matches `sample(refine_on='ode')` exactly
        (same anchor, same s=1/t=1 convention) -- no train/inference skew.
        The rollout is its own no_grad forward pass (this model's `sample` is
        itself `@torch.no_grad()`); only the SEPARATE fresh forward_with_
        feasibility call below is part of the training graph.
        """
        assert self.velocity_field.predict_feasibility, \
            'PAMO(predict_feasibility=True) required for feasibility_forward'
        assert condition_on in ('x0', 'ode'), f"condition_on must be 'x0' or 'ode', got {condition_on!r}"
        movable, rank = batch['movable'], batch['rank']
        if condition_on == 'x0':
            anchor, s_anchor, t_anchor = batch['pose'], batch['s'], batch['t']
        else:
            orders = _order_from_rank(rank, movable)
            ode_out = self.sample(batch, n_steps = n_steps, orders = orders, context = context,
                                  smoothness_cond = batch.get('smoothness'))
            anchor = ode_out['x']
            s_anchor = torch.ones_like(batch['s'])
            t_anchor = 1.

        feat = self.object_features(batch, anchor, s_anchor, t_anchor, movable)
        _velocity, _delta, feas_logit, refined_delta = self.velocity_field.forward_with_feasibility(
            batch['grid'], feat, self._cap(batch), rank, movable, anchor, self.grid_hw,
            context = context, smoothness_cond = batch.get('smoothness'))

        mask = batch['feasibility_mask']
        label = batch['feasibility_label']
        if mask.any():
            pw = feas_logit.new_tensor(self.feasibility_pos_weight)
            bce_loss = F.binary_cross_entropy_with_logits(feas_logit[mask], label[mask], pos_weight = pw)
        else:
            bce_loss = feas_logit.sum() * 0.
        with torch.no_grad():
            acc = ((torch.sigmoid(feas_logit[mask]) > 0.5) == (label[mask] > 0.5)).float().mean().item() \
                if mask.any() else 0.

        # Residual-refinement loss (2026-08-23, PLAN doc S54-62 sect16):
        # plain weighted regression toward the KNOWN-correct oracle target,
        # NOT the refined placement scored against its own feasibility_logit
        # -- a self-referential "train the residual to fool its own
        # sibling head" objective was considered and rejected: it would
        # reintroduce exactly the overoptimization risk sect7-9 already
        # spent an entire investigation characterizing and avoiding (a
        # differentiable critic is still a critic; gradient ascent against
        # an imperfect one is lower-variance than policy gradient but not
        # risk-free). This is instead ordinary supervised regression
        # against `batch['x1']` (the oracle target every OTHER loss in this
        # file already trusts), just reweighted toward the movers that
        # REALLY FAILED physically -- exactly the cases needing the most
        # correction, and information the plain endpoint_loss on the large
        # synthetic corpus never has access to (that loss has no real
        # outcome labels at all).
        target_delta = path_velocity(anchor.clone(), batch['x1'])
        residual_err = F.mse_loss(refined_delta[mask], target_delta[mask], reduction = 'none').mean(-1) \
            if mask.any() else refined_delta.new_zeros(0)
        fail_boost = 2.0
        weight = 1.0 + fail_boost * (1.0 - label[mask]) if mask.any() else None
        # FIX (found on a second read-through before trusting a real run,
        # after the first real run already used the buggy version below --
        # see RESULTS.md sect17 for whether that run's numbers still hold):
        # weight.sum()-normalized (a proper weighted MEAN) replaces a WRONG
        # fixed divisor `/(1+fail_boost)` -- that constant is weight's
        # value ONLY in the impossible all-failure case (label_rate=0); the
        # real corpus's ~0.72 success rate gives an actual mean weight of
        # ~1.56, not 3.0, so the old version silently trained the residual
        # at roughly HALF the intended gradient scale relative to the BCE
        # term next to it. Direction was still correct (failures still
        # upweighted relative to successes) -- a magnitude bug, not a sign
        # bug, but exactly the kind of "wrong scale, not wrong sign" issue
        # that's easy to miss without deriving the normalizer instead of
        # guessing it.
        residual_loss = (residual_err * weight).sum() / weight.sum() if mask.any() \
            else refined_delta.sum() * 0.

        loss = bce_loss + residual_loss
        breakdown = dict(feasibility = bce_loss.item(), feasibility_acc = acc,
                         residual = residual_loss.item(), n_labeled = int(mask.sum().item()))
        return loss, breakdown

    def affordance_forward(self, batch, pos_weight = 20.0, context = None):
        """-> (loss, breakdown). Dense affordance-map auxiliary loss
        (2026-08-24, experiments/stageb_clearance_signal/RESULTS.md sect23
        -- Phase 2 of the embodiment-conditioned affordance work; Phase 1's
        standalone net already validated the signal at held-out AUC 0.988,
        train_affordance.py).

        Needs `batch['affordance_label']` (b, n, h, w) float in {0, 1} --
        clear/data/affordance.py's build_affordance_pamo_batches supplies it,
        along with batches whose `rank` is ALL-SENTINEL (no committed order:
        the labels are first-move maps, order-free by construction, and the
        sentinel rank makes the causal mask block all mover-to-mover reads,
        matching that semantics) and whose emb_feat spans all three
        embodiments (including scenes UNSOLVABLE for a given body -- the
        all-zero map is the mass/terrain-gate signal itself, which ordinary
        BC batches can never carry because _make drops unsolvable scenes).

        `pos_weight`: labels are ~4-8%% positive (v25_label_stats.png);
        default 20 keeps the positive class from being drowned, same
        BCEWithLogits pos_weight convention as train_affordance.py."""
        assert self.velocity_field.predict_affordance, \
            'PAMO(predict_affordance=True) required for affordance_forward'
        movable, rank = batch['movable'], batch['rank']
        feat = self.object_features(batch, batch['pose'], batch['s'], batch['t'], movable)
        _v, _e, logits = self.velocity_field.forward_with_affordance(
            batch['grid'], feat, self._cap(batch), rank, movable, self.grid_hw,
            context = context, smoothness_cond = batch.get('smoothness'))
        labels = batch['affordance_label']
        pw = logits.new_tensor(pos_weight)
        loss = F.binary_cross_entropy_with_logits(logits, labels, pos_weight = pw)
        with torch.no_grad():
            pred = torch.sigmoid(logits) > 0.5
            tp = (pred & (labels > 0.5)).sum().item()
            recall = tp / max(1, int((labels > 0.5).sum().item()))
            precision = tp / max(1, int(pred.sum().item()))
        breakdown = dict(affordance = loss.item(), afford_recall = recall,
                         afford_precision = precision)
        return loss, breakdown

    def robot_path_forward(self, batch, context = None):
        """-> (loss, breakdown). Track (1a)'s robot-approach-path loss, from
        clear/data/waypoint_data.py's `waypoint_collate` batches.

        A SEPARATE method from forward(), not a branch inside it: this data
        is a single static reach-target object (no ordering, no multi-object
        placement, no class grid), so forward()'s rank_loss/flow_loss/
        validity_loss (which need batch['grid']'s wall channel, x0/x1/
        v_target for a MOVING object, etc.) don't apply -- extending
        forward() itself would mean fabricating several meaningless fields
        per batch just to keep unrelated loss terms from crashing, not
        reusing the pattern. `context` (required in practice -- EgocentricPAMO
        always supplies one) is the only thing forward() and this share:
        both read the SAME CausalVelocityField trunk, this just asks for its
        robot-path heads instead of its object-motion heads.

        The single object token built here is the REACH TARGET itself
        (pose/mass/extent), not the robot -- the robot's pose/velocity are
        the LABELS (batch['robot_v_target']/'robot_endpoint_target'), never
        model input. See CausalVelocityField's own docstring for why the
        object token already carries what the robot-path heads need."""
        assert self.velocity_field.predict_robot_path, \
            'PAMO(predict_robot_path=True) required for robot_path_forward'
        pose = batch['target_pose'][:, None, :]
        mass = batch['target_mass'][:, None]
        extent = batch['target_extent'][:, None]
        b = pose.shape[0]
        movable = torch.ones(b, 1, dtype = torch.bool, device = pose.device)
        rank = torch.zeros(b, 1, dtype = torch.long, device = pose.device)
        s = torch.zeros(b, 1, device = pose.device)

        feat = object_features(pose, mass, extent, s, batch['t'], movable, self.grid_hw,
                               drop = self.drop_obj)
        dummy_grid = pose.new_zeros(b, 1, 1, 1)
        _, _, robot_velocity, robot_endpoint = self.velocity_field.forward_with_robot_path(
            dummy_grid, feat, batch['physical'], rank, movable, context = context)

        robot_flow_loss = F.mse_loss(robot_velocity[:, 0], batch['robot_v_target'])
        robot_endpoint_loss = F.mse_loss(robot_endpoint[:, 0], batch['robot_endpoint_target'])
        loss = (self.robot_flow_weight * robot_flow_loss
               + self.robot_endpoint_weight * robot_endpoint_loss)
        breakdown = dict(robot_flow = robot_flow_loss.item(), robot_endpoint = robot_endpoint_loss.item())
        return loss, breakdown

    # sampling

    @torch.no_grad()
    def sample_robot_path(self, batch, context = None, n_steps = 30, smoothness = 0.0):
        """Integrate predict_robot_path's to_robot_velocity from t=0 to t=1,
        starting at the robot's own real batch['start_pose'] -- same
        ODE-integration shape as sample() below, applied to the robot-path
        heads instead of object motion.

        Unlike sample()'s `x` (which IS the thing being integrated, one pose
        per object), the single object token here (the reach target) stays
        FIXED throughout -- only `t` advances. What's integrated is a
        SEPARATE robot-pose state variable, using the predicted velocity at
        each t. -> (b, n_steps + 1, 3) pose trace, trace[:, 0] == start_pose.

        `smoothness` in [0, 1): opt-in EMA low-pass on the INTEGRATED
        velocity itself (v_ema = smoothness*v_ema_prev + (1-smoothness)*v_raw),
        not a post-hoc smoothing of the resulting trace -- this is generation
        -time steering (the executed route reads straight off `robot_velocity`
        each step; damping ITS jitter changes what gets walked, not just how
        a fixed trace looks after the fact). 0.0 (default) is exactly the
        previous behavior, byte-for-byte -- v_ema reduces to v_raw when the
        weight on the previous term is zero. Blending raw velocity components
        (not pose) needs no angle-unwrap care: velocity is a rate, not a
        wrapped angle -- only the INTEGRATED pose's theta wraps, already
        handled below regardless of `smoothness`.
        """
        assert self.velocity_field.predict_robot_path, \
            'PAMO(predict_robot_path=True) required for sample_robot_path'
        assert 0.0 <= smoothness < 1.0, f'smoothness must be in [0, 1), got {smoothness}'
        pose = batch['target_pose'][:, None, :]
        mass = batch['target_mass'][:, None]
        extent = batch['target_extent'][:, None]
        b = pose.shape[0]
        movable = torch.ones(b, 1, dtype = torch.bool, device = pose.device)
        rank = torch.zeros(b, 1, dtype = torch.long, device = pose.device)
        s = torch.zeros(b, 1, device = pose.device)
        dummy_grid = pose.new_zeros(b, 1, 1, 1)

        robot_pose = batch['start_pose'].clone()
        dt = 1.0 / n_steps
        trace = [robot_pose.clone()]
        v_ema = None
        for step in range(n_steps):
            t = pose.new_full((b,), step * dt)
            feat = object_features(pose, mass, extent, s, t, movable, self.grid_hw, drop = self.drop_obj)
            _, _, robot_velocity, _ = self.velocity_field.forward_with_robot_path(
                dummy_grid, feat, batch['physical'], rank, movable, context = context)
            v_raw = robot_velocity[:, 0]
            if smoothness > 0.0:
                v_ema = v_raw if v_ema is None else smoothness * v_ema + (1 - smoothness) * v_raw
                v_use = v_ema
            else:
                v_use = v_raw
            robot_pose = robot_pose + dt * v_use
            robot_pose = torch.cat([robot_pose[..., :2], wrap_angle(robot_pose[..., 2:3])], dim = -1)
            trace.append(robot_pose.clone())
        return torch.stack(trace, dim = 1)

    @torch.no_grad()
    def sample_orders(self, batch, k = 1, generator = None, examples = None, max_tries = 8,
                      context = None, movable_from_head = False):
        """k sampled orderings per example, earliest tau first, movable only.

        movable_from_head=True (needs mover_head): the mover SET is the head's own
        P > 0.5 instead of batch['movable'] (the capability table), and the order
        ranks only that set -- an infer_movable model otherwise sorts every object
        and leaves "how many" to the flow's zero-velocity targets.

        With `examples`, non-executable orders are rejected and redrawn (plain
        BFS on what the model already observes -- no oracle at inference).
        Rejection fixes executability, not optimality.
        """
        if movable_from_head:
            batch = {**batch, 'movable': self.mover_prob(batch, context = context) > 0.5}
        movable = batch['movable']
        feat0 = self.object_features(
            batch, batch['x0'], torch.zeros_like(batch['s']), 0., movable)

        checkers = None
        if exists(examples):
            from clear.data.capability import EMBODIMENTS
            from clear.data.data import example_scene
            from clear.data.oracle import order_executable
            scenes = [example_scene(ex) for ex in examples]
            from clear.data.data import embodiment_of
            embs = [embodiment_of(ex) for ex in examples]
            checkers = [lambda o, s = s, e = e: order_executable(s, e, o) for s, e in zip(scenes, embs)]

        def draw():
            u, _, _ = self.priority_head.sample_u(batch['grid'], feat0, self._cap(batch),
                                                  movable, generator, context = context)
            return orders_from_u(u, movable, self.infer_movable and not movable_from_head)

        samples = []
        for _ in range(k):
            orders = draw()
            if exists(checkers):
                pending = {i for i, o in enumerate(orders) if not checkers[i](o)}
                for _ in range(max_tries - 1):
                    if not pending:
                        break
                    redraw = draw()  # ponytail: redraws the full batch, keeps only the rejects
                    for i in list(pending):
                        if checkers[i](redraw[i]):
                            orders[i] = redraw[i]
                            pending.discard(i)
            samples.append(orders)
        return samples

    # The decided inference recipe, measured term by term over three seeds in
    # docs/EXPERIMENT_inference_recipe_2026-09-01.md. Stage A contributes the
    # committed order (and, with --mode_labels, an order distribution that ties
    # when the task ties); Stage B contributes the placement, which is where the
    # off-family failure actually lives.
    PLAN_DEFAULTS = dict(k = 4, jitter = 0.3, search = 'ranked')

    @torch.no_grad()
    def plan(self, batch, examples, generator = None, temperature = None, n_steps = 30,
             context = None, smoothness_cond = None, **overrides):
        """Stage A + Stage B as decided: draw, project the placement onto cells
        the body can actually occupy, check the plan on the planner's own map,
        and redraw (with placement noise, so a redraw differs) until it passes.

        Single-number success against the same planner run raw, strict rule:

            rooms_fork  0.832 -> 0.949      rooms 0.734 -> 0.867
            mix         0.059 -> 0.590      at one rollout, before any retry

        Placement is snapped through `oracle.find_parking` (see
        `clear/util/placement.snap`): the model proposes a cell, the oracle's own
        parking predicate accepts the nearest one that keeps the rest of the plan
        executable. That single step replaced a projection + repair + sequential
        -reachability stack, and beats it: strict single-rollout success on mix
        0.059 -> 0.590, rooms 0.734 -> 0.867, rooms_fork 0.832 -> 0.949.

        `search='ranked'` walks the head's own ranking of candidate orders,
        pre-filtered by `order_executable` (BFS, no rollout), instead of
        redrawing from a distribution that off-family is a near point mass. It
        subsumes the shift-aware temperature: with it on, `temperature` changes
        nothing (0.906 either way), so the detector in `clear/util/shift.py`
        stays a diagnostic rather than part of this path. Pass overrides
        (k, jitter, project, search) to ablate.
        """
        cfg = dict(self.PLAN_DEFAULTS, **overrides)
        return self.sample_verified(batch, examples, generator = generator, n_steps = n_steps,
                                    temperature = temperature, context = context,
                                    smoothness_cond = smoothness_cond, **cfg)

    MAX_ENUM_ORDERS = 5000

    @torch.no_grad()
    def candidate_orders(self, batch, examples, m = 8, context = None):
        """Candidate orders for each example, ranked by the head's own belief and
        pre-filtered by a check that costs no rollout.

        Blind resampling (what `sample_verified` does by default) is a poor use
        of a retry budget when the order distribution is sharp: measured
        off-family after the placement fix, 15.6% of remaining failures pick the
        wrong object SET and 10.0% the wrong order, and redrawing from a peaked
        head returns the same set again. This instead enumerates permutations of
        the movable objects at the head's own predicted depth, scores each under
        Plackett-Luce with the head's mu, drops the ones `order_executable`
        already rejects (pure BFS on the observed grid -- no oracle, no
        rollout), and returns what is left, best first.

        -> list (per example) of order tuples, possibly empty.
        """
        from itertools import permutations

        from clear.data.data import embodiment_of, example_scene
        from clear.data.oracle import order_executable
        from clear.util import plackett_luce_logp

        movable = batch['movable']
        feat0 = self.object_features(batch, batch['x0'], torch.zeros_like(batch['s']), 0., movable)
        mu, sigma = self.priority_head(batch['grid'], feat0, self._cap(batch), context = context)
        scores = -mu / sigma.clamp(min = self.priority_head.SIGMA_MIN)
        base = self.sample_orders(batch, k = 1, context = context)[0]

        out = []
        for i, ex in enumerate(examples):
            idx = [j for j in range(movable.shape[1]) if bool(movable[i, j])]
            depth = min(max(len(base[i]), ex.n_moved if ex.n_moved else 1), len(idx))
            # Full enumeration is n!/(n-d)! -- fine at this repo's n=4 (24), silently
            # explosive past ~6 movable objects. Above the cap, take the top
            # candidates of the SAME PL ranking via beam search over the scores
            # instead: exact for the head (PL factorises stepwise), so the kept
            # prefix set equals full enumeration's top slice at equal width.
            n_perm = 1
            for q in range(depth):
                n_perm *= len(idx) - q
            beamed = bool(idx) and n_perm > self.MAX_ENUM_ORDERS
            if beamed:
                # NOTE the measure difference, deliberate: plackett_luce_logp on a
                # TRUNCATED tuple normalises each step over the tuple's own suffix,
                # which rewards padding the tail with the lowest-score objects. At
                # this repo's regime (depth == |movable|) the two coincide; the
                # beam uses the proper top-d marginal (denominator = everything
                # not yet placed), which is the defensible one at depth < n.
                cands = _beam_orders(scores[i].detach().cpu().numpy(), idx, depth,
                                     width = max(4 * m, 32))
            else:
                cands = list(permutations(idx, depth)) if idx else []
            if not cands:
                out.append([])
                continue
            if beamed:
                ranked = cands                      # _beam_orders already returns best-first
            else:
                logp = plackett_luce_logp(scores[i:i + 1].expand(len(cands), -1).contiguous(),
                                          cands, movable[i:i + 1].expand(len(cands), -1))
                ranked = [c for _, c in sorted(zip(logp.tolist(), cands), key = lambda t: -t[0])]
            scene, emb = example_scene(ex), embodiment_of(ex)
            keep = [c for c in ranked if order_executable(scene, emb, list(c))][:m]
            out.append(keep or ranked[:m])
        return out

    @torch.no_grad()
    def sample_verified(self, batch, examples, k = 8, n_steps = 30, generator = None,
                        jitter = 0.0, temperature = None, context = None, smoothness_cond = None,
                        snap_placement = True, search = 'resample', strict_push = False):
        """Draw up to `k` plans and return the first one that passes its OWN
        feasibility check; if none does, return the last.

        This is what makes a retry budget deployable rather than an upper bound.
        `oracle.plan_success` needs the scene, the order and the final poses --
        no oracle search, no labels -- so the planner can execute its own plan
        on its own map, see that the goal did not open, and draw again. That is
        exactly the check `eval.success_rate` scores with, which is why
        best-of-k measured there is achievable here and not just a ceiling.

        `temperature`: scalar or (b,) divisor on mu before the argsort, for a
        shift-aware softening (clear/util/shift.py). `jitter`: placement noise,
        see sample(). Both default to off, which makes this a k = 1 rollout with
        one extra feasibility check.

        -> the same dict sample() returns, plus `tries` (b,) and `verified` (b,).
        """
        from clear.data.capability import EMBODIMENTS
        from clear.data.data import embodiment_of, example_scene
        from clear.data.oracle import plan_success

        scenes = [example_scene(ex) for ex in examples]
        embs = [embodiment_of(ex) for ex in examples]
        best = None
        tries = torch.ones(len(examples), dtype = torch.long)
        done = torch.zeros(len(examples), dtype = torch.bool)

        cand = self.candidate_orders(batch, examples, m = k, context = context) \
            if search == 'ranked' else None

        old_forward = None
        if temperature is not None:
            old_forward = self.priority_head.forward
            def _fwd(*a, _o = old_forward, **kw):
                mu, sigma = _o(*a, **kw)
                t = temperature if torch.is_tensor(temperature) else torch.full(
                    (mu.shape[0],), float(temperature), device = mu.device)
                return mu / t[:, None].to(mu.dtype), sigma
            self.priority_head.forward = _fwd
        try:
            for draw in range(k):
                orders_arg = None
                if cand is not None:
                    # ranked enumeration: hand sample() the draw-th candidate per
                    # example (falling back to its last one once exhausted), so the
                    # budget walks DOWN the head's own ranking instead of redrawing
                    # from a distribution that may be a point mass
                    orders_arg = [c[min(draw, len(c) - 1)] if c else tuple() for c in cand]
                plan = self.sample(batch, n_steps = n_steps, generator = generator,
                                   context = context, smoothness_cond = smoothness_cond,
                                   jitter = jitter, orders = orders_arg)
                x = plan['x'].detach().cpu().numpy()
                if best is None:
                    best = dict(x = plan['x'].clone(), orders = list(plan['orders']),
                                s = plan['s'].clone())
                for i, ex in enumerate(examples):
                    if done[i]:
                        continue
                    order = plan['orders'][i]
                    final = {j: (int(round(float(x[i, j, 1]))), int(round(float(x[i, j, 0]))))
                             for j in order}
                    projection_failed = False
                    if snap_placement:
                        from clear.util import NoFeasiblePlacement, snap
                        try:
                            final = snap(scenes[i], embs[i], list(order), final)
                        except NoFeasiblePlacement:
                            projection_failed = True
                        else:
                            # Return the coordinates actually checked below.
                            for j, (r, c) in final.items():
                                plan['x'][i, j, 0] = c
                                plan['x'][i, j, 1] = r
                    from clear.data.oracle import execute_plan as _exec
                    ok = not projection_failed and _exec(scenes[i], embs[i], list(order), final,
                                                         strict_push = strict_push)[1]
                    if ok or draw == k - 1:
                        best['x'][i] = plan['x'][i]
                        best['orders'][i] = order
                        best['s'][i] = plan['s'][i]
                        tries[i] = draw + 1
                        done[i] = bool(ok)
                if bool(done.all()):
                    break
        finally:
            if old_forward is not None:
                self.priority_head.forward = old_forward
        best['tries'] = tries
        best['verified'] = done
        return best

    @torch.no_grad()
    def mover_prob(self, batch, context = None):
        """(b, n) P(this body moves object j in this scene) from the mover head,
        at the t = 0 view sample() uses. Requires mover_head=True."""
        assert self.mover_head, 'mover_prob needs a mover_head=True checkpoint'
        feat0 = self.object_features(batch, batch['x0'], torch.zeros_like(batch['s']), 0., batch['movable'])
        _mu, _sigma, logit = self.priority_head(batch['grid'], feat0, self._cap(batch),
                                                context = context, return_mover = True)
        return torch.sigmoid(logit)

    def sample(self, batch, n_steps = 30, generator = None, examples = None, context = None,
              smoothness_cond = None, orders = None, refine = False, refine_weight = 1.0,
              refine_on = 'x0', jitter = 0.0, movable_from_head = False):
        """Sample tau once at t = 0, fix the order, integrate the flow under
        the slot schedule. -> dict(x, orders, s).

        `movable_from_head` (needs mover_head): replace batch['movable'] -- the
        capability table, which otherwise still reaches Stage B through
        causal_mask and the order depth -- with the mover head's own P > 0.5,
        for both the order draw and the flow. The table-free inference path.

        `smoothness_cond`: (b,) in [0, 1], the LEARNED steerable knob -- only
        meaningful (and required) if this model was constructed with
        condition_smoothness=True; ignored otherwise. Constant for the whole
        rollout (steers the trajectory's overall smoothness, not a per-step
        choice). Unrelated to sample_robot_path's own `smoothness` EMA
        parameter, which post-filters a DIFFERENT (Track 1a robot-path) head
        and exists regardless of how this model was trained.

        `orders`: pass a precomputed order (one tuple per example, as
        sample_orders/k=1 returns) to skip the internal draw -- lets a
        caller commit to a SPECIFIC (u, order) pair drawn elsewhere (e.g.
        train_pamo_fpo's rollout, which needs this same order consistent
        with the u it separately scores under a Gaussian log-prob) instead
        of this method silently redrawing its own.

        `refine` (2026-08-23, PLAN doc S54-62 sect16, default False = byte-
        identical old behavior): opt-in post-hoc correction from
        `forward_with_feasibility`'s `refined_delta` head (requires
        PAMO(predict_feasibility=True)). Without this, NOTHING the
        feasibility/residual heads learn can ever reach a sampled
        trajectory -- confirmed directly: the ODE loop above integrates
        `velocity` only and always discarded `endpoint_delta` (the `_` a
        few lines up), so sect10's feasibility-only fine-tune's only
        channel to real behavior was ever the shared trunk, indirectly.
        When True, ONE extra forward pass at t=0 (matching EXACTLY how
        `PAMO.feasibility_forward` computes `refined_delta` during
        training -- same `pose=batch['x0']`, same s=0/t=0 -- no
        train/inference skew) produces a bounded xy correction, blended
        into the ODE result for movable objects only:
        `x_xy = (1-refine_weight)*x_ode + refine_weight*(x0+refined_delta)`.
        `refine_weight=1.0` (full replacement by the head's own single-shot
        endpoint estimate) is the default once opted in; lower values blend
        toward the ODE trajectory instead of replacing it outright.

        `refine_on` (2026-08-24, RESULTS.md sect18): 'x0' (default) is the
        above, byte-identical to sect16-18 -- anchored on the pre-push pose,
        s=0/t=0. 'ode' instead anchors the SAME correction mechanism on
        THIS rollout's own just-computed `x` (s=1/t=1, matching
        PAMO.feasibility_forward(condition_on='ode')'s training anchor
        exactly), so `head_estimate_xy = x + refined_delta` is a genuine
        small delta on top of the already-integrated trajectory --
        `refine_weight` then just controls how much of that delta to keep
        (`x + refine_weight * residual`, since `(1-blend)*x + blend*(x+d)
        == x + blend*d` algebraically) rather than blending toward an
        unrelated, independently-computed t=0 estimate.
        """
        if orders is None:
            orders = self.sample_orders(batch, k = 1, generator = generator, examples = examples,
                                        context = context, movable_from_head = movable_from_head)[0]
        if movable_from_head:   # the flow's mask + zero-velocity set follow the head, not the table
            batch = {**batch, 'movable': self.mover_prob(batch, context = context) > 0.5}
        movable = batch['movable']
        n = movable.shape[1]

        rank = torch.full_like(batch['rank'], n)
        for i, order in enumerate(orders):
            for pos, j in enumerate(order):
                rank[i, j] = pos

        x = batch['x0'].clone()
        dt = 1. / n_steps
        progress = np.zeros((len(orders), n), dtype = np.float32)

        for step in range(n_steps):
            t = step * dt
            progress_next = np.stack([oracle_progress(o, n, t + dt)[0] for o in orders])
            ds = torch.as_tensor(progress_next - progress, device = x.device)
            s = torch.as_tensor(progress, device = x.device)

            feat = self.object_features(batch, x, s, t, movable, time = t)
            velocity, _ = self.velocity_field(batch['grid'], feat, self._cap(batch), rank,
                                              movable, context = context,
                                              smoothness_cond = smoothness_cond)

            x = x + ds[..., None] * velocity
            if jitter > 0.0:
                # Placement diversity. The ODE above is deterministic given x0,
                # so k independent samples differ ONLY in their committed order
                # -- measured: any-of-k on the training family gains nothing for
                # a head whose order distribution is sharp. This turns the
                # probability-flow ODE into an SDE the cheap way (Euler-Maruyama
                # on the moving coordinates only): variance is injected in
                # proportion to how far this object moves in this step, so a
                # stationary object is untouched and the total injected scale is
                # `jitter` regardless of n_steps. jitter = 0.0 (default) is
                # byte-identical to the deterministic rollout.
                z = torch.randn(x[..., :2].shape, device = x.device, dtype = x.dtype,
                                generator = generator)
                x = torch.cat([x[..., :2] + jitter * ds[..., None].sqrt() * z, x[..., 2:3]],
                              dim = -1)
            x[..., 2] = wrap_angle(x[..., 2])
            progress = progress_next

        if refine:
            assert self.velocity_field.predict_feasibility, \
                'PAMO(predict_feasibility=True) required for sample(refine=True)'
            assert refine_on in ('x0', 'ode'), f"refine_on must be 'x0' or 'ode', got {refine_on!r}"
            if refine_on == 'x0':
                anchor = batch['x0']
                s_anchor = torch.zeros_like(anchor[..., 0])
                t_anchor = 0.
            else:
                anchor = x
                s_anchor = torch.ones_like(x[..., 0])
                t_anchor = 1.
            feat_a = self.object_features(batch, anchor, s_anchor, t_anchor, movable)
            _v, _e, _logit, refined_delta = self.velocity_field.forward_with_feasibility(
                batch['grid'], feat_a, self._cap(batch), rank, movable, anchor, self.grid_hw,
                context = context, smoothness_cond = smoothness_cond)
            head_estimate_xy = anchor[..., :2] + refined_delta[..., :2]
            blend = movable[..., None].float() * refine_weight
            x = torch.cat([(1 - blend) * x[..., :2] + blend * head_estimate_xy, x[..., 2:3]], dim = -1)

        return dict(x = x, orders = orders, s = torch.as_tensor(progress, device = x.device))


def _self_check():
    """learned_loss_weight's contract (iteration 2 -- see SensitivityHead's
    own docstring for why this isn't a learned-from-emb_feat function any
    more): False (default) must never even construct a sensitivity_head.
    True must weight ABOVE-average-error objects with alpha > 1 and
    BELOW-average ones with alpha < 1 -- the property that failed in
    iteration 1 (measured directly on a trained checkpoint: alpha chased the
    EASIEST embodiment, not the hardest) -- and must stay bounded, finite,
    and trainable (gradient reaches the velocity field's endpoint head
    through the non-detached copy of the error, even though alpha itself
    has no learned parameters to check gradient against any more)."""
    import numpy as np

    from clear.model.encoders import SensitivityHead
    from clear.data.data import build_examples, collate

    # unit-level: the actual property that broke before, tested directly and
    # cheaply, without needing a trained model to observe it emerge.
    head = SensitivityHead()
    err = torch.tensor([0.001, 0.01, 0.01, 0.5])  # object 0 easiest, object 3 hardest
    movable = torch.ones(1, 4, dtype = torch.bool)
    alpha = head(err[None], movable)[0]
    assert alpha[3] > alpha[1] == alpha[2] > alpha[0], (
        f"alpha must increase with error (hard examples get MORE weight, not less): {alpha.tolist()}")
    assert alpha.min() >= 1 - head.MAX_DEV - 1e-4 and alpha.max() <= 1 + head.MAX_DEV + 1e-4, (
        f"alpha must stay within [1-MAX_DEV, 1+MAX_DEV]: {alpha.tolist()}")
    print(f"ok SensitivityHead: error-monotonic and bounded (alpha={[round(a.item(), 3) for a in alpha]} "
         f"for err={err.tolist()})")

    examples = build_examples(6, h = 8, w = 8, n_objects = 3, seed = 1)
    rng = np.random.default_rng(0)
    batch = collate(examples, rng)

    torch.manual_seed(0)
    plain = PAMO(grid_hw = (8, 8), dim = 32, depth = 2, heads = 2, dim_head = 16)
    assert not hasattr(plain, 'sensitivity_head'), "default PAMO must not carry a sensitivity head at all"
    _, parts_plain = plain(batch)
    assert 'sensitivity' not in parts_plain, "default breakdown must not mention sensitivity at all"

    torch.manual_seed(0)
    weighted = PAMO(grid_hw = (8, 8), dim = 32, depth = 2, heads = 2, dim_head = 16,
                    learned_loss_weight = True)
    loss_w, parts_w = weighted(batch)
    assert torch.isfinite(loss_w) and 1 - weighted.sensitivity_head.MAX_DEV - 1e-4 <= parts_w['sensitivity'] \
        <= 1 + weighted.sensitivity_head.MAX_DEV + 1e-4
    print(f"ok learned_loss_weight=True end-to-end: finite loss, mean alpha={parts_w['sensitivity']:.4f}")

    loss_w.backward()
    grads = [p.grad for p in weighted.velocity_field.to_endpoint.parameters() if p.grad is not None]
    assert grads and any(g.abs().sum() > 0 for g in grads), (
        "gradient didn't reach to_endpoint through the alpha-weighted loss -- E4PAMO's exact "
        "failure mode (built the feature, nothing downstream ever used it)")
    assert not list(weighted.sensitivity_head.parameters()), (
        "SensitivityHead should have NO learned parameters in this iteration -- "
        "that's the whole point (nothing left to game)")
    print("ok gradient reaches velocity_field.to_endpoint; sensitivity_head itself has zero parameters, as designed")



def _beam_orders(scores_row, idx, depth, width):
    """Top-`width` depth-d orders under the PROPER Plackett-Luce top-d marginal:
    each step's denominator is the logsumexp over everything not yet placed
    (all of `idx`, not just the tuple). At depth == len(idx) this is exactly
    plackett_luce_logp's measure, so the beam returns the same top slice full
    enumeration would -- without materialising n!/(n-d)! tuples. At depth <
    len(idx) it deliberately differs (see candidate_orders' comment). numpy-
    only; one example's score row.
    """
    import numpy as np
    s = {j: float(scores_row[j]) for j in idx}
    beams = [((), 0.0)]
    for _ in range(depth):
        nxt = []
        for prefix, lp in beams:
            rest = [j for j in idx if j not in prefix]
            if not rest:
                continue
            lse = float(np.logaddexp.reduce([s[j] for j in rest]))
            for j in rest:
                nxt.append((prefix + (j,), lp + s[j] - lse))
        nxt.sort(key = lambda t: -t[1])
        beams = nxt[:width]
    return [p for p, _lp in beams]
