"""affordancenet: affordance_transformer, stageb_aux_heads.

affordance_transformer: Affordance transformer: attention over [capability, objects, scene] tokens.

Named after Gibson's affordances -- the world perceived in terms of what THIS
body can do with it. That is literally this block's job: fuse the capability
token with objects and scene so the PriorityHead can read "which object is
actionable now" and the CausalVelocityField can read "where it can go".

The one attention stack both heads share structurally (each head owns its own
instance / parameters). Takes an optional per-sample boolean mask so the same
block serves the order-agnostic PriorityHead (no mask) and the
CausalVelocityField (causal mask).

ein notation:
  b - batch
  t - tokens (1 capability + n objects + s scene)
  h - attention heads
  d - model dimension
  e - head dimension

stageb_aux_heads: Quarantined Stage-2 auxiliary forwards: robot path, feasibility+residual, affordance.

Opt-in heads riding on CausalVelocityField's trunk. None of them is in the
deployed stack (setK trains with all three off); each exists for one recorded
experiment:

  forward_with_robot_path    approximate inter-phase robot pose (PLAN sect132)
  forward_with_feasibility   per-object park feasibility + bounded xy residual
                             (experiments/stageb_clearance_signal v21/v22)
  forward_with_affordance    full-res affordance cross-attention read
                             (train_pamo_affordance, affordance_kappa)

Moved out of causal_velocity_field.py (2026-09-02, Stage-2 simplification).
Mixin: module attribute names (`to_robot_velocity`, `to_feasibility`,
`to_residual`, `to_afford_q/k`) are built in CausalVelocityField.__init__ as
before, so every existing checkpoint's state_dict keys are unchanged.
"""

# ---- affordance_transformer ----
import torch
from einops import rearrange
from torch import nn
from torch.nn import Module, ModuleList

# helpers


def exists(v):
    return v is not None

# feedforward


class FeedForward(Module):
    def __init__(self, dim, mult = 4):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, dim * mult),
            nn.GELU(),
            nn.Linear(dim * mult, dim),
        )

    def forward(self, x):
        return self.net(x)

# attention


class Attention(Module):
    def __init__(self, dim, heads = 4, dim_head = 32):
        super().__init__()
        inner = heads * dim_head
        self.heads = heads
        self.scale = dim_head ** -0.5
        self.norm = nn.LayerNorm(dim)
        self.to_qkv = nn.Linear(dim, inner * 3, bias = False)
        self.to_out = nn.Linear(inner, dim, bias = False)

    def forward(self, x, mask = None, bias = None):
        """mask: (b, t, t) bool, True = query row may NOT attend key column.
        bias: (b, t, t) float, added to attention logits before the (harder)
        mask -- a graded penalty rather than an outright block. See
        causal_velocity_field.causal_bias for the one caller that uses this."""
        x = self.norm(x)
        q, k, v = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = (rearrange(t, 'b t (h e) -> b h t e', h = self.heads) for t in (q, k, v))

        sim = torch.einsum('b h i e, b h j e -> b h i j', q, k) * self.scale

        if exists(bias):
            sim = sim + rearrange(bias, 'b i j -> b 1 i j')

        if exists(mask):
            sim = sim.masked_fill(rearrange(mask, 'b i j -> b 1 i j'), -torch.finfo(sim.dtype).max)

        attn = sim.softmax(dim = -1)

        if getattr(self, 'store_attn', False):
            self.attn = attn.detach()  # (b, h, t, t) -- read by viz.model, never by the model

        out = torch.einsum('b h i j, b h j e -> b h i e', attn, v)
        return self.to_out(rearrange(out, 'b h t e -> b t (h e)'))

# perception transformer


class AffordanceTransformer(Module):
    def __init__(self, dim, depth = 4, heads = 4, dim_head = 32):
        super().__init__()
        self.layers = ModuleList([
            ModuleList([Attention(dim, heads = heads, dim_head = dim_head), FeedForward(dim)])
            for _ in range(depth)
        ])
        self.norm = nn.LayerNorm(dim)

    def forward(self, tokens, mask = None, bias = None):
        for attn, ff in self.layers:
            tokens = attn(tokens, mask = mask, bias = bias) + tokens
            tokens = ff(tokens) + tokens
        return self.norm(tokens)


# ---- stageb_aux_heads ----
from clear.util import wall_oob_penalty


class StageBAuxHeads:
    def forward_with_robot_path(self, grid, object_features, capability, rank, movable, context = None,
                                smoothness_cond = None):
        """Same trunk as forward(), plus the robot-approach-path heads.
        -> (velocity, endpoint_delta, robot_velocity, robot_endpoint_delta),
        each (b, n, 3). Requires predict_robot_path=True at construction."""
        assert self.predict_robot_path, "CausalVelocityField(predict_robot_path=True) required"
        out = self._trunk_out(grid, object_features, capability, rank, movable, context, smoothness_cond)
        return (self.to_velocity(out), self.to_endpoint(out),
                self.to_robot_velocity(out), self.to_robot_endpoint(out))

    def forward_with_feasibility(self, grid, object_features, capability, rank, movable, pose, grid_hw,
                                 context = None, smoothness_cond = None):
        """Same trunk as forward(), plus the feasibility + residual-refinement
        heads. -> (velocity, endpoint_delta, feasibility_logit,
        refined_delta): feasibility_logit is (b, n); refined_delta is
        (b, n, 3), endpoint_delta with a bounded xy correction added (see
        `to_residual`'s own comment in __init__ for the mechanism/rationale
        -- this is the part sect10's feasibility-only head was missing).
        Requires predict_feasibility=True at construction.

        `pose`: (b, n, 3) the CURRENT pose each object's endpoint_delta is
        relative to (batch['pose'], same tensor clear.py's own endpoint_loss
        already adds delta to) -- needed here only to build push_distance/
        wall_occ, the two scalars that depend on the CANDIDATE endpoint this
        forward pass proposes, not on pre-placement context alone."""
        assert self.predict_feasibility, "CausalVelocityField(predict_feasibility=True) required"
        out = self._trunk_out(grid, object_features, capability, rank, movable, context, smoothness_cond)
        velocity, endpoint_delta = self.to_velocity(out), self.to_endpoint(out)

        push_distance = endpoint_delta[..., :2].norm(dim = -1, keepdim = True)  # (b, n, 1)

        pred_end_xy = pose[..., :2] + endpoint_delta[..., :2]
        h, w = grid_hw
        scale = pred_end_xy.new_tensor([w - 1, h - 1])
        pred_xy_norm = pred_end_xy / scale * 2 - 1
        wall_channel = grid[:, 2:3]  # WALL is channel index 2, same convention as clear.py's own validity_loss
        wall_occ = wall_oob_penalty(pred_xy_norm, wall_channel)[..., None]  # (b, n, 1)

        n_movers = movable.float().sum(-1, keepdim = True).clamp(min = 1)  # (b, 1)
        order_index_norm = (rank.float() / n_movers).unsqueeze(-1)  # (b, n, 1); n_movers used as the
        # normalizer (not n-1) so a 1-mover scene's order_index_norm=0 stays in-range -- sentinel
        # ranks for immovable objects land wherever they land, masked out of the loss regardless
        n_movers_norm = (n_movers / 8.0).unsqueeze(-1).expand(-1, out.shape[1], -1)  # (b, n, 1), /8 = this
        # project's own native grid's max n_obj (NATIVE grid_hw=(8,8) scenes use n_obj=4 objects,
        # never more than 8 -- see demo_spot_maze_push.py/_native_scene callers), a fixed, known
        # normalizer rather than a per-batch one that would make the same scene-complexity value
        # mean different things across batches

        feas_in = torch.cat([out, push_distance, wall_occ, order_index_norm, n_movers_norm], dim = -1)
        feasibility_logit = self.to_feasibility(feas_in).squeeze(-1)  # (b, n)

        residual_xy = self.delta_max * torch.tanh(self.to_residual(feas_in))  # (b, n, 2), bounded
        # cat, not in-place assignment -- endpoint_delta is also returned as its own
        # value below, an in-place write here would risk a silent autograd/aliasing bug
        refined_delta = torch.cat([endpoint_delta[..., :2] + residual_xy, endpoint_delta[..., 2:3]], dim = -1)
        return velocity, endpoint_delta, feasibility_logit, refined_delta

    def forward_with_affordance(self, grid, object_features, capability, rank, movable, grid_hw,
                                context = None, smoothness_cond = None):
        """Same trunk as forward(), plus the affordance-map head (see the
        predict_affordance block in __init__). -> (velocity, endpoint_delta,
        affordance_logits) with affordance_logits (b, n, h, w) -- per-object
        park-cell logits at the RAW grid resolution.

        Coarse-map spatial layout: SceneEncoder rearranges its stride-2 conv
        output 'b d h w -> b (h w) d', row-major -- reshaping the (b, n, s)
        token scores back to (ch, cw) below inverts exactly that, so token
        j sits at coarse cell (j // cw, j % cw). Verified end-to-end by the
        self-check's layout probe (a single wall cell must displace the
        response at ITS corner, not a scrambled one)."""
        assert self.predict_affordance, "CausalVelocityField(predict_affordance=True) required"
        full, n = self._trunk_full(grid, object_features, capability, rank, movable, context,
                                   smoothness_cond)
        out = full[:, 1:1 + n]
        scene_out = full[:, 1 + n:]

        q = self.to_afford_q(out)                          # (b, n, d)
        k = self.to_afford_k(scene_out)                    # (b, s, d)
        coarse = torch.einsum('bnd,bsd->bns', q, k) / (q.shape[-1] ** 0.5)

        h, w = grid_hw
        ch, cw = (h + 1) // 2, (w + 1) // 2               # SceneEncoder's own stride-2 output size
        b = coarse.shape[0]
        coarse_img = coarse.reshape(b * n, 1, ch, cw)
        up = torch.nn.functional.interpolate(coarse_img, size = (h, w), mode = 'bilinear',
                                             align_corners = False)
        grid_rep = grid[:, None].expand(-1, n, -1, -1, -1).reshape(b * n, grid.shape[1], h, w)
        logits = self.afford_decoder(torch.cat([up, grid_rep], dim = 1))
        return self.to_velocity(out), self.to_endpoint(out), logits.reshape(b, n, h, w)
