"""world: push_route, tile_surface, controller_interface.

push_route: Object routes a PUSHING robot can actually execute, and the corner waypoints an executor needs.

Why this exists (2026-08-28, user's top-down observation): every executor received ONE park per object and
pushed the object toward it in a straight line. The oracle picks parks with a carry BFS (`oracle.bfs_path`:
walls and other objects avoided), so the park is reachable -- but by a path with corners, not by the straight
segment the executor drives. On rooms doorway scenes the straight segment crosses a wall and the robot spends
its whole budget pressing the box into it (G1 1009: 40 s in the doorway, then a fall).

Two rules a carried-object path ignores but a pushed object obeys (Sokoban):
  1. to move the object from cell A to B = A + d, the robot must stand on A - d (behind it), which must be a
     free cell (in grid, not WALL, not another object);
  2. when the push direction changes at A, the robot has to walk from its old standing cell A - d_old to the
     new one A - d_new without passing through A (the object) -- a free-cell BFS around it.
`pushable_path` is a Dijkstra over (cell, direction) states with those rules; a turn costs TURN_COST extra so
corridors are preferred to zig-zags. `segments` turns the path into corner cells (the executor's sub-goals).

    .venv/bin/python -m clear.mj_util.push_route diag SEED [SEED ...]
        For each rooms seed: oracle (humanoid) parks and, if runs/cross_body/plans/SEED.json exists, the PAMO
        (g1_wo_wrist, corrected) parks -> per mover: straight line crosses a wall?, carry path?, pushable path?
        (+ turns). Aggregate at the end.

tile_surface: Explicit directed ramps and stair treads for the setup-figure transfer scene.

Opt-in via public geometry in scene.params['surface_tiles']; old scenes unchanged.
Heights describe the support surface, not a discounted symbolic climb number.

controller_interface: Maze world model + the `InteractionController` contract shared by exp 03 / exp 04.

  MazeScene / MazeObj    clear.data.grid.Scene extended with the metric axes exp 03 needs:
                         per-cell ramp slope (deg), per-cell passage width (m), gate tags,
                         object footprint/height/friction.  `can_enter` dispatches to the
                         body's own edge predicate, so every clear.data.oracle primitive
                         (bfs_path, park_valid, find_parking, ...) is body-aware here.
  Observation / observe  what a planner may see: heights, slopes, widths, occupancy,
                         start/goal, object states -- and phi_B only when the method is
                         allowed it (the evaluator decides; NoEmb never receives it).
  scene_to_mjcf          the MuJoCo realisation (blocks, ramps, narrow slabs, free boxes).
  AbstractController     CPU-runnable deterministic executor: teleport along a cell path,
                         every edge and every interaction checked against a feasibility
                         model (the privileged BodyCapability at execution time; a
                         planner's own belief at plan time).  Runs the whole evaluator
                         on this host.
  make_controller        'abstract' (default here), 'mocap' (unimplemented), 'sumo_spot' / 'mjlab'
                         adapters (GPU / pixi env, not runnable on this host).
"""
from __future__ import annotations

# ---- push_route ----
import heapq
import json
import os
import sys
from collections import deque

import numpy as np

from clear.data.capability import WALL

DIRS = ((-1, 0), (1, 0), (0, -1), (0, 1))
DIRS8 = ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1))
TURN_COST = 3.0  # a turn = a robot repositioning leg; prefer straight pushes
RELAXED = os.environ.get("PAMO_PUSH_RULE", "relaxed") == "relaxed"
# relaxed (default): 8-direction pushes (a diagonal step only when both flanking cardinal cells are free, like
# grid.cell_path) and the robot may stand up to 45 deg off the push axis behind the object -- what Spot and G1
# were seen doing (rooms 1006: the 4-connected rule says unpushable, both bodies pushed it). strict: 4-connected,
# robot exactly behind. PAMO_PUSH_RULE=strict selects the latter.


def _free(scene, cell, blocked):
    r, c = cell
    return (0 <= r < scene.terrain.shape[0] and 0 <= c < scene.terrain.shape[1]
            and int(scene.terrain[r, c]) != WALL and cell not in blocked)


def robot_can_reach(scene, blocked, src, dst, avoid):
    """Free-cell BFS for the ROBOT from src to dst, never entering `avoid` (the object's cell) or `blocked`."""
    if src == dst:
        return True
    if not _free(scene, src, blocked) or not _free(scene, dst, blocked):
        return False
    seen = {src, avoid}
    q = deque([src])
    while q:
        cell = q.popleft()
        for dr, dc in DIRS:
            nxt = (cell[0] + dr, cell[1] + dc)
            if nxt in seen or not _free(scene, nxt, blocked):
                continue
            if nxt == dst:
                return True
            seen.add(nxt)
            q.append(nxt)
    return False


def pushable_path(scene, src, dst, blocked=(), turn_cost=TURN_COST, robot_cell=None, can_drag=False):
    """Cells (inclusive) along which the robot can move the object src -> dst, or None. See pushable_route."""
    r = pushable_route(scene, src, dst, blocked, turn_cost, robot_cell, can_drag)
    return None if r is None else r[0]


PULL_COST = 0.5  # prefer a push when both work (a pull needs a grasp and a backwards walk)


def pushable_route(scene, src, dst, blocked=(), turn_cost=TURN_COST, robot_cell=None, can_drag=False):
    """-> (cells, modes) or None. modes[k] in {"push", "pull"} is how the object goes from cells[k] to cells[k+1].
    Push: the robot stands behind the object (RELAXED: up to 45 deg off-axis). Pull (can_drag bodies only):
    the robot stands on the destination cell, grasps, and retreats one cell further -- that retreat cell must be
    free. `blocked` = cells of the OTHER objects. `robot_cell`: where the robot is before the first move -- its
    first standing cell must be reachable around the object. Turns require the robot to walk from where the
    previous move left it to the new standing cell without crossing the object."""
    blocked = set(blocked) - {src, dst}
    if src == dst:
        return [src], []
    dirs = DIRS8 if RELAXED else DIRS
    start = (src, None, None)
    dist = {start: 0.0}
    prev = {start: None}
    heap = [(0.0, 0, src, None, None)]
    tie = 1
    while heap:
        d0, _, cell, di, mode = heapq.heappop(heap)
        if dist.get((cell, di, mode), np.inf) < d0:
            continue
        if cell == dst:
            cells, modes = [], []
            st = (cell, di, mode)
            while st is not None:
                cells.append(st[0])
                if st[2] is not None:
                    modes.append(st[2])
                st = prev[st]
            return cells[::-1], modes[::-1]
        # where the robot is now, given the last move
        if di is None:
            robot_from = [tuple(robot_cell)] if robot_cell is not None else None
        elif mode == "push":
            robot_from = [b for b in _standing_cells(cell, dirs[di]) if _free(scene, b, blocked)]
        else:  # pull: the robot retreated one cell ahead of the object
            robot_from = [(cell[0] + dirs[di][0], cell[1] + dirs[di][1])]
        for k, (dr, dc) in enumerate(dirs):
            nxt = (cell[0] + dr, cell[1] + dc)
            if not _free(scene, nxt, blocked):
                continue
            if dr != 0 and dc != 0:  # diagonal object step: corner-safe like grid.cell_path
                if not (_free(scene, (cell[0] + dr, cell[1]), blocked) and _free(scene, (cell[0], cell[1] + dc), blocked)):
                    continue
            options = []
            stands = [b for b in _standing_cells(cell, (dr, dc)) if _free(scene, b, blocked)]
            if stands:
                options.append(("push", stands, 0.0))
            if can_drag and (dr == 0 or dc == 0):   # pulling along a diagonal is not modelled
                retreat = (nxt[0] + dr, nxt[1] + dc)
                if _free(scene, retreat, blocked):
                    options.append(("pull", [nxt], PULL_COST))
            for new_mode, targets, extra in options:
                if robot_from is not None:
                    if not any(robot_can_reach(scene, blocked, rf, t, avoid=cell) for rf in robot_from for t in targets):
                        continue
                cost = 1.0 + extra + (0.4142 if (dr != 0 and dc != 0) else 0.0)
                if di is not None and (k != di or new_mode != mode):
                    cost += turn_cost
                nd = d0 + cost
                st = (nxt, k, new_mode)
                if nd < dist.get(st, np.inf):
                    dist[st] = nd
                    prev[st] = (cell, di, mode)
                    heapq.heappush(heap, (nd, tie, nxt, k, new_mode))
                    tie += 1
    return None


def _standing_cells(cell, d):
    """Cells the robot may stand on to push the object at `cell` in direction d: directly behind, and (relaxed
    rule) the two cells 45 deg off the axis behind it."""
    dr, dc = d
    behind = (cell[0] - dr, cell[1] - dc)
    if not RELAXED:
        return [behind]
    if dr == 0 or dc == 0:   # cardinal push: behind, behind+-lateral
        lat = (dc, dr) if dr == 0 else (dc, dr)
        lat = (0, 1) if dr != 0 else (1, 0)
        return [behind, (behind[0] + lat[0], behind[1] + lat[1]), (behind[0] - lat[0], behind[1] - lat[1])]
    # diagonal push: behind diagonal, and the two cardinal cells adjacent to it on the far side
    return [behind, (cell[0] - dr, cell[1]), (cell[0], cell[1] - dc)]


def segments(path):
    """Corner cells of a cell path (direction changes), dst included, src excluded. Straight path -> [dst]."""
    if path is None or len(path) < 2:
        return []
    out = []
    for a, b, c in zip(path[:-2], path[1:-1], path[2:]):
        if (b[0] - a[0], b[1] - a[1]) != (c[0] - b[0], c[1] - b[1]):
            out.append(b)
    out.append(path[-1])
    return out


def line_crosses_wall(scene, spec, p0_world, p1_world, samples=64):
    p0, p1 = np.asarray(p0_world, float), np.asarray(p1_world, float)
    for t in np.linspace(0.0, 1.0, samples):
        cell = spec.world_to_cell(p0 + t * (p1 - p0))
        if not spec.in_grid(cell) or int(scene.terrain[cell]) == WALL:
            return True
    return False


def route_for_push(scene, spec, positions_cells, i, park_world):
    """-> dict(path, corners_world, straight_ok, carry_ok, pushable) for moving object i to `park_world`.
    corners_world: world sub-goals (cell centres for corners, the exact park last); None if not pushable."""
    from clear.data import oracle
    src = tuple(positions_cells[i])
    dst = tuple(spec.world_to_cell(park_world))
    blocked = {tuple(c) for j, c in enumerate(positions_cells) if j != i and c is not None}
    carry = oracle.bfs_path(scene, src, dst, blocked)
    path = pushable_path(scene, src, dst, blocked)
    straight_ok = not line_crosses_wall(scene, spec, spec.cell_to_world(src), park_world)
    corners = None
    if path is not None:
        cs = segments(path)
        corners = [list(map(float, spec.cell_to_world(c))) for c in cs[:-1]] + [list(map(float, park_world))]
    return {"path": path, "corners_world": corners, "straight_ok": straight_ok,
            "carry_ok": carry is not None, "pushable": path is not None,
            "n_turns": max(0, len(segments(path)) - 1) if path is not None else None}


def corner_subgoals(scene, spec, obstacle_cells, src_cell, dst_cell, goal_world, only_if_blocked=True):
    """Executor sub-goals for pushing an object src_cell -> goal_world: the corners of the 8-directional,
    corner-safe cell path (clear.data.grid.cell_path -- the same path the training labels use, other objects'
    cells treated as walls) as cell centres, then the exact park. Falls back to [goal_world] when no cell path
    exists (the executor then does what it always did) or when the path has no corner."""
    from clear.data.grid import cell_path
    src_cell, dst_cell = tuple(int(v) for v in src_cell), tuple(int(v) for v in dst_cell)
    terrain = np.array(scene.terrain, copy=True)
    for c in obstacle_cells:
        c = tuple(int(v) for v in c)
        if c != src_cell and c != dst_cell and 0 <= c[0] < terrain.shape[0] and 0 <= c[1] < terrain.shape[1]:
            terrain[c] = WALL
    if only_if_blocked and not line_crosses_wall(scene, spec, spec.cell_to_world(src_cell), goal_world):
        # the direct push is wall-free: keep it. Short diagonal pushes out of a doorway (rooms 1006 obj_0,
        # G1 done in 9.8 s in gate1e) work physically although the cell rules forbid the diagonal; forcing
        # them into "south, then east" segments adds a repositioning leg for nothing.
        return [list(map(float, goal_world))], None
    try:
        path = cell_path(terrain, src_cell, dst_cell)
    except Exception:  # noqa: BLE001 -- KeyError from an unreachable park
        return [list(map(float, goal_world))], None
    corners = segments(path)
    subs = [list(map(float, spec.cell_to_world(c))) for c in corners[:-1]] + [list(map(float, goal_world))]
    return subs, path


# ---- tile_surface ----
import math


def edge_features(scene):
    """Public geometric requirements only; no body, feasibility or route labels."""
    h,w=scene.shape
    out=np.full((4,h,w),10.,np.float32)
    for r in range(h):
        for c in range(w):
            for k,(dr,dc) in enumerate(NEIGHBORS):
                dest=(r+dr,c+dc)
                if scene.in_bounds(dest):out[k,r,c]=step_requirement(scene,(r,c),dest)
    return out


def tread_features(scene):
    """Available stair tread depth on each edge; large sentinel off stair tiles."""
    h,w=scene.shape;out=np.full((4,h,w),10.,np.float32)
    for r in range(h):
        for c in range(w):
            for k,(dr,dc) in enumerate(NEIGHBORS):
                for cell in ((r,c),(r+dr,c+dc)):
                    t=tile(scene,cell)
                    if t and t['kind']=='stairs':out[k,r,c]=min(out[k,r,c],scene.cell_m/t['n'])
    return out


def tile(scene, cell):
    return scene.params.get('surface_tiles', {}).get(f'{cell[0]},{cell[1]}')


def height(scene, xy):
    x, y = xy
    cell = (int(math.floor(y / scene.cell_m)), int(math.floor(x / scene.cell_m)))
    if not scene.in_bounds(cell):
        return 0.
    t = tile(scene, cell)
    if not t:
        return float(scene.height[cell] + (y-(cell[0]+.5)*scene.cell_m)*
                     math.tan(math.radians(float(scene.slope_deg[cell]))))
    if t['kind']=='fixed_step':
        inside=(abs(x-(cell[1]+.5)*scene.cell_m)<t['dx']/2 and
                abs(y-(cell[0]+.5)*scene.cell_m)<t['dy']/2)
        return t['base']+(t['rise'] if inside else 0.)
    u = (y / scene.cell_m - cell[0]) if t['axis'] == 'row' else (x / scene.cell_m - cell[1])
    if t['sign'] < 0:
        u = 1-u
    if t['kind'] == 'stairs':
        u = min(t['n'], max(1, math.floor(u*t['n'])+1))/t['n']
    return t['base'] + t['rise']*u


def step_requirement(scene, frm, to):
    """Largest discontinuity including internal stair risers; descents also count."""
    a = ((frm[1]+.5)*scene.cell_m, (frm[0]+.5)*scene.cell_m)
    b = ((to[1]+.5)*scene.cell_m, (to[0]+.5)*scene.cell_m)
    mid = ((a[0]+b[0])/2, (a[1]+b[1])/2)
    eps = 1e-6
    # A side approach to a ramp encounters a varying-height face. Its midpoint
    # alone understates the discontinuity seen across the stance. Use the full
    # shared cell edge envelope (conservative, body-independent geometry).
    tangent=(0.,scene.cell_m) if frm[0]==to[0] else (scene.cell_m,0.)
    gap=0.
    for u in (-.5+eps,-.25,0.,.25,.5-eps):
        p=(mid[0]+u*tangent[0],mid[1]+u*tangent[1])
        gap=max(gap,abs(height(scene,(p[0]+eps*(b[0]-a[0]),p[1]+eps*(b[1]-a[1]))) -
                        height(scene,(p[0]-eps*(b[0]-a[0]),p[1]-eps*(b[1]-a[1])))))
    for cell in (frm, to):
        t = tile(scene, cell)
        if t and t['kind'] == 'stairs':
            gap = max(gap, t['rise']/t['n'])
        if t and t['kind']=='fixed_step':gap=max(gap,t['rise'])
    return gap


def geometry(scene, cell):
    """MJCF geoms with exact support endpoints and fully filled platforms."""
    t = tile(scene, cell)
    if not t:
        return None
    r,c = cell; size=scene.cell_m; x=(c+.5)*size; y=(r+.5)*size
    parts=[]
    if t['kind']=='fixed_step':
        base=t['base'];rise=t['rise']
        parts.append(f'<geom name="support_{r}_{c}" type="box" pos="{x} {y} {base/2}" size="{size/2} {size/2} {base/2}" material="step"/>')
        parts.append(f'<geom name="fixed_step_{r}_{c}" type="box" pos="{x} {y} {base+rise/2}" size="{t["dx"]/2} {t["dy"]/2} {rise/2}" material="step"/>')
    elif t['kind'] == 'stairs':
        for i in range(t['n']):
            z=t['base']+t['rise']*(i+1)/t['n']
            offset=t['sign']*size*((i+.5)/t['n']-.5)
            px=x+(offset if t['axis']=='col' else 0)
            py=y+(offset if t['axis']=='row' else 0)
            sx=size/(2*t['n']) if t['axis']=='col' else size/2
            sy=size/(2*t['n']) if t['axis']=='row' else size/2
            parts.append(f'<geom name="stair_{r}_{c}_{i}" type="box" pos="{px} {py} {z/2}" size="{sx} {sy} {z/2}" material="step"/>')
    else:
        angle=t['sign']*math.atan2(t['rise'],size)
        thickness=.05
        z=t['base']+t['rise']/2-math.cos(angle)*thickness/2
        shift=math.sin(angle)*thickness/2
        axis='1 0 0' if t['axis']=='row' else '0 1 0'
        qangle=angle if t['axis']=='row' else -angle
        q=[math.cos(qangle/2),*(math.sin(qangle/2)*float(v) for v in axis.split())]
        px=x+(shift if t['axis']=='col' else 0);py=y+(shift if t['axis']=='row' else 0)
        sx=size/(2*math.cos(angle)) if t['axis']=='col' else size/2
        sy=size/(2*math.cos(angle)) if t['axis']=='row' else size/2
        parts.append(f'<geom name="ramp_{r}_{c}" type="box" pos="{px} {py} {z}" quat="{" ".join(map(str,q))}" size="{sx} {sy} {thickness/2}" material="ramp"/>')
        if t['base']>0:
            parts.append(f'<geom name="support_{r}_{c}" type="box" pos="{x} {y} {t["base"]/2}" size="{size/2} {size/2} {t["base"]/2}" material="step"/>')
    return '\n'.join(parts)


# ---- controller_interface ----
import copy
from dataclasses import dataclass, field
from typing import Any, Protocol


from experiments.common.interfaces import ExecutionResult, FailureType, InteractionController
from clear.data.grid import Obj, Scene, height_to_terrain

CELL_M = 1.0            # metres per grid cell.  1.0, not clear.mj_util.mj_maze's 0.8: the widest
                        # measured body (google_robot mobile base, 0.82 m collision width + margin)
                        # must fit through an open cell, and the narrow-gate range must straddle all
                        # four measured widths (0.48 / 0.53 / 0.53 / 0.82 m).  See REPORT decision D5.
WALL_H = 1.5            # metres; walls are walls for every body (> any step limit)
OBJ_RAISED_MAX = 0.06   # objects can only be pushed over cells at (near) ground level
NEIGHBORS = ((-1, 0), (1, 0), (0, -1), (0, 1))


@dataclass
class MazeObj(Obj):
    object_id: int = -1
    dx_m: float = 0.4
    dy_m: float = 0.4
    height_m: float = 0.4
    friction: float = 0.5

    @classmethod
    def make(cls, object_id, cell, mass, dx_m, dy_m, height_m, friction, theta=0.0, cell_m=CELL_M):
        return cls(cell=tuple(int(v) for v in cell), mass=float(mass),
                   extent=float(max(dx_m, dy_m) / cell_m), theta=float(theta),
                   object_id=int(object_id), dx_m=float(dx_m), dy_m=float(dy_m),
                   height_m=float(height_m), friction=float(friction))

    def to_manifest(self, cell_m=CELL_M) -> dict:
        x, y = cell_to_world(self.cell, cell_m)
        return {"object_id": int(self.object_id), "asset_id": "box",
                "initial_configuration": [round(x, 4), round(y, 4), round(float(self.theta), 5)],
                "mass": round(float(self.mass), 4),
                "geometry": [round(self.dx_m, 4), round(self.dy_m, 4), round(self.height_m, 4)],
                "friction": round(float(self.friction), 4)}


def cell_to_world(cell, cell_m=CELL_M):
    r, c = cell
    return (c + 0.5) * cell_m, (r + 0.5) * cell_m


def world_to_cell(xy, cell_m=CELL_M):
    return int(math.floor(xy[1] / cell_m)), int(math.floor(xy[0] / cell_m))


@dataclass
class MazeScene(Scene):
    slope_deg: np.ndarray | None = None      # (H, W) ramp slope in degrees, 0 = flat-topped block
    passage_width: np.ndarray | None = None  # (H, W) free width in metres (CELL_M = open)
    gates: dict = field(default_factory=dict) # route label -> [cells] (privileged, evaluator only)
    family: str = ""
    base_scene_id: str = ""
    wall_h: float = WALL_H
    cell_m: float = CELL_M
    params: dict = field(default_factory=dict)  # family parameters, for the manifest

    @classmethod
    def build(cls, height, start, goal, objects, slope_deg=None, passage_width=None, gates=None,
              family="", base_scene_id="", params=None, cell_m=CELL_M):
        height = np.asarray(height, dtype=np.float32)
        h, w = height.shape
        return cls(terrain=height_to_terrain(height), start=tuple(start), goal=tuple(goal),
                   objects=list(objects), height=height,
                   slope_deg=(np.zeros((h, w), np.float32) if slope_deg is None else np.asarray(slope_deg, np.float32)),
                   passage_width=(np.full((h, w), cell_m, np.float32) if passage_width is None
                                  else np.asarray(passage_width, np.float32)),
                   gates={k: [tuple(c) for c in v] for k, v in (gates or {}).items()},
                   family=family, base_scene_id=base_scene_id, params=dict(params or {}), cell_m=float(cell_m))

    # -- body-dependent predicates --------------------------------------------------------
    def can_enter(self, emb, frm, to) -> bool:
        if hasattr(emb, "can_enter"):
            return bool(emb.can_enter(self, frm, to))
        return super().can_enter(emb, frm, to)

    def can_start(self, emb) -> bool:
        return True

    def is_wall(self, cell) -> bool:
        return float(self.height[cell]) >= self.wall_h - 1e-6

    def copy(self) -> "MazeScene":
        return copy.deepcopy(self)

    def object_by_id(self, object_id: int) -> MazeObj:
        for o in self.objects:
            if o.object_id == object_id:
                return o
        raise KeyError(object_id)

    def index_of(self, object_id: int) -> int:
        for i, o in enumerate(self.objects):
            if o.object_id == object_id:
                return i
        raise KeyError(object_id)

    def occupancy(self) -> np.ndarray:
        occ = np.zeros(self.shape, dtype=bool)
        for o in self.objects:
            if self.in_bounds(o.cell):       # a physically shoved box can leave the grid (family_mpc_q0: cell row 18 of 12)
                occ[o.cell] = True
        return occ

    def route_class(self, cells) -> str:
        """Gate labels crossed by a cell trajectory, '+'-joined in order of first crossing;
        'direct' when no gate is crossed."""
        tag = {c: name for name, cs in self.gates.items() for c in cs}
        seen = []
        for c in cells:
            t = tag.get(tuple(c))
            if t is not None and t not in seen:
                seen.append(t)
        return "+".join(seen) if seen else "direct"

    def object_blocked_cells(self, obj) -> set:
        """Cells an object cannot be pushed onto: raised, ramp, or too narrow for it."""
        h, w = self.shape
        wide = max(float(obj.dx_m), float(obj.dy_m))
        out = set()
        support = float(self.height[obj.cell]) if self.params.get("surface_tiles") else 0.
        for r in range(h):
            for c in range(w):
                if (abs(float(self.height[r, c])-support) > OBJ_RAISED_MAX or float(self.slope_deg[r, c]) > 0
                        or float(self.passage_width[r, c]) < wide - 1e-6):
                    out.add((r, c))
        return out


def _rise_m(scene: MazeScene, cell) -> float:
    s = float(scene.slope_deg[cell])
    return scene.cell_m * math.tan(math.radians(s)) if s > 0 else 0.0


def edge_step_up(scene: MazeScene, frm, to) -> float:
    """Signed step from `frm` to `to` in metres.  Ramp cells rise along +row: entering a ramp
    from below meets its low edge, leaving it upward leaves from its high edge."""
    if scene.params.get('surface_tiles'):
        return step_requirement(scene, frm, to)
    dr = int(to[0]) - int(frm[0])
    h_from = float(scene.height[frm])
    if scene.slope_deg[frm] > 0:
        r = _rise_m(scene, frm)
        h_from += r / 2 if dr > 0 else (-r / 2 if dr < 0 else 0.0)
    h_to = float(scene.height[to])
    if scene.slope_deg[to] > 0:
        r = _rise_m(scene, to)
        h_to += -r / 2 if dr > 0 else (r / 2 if dr < 0 else 0.0)
    return h_to - h_from


class FeasibilityModel(Protocol):
    """What the AbstractController asks of a body: the privileged BodyCapability at execution
    time, or a planner's own belief (predicted traversability) at plan time."""
    def can_enter(self, scene, frm, to) -> bool: ...
    def part(self, name: str): ...
    def part_can_move(self, part, obj) -> tuple[bool, str | None]: ...


# --------------------------------------------------------------------------------------
# observation


@dataclass
class Observation:
    heights: np.ndarray
    slope_deg: np.ndarray
    passage_width: np.ndarray
    occupancy: np.ndarray
    start: tuple
    goal: tuple
    objects: list                    # [{object_id, cell, xy, yaw, mass, dx_m, dy_m, height_m, friction}]
    cell_m: float
    wall_h: float
    phi_B: tuple | None = None       # (rows (L, D), mask (L,)) -- only for methods allowed it
    structure_hash: str | None = None
    extra: dict = field(default_factory=dict)

    @property
    def shape(self):
        return self.heights.shape

    def as_scene(self) -> MazeScene:
        """A planner-side MazeScene built ONLY from what is observed (no gates, no family)."""
        objs = [MazeObj.make(o["object_id"], o["cell"], o["mass"], o["dx_m"], o["dy_m"], o["height_m"],
                             o["friction"], o["yaw"], self.cell_m) for o in self.objects]
        sc = MazeScene.build(self.heights, self.start, self.goal, objs, self.slope_deg, self.passage_width)
        sc.wall_h = self.wall_h
        sc.cell_m = self.cell_m
        if "surface_tiles" in self.extra:
            sc.params["surface_tiles"] = copy.deepcopy(self.extra["surface_tiles"])
        return sc


def observe(scene: MazeScene, robot_cell=None, structure=None) -> Observation:
    """What the planner sees.  `structure`: a StructureDescription (phi_B) or None."""
    robot_cell = tuple(scene.start if robot_cell is None else robot_cell)
    objs = []
    for o in scene.objects:
        x, y = cell_to_world(o.cell, scene.cell_m)
        objs.append({"object_id": int(o.object_id), "cell": tuple(int(v) for v in o.cell),
                     "xy": (float(x), float(y)), "yaw": float(o.theta), "mass": float(o.mass),
                     "dx_m": float(o.dx_m), "dy_m": float(o.dy_m), "height_m": float(o.height_m),
                     "friction": float(o.friction)})
    phi = None
    if structure is not None:
        from clear.maze.robots import padded_rows
        phi = padded_rows(structure.rows)
    return Observation(heights=np.asarray(scene.height, np.float32).copy(),
                       slope_deg=np.asarray(scene.slope_deg, np.float32).copy(),
                       passage_width=np.asarray(scene.passage_width, np.float32).copy(),
                       occupancy=scene.occupancy(), start=robot_cell, goal=tuple(scene.goal),
                       objects=objs, cell_m=scene.cell_m, wall_h=scene.wall_h, phi_B=phi,
                       structure_hash=None if structure is None else structure.structure_hash,
                       extra={"surface_tiles": copy.deepcopy(scene.params["surface_tiles"])}
                       if scene.params.get("surface_tiles") else {})


# --------------------------------------------------------------------------------------
# MuJoCo realisation


def scene_to_mjcf(scene: MazeScene, border: bool = True, start_marker: bool = True) -> str:
    """MJCF text for a MazeScene: floor + border ring, one box per raised cell, tilted slabs
    for ramp cells, side slabs for narrow passages, free-joint boxes obj_<id> (geom group 5,
    as clear.util.project.from_mujoco expects), a start marker body and a 'goal' site."""
    cell = scene.cell_m
    h, w = scene.shape
    parts = [f"""
<mujoco model="maze_embodiment">
  <option timestep="0.002"/>
  <visual>
    <headlight ambient="0.35 0.35 0.35" diffuse="0.35 0.35 0.35" specular="0.05 0.05 0.05"/>
    <global offwidth="1280" offheight="960"/>
  </visual>
  <asset>
    <texture type="2d" name="grid" builtin="checker" rgb1=".08 .11 .16" rgb2=".15 .18 .25" width="300" height="300"/>
    <material name="grid" texture="grid" texuniform="true" texrepeat="{w} {h}" reflectance="0.0"/>
    <material name="wall" rgba="1 1 1 1"/>
    <material name="step" rgba=".75 .78 .84 1"/>
    <material name="ramp" rgba=".62 .70 .80 1"/>
    <material name="target" rgba="0.96 0.26 0.33 1"/>
  </asset>
  <worldbody>
    <light name="global" directional="true" ambient=".2 .2 .2" diffuse=".45 .45 .45" specular=".05 .05 .05"
           castshadow="false" pos="{w * cell / 2} {h * cell / 2} 8" dir="0 0 -1"/>
    <geom name="floor" type="plane" size="{(w + 2) * cell} {(h + 2) * cell} 0.1"
          pos="{w * cell / 2} {h * cell / 2} 0" material="grid" friction="1 0.005 0.0001"/>
"""]
    wh = scene.wall_h
    # `wall_h` classifies a cell as wall; it is not how tall the wall is drawn. Left equal, a
    # wall beside the 0.6 m plateau only stands 0.4 m above the floor the robot walks on, which
    # reads as a kerb next to a 1.2 m crate. `wall_top_m` raises every wall geom -- cells, the
    # narrow-passage slabs and the perimeter -- to one common top, without touching the height
    # grid the planner and the collision checks read.
    top = float(scene.params.get("wall_top_m") or wh)
    if top < wh - 1e-6:
        raise ValueError(f"wall_top_m {top} is below the wall threshold {wh}")
    if border and scene.params.get("include_border", True):
        for k, r in enumerate((-1, h)):
            parts.append(f'    <geom name="border{k}" type="box" pos="{w * cell / 2} {(r + 0.5) * cell} {top / 2}" '
                         f'size="{(w + 2) * cell / 2} {cell / 2} {top / 2}" material="wall"/>\n')
        for k, c in enumerate((-1, w)):
            parts.append(f'    <geom name="border_side{k}" type="box" pos="{(c + 0.5) * cell} {h * cell / 2} {top / 2}" '
                         f'size="{cell / 2} {h * cell / 2} {top / 2}" material="wall"/>\n')
    for r in range(h):
        for c in range(w):
            x, y = cell_to_world((r, c), cell)
            z = float(scene.height[r, c])
            s = float(scene.slope_deg[r, c])
            pw = float(scene.passage_width[r, c])
            explicit = geometry(scene, (r, c))
            if explicit is not None:
                parts.append(explicit)
            elif s > 0:
                th = math.radians(s)
                t = 0.05
                cy = y + math.sin(th) * t / 2
                cz = z - math.cos(th) * t / 2
                parts.append(f'    <geom name="ramp_{r}_{c}" type="box" pos="{x} {cy} {cz}" '
                             f'quat="{math.cos(th / 2)} {math.sin(th / 2)} 0 0" '
                             f'size="{cell / 2} {cell / (2 * math.cos(th))} {t / 2}" material="ramp"/>\n')
            elif z > 1e-4:
                is_wall = z >= wh - 1e-3
                zh = top if is_wall else z
                mat = "wall" if is_wall else "step"
                parts.append(f'    <geom name="cell_{r}_{c}" type="box" pos="{x} {y} {zh / 2}" '
                             f'size="{cell / 2} {cell / 2} {zh / 2}" material="{mat}"/>\n')
            if pw < cell - 1e-6:
                slab = (cell - pw) / 2
                for k, xc in enumerate((x - cell / 2 + slab / 2, x + cell / 2 - slab / 2)):
                    parts.append(f'    <geom name="narrow_{r}_{c}_{k}" type="box" pos="{xc} {y} {top / 2}" '
                                 f'size="{slab / 2} {cell / 2} {top / 2}" material="wall"/>\n')
    for o in scene.objects:
        x, y = cell_to_world(o.cell, cell)
        gap = 0.0  # physical dimensions must match the manifest, not shrink each side
        shade = 0.6 + 0.4 * (1.0 - min(float(o.mass), 20.0) / 20.0)
        parts.append(f"""
    <body name="obj_{o.object_id}" pos="{x} {y} {float(scene.height[o.cell]) + o.height_m / 2}" quat="{math.cos(o.theta / 2)} 0 0 {math.sin(o.theta / 2)}">
      <freejoint/>
      <geom type="box" size="{o.dx_m / 2 - gap} {o.dy_m / 2 - gap} {o.height_m / 2 - gap}" mass="{o.mass}"
            group="5" priority="2" friction="{o.friction} 0.005 0.0001" rgba="{0.7 * shade} {0.5 * shade} {0.3 * shade} 1"/>
    </body>""")
    sx, sy = cell_to_world(scene.start, cell)
    gx, gy = cell_to_world(scene.goal, cell)
    if start_marker:
        parts.append(f"""
    <body name="pelvis" pos="{sx} {sy} 0.5">
      <geom type="cylinder" size="0.15 0.5" group="5" contype="0" conaffinity="0" rgba="0.35 0.55 0.91 0.9"/>
    </body>""")
    parts.append(f"""
    <site name="start" type="box" pos="{sx} {sy} 0.02" size="0.1 0.1 0.01" rgba="0.35 0.55 0.91 0.5"/>
    <site name="goal" pos="{gx} {gy} 0.02" size="0.3" rgba="0.96 0.26 0.33 0.5"/>
    <geom name="goal_disc" type="cylinder" pos="{gx} {gy} 0.05" size="{0.4 * cell} 0.05" group="5"
          contype="0" conaffinity="0" material="target"/>
  </worldbody>
</mujoco>""")
    return "".join(parts)


def trajectory_length_m(cells, cell_m=CELL_M) -> float:
    total = 0.0
    for a, b in zip(cells[:-1], cells[1:]):
        total += math.hypot(b[0] - a[0], b[1] - a[1]) * cell_m
    return float(total)


# --------------------------------------------------------------------------------------
# abstract controller


def bfs_cells(scene: MazeScene, body, src, dst, blocked=()) -> list | None:
    """Shortest 4-connected robot path src -> dst under body.can_enter, never entering
    `blocked` (object cells).  Inclusive of both ends; None if unreachable."""
    src, dst = tuple(src), tuple(dst)
    if src == dst:
        return [src]
    blocked = set(blocked) - {src}
    prev = {src: None}
    q = deque([src])
    while q:
        cell = q.popleft()
        for dr, dc in NEIGHBORS:
            nxt = (cell[0] + dr, cell[1] + dc)
            if not scene.in_bounds(nxt) or nxt in prev or nxt in blocked:
                continue
            if not scene.can_enter(body, cell, nxt):
                continue
            prev[nxt] = cell
            if nxt == dst:
                out = [nxt]
                while prev[out[-1]] is not None:
                    out.append(prev[out[-1]])
                return out[::-1]
            q.append(nxt)
    return None


def standing_cells(cell, d) -> list:
    """Cells a robot may stand on to push the object at `cell` in direction d (behind it,
    plus the two 45-degree-off cells: clear.mj_util.push_route's relaxed rule)."""
    dr, dc = d
    behind = (cell[0] - dr, cell[1] - dc)
    if dr == 0 or dc == 0:
        lat = (0, 1) if dr != 0 else (1, 0)
        return [behind, (behind[0] + lat[0], behind[1] + lat[1]), (behind[0] - lat[0], behind[1] - lat[1])]
    return [behind, (cell[0] - dr, cell[1]), (cell[0], cell[1] - dc)]


def object_route(scene: MazeScene, obj, target, can_drag: bool, robot_cell=None):
    """(cells, modes) along which `obj` can be moved to `target` (Sokoban rules, clear.mj_util.
    push_route.pushable_route), or None.  Other objects and raised/narrow cells block."""
    blocked = {o.cell for o in scene.objects if o is not obj} | scene.object_blocked_cells(obj)
    blocked.discard(tuple(obj.cell))
    return pushable_route(scene, tuple(obj.cell), tuple(target), blocked=blocked,
                          robot_cell=robot_cell, can_drag=can_drag)


class AbstractController(InteractionController):
    """Deterministic grid executor.  `body` is any FeasibilityModel; the scene is mutated as
    objects move.  Every robot step goes through `body.can_enter`, every interaction through
    `body.part_can_move` + the Sokoban route -- exactly the checks the privileged oracle
    plans with, so an oracle plan executes, and a plan that violates a capability fails at
    the violating step (spec 9.1: a kinematically valid plan that fails in execution scores 0).
    """
    name = "abstract"

    def __init__(self, scene: MazeScene, body, robot_cell=None):
        self.scene = scene
        self.body = body
        self.robot = tuple(scene.start if robot_cell is None else robot_cell)
        self.trajectory = [self.robot]
        self.attempted: set = set()
        self.log: list = []
        self.legs: list = []          # every transit leg (cell path) the robot walked, in order
        self.initial_cells = {o.object_id: tuple(o.cell) for o in scene.objects}

    # -- state ------------------------------------------------------------------------------
    def robot_state(self) -> dict:
        x, y = cell_to_world(self.robot, self.scene.cell_m)
        return {"cell": list(self.robot), "xy": [x, y]}

    def object_state(self) -> dict:
        return {int(o.object_id): {"cell": list(o.cell), "xy": list(cell_to_world(o.cell, self.scene.cell_m))}
                for o in self.scene.objects}

    def at_goal(self) -> bool:
        return tuple(self.robot) == tuple(self.scene.goal)

    def displacement_m(self) -> dict:
        """Planar centre displacement of every object from its initial cell (m)."""
        out = {}
        for o in self.scene.objects:
            a = np.array(cell_to_world(self.initial_cells[o.object_id], self.scene.cell_m))
            b = np.array(cell_to_world(o.cell, self.scene.cell_m))
            out[int(o.object_id)] = float(np.linalg.norm(a - b))
        return out

    def _result(self, ok, failure, before_obj, before_rob, info=None) -> ExecutionResult:
        res = ExecutionResult(bool(ok), None if ok else failure, before_obj, self.object_state(),
                              before_rob, self.robot_state(), dict(info or {}))
        self.log.append(res)
        return res

    # -- navigate -----------------------------------------------------------------------------
    def navigate(self, base_goal, observation=None) -> ExecutionResult:
        """`base_goal`: a target cell, or an explicit cell path (list) to follow.  A single
        cell is routed with the controller's OWN feasibility model (a real controller's
        local planner); a path is followed as given and fails at the first edge the body
        cannot take or the first occupied cell."""
        before_obj, before_rob = self.object_state(), self.robot_state()
        occ = {tuple(o.cell) for o in self.scene.objects}
        if isinstance(base_goal, (list, tuple)) and base_goal and isinstance(base_goal[0], (list, tuple)):
            path = [tuple(int(v) for v in c) for c in base_goal]
            if path[0] != self.robot:
                path = [self.robot] + path
        else:
            dst = tuple(int(v) for v in base_goal)
            path = bfs_cells(self.scene, self.body, self.robot, dst, blocked=occ)
            if path is None:
                return self._result(False, FailureType.UNREACHABLE_TARGET, before_obj, before_rob,
                                    {"reason": "no route", "target": list(dst)})
        for a, b in zip(path[:-1], path[1:]):
            if abs(a[0] - b[0]) + abs(a[1] - b[1]) != 1:
                return self._result(False, FailureType.CONTROLLER_TIMEOUT, before_obj, before_rob,
                                    {"reason": "non-adjacent waypoint", "at": list(a), "to": list(b)})
            if b in occ:
                return self._result(False, FailureType.ROBOT_COLLISION, before_obj, before_rob,
                                    {"reason": "occupied cell", "at": list(a), "to": list(b)})
            if not self.scene.can_enter(self.body, a, b):
                self.robot = a
                return self._result(False, FailureType.CONTROLLER_TIMEOUT, before_obj, before_rob,
                                    {"reason": "edge infeasible for body", "at": list(a), "to": list(b)})
            self.robot = b
            self.trajectory.append(b)
        self.legs.append([list(c) for c in path])
        return self._result(True, None, before_obj, before_rob, {"path": [list(c) for c in path]})

    # -- interact -------------------------------------------------------------------------------
    def interact(self, object_id, target_configuration, contact_point=None, body_part=None) -> ExecutionResult:
        """Move `object_id` to the target cell with `body_part`.  Preconditions (all checked
        with this controller's feasibility model): the part exists and can move the object,
        a Sokoban route exists, and every standing cell along it is reachable by the body.
        On success the object is at the target and the robot where the last move left it."""
        before_obj, before_rob = self.object_state(), self.robot_state()
        try:
            obj = self.scene.object_by_id(int(object_id))
        except KeyError:
            return self._result(False, FailureType.WRONG_OBJECT_SELECTION, before_obj, before_rob,
                                {"reason": f"unknown object {object_id}"})
        self.attempted.add(int(object_id))
        target = tuple(int(v) for v in (target_configuration if len(target_configuration) == 2
                                        else world_to_cell(target_configuration, self.scene.cell_m)))
        part = self.body.part(body_part) if body_part is not None else None
        if part is None:
            return self._result(False, FailureType.CONTACT_FAILURE, before_obj, before_rob,
                                {"reason": f"body part {body_part!r} unavailable"})
        ok, why = self.body.part_can_move(part, obj)
        if not ok:
            return self._result(False, FailureType(why), before_obj, before_rob,
                                {"reason": f"{part.name} cannot move object {object_id}", "check": why})
        if target == tuple(obj.cell):
            return self._result(True, None, before_obj, before_rob, {"reason": "already at target"})
        if not self.scene.in_bounds(target) or self.scene.is_wall(target) or target in self.scene.object_blocked_cells(obj) \
                or any(o is not obj and tuple(o.cell) == target for o in self.scene.objects):
            return self._result(False, FailureType.UNREACHABLE_TARGET, before_obj, before_rob,
                                {"reason": "target cell not placeable", "target": list(target)})
        route = object_route(self.scene, obj, target, can_drag=bool(part.can_grasp), robot_cell=self.robot)
        if route is None:
            return self._result(False, FailureType.UNREACHABLE_TARGET, before_obj, before_rob,
                                {"reason": "no push/pull route", "target": list(target)})
        cells, modes = route
        others = {tuple(o.cell) for o in self.scene.objects if o is not obj}
        for k in range(len(cells) - 1):
            a, b = cells[k], cells[k + 1]
            d = (b[0] - a[0], b[1] - a[1])
            if modes[k] == "push":
                cands = [s for s in standing_cells(a, d) if self.scene.in_bounds(s) and s not in others
                         and s != a and not self.scene.is_wall(s)]
                legs = [(s, bfs_cells(self.scene, self.body, self.robot, s, blocked=others | {a})) for s in cands]
                legs = [(s, p) for s, p in legs if p is not None]
                if not legs:
                    return self._result(False, FailureType.UNREACHABLE_TARGET, before_obj, before_rob,
                                        {"reason": "standing cell unreachable", "object_cell": list(a), "dir": list(d)})
                s, p = min(legs, key=lambda t: len(t[1]))
                self.trajectory += p[1:]
                self.legs.append([list(c) for c in p])
                obj.cell = b
                # the pusher advances into the cell the object left (if it can enter it)
                if self.scene.can_enter(self.body, s, a) and abs(s[0] - a[0]) + abs(s[1] - a[1]) == 1:
                    self.robot = a
                    self.trajectory.append(a)
                else:
                    self.robot = s
            else:  # pull: robot stands on the destination, grasps, retreats one cell further
                p = bfs_cells(self.scene, self.body, self.robot, b, blocked=others | {a})
                retreat = (b[0] + d[0], b[1] + d[1])
                if p is None or not self.scene.in_bounds(retreat) or retreat in others \
                        or not self.scene.can_enter(self.body, b, retreat):
                    return self._result(False, FailureType.UNREACHABLE_TARGET, before_obj, before_rob,
                                        {"reason": "pull stance unreachable", "object_cell": list(a)})
                self.trajectory += p[1:]
                self.legs.append([list(c) for c in p])
                obj.cell = b
                self.robot = retreat
                self.trajectory.append(retreat)
        return self._result(True, None, before_obj, before_rob,
                            {"route": [list(c) for c in cells], "modes": list(modes), "part": part.name})


# --------------------------------------------------------------------------------------
# factory


def _unavailable(name, why):
    def _make(*a, **k):
        raise NotImplementedError(f"controller {name!r} is not runnable on this host: {why}")
    return _make


CONTROLLERS = {
    "abstract": lambda scene, body, **kw: AbstractController(scene, body, **kw),
    "mujoco_policy": _unavailable("mujoco_policy", "physical execution is not part of this distribution"),
    "mjlab_native": _unavailable("mjlab_native", "physical execution is not part of this distribution"),
}


def make_controller(name: str, scene: MazeScene, body, **kw) -> InteractionController:
    try:
        factory = CONTROLLERS[name]
    except KeyError:
        raise KeyError(f"unknown controller {name!r}; choose from {sorted(CONTROLLERS)}")
    return factory(scene, body, **kw)
