"""Maze world model: `world` (scenes, observations, routes, the abstract controller) and
`robots` (body registry and link-level structure descriptions)."""
