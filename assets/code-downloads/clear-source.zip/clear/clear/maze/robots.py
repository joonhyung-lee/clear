"""robots: robot_registry, structure_parser, physical_registry.

robot_registry: Robot registry for the maze experiments: the four main bodies, the locked-joint
counterfactual, their controller-advertised body parts, and the PRIVILEGED capability
model (`BodyCapability`) the oracle, the scene generator and the executor use.

Two kinds of facts live here and are kept apart on purpose:

  static entry (RobotEntry)     asset path, root body, which joints a derived body locks,
                                which body parts the low-level controller can execute
                                (exp 03 spec section 4.3) with their nominal contact
                                geometry and strength.  Hand-written, versioned.
  measured limits (LocomotionLimits) step height, slope, passage width.  Nominal defaults
                                are shipped here; `experiments/exp3/
                                capability_probe.py` measures them on isolated probes and
                                writes `capability_tables.json`, which overrides the
                                defaults when present (provenance is recorded per value).

Nothing in this module is ever handed to a learned method.  Learned methods read the
structural description from `structure_parser.py` (link rows) and nothing else.

structure_parser: phi_B: the link-level structural description of a body (exp 03 spec 4.2).

Two views of the same MJCF, produced together so they cannot drift:

  links   the spec's serialisable schema, one entry per non-world body:
          link_id, parent_id, mass, inertia[3], geometry[...], joint_type, joint_range,
          actuator_gear, damping.  Written to <body>.json, hashed -> `structure_hash`.
  rows    the numeric (L, 20) matrix `clear.data.morphology.link_rows_v3_from_model`
          emits (the adopted encoder input, docs/CLEAR_FULL_OVERVIEW 4.1), padded to
          MAX_LINKS with a mask for the set-attention MorphologyEncoder.

Derived bodies (`RobotEntry.locked_joints`, e.g. g1_shoulder_locked) are produced by
deleting the locked joints (and the actuators/sensors on them) from the MJCF with MjSpec
before parsing -- the links stay, their incoming joint becomes 'fixed', gear and damping
vanish.  No new body ID is minted: the planner sees a different phi_B, nothing else.

No derived capability label (can_climb_stairs, max_push_mass, ...) is ever emitted here.

physical_registry: Versioned execution assets. Limits remain nominal until physical calibration.

Opt-in profile so historic abstract manifests/checkpoints retain their meaning.
"""
from __future__ import annotations

# ---- robot_registry ----
import json
import math
import os
from dataclasses import asdict, dataclass, field, replace
from typing import Any

ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "asset")

ROLES = ("body", "arm", "foot")        # signature-level body-part vocabulary (spec 7 + decision D3)


@dataclass(frozen=True)
class BodyPart:
    """One controller-executable interaction part.

    h_min/h_max: contact height range (m).  A pusher contacts at the LOWEST height it can
    (best for tipping) but must be below the object's top: feasible iff h_min <= obj height.
    reach_m > 0: an arm -- the base may stand up to reach_m from the object's face.
    can_grasp: pulling/dragging is allowed (the Sokoban "stand behind" rule is relaxed).
    """
    name: str
    role: str
    max_mass_kg: float
    max_extent_m: float
    h_min: float
    h_max: float
    reach_m: float = 0.0
    can_grasp: bool = False
    n_contacts: int = 1            # contact SET size the executor commands: 1 effector = 1 point,
    pair_separation_m: float = 0.0 # a two-hand pair = 2 points this far apart along the face (EAL 2.2)

    def __post_init__(self):
        assert self.role in ROLES, self.role
        assert self.n_contacts in (1, 2), self.n_contacts
        assert self.n_contacts == 1 or self.pair_separation_m > 0, "a pair needs a separation"


@dataclass(frozen=True)
class LocomotionLimits:
    max_step_m: float
    max_slope_deg: float
    width_m: float
    provenance: dict = field(default_factory=dict)   # value name -> tag


@dataclass(frozen=True)
class RobotEntry:
    embodiment_id: str
    asset: str                 # relative to asset/
    root_body: str
    parts: tuple               # tuple[BodyPart]
    loco: LocomotionLimits     # nominal defaults; capability_tables.json overrides
    base_id: str | None = None # derived bodies: the body they are derived from
    locked_joints: tuple = ()  # joints welded in the derived structural description
    color: str = "#444444"     # figure colour

    @property
    def part_names(self) -> tuple:
        return tuple(p.name for p in self.parts)


def role_of(part_name: str) -> str:
    if part_name in ROLES:
        return part_name
    for e in REGISTRY.values():
        for p in e.parts:
            if p.name == part_name:
                return p.role
    raise KeyError(part_name)


_NOM = "nominal"
_wheel_parts = (
    BodyPart("base_bumper", "body", max_mass_kg=6.0, max_extent_m=0.9, h_min=0.18, h_max=0.30),
)
_spot_parts = (
    BodyPart("torso", "body", max_mass_kg=8.0, max_extent_m=0.9, h_min=0.40, h_max=0.55),
    BodyPart("front_left_foot", "foot", max_mass_kg=2.0, max_extent_m=0.5, h_min=0.05, h_max=0.15),
    BodyPart("front_right_foot", "foot", max_mass_kg=2.0, max_extent_m=0.5, h_min=0.05, h_max=0.15),
)
_spot_arm_parts = (
    BodyPart("torso", "body", max_mass_kg=8.0, max_extent_m=0.9, h_min=0.40, h_max=0.55),
    BodyPart("gripper", "arm", max_mass_kg=4.0, max_extent_m=0.7, h_min=0.10, h_max=0.90, reach_m=1.0, can_grasp=True),
)
_g1_parts = (
    BodyPart("left_hand", "arm", max_mass_kg=8.0, max_extent_m=0.8, h_min=0.30, h_max=1.20, reach_m=0.55),
    BodyPart("right_hand", "arm", max_mass_kg=8.0, max_extent_m=0.8, h_min=0.30, h_max=1.20, reach_m=0.55),
    BodyPart("forearm", "arm", max_mass_kg=11.0, max_extent_m=0.9, h_min=0.60, h_max=1.00, reach_m=0.35),
    BodyPart("torso", "body", max_mass_kg=20.0, max_extent_m=0.9, h_min=0.55, h_max=0.95),
)
_g1_locked_parts = tuple(p for p in _g1_parts if p.role == "body")   # hand/forearm actions removed

REGISTRY: dict[str, RobotEntry] = {
    "husky": RobotEntry(
        "husky", "husky/husky_wo_plate.xml", "base_husky", _wheel_parts,
        LocomotionLimits(0.075, 10.0, 0.70,
                         {"max_step_m": _NOM, "max_slope_deg": _NOM, "width_m": _NOM}),
        color="#d95f02"),
    "spot": RobotEntry(
        "spot", "spot/spot.xml", "body", _spot_parts,
        LocomotionLimits(0.28, 25.0, 0.50, {"max_step_m": _NOM, "max_slope_deg": _NOM, "width_m": _NOM}),
        color="#1b9e77"),
    "spot_arm": RobotEntry(
        "spot_arm", "spot_w_arm/spot_arm_pos_native.xml", "body", _spot_arm_parts,
        LocomotionLimits(0.28, 25.0, 0.50, {"max_step_m": _NOM, "max_slope_deg": _NOM, "width_m": _NOM}),
        color="#7570b3"),
    "g1": RobotEntry(
        "g1", "g1/g1_pos_native.xml", "pelvis", _g1_parts,
        LocomotionLimits(0.38, 20.0, 0.46, {"max_step_m": _NOM, "max_slope_deg": _NOM, "width_m": _NOM}),
        color="#e7298a"),
    "g1_shoulder_locked": RobotEntry(
        "g1_shoulder_locked", "g1/g1_pos_native.xml", "pelvis", _g1_locked_parts,
        LocomotionLimits(0.38, 20.0, 0.46, {"max_step_m": _NOM, "max_slope_deg": _NOM, "width_m": _NOM}),
        base_id="g1",
        locked_joints=("left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint",
                       "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint"),
        color="#a6761d"),
}
MAIN_BODIES = ("husky", "spot", "spot_arm", "g1")
COUNTERFACTUAL_BODIES = ("g1_shoulder_locked",)
ALL_BODIES = MAIN_BODIES + COUNTERFACTUAL_BODIES


# --------------------------------------------------------------------------------------
# structural variants: capability DERIVED from the structure, not looked up by body id
#
# The four base entries above are hand-written tables keyed by body id, so a learner that sees
# only them can memorise four (phi_B, capability) pairs and has no reason to read joint-level
# structure (measured 2026-09-08: locking the G1 shoulders changes 6 of 30 phi_B rows and moves
# the trained planner's feasibility/edge outputs by exactly 0). A variant id
#     "<base>@lock=<joint>+<joint>+..."
# is a body whose listed joints are welded (deleted from the MjSpec, as `load_robot_spec` does
# for the canonical counterfactual) and whose PARTS are derived by one rule: a part survives
# iff no joint on its kinematic chain is locked. Training on a family of such variants gives
# the encoder the structure -> capability mapping the counterfactual test asks it to have.

PART_CHAINS = {   # base body -> part name -> joints that must all be free for the executor to use the part
    "spot_arm": {"gripper": ("arm_sh0", "arm_sh1", "arm_el0", "arm_el1", "arm_wr0", "arm_wr1")},
    "g1": {"left_hand": ("left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint"),
           "right_hand": ("right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint"),
           "forearm": ("left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint",
                       "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint"),
           "both_hands": ("left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint",
                          "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint")},
}
LOCK_GROUPS = {   # named joint groups a variant may lock (training family); the canonical test lock is excluded below
    "spot_arm": {"shoulder": ("arm_sh0", "arm_sh1"), "elbow": ("arm_el0", "arm_el1"), "wrist": ("arm_wr0", "arm_wr1")},
    "g1": {"left_shoulder": ("left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint"),
           "right_shoulder": ("right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint"),
           "left_elbow": ("left_elbow_joint",), "right_elbow": ("right_elbow_joint",)},
}
VARIANT_SEP = "@lock="


def derive_parts(base: RobotEntry, locked) -> tuple:
    """Parts of `base` that keep every joint of their chain free. Parts with no chain entry
    (torso, bumper, feet) never depend on the locked set."""
    chains = PART_CHAINS.get(base.base_id or base.embodiment_id, {})
    locked = set(locked)
    return tuple(p for p in base.parts if not (set(chains.get(p.name, ())) & locked))


def variant_id(base_id: str, locked) -> str:
    return base_id + VARIANT_SEP + "+".join(sorted(set(locked)))


def structural_variants(base_ids=("spot_arm", "g1"), max_groups: int = 2, exclude_canonical: bool = True) -> list:
    """Every non-empty combination of up to `max_groups` lock groups per base body, as variant ids.
    The canonical counterfactual (both G1 shoulders) is held out of the training family."""
    from itertools import combinations
    out = []
    for b in base_ids:
        groups = LOCK_GROUPS.get(b, {})
        names = sorted(groups)
        for k in range(1, max_groups + 1):
            for combo in combinations(names, k):
                joints = tuple(j for g in combo for j in groups[g])
                vid = variant_id(b, joints)
                if exclude_canonical and any(set(joints) == set(e.locked_joints) for k, e in REGISTRY.items()
                                             if e.locked_joints and VARIANT_SEP not in k):
                    continue
                out.append(vid)
    return out


def _make_variant(embodiment_id: str) -> RobotEntry:
    base_id, spec = embodiment_id.split(VARIANT_SEP, 1)
    base = REGISTRY[base_id]
    locked = tuple(sorted(set(j for j in spec.split("+") if j)))
    if not locked:
        raise ValueError(f"variant {embodiment_id!r} locks nothing")
    return replace(base, embodiment_id=embodiment_id, base_id=base_id, locked_joints=locked,
                   parts=derive_parts(base, locked))


def get(embodiment_id: str) -> RobotEntry:
    try:
        return REGISTRY[embodiment_id]
    except KeyError:
        if VARIANT_SEP in embodiment_id and embodiment_id.split(VARIANT_SEP, 1)[0] in REGISTRY:
            REGISTRY[embodiment_id] = _make_variant(embodiment_id)   # cached; configure() drops these
            return REGISTRY[embodiment_id]
        raise KeyError(f"unknown embodiment {embodiment_id!r}; registered: {sorted(REGISTRY)}")


def asset_path(embodiment_id: str) -> str:
    return os.path.join(ASSETS, get(embodiment_id).asset)


# --------------------------------------------------------------------------------------
# privileged capability model


def tip_limit_m(obj) -> float:
    """Highest contact height that still slides an object instead of tipping it:
    half of its narrowest footprint axis over the ground friction (capability.py rule,
    in metres, with the object's own friction)."""
    half = 0.5 * min(float(obj.dx_m), float(obj.dy_m))
    return half / max(float(obj.friction), 1e-3)


@dataclass(frozen=True)
class BodyCapability:
    """Exact feasibility predicates for one embodiment.  Read by the oracle, the
    generator and the executor only (spec 4.2: 'The oracle planner may use these
    capability predicates. CLEAR and learned baselines may not.')

    Duck-types `clear.data.capability.Embodiment` where `clear.data.oracle` needs it
    (`can_move`, `clearance`, `can_drag`, `traversable`), and adds the edge predicate
    `can_enter(scene, frm, to)` that `MazeScene.can_enter` dispatches to.
    """
    entry: RobotEntry
    loco: LocomotionLimits

    # -- Embodiment duck-typing ---------------------------------------------------------
    name: str = ""
    clearance: float = 0.0
    n_arms: int = 0

    @property
    def embodiment_id(self) -> str:
        return self.entry.embodiment_id

    @property
    def parts(self) -> tuple:
        return self.entry.parts

    @property
    def can_drag(self) -> bool:
        return any(p.can_grasp for p in self.parts)

    @property
    def traversable(self):
        from clear.data.capability import FLAT, STEP
        return frozenset({FLAT, STEP}) if self.loco.max_step_m >= 0.15 else frozenset({FLAT})

    @property
    def climb(self) -> float:
        return float(self.loco.max_step_m)

    @property
    def max_mass(self) -> float:
        return max((p.max_mass_kg for p in self.parts), default=0.0)

    @property
    def max_extent(self) -> float:
        return max((p.max_extent_m for p in self.parts), default=0.0)

    @property
    def push_height(self) -> float:
        return 0.0

    def can_traverse(self, terrain_class: int) -> bool:
        return terrain_class in self.traversable

    # -- traversal ------------------------------------------------------------------------
    def can_enter(self, scene, frm, to) -> bool:
        """Edge predicate: step-up, ramp slope and passage width of `to`, all against
        this body's limits.  Step DOWN is free (falling is allowed, as in clear.data.terrain)."""
        from clear.maze.world import edge_step_up
        if not scene.in_bounds(to):
            return False
        if float(scene.height[to]) >= scene.wall_h - 1e-6:
            return False
        if edge_step_up(scene, frm, to) > self.loco.max_step_m + 1e-6:
            return False
        if float(scene.slope_deg[to]) > self.loco.max_slope_deg + 1e-6:
            return False
        if float(scene.passage_width[to]) < self.loco.width_m - 1e-6:
            return False
        return True

    # -- interaction ------------------------------------------------------------------------
    def part(self, name: str) -> BodyPart | None:
        if name in ROLES:
            return next((p for p in self.parts if p.role == name), None)
        for p in self.parts:
            if p.name == name:
                return p
        return None

    def has_role(self, role: str) -> bool:
        return any(p.role == role for p in self.parts)

    def parts_for_role(self, role: str) -> list:
        return [p for p in self.parts if p.role == role]

    def part_can_move(self, part: BodyPart, obj) -> tuple[bool, str | None]:
        """(ok, failure_reason).  Reasons are the evaluator's failure taxonomy names."""
        if float(obj.mass) > part.max_mass_kg + 1e-9:
            return False, "CONTACT_FAILURE"
        if max(float(obj.dx_m), float(obj.dy_m)) > part.max_extent_m + 1e-9:
            return False, "CONTACT_FAILURE"
        if part.h_min > float(obj.height_m) + 1e-9:
            return False, "CONTACT_FAILURE"          # the part passes over the object
        if not part.can_grasp and part.h_min > tip_limit_m(obj) + 1e-9:
            return False, "OBJECT_TOPPLE"            # pushing above the tipping height
        return True, None

    def feasible_parts(self, obj) -> list:
        return [p for p in self.parts if self.part_can_move(p, obj)[0]]

    def can_move(self, obj) -> bool:
        return bool(self.feasible_parts(obj))

    def preferred_part(self, obj, need_grasp: bool = False) -> BodyPart | None:
        for p in self.parts:
            if need_grasp and not p.can_grasp:
                continue
            if self.part_can_move(p, obj)[0]:
                return p
        return None

    def to_dict(self) -> dict:
        return {"embodiment_id": self.embodiment_id, "loco": asdict(self.loco),
                "parts": [asdict(p) for p in self.parts]}


def body_capability(embodiment_id: str, tables: dict | None = None) -> BodyCapability:
    """The privileged capability model of a registered body, with measured locomotion
    limits from `tables` (see load_capability_tables) overriding the nominal defaults."""
    entry = get(embodiment_id)
    loco = entry.loco
    if tables and embodiment_id in tables:
        t = tables[embodiment_id]
        loco = LocomotionLimits(float(t.get("max_step_m", loco.max_step_m)),
                                float(t.get("max_slope_deg", loco.max_slope_deg)),
                                float(t.get("width_m", loco.width_m)),
                                dict(t.get("provenance", loco.provenance)))
    return BodyCapability(entry, loco, name=embodiment_id,
                          n_arms=sum(p.role == "arm" for p in entry.parts))


DEFAULT_TABLES_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                   "maze_embodiment", "data", "capability_tables.json")


def load_capability_tables(path: str | None = None) -> dict:
    """{embodiment_id: {max_step_m, max_slope_deg, width_m, provenance{}}} or {} when the
    probe has not been run.  Missing file is not an error: nominal defaults apply."""
    path = path or DEFAULT_TABLES_PATH
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f).get("bodies", {})


def all_capabilities(tables: dict | None = None, bodies=ALL_BODIES) -> dict:
    return {b: body_capability(b, tables) for b in bodies}


# ---- structure_parser ----
import hashlib

import mujoco
import numpy as np


STRUCTURE_DIM = 20      # morphology rows v3
MAX_LINKS = 64

_JOINT_NAMES = {int(mujoco.mjtJoint.mjJNT_FREE): "free", int(mujoco.mjtJoint.mjJNT_BALL): "ball",
                int(mujoco.mjtJoint.mjJNT_HINGE): "hinge", int(mujoco.mjtJoint.mjJNT_SLIDE): "slide"}
_GEOM_NAMES = {int(mujoco.mjtGeom.mjGEOM_BOX): "box", int(mujoco.mjtGeom.mjGEOM_SPHERE): "sphere",
               int(mujoco.mjtGeom.mjGEOM_CYLINDER): "cylinder", int(mujoco.mjtGeom.mjGEOM_CAPSULE): "capsule",
               int(mujoco.mjtGeom.mjGEOM_MESH): "mesh"}


@dataclass
class StructureDescription:
    embodiment_id: str
    source_asset: str
    locked_joints: list
    links: list                      # schema entries
    rows: np.ndarray                 # (L, STRUCTURE_DIM) float32
    structure_hash: str = ""
    extra: dict = field(default_factory=dict)

    @property
    def n_links(self) -> int:
        return len(self.links)

    def padded(self, max_links: int = MAX_LINKS):
        return padded_rows(self.rows, max_links)

    def to_json_dict(self) -> dict:
        return {"embodiment_id": self.embodiment_id, "source_asset": self.source_asset,
                "locked_joints": list(self.locked_joints), "structure_hash": self.structure_hash,
                "rows_version": 3, "rows": np.asarray(self.rows, dtype=float).round(6).tolist(),
                "links": self.links}


def load_robot_spec(entry: RobotEntry) -> mujoco.MjSpec:
    """MjSpec of the body's asset with `entry.locked_joints` welded (deleted)."""
    spec = mujoco.MjSpec.from_file(os.path.join(ASSETS, entry.asset))
    lock = set(entry.locked_joints)
    if lock:
        have = {j.name for j in spec.joints}
        missing = lock - have
        if missing:
            raise KeyError(f"{entry.embodiment_id}: locked joints not in {entry.asset}: {sorted(missing)}")
        for s in list(spec.sensors):
            if s.objname in lock:
                spec.delete(s)
        for a in list(spec.actuators):
            if a.target in lock:
                spec.delete(a)
        for j in list(spec.joints):
            if j.name in lock:
                spec.delete(j)
    return spec


def load_robot_model(entry: RobotEntry) -> mujoco.MjModel:
    return load_robot_spec(entry).compile()


def _links_schema(model: mujoco.MjModel) -> list:
    gear_by_jnt: dict[int, float] = {}
    for a in range(model.nu):
        if model.actuator_trntype[a] == mujoco.mjtTrn.mjTRN_JOINT:
            j = int(model.actuator_trnid[a, 0])
            gear_by_jnt[j] = max(gear_by_jnt.get(j, 0.0), abs(float(model.actuator_gear[a, 0])))
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    links = []
    for b in range(1, model.nbody):
        gadr, gnum = int(model.body_geomadr[b]), int(model.body_geomnum[b])
        geoms = []
        for g in range(gadr, gadr + gnum):
            geoms.append([_GEOM_NAMES.get(int(model.geom_type[g]), "other")]
                         + [round(float(v), 5) for v in model.geom_size[g]])
        jadr, jnum = int(model.body_jntadr[b]), int(model.body_jntnum[b])
        if jnum:
            j = jadr
            jtype = _JOINT_NAMES[int(model.jnt_type[j])]
            lo, hi = (float(v) for v in model.jnt_range[j])
            rng = [round(lo, 5), round(hi, 5)] if hi > lo else [0.0, 0.0]
            gear = round(gear_by_jnt.get(j, 0.0), 5)
            damping = round(float(model.dof_damping[int(model.jnt_dofadr[j])]), 5)
        else:
            jtype, rng, gear, damping = "fixed", [0.0, 0.0], 0.0, 0.0
        links.append({
            "link_id": b - 1,
            "parent_id": None if int(model.body_parentid[b]) == 0 else int(model.body_parentid[b]) - 1,
            "name": mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, b),
            "mass": round(float(model.body_mass[b]), 5),
            "inertia": [round(float(v), 6) for v in model.body_inertia[b]],
            "geometry": [round(float(v), 5) for v in model.body_pos[b]] + [round(float(data.xpos[b][2]), 5)]
                        + [len(geoms), max((max(g[1:]) for g in geoms), default=0.0)],
            "geoms": geoms,
            "joint_type": jtype,
            "joint_range": rng,
            "actuator_gear": gear,
            "damping": damping,
        })
    return links


def structure_hash(links: list) -> str:
    """sha256 of the canonical schema (names excluded -- the hash is about structure, not
    labels).  Stable across processes; changes when any joint is locked or any mass moves."""
    canon = [{k: v for k, v in l.items() if k != "name"} for l in links]
    return hashlib.sha256(json.dumps(canon, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def parse_structure(entry_or_id) -> StructureDescription:
    entry = entry_or_id if isinstance(entry_or_id, RobotEntry) else get(entry_or_id)
    from clear.data.morphology import link_rows_v3_from_model
    model = load_robot_model(entry)
    rows = link_rows_v3_from_model(model).astype(np.float32)
    assert rows.shape[1] == STRUCTURE_DIM, rows.shape
    assert 2 <= rows.shape[0] <= MAX_LINKS, rows.shape
    assert np.isfinite(rows).all(), entry.embodiment_id
    links = _links_schema(model)
    assert len(links) == rows.shape[0]
    desc = StructureDescription(entry.embodiment_id, entry.asset, list(entry.locked_joints), links, rows)
    desc.structure_hash = structure_hash(links)
    return desc


def padded_rows(rows: np.ndarray, max_links: int = MAX_LINKS):
    """-> (rows (max_links, D) float32, mask (max_links,) bool)."""
    rows = np.asarray(rows, dtype=np.float32)
    out = np.zeros((max_links, rows.shape[1]), dtype=np.float32)
    mask = np.zeros(max_links, dtype=bool)
    out[: len(rows)] = rows
    mask[: len(rows)] = True
    return out, mask


def write_structure_file(desc: StructureDescription, path: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as f:
        json.dump(desc.to_json_dict(), f, indent=1, sort_keys=True)
    return path


def read_structure_file(path: str) -> StructureDescription:
    with open(path) as f:
        d = json.load(f)
    desc = StructureDescription(d["embodiment_id"], d["source_asset"], list(d.get("locked_joints", [])),
                                d["links"], np.asarray(d["rows"], dtype=np.float32), d["structure_hash"])
    return desc


_CACHE: dict[str, StructureDescription] = {}


def structure_for(embodiment_id: str) -> StructureDescription:
    """Cached parse for a registered body."""
    if embodiment_id not in _CACHE:
        _CACHE[embodiment_id] = parse_structure(embodiment_id)
    return _CACHE[embodiment_id]


# ---- physical_registry ----
def configure():
    REGISTRY['spot'] = replace(REGISTRY['spot'], asset='spot_deployment/spot.xml',
        parts=tuple(p for p in REGISTRY['spot'].parts if p.role == 'body'))
    REGISTRY['spot_arm'] = replace(REGISTRY['spot_arm'], asset='spot_deployment/spot_arm.xml',
        parts=tuple(replace(p, can_grasp=False) for p in REGISTRY['spot_arm'].parts))
    base = REGISTRY['g1']
    hand = next(p for p in base.parts if p.role == 'arm')
    REGISTRY['g1'] = replace(base, parts=(replace(hand, name='both_hands', n_contacts=2, pair_separation_m=0.28),
        next(p for p in base.parts if p.role == 'body')))
    for k in [k for k in REGISTRY if VARIANT_SEP in k]:   # variants derive from the configured base
        del REGISTRY[k]
    _CACHE.clear()
