"""Data and vendored source locations in a standalone CLEAR checkout."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ASSET = ROOT / 'asset'
EXP3_PROBES = ASSET / 'experiments/exp3/probes'
THIRD_PARTY = ROOT / 'third_party'
MJLAB = THIRD_PARTY / 'mjlab'
SUMO = Path(os.environ.get('SUMO_REPO', THIRD_PARTY / 'sumo'))
MENAGERIE = Path(os.environ.get('CLEAR_MENAGERIE', ASSET / 'menagerie'))
