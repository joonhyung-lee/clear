"""Embodiment capability: what terrain can I cross, what objects can I move.

Phase 1 is hardcoded from the structured prior (URDF-derivable numbers).
The rest of the codebase only ever calls `can_traverse` / `can_move`, so
swapping in a learned probe later touches this file and nothing else.

# ponytail: hardcoded predicates. Replace the bodies with a learned probe
# (self-supervised patch encoder + proprioceptive-risk regression) only once
# a fixed-capability agent actually trains and the ordering learns. A probe
# that returns 0/1 on toy terrain is the same function with 3 training stages
# bolted in front of it.
"""

from dataclasses import dataclass

FLAT, STEP, WALL = 0, 1, 2
TERRAIN_NAMES = {FLAT: "flat", STEP: "step", WALL: "wall"}


@dataclass(frozen=True)
class Embodiment:
    name: str
    traversable: frozenset  # terrain classes this body can cross
    max_mass: float  # heaviest object it can displace (0 = no manipulation)
    max_extent: float  # largest object bbox axis it can grasp/push, in cells
    n_arms: int
    climb: float = None  # metres of step-up, when the body was DEFINED metrically.
    #                      None for the three class-table bodies, whose limit is
    #                      derived by terrain.climb_limit instead. When it is set
    #                      it is authoritative: `traversable` was derived FROM it,
    #                      so the descriptor the model reads and the class table
    #                      the oracle plans with cannot disagree.
    can_drag: bool = False  # can PULL an object toward itself (gripper/arm): the pusher's Sokoban rule
    # is relaxed -- the robot may stand on the destination side and retreat one cell. Planning-only
    # today (2026-08-28, PLAN 134): the multi-object executors push; spot_barrier_drag.py shows the
    # Spot arm can drag but that is a separate task. Derived for measured robots from arm_reach > 0
    # with a gripper (spot_w_arm); G1 without wrists cannot grasp.
    push_height: float = 0.0  # metres: the height at which THIS body's end effector
    # contacts an object it pushes. 0.0 (default, every existing body/checkpoint) =
    # not modelled, and `can_move` behaves exactly as before.
    #
    # Why it is a capability at all (docs/CLEAR_ARCHITECTURE.md §5, measured
    # 2026-08-27): a box pushed at height h tips instead of sliding once
    # h > half_width / friction. half_width and friction are the OBJECT's, h is the
    # BODY's -- so the same box is pushable by Spot (~0.45 m contact) and tips under
    # G1 (~0.75 m). Unlike mass and extent, this axis does NOT order the bodies:
    # a taller, stronger body is WORSE on small objects. That non-inclusion is the
    # whole point -- rooms is a capability-inclusion stage, which is why kappa
    # shuffling there costs nothing physically (CLEAR_ARCHITECTURE §5).
    clearance: float = 0.0  # cells of open lateral room this body's own footprint
    # needs BESIDE an object to interact with it -- same resolution-agnostic "in
    # grid cells" convention as max_extent, not metres (the abstract Scene has no
    # metric cell_size at all). 0.0 (every body until this is explicitly set) is
    # inert. Added this session (docs/HANDOFF_pamo_push_maze.md's obj_1
    # investigation): mass/extent alone said quadruped COULD move a real box that
    # a physical Spot then spent 59s never getting closer than 0.887m to, wedged
    # in a 1-cell-wide slot between two walls. A hard-gate version of this field
    # (an object flanked on both sides of an axis was simply infeasible) was
    # tried first and reverted: on the seed that motivated it, EVERY object was
    # flanked-or-too-heavy, so the whole scene went from "solvable" to
    # "unsolvable" instead of finding the honest best-available order -- the
    # grid's own resolution can't actually certify a flanked cell is
    # impassable (the true failure had open neighbor cells on two sides), so a
    # hard reject overclaimed certainty a 1-cell-coarse check doesn't have.
    # `clearance`/flanked-ness is now read ONLY by oracle.py's search, as a
    # soft cost that makes the solver prefer a non-flanked mover when one
    # exists and still use a flanked one when it's the only way -- see
    # oracle.py's `_flanked` and `_neighbors`. can_move itself stays pure
    # mass/extent, as it always was.

    def can_traverse(self, terrain: int) -> bool:
        return terrain in self.traversable

    def can_move(self, obj) -> bool:
        """obj needs .mass and .extent (max bbox axis, in grid cells).

        With `push_height` set, the tipping limit joins the mass/extent gates:
        the object tips (rather than slides) when the contact height exceeds
        half_width / friction. Cells are metres in every physical bridge this
        repo has (ProjectionSpec cell_size 1.0), so extent/2 IS the half width.
        push_height = 0.0 keeps the old two-term predicate byte-identical.
        """
        if obj.mass > self.max_mass or obj.extent > self.max_extent:
            return False
        return self.push_height <= 0.0 or self.push_height <= tip_limit(obj.extent)


PUSH_FRICTION = 0.5  # object-ground friction assumed by the tipping limit. The
# measured value for our boxes (docs/CLEAR_ARCHITECTURE.md §5: 0.25 / 0.5 = 0.50 m,
# vs the SUMO table's 0.52 / 0.3 = 1.73 m). One constant, not per-object, until a
# generator actually varies friction.


def tip_limit(extent: float) -> float:
    """Highest contact point (metres) that still slides an object of this bbox
    axis instead of tipping it: half_width / friction."""
    return (extent / 2.0) / PUSH_FRICTION


WHEEL = Embodiment("wheel", frozenset({FLAT}), max_mass=2.0, max_extent=0.6, n_arms=0)
QUADRUPED = Embodiment("quadruped", frozenset({FLAT, STEP}), max_mass=5.0, max_extent=0.8, n_arms=0,
                      clearance=1.0)  # the one embodiment this session actually validates
# physically -- see Embodiment.clearance's own docstring for why this value (not a
# tuned constant, just "one full cell of slack", the coarsest meaningful setting).
HUMANOID = Embodiment("humanoid", frozenset({FLAT, STEP}), max_mass=20.0, max_extent=1.5, n_arms=2)

QUADRUPED_ARM = Embodiment("quadruped_arm", frozenset({FLAT, STEP}), max_mass=5.0, max_extent=0.8, n_arms=1,
                          clearance=1.0, can_drag=True)  # Spot with the arm: same base, plus pulling (PLAN 134).
# NOT in EMBODIMENTS: build_examples samples every registered body by default, so registering it would change
# the training distribution (tests/test_core.py::test_rejection moved 0.95 -> 0.948 when it was). Planner-side
# callers that want the dragging Spot import this constant explicitly (experiments/g1_probe/gate1_rooms.py).

EMBODIMENTS = {e.name: e for e in (WHEEL, QUADRUPED, HUMANOID)}

# Contact heights for the three class bodies, in metres. quadruped/humanoid stand in
# for Spot-with-arm (~0.45) and G1 (~0.75) as measured in docs/CLEAR_ARCHITECTURE.md
# §5; wheel gets a low pusher plate. ASSIGNED, not measured for these three.
PUSH_HEIGHTS = {"wheel": 0.20, "quadruped": 0.45, "humanoid": 0.75}


TIP_HEIGHTS = (0.15, 0.35, 0.55, 0.75)  # metres, the span Spot(~0.45)/G1(~0.75) sit inside


def tipping_variants(heights = TIP_HEIGHTS, base = None):
    """Each base body at several contact heights, everything else identical.

    Why this and not `tipping_bodies`: with one height per body, [mass, extent,
    arms, climb] identifies the body exactly, so the cheapest way to fit the
    plan heads is to look the body up and never read the height at all -- the
    same failure `terrain.synthetic_embodiment`'s own docstring describes for
    the climb channel, and the one measured for push_height in
    experiments/kappa_tipping/RESULTS.md. Variants that differ ONLY in height
    make the probe row the only thing that can separate them.
    """
    from dataclasses import replace
    base = base or EMBODIMENTS
    return {f"{n}_h{int(100 * h):03d}": replace(e, name = f"{n}_h{int(100 * h):03d}",
                                                push_height = h)
            for n, e in base.items() for h in heights}


def tipping_bodies(scale: float = 1.0):
    """EMBODIMENTS with contact heights attached -> capability stops being a chain.

    `scale` < 1 stands in for a lower pusher plate or a rougher floor. Measured
    trade-offs per scale and per object-size distribution:
    experiments/kappa_tipping/RESULTS.md.
    """
    from dataclasses import replace
    return {n: replace(e, push_height = scale * PUSH_HEIGHTS[n]) for n, e in EMBODIMENTS.items()}
EMBODIMENT_IDS = {name: i for i, name in enumerate(EMBODIMENTS)}


def feature_vector(emb: Embodiment) -> list:
    """Low-dim structured prior fed to the network as the embodiment token.

    `clearance` added 2026-08-20 (rooms physical-stall investigation): the
    field has existed since the session that found the underlying physical
    problem (a quadruped wedged in a 1-cell-wide slot, see `Embodiment.
    clearance`'s own docstring) but was only ever read by oracle.py's ORDER
    search (`_flanked`/`n_flanked_moved`, a soft tie-break) -- never exposed
    to the network at all. `build_examples` already samples all of
    `EMBODIMENTS` by default, so oracle's own order LABELS already vary with
    `clearance` (quadruped's flanked-avoidance tie-break fires, wheel/
    humanoid's don't, since both are still at the 0.0 "not yet calibrated"
    default) -- PAMO had no input feature that could explain that variance.
    This closes that gap for quadruped specifically; wheel/humanoid's 0.0 is
    still a placeholder, not a validated "needs no clearance" claim (see
    `Embodiment.clearance`'s docstring) -- calibrating those is future work,
    not done here. BREAKING: changes FEATURE_DIM, invalidates every existing
    checkpoint's capability-encoder input layer -- retrain, don't reuse."""
    return [
        float(FLAT in emb.traversable),
        float(STEP in emb.traversable),
        emb.max_mass / 20.0,
        emb.max_extent,
        emb.n_arms / 2.0,
        emb.clearance,
    ]


FEATURE_DIM = 6


def physical_vector(emb: Embodiment, climb: float = None, use_arm: bool = False) -> list:
    """Metric descriptor for the perception path: what the body can do, in
    physical units, with no reference to the FLAT/STEP/WALL abstraction.

    feature_vector() above encodes traversability as class membership, so it
    can only ever describe the three bodies the class table was written for.
    A metric climb limit is continuous, which is what lets the capability
    encoder be tested on a body it never saw -- the only evidence that it
    learned to compare a step against a limit rather than memorise three
    lookup rows.

    `climb` overrides the derived limit; that override IS the unseen-body test.

    `use_arm`: is THIS approach-path variant assuming the body reaches out
    with an arm (judo SpotBase's own `use_arm` flag), or does it plan to make
    contact with the body itself. Not a property of the embodiment class --
    two profiles can share the same `emb` and differ only here (see
    waypoint_data.PROFILES "quadruped" vs "quadruped_arm").
    """
    from clear.data.terrain import climb_limit  # local: terrain imports this module

    c = climb_limit(emb) if climb is None else float(climb)
    return [
        c,                              # metres of step-up, unnormalised here
        emb.max_mass / 20.0,
        emb.max_extent,
        emb.n_arms / 2.0,
        float(emb.max_mass > 0.0),      # can it manipulate at all
        float(use_arm),                 # does THIS variant's route assume arm reach
    ]


PHYSICAL_DIM = 6

# ARM_REACH_MARGIN: how much farther an arm-reach approach can stand off vs a
# body-contact one. Promoted here from waypoint_data.py (2026-08-21,
# docs/PLAN_verification_and_sota_comparison.md §21) so spot_push_bridge.py's
# geometric feasibility check and waypoint_data.py's PRM standoff both read
# one number instead of two independently-hardcoded copies. ponytail: still a
# placeholder, no measured Spot arm reach in this repo -- replace once a real
# value is load-bearing (same caveat waypoint_data.py's original carried).
ARM_REACH_MARGIN = 0.35
