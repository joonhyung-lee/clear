"""Toy 2D PAMO scene: terrain grid + movable objects + start/goal.

This is the phase-1 stand-in for the MuJoCo maze. Same abstraction the oracle
solver runs on, so when the real maze arrives it only needs a projection into
this struct -- not a second solver.
"""

import heapq
from dataclasses import dataclass, field

import numpy as np

from clear.data.capability import FLAT, STEP, WALL, Embodiment

POSE_DIM = 4  # x, y, cos(theta), sin(theta)


@dataclass
class Obj:
    cell: tuple  # (row, col) occupied cell -- blocks traversal
    mass: float
    extent: float  # max bbox axis in grid cells
    theta: float = 0.0
    goal_cell: tuple | None = None  # where the oracle parks it
    local_points: np.ndarray | None = None  # (k, 2) real footprint samples, grid-cell
    # units, OFFSET from this object's own current position -- not baked to a fixed
    # world position, precisely so it stays correct as oracle.py's sequential search
    # moves this object: re-anchor at query time by adding whatever position is
    # CURRENTLY assumed for it (positions[j] in find_parking, not necessarily this
    # object's own .cell) -- see attach_geometry_points()/oracle.py's
    # _path_clips_object. None (every scene until attach_geometry_points runs, and
    # every caller that never calls it) means "no richer shape known" -- callers fall
    # back to the single-point circular check this field replaces.

    @property
    def pose(self) -> np.ndarray:
        r, c = self.cell
        return np.array([c, r, np.cos(self.theta), np.sin(self.theta)], dtype=np.float32)

    def goal_pose(self, goal_theta: float) -> np.ndarray:
        r, c = self.goal_cell if self.goal_cell is not None else self.cell
        return np.array([c, r, np.cos(goal_theta), np.sin(goal_theta)], dtype=np.float32)


@dataclass
class Scene:
    terrain: np.ndarray  # (H, W) int in {FLAT, STEP, WALL}
    start: tuple
    goal: tuple
    objects: list = field(default_factory=list)
    height: np.ndarray | None = None  # (H, W) float metres, when the scene is
    #   metric. `terrain` is then a DERIVED view of it (see height_to_terrain),
    #   kept because object logic, the scene tensor, viz and the MJCF extrusion
    #   all still speak classes. None = the class world, unchanged.
    wall_points: np.ndarray | None = None  # (m, 2) real WALL-cell footprint
    # samples, grid-cell units, ABSOLUTE (walls are static, no re-anchoring needed
    # unlike Obj.local_points). None until attach_geometry_points() runs -- see
    # its own docstring and oracle.py's _path_clips_wall (2026-08-21, closes the
    # gap that nothing ever checked a straight push path against a wall at all,
    # only against other objects -- see docs/... oracle-anatomy artifact §6's
    # seed 1006 corner case).

    @property
    def shape(self):
        return self.terrain.shape

    @property
    def metric(self) -> bool:
        return self.height is not None

    def occupied(self) -> dict:
        return {o.cell: i for i, o in enumerate(self.objects)}

    def in_bounds(self, cell) -> bool:
        r, c = cell
        h, w = self.terrain.shape
        return 0 <= r < h and 0 <= c < w

    def can_enter(self, emb: Embodiment, frm, to) -> bool:
        """THE body-dependent traversal predicate. Every planner check goes
        through here so the two worlds cannot drift apart.

        Metric scene: climbing is a property of the EDGE -- the body clears the
        step-up from where it stands to where it steps, and a step down is
        always free. Class scene: the cell-class lookup, bit-for-bit what it
        always was, so `height=None` leaves every existing number untouched.
        """
        if self.height is None:
            return emb.can_traverse(int(self.terrain[to]))
        from clear.data.terrain import climb_limit
        return float(self.height[to] - self.height[frm]) <= climb_limit(emb) + 1e-6

    def can_start(self, emb: Embodiment) -> bool:
        """Whether the body can be standing where the scene puts it. In a
        metric world it always can -- height is where you are, not a gate you
        passed -- so only the class world can refuse."""
        return True if self.height is not None else emb.can_traverse(int(self.terrain[self.start]))

    def free_cells(self, emb: Embodiment) -> list:
        """Cells the body could stand on, ignoring objects."""
        h, w = self.terrain.shape
        if self.height is not None:
            return [(r, c) for r in range(h) for c in range(w)
                    if int(self.terrain[r, c]) != WALL]
        return [
            (r, c) for r in range(h) for c in range(w) if emb.can_traverse(int(self.terrain[r, c]))
        ]

    def tensor(self) -> np.ndarray:
        """(C, H, W) float encoding for the scene CNN."""
        h, w = self.terrain.shape
        chans = np.zeros((5, h, w), dtype=np.float32)
        for k, cls in enumerate((FLAT, STEP, WALL)):
            chans[k] = self.terrain == cls
        chans[3][self.start] = 1.0
        chans[4][self.goal] = 1.0
        return chans


def _rect_perimeter_points(half: float, theta: float, n: int) -> np.ndarray:
    """n points around a `half`-half-size square's perimeter, rotated by
    theta -- the oriented-footprint proxy every Obj already carries all the
    data for (extent, theta) but that _path_clips_object used to ignore,
    treating every object as a rotation-blind circle. Evenly spaced by
    parameter along each of the 4 edges (not true arc-length uniform, close
    enough at n~16 -- this is a cheap proxy, not a physics mesh)."""
    per_edge = max(1, n // 4)
    t = np.linspace(-half, half, per_edge, endpoint=False)
    edges = [
        np.stack([t, np.full_like(t, half)], axis=1),
        np.stack([np.full_like(t, half), -t], axis=1),
        np.stack([-t, np.full_like(t, -half)], axis=1),
        np.stack([np.full_like(t, -half), t], axis=1),
    ]
    pts = np.concatenate(edges)
    c, s = np.cos(theta), np.sin(theta)
    R = np.array([[c, -s], [s, c]])
    return pts @ R.T


def _wall_cell_points(scene: "Scene", n_per_cell: int, rng: np.random.Generator) -> np.ndarray:
    """n_per_cell grid-cell-unit points per WALL cell, jittered uniformly
    within that cell's own unit square. Every WALL cell IS exactly a unit
    square at this grid's resolution -- no finer truth to recover for a
    synthetic scene -- so this exists to give a straight-line check something
    to test against at all (see attach_geometry_points), not to add precision
    beyond the grid's own."""
    rows, cols = np.where(scene.terrain == WALL)
    if len(rows) == 0:
        return np.zeros((0, 2))
    jitter = rng.uniform(-0.5, 0.5, size=(len(rows) * n_per_cell, 2))
    centers = np.repeat(np.stack([rows, cols], axis=1).astype(float), n_per_cell, axis=0)
    return centers + jitter


def attach_geometry_points(scene: "Scene", n_per_object: int = 16, n_per_wall_cell: int = 4,
                           seed: int = 0) -> None:
    """Populate every Obj.local_points and Scene.wall_points analytically --
    no MuJoCo needed. Every generator in this file already knows an object's
    true oriented footprint (extent + theta) and a WALL cell's true footprint
    (its own unit square) exactly; this just exposes that existing geometry to
    oracle.py's straight-line checks (_path_clips_object, _path_clips_wall)
    instead of collapsing objects to a rotation-blind circle and never
    checking walls at all (2026-08-21, docs/PLAN_verification_and_sota_
    comparison.md §21/§22, the oracle-anatomy artifact's diagnosed gaps).

    Mutates `scene` in place -- same convention `assign_goal_cells` already
    uses for `goal_cell`. Opt-in: call this on a scene before handing it to
    oracle.solve()/find_parking if you want the richer checks; a scene that
    never calls this keeps every field at its None default and oracle.py's
    checks fall back to exactly their old behavior -- zero risk to any
    existing caller (bulk synthetic training-data generation included, unless
    it's updated to call this too).
    """
    rng = np.random.default_rng(seed)
    for obj in scene.objects:
        obj.local_points = _rect_perimeter_points(obj.extent / 2.0, obj.theta, n_per_object)
    scene.wall_points = _wall_cell_points(scene, n_per_wall_cell, rng)


CARD = ((-1, 0), (1, 0), (0, -1), (0, 1))
DIAG = ((-1, -1), (-1, 1), (1, -1), (1, 1))
SQRT2 = 2 ** 0.5


def _free(terrain: np.ndarray, cell: tuple) -> bool:
    h, w = terrain.shape
    r, c = cell
    return 0 <= r < h and 0 <= c < w and terrain[cell] != WALL


def cell_path(terrain: np.ndarray, start: tuple, goal: tuple) -> list:
    """Shortest cell-to-cell path, 8-directional (diagonal moves allowed),
    Dijkstra-weighted (cardinal cost 1, diagonal cost sqrt2). A diagonal step
    is only legal when BOTH flanking cardinal cells are free -- otherwise it
    would cut through a wall corner -- so it detours cardinally around a
    blocked corner instead. Cell-to-cell, not edge-only: direct movement
    between cells is allowed, just never through a wall.

    Callers only invoke this once a path is already known to exist (e.g.
    after assign_goal_cells picked `goal` via a walls-and-objects-avoiding
    BFS, which is strictly more restrictive than walls-only, so a walls-only
    path is guaranteed)."""
    if start == goal:
        return [start]
    dist = {start: 0.0}
    parent = {}
    pq = [(0.0, start)]
    while pq:
        d, cell = heapq.heappop(pq)
        if d > dist.get(cell, d):
            continue
        if cell == goal:
            break
        r, c = cell
        for dr, dc in CARD:
            nxt = (r + dr, c + dc)
            if _free(terrain, nxt):
                nd = d + 1.0
                if nd < dist.get(nxt, float("inf")):
                    dist[nxt] = nd
                    parent[nxt] = cell
                    heapq.heappush(pq, (nd, nxt))
        for dr, dc in DIAG:
            nxt = (r + dr, c + dc)
            flank1, flank2 = (r + dr, c), (r, c + dc)
            if _free(terrain, nxt) and _free(terrain, flank1) and _free(terrain, flank2):
                nd = d + SQRT2
                if nd < dist.get(nxt, float("inf")):
                    dist[nxt] = nd
                    parent[nxt] = cell
                    heapq.heappush(pq, (nd, nxt))
    path = [goal]
    while path[-1] != start:
        path.append(parent[path[-1]])
    path.reverse()
    return path


def gp_field(rng: np.random.Generator, h: int, w: int, length: float) -> np.ndarray:
    """One squared-exponential GP prior sample on the cell-center grid.
    K = exp(-|x-x'|^2 / len^2), sampled via Cholesky -- the sparse half of the
    two-stage scheme; the continuous world is the SAME field rendered densely
    (dense interpolation lives in viz/figure code, not here)."""
    ys, xs = np.mgrid[0:h, 0:w]
    pts = np.stack([xs.ravel(), ys.ravel()], 1).astype(np.float64)
    d2 = ((pts[:, None, :] - pts[None, :, :]) ** 2).sum(-1)
    K = np.exp(-d2 / length**2)
    chol = np.linalg.cholesky(K + 1e-8 * np.eye(h * w))
    return (chol @ rng.standard_normal(h * w)).reshape(h, w)


def _connected(terrain: np.ndarray, a: tuple, b: tuple) -> bool:
    """BFS reachability avoiding WALL (cardinal moves)."""
    from collections import deque
    if terrain[a] == WALL or terrain[b] == WALL:
        return False
    h, w = terrain.shape
    seen, q = {a}, deque([a])
    while q:
        r, c = q.popleft()
        if (r, c) == b:
            return True
        for dr, dc in CARD:
            nxt = (r + dr, c + dc)
            if 0 <= nxt[0] < h and 0 <= nxt[1] < w and nxt not in seen and terrain[nxt] != WALL:
                seen.add(nxt)
                q.append(nxt)
    return False


MAX_PHYSICAL_EXTENT = 0.9  # largest fraction of a cell an object's physical footprint
# is ever actually rendered at -- clear/mj_util/demo_spot_maze_push.py,
# batch_physical_eval.py, and mj_maze.py's own scene_to_mjcf all separately cap
# extent at this same value. `gp_scene`/`random_scene` below check placement
# clearance against THIS value (not the raw, uncapped `extent` they sample,
# which can go up to 1.4 -- an oracle-capability threshold, not a real size)
# so a scene that passes here can't spawn overlapping physically.

PLACEMENT_MARGIN = 0.12  # cells of slack beyond bare contact. Found the hard way
# (2026-08-20, docs/PREREGISTRATION_physical_ablation_eval.md's disturbance-rate
# investigation): objects were being placed with ZERO adjacency check at all --
# MuJoCo's own contact report showed real objects spawned 0.15-0.19m INSIDE a
# wall or another object, launching violently on the very first physics step,
# in ~45% of episodes. 0.12 cells is comfortably more than the ~0.05-cell gap a
# MAX_PHYSICAL_EXTENT=0.9 object leaves against a cell boundary it never used to
# check at all.


def _wall_adjacent_extent_ok(terrain: np.ndarray, cell: tuple, extent: float,
                             margin: float = PLACEMENT_MARGIN) -> bool:
    """True if an object this wide, centered on `cell`, clears every WALL (or
    off-grid) cardinal neighbor by at least `margin`. A cell being FLAT was
    the only thing ever checked before -- never whether the object's own
    footprint reaches past that cell's boundary into a neighbor's."""
    half = min(extent, MAX_PHYSICAL_EXTENT) / 2.0
    if half + margin <= 0.5:
        return True  # doesn't reach the boundary even with margin -- neighbors irrelevant
    r, c = cell
    h, w = terrain.shape
    for dr, dc in CARD:
        nr, nc = r + dr, c + dc
        if not (0 <= nr < h and 0 <= nc < w) or terrain[nr, nc] == WALL:
            return False
    return True


def _objects_clear(cell_a: tuple, extent_a: float, cell_b: tuple, extent_b: float,
                   margin: float = PLACEMENT_MARGIN) -> bool:
    """True if two objects' physical footprints (axis-aligned boxes centered
    on their own cells) don't overlap, with `margin` slack."""
    half_a = min(extent_a, MAX_PHYSICAL_EXTENT) / 2.0
    half_b = min(extent_b, MAX_PHYSICAL_EXTENT) / 2.0
    dist = float(np.hypot(cell_a[0] - cell_b[0], cell_a[1] - cell_b[1]))
    return dist >= half_a + half_b + margin


def _try_place(rng: np.random.Generator, candidates: list, terrain: np.ndarray, placed: list,
               ext_lo: float, ext_hi: float, tries_per_cell: int = 3):
    """Pop candidate cells (mutates `candidates`, shuffled by the caller)
    until one, paired with a freshly sampled extent in [ext_lo, ext_hi),
    clears the terrain's walls and every object already in `placed` --
    resampling extent a few times per cell before giving up on it, since a
    smaller draw can fit where a larger one didn't. -> (cell, extent), or
    None once candidates run out."""
    while candidates:
        cell = candidates.pop()
        for _ in range(tries_per_cell):
            extent = float(rng.uniform(ext_lo, ext_hi))
            if not _wall_adjacent_extent_ok(terrain, cell, extent):
                continue
            if all(_objects_clear(cell, extent, p.cell, p.extent) for p in placed):
                return cell, extent
    return None


def gp_scene(rng: np.random.Generator, h=16, w=16, n_objects=6, length=None,
             wall_q=0.72) -> Scene:
    """GP-prior terrain: one SE field, one threshold -> flat/wall. No STEP --
    every embodiment shares the same traversal capability here; capability
    differences (if any) come only from mass/extent, not terrain.
    length defaults to U(2, 4.5) so terrain style itself is a diversity axis
    (1.5 = shattered maze, 6 = open plains).

    Objects: plugs go on CHOKE cells -- path cells whose removal disconnects
    start from goal -- so clearing them is genuinely required (organic GP
    terrain has too many alternate routes for naive on-path placement; that
    variant measured n_moved ~ 0). Terrain without at least one choke cell is
    resampled. The rest scatter on free cells. Solvability per embodiment is
    still the oracle's call in build_examples.
    """
    for _ in range(256):
        L = float(length) if length is not None else float(rng.uniform(2.0, 4.5))
        field = gp_field(rng, h, w, L)
        wall_t = np.quantile(field, wall_q)
        terrain = np.where(field > wall_t, WALL, FLAT).astype(np.int64)

        free = [(int(r), int(c)) for r, c in np.argwhere(terrain != WALL)]
        if len(free) < n_objects + 8:
            continue
        start = free[int(rng.integers(len(free)))]
        far = [c for c in free if abs(c[0] - start[0]) + abs(c[1] - start[1]) >= (h + w) // 2]
        rng.shuffle(far)
        goal = next((c for c in far if _connected(terrain, start, c)), None)
        if goal is None:
            continue

        path = cell_path(terrain, start, goal)
        chokes = []
        for c in path[1:-1]:
            orig = terrain[c]
            terrain[c] = WALL
            if not _connected(terrain, start, goal):
                chokes.append(c)
            terrain[c] = orig
        if not chokes:
            continue
        rng.shuffle(chokes)
        rest = [c for c in free if c not in set(chokes) and c not in (start, goal)]
        rng.shuffle(rest)

        # light-plug scenes (p=0.3): plugs movable by the wheel body too
        # (mass <= 2, extent <= 0.6) -- without this, chokes are humanoid-only
        # and wheel all but vanishes from the data (measured 1/235 examples)
        light = rng.random() < 0.3
        plug_mass_hi, plug_ext_hi = (2.0, 0.6) if light else (18.0, 1.4)

        objects = []
        while len(objects) < 2 and chokes:
            got = _try_place(rng, chokes, terrain, objects, 0.3, plug_ext_hi)
            if got is None:
                break
            cell, extent = got
            objects.append(Obj(
                cell=cell,
                # plugs stay liftable by at least one embodiment so hard
                # scenes survive the oracle filter instead of being dropped
                mass=float(np.exp(rng.uniform(np.log(0.5), np.log(plug_mass_hi)))),
                extent=extent, theta=float(rng.uniform(-np.pi, np.pi)),
            ))
        if not objects:
            continue  # no choke had room for even a plug's own footprint -- resample

        while len(objects) < n_objects and rest:
            got = _try_place(rng, rest, terrain, objects, 0.3, 1.4)
            if got is None:
                break
            cell, extent = got
            objects.append(Obj(
                cell=cell,
                mass=float(np.exp(rng.uniform(np.log(0.5), np.log(25.0)))),
                extent=extent, theta=float(rng.uniform(-np.pi, np.pi)),
            ))
        # same tolerance the original code had for a short `rest` pool -- fewer
        # objects than n_objects rather than a forced resample, `rest` running
        # out here is no different from it always being shorter than needed.
        return Scene(terrain=terrain, start=start, goal=goal, objects=objects)
    raise RuntimeError("gp_scene: no connected terrain in 256 resamples")


# Metric terrain constants. WALL_H is the floor of the wall band: nothing in
# TRAIN_CLIMB/EVAL_CLIMB reaches it, so walls stay walls for every body and the
# scene keeps the maze structure the ordering task needs. WALK_MAX is sampled
# per scene so different scenes place their steps against different limits.
# Floor of the wall band. It must clear WALK_MAX + the largest climb limit any
# body is given, or a body standing on a high platform simply steps onto the
# wall: at 1.20 with walk_max 1.10 and climb 0.95 the most capable bodies
# walked over the maze and their plans stopped moving anything (n_moved 0.22
# against the class world's 1.57). Walls carry the ordering task; they are not
# allowed to be terrain. (mj_maze.WALL_H is the class world's slab height, a
# different quantity.)
METRIC_WALL_H = 2.20

# Fraction of cells held at exactly ground level. The class world hands every
# body one large connected FLAT region, and the ordering task is built on the
# assumption that a body can move around at all. A pure ramp has some Delta h
# on every edge, so a 0.05 m body is trapped where it stands -- yield for the
# lowest climb band fell to 0.01 against the class world's 0.27. The plain
# restores a floor everyone shares; the ramp above it still separates limits.
FLAT_Q = 0.40
# Top of the walkable ramp, sampled per scene. Chosen by measuring what the
# oracle can actually distinguish (25-30 scenes, grid 12, 9 climb limits from
# 0.05 to 0.90; "differ" = two limits inside the held-out band yield different
# reachable sets):
#
#   walk_max      length      distinct sets   0.25 vs 0.40 differ   yield
#   (class world)               2.00 / 9          0.00             1.11
#   0.30-0.85     2.0-4.5       4.24              0.28             --
#   0.45-1.10     2.0-4.5       4.90              0.63             0.79
#   0.45-1.10     1.8-3.5       5.57              0.73             --
#   0.60-1.20     1.5-3.0       6.44              0.92             --
#
# Rougher terrain buys discriminability and costs solvable examples. This takes
# the middle: it leaves the length scale at gp_scene's own U(2, 4.5) so the
# maze keeps its character, and gets the separation from height alone.
WALK_MAX_RANGE = (0.45, 1.10)

# ...and on this fraction of scenes the ramp is nearly flat instead. Direct
# analogue of gp_scene dropping the step band with p=0.35, for the same
# reason: a body is only in the data if some scene is solvable for it, and a
# 0.05 m climb limit clears almost no edge on a ramp. Without this the lowest
# climb band yielded 0.00 examples against the class world's 0.27, and the
# bottom third of TRAIN_CLIMB was dead weight in the descriptor.
FLAT_SCENE_P = 0.35
FLAT_SCENE_RANGE = (0.02, 0.12)


def height_to_terrain(height: np.ndarray) -> np.ndarray:
    """The class view of a metric surface, for everything that still speaks
    classes: object placement, Scene.tensor, viz, the MJCF extrusion.

    Thresholds match CLASS_HEIGHT's own boundaries (STEP 0.15, WALL 1.0), so a
    class scene round-trips through here unchanged. This is a lossy view by
    design -- the planner reads `height`, never this.
    """
    return np.where(height >= 1.0, WALL,
                    np.where(height >= 0.075, STEP, FLAT)).astype(np.int64)


def _gp_surface(rng, h, w, length, wall_q, walk_max):
    """(height, terrain) for one metric scene. Split out because the
    discriminating generator needs the same surface with different object
    placement, and two copies of the height maths would drift."""
    L = float(length) if length is not None else float(rng.uniform(2.0, 4.5))
    top = (float(walk_max) if walk_max is not None else
           float(rng.uniform(*(FLAT_SCENE_RANGE if rng.random() < FLAT_SCENE_P
                               else WALK_MAX_RANGE))))
    f = gp_field(rng, h, w, L)
    # Rank-transform to uniform so wall_q means the same fraction of cells
    # whatever the field's realised scale, then map to metres: a flat plain, a
    # continuous walkable ramp above it, the wall band above that.
    u = f.argsort(axis = None).argsort().reshape(f.shape) / max(1, f.size - 1)
    ramp = np.clip((u - FLAT_Q) / max(1e-9, wall_q - FLAT_Q), 0.0, 1.0)
    height = np.where(u >= wall_q,
                      METRIC_WALL_H + (u - wall_q) / max(1e-9, 1 - wall_q) * 0.6,
                      top * ramp).astype(np.float32)
    return height, height_to_terrain(height)


def reach_at(height: np.ndarray, start: tuple, climb: float, blocked = ()) -> np.ndarray:
    """(H, W) bool: cells a body with this climb limit can reach from `start`.

    Limit-parameterised twin of terrain.reachable_mask, which needs an
    Embodiment. Scene generation has to ask the question for a limit it has not
    built a body for yet.
    """
    from collections import deque
    hh, ww = height.shape
    blocked = set(blocked)
    seen = np.zeros((hh, ww), bool)
    if start in blocked:
        return seen
    seen[start] = True
    q = deque([start])
    while q:
        r, c = q.popleft()
        for dr, dc in CARD:
            nr, nc = r + dr, c + dc
            if (0 <= nr < hh and 0 <= nc < ww and not seen[nr, nc]
                    and (nr, nc) not in blocked
                    and float(height[nr, nc] - height[r, c]) <= climb + 1e-6):
                seen[nr, nc] = True
                q.append((nr, nc))
    return seen


def gp_height_scene(rng: np.random.Generator, h=16, w=16, n_objects=6, length=None,
                    wall_q=0.72, walk_max=None) -> Scene:
    """Continuously-metric terrain: the SAME SE-GP field gp_scene samples, kept
    as metres instead of thresholded into three classes.

    This is the change the end-to-end results asked for. Under three class
    heights the oracle's terrain capability is a 2-bit function of the climb
    limit, so every held-out body is class-identical to a trained one and no
    plan-level capability claim is testable -- `cap0 SR` barely moved while
    `cap0 edge` collapsed (RESULTS_E2E.md §3). Here the step-up between two
    adjacent cells takes a continuous range, so two bodies whose limits differ
    by centimetres genuinely get different reachable sets and the oracle plans
    differently for them.

    Walls are kept as a band above METRIC_WALL_H rather than dissolved into the
    continuum: they carry the maze structure the ordering task is built on, and
    a surface with no impassable cells has no chokepoints to plug.
    """
    for _ in range(64):
        height, terrain = _gp_surface(rng, h, w, length, wall_q, walk_max)

        free = [(int(r), int(c)) for r, c in np.argwhere(terrain != WALL)]
        if len(free) < n_objects + 8:
            continue
        start = free[int(rng.integers(len(free)))]
        far = [c for c in free if abs(c[0] - start[0]) + abs(c[1] - start[1]) >= (h + w) // 2]
        rng.shuffle(far)
        goal = next((c for c in far if _connected(terrain, start, c)), None)
        if goal is None:
            continue

        path = cell_path(terrain, start, goal)
        chokes = []
        for c in path[1:-1]:
            orig = terrain[c]
            terrain[c] = WALL
            if not _connected(terrain, start, goal):
                chokes.append(c)
            terrain[c] = orig
        if not chokes:
            continue
        rng.shuffle(chokes)
        plugs = chokes[:2]
        rest = [c for c in free if c not in set(plugs) and c not in (start, goal)]
        rng.shuffle(rest)
        cells = plugs + rest[: n_objects - len(plugs)]

        light = rng.random() < 0.3
        plug_mass_hi, plug_ext_hi = (2.0, 0.6) if light else (18.0, 1.4)
        objects = [
            Obj(
                cell = cell,
                mass = float(np.exp(rng.uniform(np.log(0.5),
                                    np.log(plug_mass_hi if k < len(plugs) else 25.0)))),
                extent = float(rng.uniform(0.3, plug_ext_hi if k < len(plugs) else 1.4)),
                theta = float(rng.uniform(-np.pi, np.pi)),
            )
            for k, cell in enumerate(cells)
        ]
        return Scene(terrain = terrain, start = start, goal = goal, objects = objects,
                     height = height)
    raise RuntimeError("gp_height_scene: no connected terrain in 64 resamples")


# Probe limits the discriminating generator plans against. They bracket the
# range bodies are actually drawn from (0.02 - 0.95), so a body's limit lands on
# one side or the other and the plan it needs follows from that.
PROBE_LO = (0.05, 0.30)
PROBE_HI = (0.45, 0.90)


def gp_discriminating_scene(rng: np.random.Generator, h=16, w=16, n_objects=6,
                            length=None, walk_max=None, n_bands=None) -> Scene:
    """A metric scene whose PLAN depends on the climb limit, not just whose
    reachable set does.

    Continuous heights made the reachable set a continuous function of the
    limit and left the plan alone: two bodies differing only in climb limit got
    identical oracle order sets on 95% of gp_height_scene scenes, because
    chokepoint plugs sit on the wall structure and walls stop everybody. So
    `cap0 SR` could not drop -- there was nothing in the ordering task for the
    capability channel to carry (RESULTS_METRIC.md).

    The fix is in where objects go, not in the terrain -- but it has to be
    CONSTRUCTED, not searched for. Rejection-sampling gp_height_scene for a
    scene holding both a universal and a capability-specific chokepoint found
    one in 4 of 100, at every wall density tried (0.72 to 0.86): organic GP
    terrain has too many alternate routes for universal chokes, which is the
    same observation gp_scene's own docstring records.

    So the structure is built, the way random_scene builds it. Wall bands span
    the grid with a gap or two each, every gap plugged, over a continuously
    varying floor. Then one band gets a LEDGE: a single cell raised to sit a
    sampled step above the floor either side of it.

      the plugged gaps      block everybody, so every body keeps an ordering
                            task and n_moved >= 1 survives
      the ledge             is a step of `lo < step <= hi`. A capable body
                            climbs over that band and skips its plug; a weak
                            body cannot and must clear it.

    The weak body's plan clears every band's plug; the capable body's skips
    one. The difference is caused by the climb limit and nothing else.
    """
    n_bands = n_bands or max(2, (h - 2) // 4)
    for _ in range(64):
        lo = float(rng.uniform(*PROBE_LO))
        hi = float(rng.uniform(*PROBE_HI))
        # Pure walkable ramp: wall_q above 1 keeps _gp_surface from carving any
        # wall band of its own, because the bands below are the structure here.
        floor, _ = _gp_surface(rng, h, w, length, 1.01, walk_max)
        height = floor.copy()

        edges = np.linspace(1, h - 1, n_bands + 1).astype(int)
        rows = []
        for a, b in zip(edges[:-1], edges[1:]):
            r = int(rng.integers(a, max(a + 1, b)))
            if r in (0, h - 1) or r in rows:
                continue
            rows.append(r)
        if len(rows) < 2:
            continue

        gaps = {}
        for r in rows:
            height[r, :] = METRIC_WALL_H + rng.uniform(0, 0.4, w).astype(np.float32)
            cols = rng.choice(w, size = int(rng.integers(1, 3)), replace = False)
            height[r, cols] = floor[r, cols]
            gaps[r] = [(r, int(c)) for c in cols]

        # The ledge. Its two approach cells must be near enough in height that
        # one step clears the band from EITHER side for the capable body, or it
        # is a one-way crossing and the bypass is not a bypass.
        ledge_row = rows[int(rng.integers(len(rows)))]
        ledge = None
        for c in rng.permutation(w):
            c = int(c)
            if (ledge_row, c) in gaps[ledge_row]:
                continue
            a, b = float(floor[ledge_row - 1, c]), float(floor[ledge_row + 1, c])
            slack = hi - abs(a - b)
            if slack <= lo + 0.02:
                continue
            step = float(rng.uniform(lo + 0.01, slack))
            height[ledge_row, c] = max(a, b) + step
            ledge = (ledge_row, c)
            break
        if ledge is None:
            continue

        terrain = height_to_terrain(height)
        start = (0, int(rng.integers(0, w)))
        goal = (h - 1, int(rng.integers(0, w)))
        if start in (ledge,) or goal in (ledge,):
            continue

        # Verify against the oracle's own rule rather than trusting the
        # construction. Three conditions, and each one is load-bearing.
        plugs = [g for r in rows for g in gaps[r]]
        ledge_plugs = gaps[ledge_row]
        if reach_at(height, start, hi, blocked = plugs)[goal]:
            continue    # with everything plugged even the capable body must be
            #             stuck, or it has no ordering task and n_moved hits 0
        if not reach_at(height, start, hi, blocked = ledge_plugs)[goal]:
            continue    # clearing the OTHER bands must be enough for it: the
            #             ledge is what carries it over the band it skips
        if reach_at(height, start, lo, blocked = ledge_plugs)[goal]:
            continue    # and must NOT be enough for the weak body, or the
            #             ledge is climbable by both and discriminates nothing
        if not reach_at(height, start, lo)[goal]:
            continue    # weak body must be able to solve it once plugs are gone

        taken = set(plugs) | {start, goal, ledge}
        rest = [(int(r), int(c)) for r, c in np.argwhere(terrain != WALL)
                if (int(r), int(c)) not in taken]
        rng.shuffle(rest)
        cells = plugs[:n_objects] + rest[: max(0, n_objects - len(plugs))]

        # Every plug must be liftable by at least one body: the weak body has
        # to clear ALL of them, so one immovable plug drops the scene for it and
        # takes the capability contrast with it.
        n_plug = min(len(plugs), n_objects)
        objects = [
            Obj(
                cell = cell,
                mass = float(np.exp(rng.uniform(np.log(0.5),
                                    np.log(16.0 if k < n_plug else 25.0)))),
                extent = float(rng.uniform(0.3, 1.3 if k < n_plug else 1.4)),
                theta = float(rng.uniform(-np.pi, np.pi)),
            )
            for k, cell in enumerate(cells)
        ]
        return Scene(terrain = terrain, start = start, goal = goal, objects = objects,
                     height = height)
    raise RuntimeError("gp_discriminating_scene: no qualifying terrain in 64 resamples")


def two_route_scene(rng: np.random.Generator, h=12, w=12, ledge_h=0.15,
                    n_objects=4, plug_mass=None, passage_len=1) -> Scene:
    """Two ways past one wall band, plugged by DIFFERENT objects.

    The plan's variant A, built so the climb limit decides which object gets
    moved rather than merely which way the robot walks.

        step route  short, crosses a ledge `ledge_h` tall, plugged by object A
        flat route  long, at ground level, plugged by object B

    A body that clears the ledge takes the short route and moves A. One that
    cannot must detour and move B. Same scene, same goal, different order set —
    which is the thing that stayed 95% identical when only the terrain was made
    continuous (RESULTS_METRIC.md), because both routes were plugged by the
    same object.

    Sweeping `ledge_h` is the point: it puts a body's own limit on the x-axis,
    so the capability token has to compare against it instead of keying on
    which of three robots it is. Note the sweep only exists in metres -- with
    three terrain classes the ledge is 0.15 m and nothing else.

    `plug_mass = (short, long)` moves the gate from climbing to strength: make
    the short route's plug heavy and the long one's light, and a body that
    cannot lift the heavy plug has to detour exactly as a body that cannot
    climb does. Default keeps both plugs light so the climb is the only gate --
    one axis at a time, or a probe cannot say which one moved the plan.
    """
    band = h // 2
    col_s = int(rng.integers(1, w // 2))                  # step gap, near start
    col_f = int(rng.integers(w // 2 + 1, w - 1))          # flat gap, far side

    height = np.zeros((h, w), np.float32)
    height[band, :] = METRIC_WALL_H
    height[band, col_s] = float(ledge_h)
    height[band, col_f] = 0.0
    band_rows = {band}
    if passage_len == 2:
        # 2026-08-26 (user decision): no box ever sits ON the ledge. The wall band
        # becomes two rows thick; each gap is a 2-cell passage whose START-side
        # cell is flat and holds the plug, the ledge cell behind it stays empty.
        height[band - 1, :] = METRIC_WALL_H
        height[band - 1, col_s] = 0.0
        height[band - 1, col_f] = 0.0
        band_rows.add(band - 1)
        plugs = [(band - 1, col_s), (band - 1, col_f)]
    else:
        plugs = [(band, col_s), (band, col_f)]

    start, goal = (0, col_s), (h - 1, col_s)
    taken = set(plugs) | {start, goal}
    rest = [(r, c) for r in range(h) for c in range(w)
            if r not in band_rows and (r, c) not in taken]
    rng.shuffle(rest)
    cells = plugs + rest[: max(0, n_objects - len(plugs))]

    def plug_m(k):
        if plug_mass is None:
            return float(rng.uniform(0.4, 1.6))
        return float(plug_mass[k])          # 0 = step route, 1 = flat route

    objects = [
        Obj(cell = cell,
            mass = plug_m(k) if k < len(plugs)
            else float(np.exp(rng.uniform(np.log(0.5), np.log(25.0)))),
            # plug extents stay small so mass is the only strength gate
            extent = float(rng.uniform(0.25, 0.55)) if k < len(plugs)
            else float(rng.uniform(0.3, 1.4)),
            theta = float(rng.uniform(-np.pi, np.pi)))
        for k, cell in enumerate(cells)
    ]
    return Scene(terrain = height_to_terrain(height), start = start, goal = goal,
                 objects = objects, height = height)


def scene_from_text(text, ledge_h = 0.30, mass = None, extent = None,
                    wall_h = None) -> Scene:
    """A hand-drawn maze. One character per cell, row 0 at the top.

        #  wall          .  floor           L  ledge, `ledge_h` metres
        S  robot start   G  goal            0-9  a movable object, by id

    `mass` and `extent` are dicts keyed by that digit; anything unlisted gets
    1.0 kg and 0.4 cells. `ledge_h` may be a dict too, if different ledges
    should differ.

        scene_from_text('''
            #########
            #...S...#
            #.#L#.#.#
            #.......#
            #..0.1..#
            #...G...#
            #########''', ledge_h = 0.3, mass = {0: 12.0, 1: 1.0})

    Exists so a scene can be DESIGNED rather than sampled. Every generator in
    this file encodes assumptions that turned out to decide the result -- one
    of them made "always clear the far plug" score 0.81 without reading the
    body -- and a drawn scene puts those assumptions where they can be seen.
    """
    rows = [r.strip() for r in text.strip().splitlines() if r.strip()]
    h, w = len(rows), max(len(r) for r in rows)
    wall = float(wall_h if wall_h is not None else METRIC_WALL_H)
    height = np.zeros((h, w), np.float32)
    start = goal = None
    objects, ids = [], []
    mass = mass or {}
    extent = extent or {}

    for r, row in enumerate(rows.copy()):
        for c, ch in enumerate(row.ljust(w, '#')):
            if ch == '#':
                height[r, c] = wall
            elif ch == 'L':
                lh = ledge_h[len(ids)] if isinstance(ledge_h, dict) else ledge_h
                height[r, c] = float(lh)
            elif ch == 'S':
                start = (r, c)
            elif ch == 'G':
                goal = (r, c)
            elif ch.isdigit():
                ids.append(int(ch))
                objects.append(Obj(cell = (r, c), mass = float(mass.get(int(ch), 1.0)),
                                   extent = float(extent.get(int(ch), 0.4)), theta = 0.0))
    if start is None or goal is None:
        raise ValueError('the map needs both an S and a G')
    # objects are ordered by their digit, so mass={0: ...} always names the
    # same one however the map is drawn
    objects = [o for _, o in sorted(zip(ids, objects), key = lambda p: p[0])]
    return Scene(terrain = height_to_terrain(height), start = start, goal = goal,
                 objects = objects, height = height)


def rescale_extents(scene: Scene, rng, hi: float, lo: float = 0.3) -> Scene:
    """Resample every object's bbox axis in [lo, hi], in place.

    The generators draw 0.3-1.4 cells, which is narrow enough that the tipping
    limit (extent/2 / friction) sits below every realistic contact height --
    measured: at the real heights the humanoid loses 100% of rooms_fork scenes
    (experiments/kappa_tipping/RESULTS.md). The physical session's own fix for
    G1 was to widen the BOX, not lower the robot; this is that knob.

    Note `extent` above MAX_PHYSICAL_EXTENT (0.9) only widens the capability
    gates (`can_move`'s max_extent, `tip_limit`); the physical footprint used
    for clearance geometry stays clipped at 0.9 by `attach_geometry_points`.
    """
    for o in scene.objects:
        o.extent = float(rng.uniform(lo, hi))
    return scene


def roll_scene(scene: Scene, dr: int, dc: int) -> Scene:
    """The same scene translated on the torus: identical topology and identical
    object/terrain relations, only the ABSOLUTE coordinates change.

    Used two ways (2026-08-31, docs/EXPERIMENT_afford_channel_ood_2026-08-31.md
    §4): as a probe -- a model that reads the scene scores the same at every
    shift, one with an absolute-coordinate prior does not -- and as training
    augmentation, which denies that prior a fixed frame to attach to. Goal
    cells are cleared because they are an oracle output, not scene state; the
    caller re-solves the rolled scene.
    """
    m = lambda cell: ((cell[0] + dr) % scene.shape[0], (cell[1] + dc) % scene.shape[1])
    return Scene(
        terrain = np.roll(np.roll(scene.terrain, dr, axis = 0), dc, axis = 1),
        start = m(scene.start), goal = m(scene.goal),
        objects = [Obj(**{**vars(o), 'cell': m(o.cell), 'goal_cell': None}) for o in scene.objects],
        height = None if scene.height is None else
                 np.roll(np.roll(scene.height, dr, axis = 0), dc, axis = 1),
    )


def chain_scene(rng: np.random.Generator, h=16, w=16, depth=5) -> Scene:
    """Serial-corridor scene: `depth` objects queued in a one-wide corridor,
    so the ONLY valid order is front-to-back -- a forced precedence chain of
    length `depth`. This family absorbs the Hanoi role: order accuracy sliced
    by chain depth measures how far the priority head's ordering carries.

    Open rows at top and bottom give the robot parking room; the corridor
    column is randomized so the network cannot memorize a location.
    """
    assert depth <= h - 4, "corridor must fit between the open rows"
    terrain = np.full((h, w), WALL, dtype=np.int64)
    terrain[0, :] = FLAT
    terrain[h - 1, :] = FLAT
    col = int(rng.integers(1, w - 1))
    terrain[1 : h - 1, col] = FLAT

    start = (0, int(rng.integers(0, w)))
    goal = (h - 1, int(rng.integers(0, w)))

    first = int(rng.integers(2, h - 1 - depth))  # queue start row, inside corridor
    objects = [
        Obj(
            cell=(first + k, col),
            mass=float(np.exp(rng.uniform(np.log(0.5), np.log(18.0)))),
            extent=float(rng.uniform(0.3, 1.4)),
            theta=float(rng.uniform(-np.pi, np.pi)),
        )
        for k in range(depth)
    ]
    return Scene(terrain=terrain, start=start, goal=goal, objects=objects)


def random_scene(rng: np.random.Generator, h=8, w=8, n_objects=4) -> Scene:
    """Corridor-style maze: a wall band with a couple of gaps, some of them
    plugged by movable objects. No STEP terrain -- every embodiment shares
    the same traversal capability; only mass/extent differ.

    Retries the whole terrain+placement pair (like gp_scene already did),
    not just placement alone: a plug/open-cell pool this tight sometimes has
    no arrangement with real clearance at all, and a fresh wall-band draw is
    more likely to open one up than re-shuffling the same pool would be."""
    for _ in range(64):
        terrain = np.full((h, w), FLAT, dtype=np.int64)

        # Wall bands between start and goal, count scaling with grid height, so the
        # robot must cross several. One band alone can never require clearing two
        # objects in sequence, which is the case the whole ordering claim rests on.
        # 8x8 -> 2 bands (the validated setting), 16x16 -> 3.
        n_bands = max(2, (h - 2) // 4)
        edges = np.linspace(1, h - 1, n_bands + 1).astype(int)
        plugged = []
        for lo, hi in zip(edges[:-1], edges[1:]):
            row = int(rng.integers(lo, max(lo + 1, hi)))
            terrain[row, :] = WALL
            n_gaps = int(rng.integers(1, 2 + w // 8))  # w=8 -> 1-2, w=16 -> 1-3
            gaps = rng.choice(w, size=n_gaps, replace=False)
            terrain[row, gaps] = FLAT
            # plug EVERY gap of this band most of the time -> crossing it demands a
            # move. Leaving a gap open (the old default) made blockers optional and
            # collapsed the ordering task to nothing.
            keep_open = 0 if rng.random() < 0.75 else 1
            band = [(row, int(g)) for g in gaps]
            rng.shuffle(band)
            plugged += band[: max(0, len(band) - keep_open)]

        start = (0, int(rng.integers(0, w)))
        goal = (h - 1, int(rng.integers(0, w)))
        terrain[start] = FLAT
        terrain[goal] = FLAT
        plugged = [c for c in plugged if terrain[c] != WALL and c not in (start, goal)]
        rng.shuffle(plugged)

        open_cells = [
            (r, c)
            for r in range(h)
            for c in range(w)
            if terrain[r, c] != WALL and (r, c) not in (start, goal) and (r, c) not in set(plugged)
        ]
        rng.shuffle(open_cells)

        # Gap plugs must be liftable by at least one embodiment, else the scene is
        # unsolvable for everyone and gets dropped -- capping mass below humanoid's
        # 20.0 keeps the hard scenes in the dataset instead of filtering them out.
        objects = []
        plug_pool = list(plugged)
        while len(objects) < min(n_objects, len(plugged)) and plug_pool:
            got = _try_place(rng, plug_pool, terrain, objects, 0.3, 1.4)
            if got is None:
                break
            cell, extent = got
            objects.append(Obj(cell=cell,
                mass=float(np.exp(rng.uniform(np.log(0.5), np.log(18.0)))),
                extent=extent, theta=float(rng.uniform(-np.pi, np.pi))))
        if plugged and not objects:
            continue  # not one gap plug had room for its own footprint -- resample

        while len(objects) < n_objects and open_cells:
            got = _try_place(rng, open_cells, terrain, objects, 0.3, 1.4)
            if got is None:
                break
            cell, extent = got
            objects.append(Obj(cell=cell,
                mass=float(np.exp(rng.uniform(np.log(0.5), np.log(25.0)))),
                extent=extent, theta=float(rng.uniform(-np.pi, np.pi))))
        return Scene(terrain=terrain, start=start, goal=goal, objects=objects)
    raise RuntimeError("random_scene: no valid placement in 64 resamples")


def walled_room_scene(rng: np.random.Generator, h=8, w=8, n_objects=4, n_rows=None) -> Scene:
    """Closed corridor: left/right walls for the whole run (never open on the
    sides, unlike gp_scene/random_scene's floating wall bands), n_rows
    cross-gates staggered so consecutive gaps don't line up -- forces an
    S-shaped walk, not a straight shot. Same structural idea as
    2027-icra/exp3_teleop_spot_h1/demo_spot_arm_maze.py's gen_maze (user's own
    reference, 2026-08-20) -- staggered chained gates, one blocker parked in
    each throat, decoys in the open rooms between -- expressed natively in
    grid cells instead of porting its metric constants (2.2m gate, 0.15m
    wall). Porting those verbatim would hit the exact aliasing 6A already
    found this session (grid=8 can't represent that combination at any
    cell_size); staying in cell units sidesteps it by construction, the same
    way gp_scene/random_scene always have.

    n_rows=None (default) draws the gate-row COUNT and POSITIONS at random
    per scene -- was a fixed linspace(2 rows always in the same 2 spots)
    before; every scene had an identical skeleton and only the gap column
    varied. Pass an int to pin n_rows for a reproducible demo frame."""
    row_lo, row_hi = 2, h - 3
    max_rows = max(1, (row_hi - row_lo) // 2 + 1)  # how many rows fit with spacing>=2
    for _ in range(64):
        terrain = np.full((h, w), FLAT, dtype=np.int64)
        terrain[:, 0] = WALL
        terrain[:, w - 1] = WALL

        rows_n = n_rows if n_rows is not None else int(rng.integers(1, max_rows + 1))
        row_candidates = list(range(row_lo, row_hi + 1))
        rng.shuffle(row_candidates)
        rows = []
        for r in row_candidates:
            if all(abs(r - x) >= 2 for x in rows):
                rows.append(r)
            if len(rows) == rows_n:
                break
        rows.sort()
        if len(rows) != rows_n:
            continue  # grid too short for this many separated gate rows

        prev_gap = None
        gaps = []
        for row in rows:
            candidates = [c for c in range(1, w - 1)
                         if prev_gap is None or abs(c - prev_gap) >= max(2, w // 3)]
            if not candidates:
                break
            gap = int(rng.choice(candidates))
            gaps.append(gap)
            prev_gap = gap
        if len(gaps) != rows_n:
            continue

        for row, gap in zip(rows, gaps):
            terrain[row, 1:w - 1] = WALL
            terrain[row, gap] = FLAT

        start_col = int(rng.integers(1, w - 1))
        goal_col = int(rng.integers(1, w - 1))
        start, goal = (0, start_col), (h - 1, goal_col)
        terrain[start] = FLAT
        terrain[goal] = FLAT
        if not _connected(terrain, start, goal):
            continue  # staggering picked a combination that also cut the route

        # one blocker per gate, forced into its own throat -- same clearance
        # discipline as gp_scene/random_scene, so a gate this narrow simply
        # rejects an extent too wide for it rather than spawning overlapped
        blocker_cells = list(zip(rows, gaps))
        objects = []
        for cell in blocker_cells:
            got = _try_place(rng, [cell], terrain, objects, 0.3, 0.8)
            if got is None:
                break
            c, extent = got
            objects.append(Obj(cell=c,
                # kept under QUADRUPED's own max_mass=5.0 -- the [2,18) range
                # gp_scene/random_scene use for their own plugs mostly draws
                # ABOVE that (log-uniform, median ~6) once both gates need to
                # be quadruped-liftable at once, that compounds to 13/100
                # solvable (measured) -- this is meant for quadruped visual
                # debugging specifically, so bias the draw to actually land there
                mass=float(np.exp(rng.uniform(np.log(1.0), np.log(4.5)))),
                extent=extent, theta=float(rng.uniform(-np.pi, np.pi))))
        if len(objects) < len(blocker_cells):
            continue  # a throat had no room even for its own blocker -- resample

        # decoys scattered in the open rooms (strictly between consecutive gate
        # rows, and before/after the first/last one)
        room_edges = [0] + rows + [h - 1]
        open_cells = [
            (r, c) for lo, hi in zip(room_edges[:-1], room_edges[1:])
            for r in range(lo + 1, hi) for c in range(1, w - 1)
            if terrain[r, c] != WALL and (r, c) not in (start, goal)
            and (r, c) not in set(blocker_cells)
        ]
        rng.shuffle(open_cells)
        while len(objects) < n_objects and open_cells:
            got = _try_place(rng, open_cells, terrain, objects, 0.3, 1.4)
            if got is None:
                break
            c, extent = got
            objects.append(Obj(cell=c,
                mass=float(np.exp(rng.uniform(np.log(0.5), np.log(25.0)))),
                extent=extent, theta=float(rng.uniform(-np.pi, np.pi))))

        return Scene(terrain=terrain, start=start, goal=goal, objects=objects)
    raise RuntimeError("walled_room_scene: no valid staggered-gate layout in 64 resamples")


def _self_check_geometry_points():
    """docs/PLAN_verification_and_sota_comparison.md §21/§22 -- smallest thing
    that fails if attach_geometry_points' geometry breaks."""
    # theta=0 square: every point must sit exactly on the boundary (one axis at
    # +-half, the other spanning [-half, half)).
    pts = _rect_perimeter_points(half=2.0, theta=0.0, n=16)
    on_boundary = np.isclose(np.abs(pts), 2.0, atol=1e-9).any(axis=1)
    assert on_boundary.all(), "some perimeter points aren't on the square's boundary at theta=0"
    assert (np.abs(pts) <= 2.0 + 1e-9).all(), "a perimeter point fell outside the half-size"

    # a theta rotation must preserve every point's distance from the center
    # (rigid rotation, not a reshape) -- compare against the theta=0 case.
    rot = _rect_perimeter_points(half=2.0, theta=np.pi / 3, n=16)
    r0 = np.linalg.norm(pts, axis=1)
    r1 = np.linalg.norm(rot, axis=1)
    assert np.allclose(sorted(r0), sorted(r1), atol=1e-9), "rotation changed point radii"

    # wall points: build a tiny scene with one WALL cell, check every sampled
    # point lands inside that cell's own unit square (center +- 0.5).
    terrain = np.full((5, 5), FLAT, dtype=np.int64)
    terrain[2, 2] = WALL
    scene = Scene(terrain=terrain, start=(0, 0), goal=(4, 4),
                 objects=[Obj(cell=(1, 1), mass=1.0, extent=0.6, theta=0.3)])
    attach_geometry_points(scene, n_per_object=16, n_per_wall_cell=20, seed=0)
    assert scene.objects[0].local_points.shape == (16, 2)
    assert scene.wall_points.shape == (20, 2)
    assert np.all(np.abs(scene.wall_points - np.array([2.0, 2.0])) <= 0.5 + 1e-9), (
        "a wall point fell outside its own cell's unit square")
    # theta=0.3 != 0, so the object's own points must NOT still be theta=0-aligned
    # (i.e. attach_geometry_points actually used the object's real theta, not a
    # hardcoded 0) -- theta=0 would put a point exactly on the axis (y=0 for some
    # x=+-half); confirm none do.
    on_axis = np.isclose(scene.objects[0].local_points[:, 1], 0.0, atol=1e-6)
    assert not on_axis.any(), "local_points look theta=0-aligned -- object's own theta unused?"

    # a scene that never calls attach_geometry_points must keep every field at
    # its None default -- the fallback path this whole feature promises.
    untouched = Obj(cell=(0, 0), mass=1.0, extent=0.5)
    assert untouched.local_points is None
    s2 = Scene(terrain=terrain, start=(0, 0), goal=(4, 4), objects=[untouched])
    assert s2.wall_points is None

    print(f"ok attach_geometry_points: {len(pts)} perimeter pts/object (rotation-preserving), "
         f"{scene.wall_points.shape[0]} wall pts/cell (in-bounds), untouched scenes stay None")


def precedence_bank_scene(seed, h=8, w=8, n_objects=4):
    """THE per-seed scene constructor shared by the precedence-bank miner
    (experiments/ordering_stage/v3_mine_precedence_bank.py) and train_pamo's
    --precedence_bank injection (docs/PAPER_FREEZE_2026-08-24.md axis ⑤,
    ordering depth curve). One definition on purpose: if miner and training
    ever construct bank scenes differently, the mined k certificates silently
    stop describing the scenes being trained on."""
    return walled_room_scene(np.random.default_rng(seed), h, w, n_objects=n_objects)


def mid_episode_scene(rng, base_scene_fn, emb, p_partial=0.6, max_tries=8):
    """Synthetic MID-EPISODE state (2026-08-25, PLAN §67 -- BC test-time
    distribution shift): the closed-loop planner is re-queried on states no
    initial-scene generator produces -- some objects already parked, one
    possibly half-pushed, the robot standing where its last push ended. This
    fabricates such states from the training distribution itself so the
    oracle can label them (DAgger with a free expert), WITHOUT touching eval
    seeds: draw a base scene, solve, abstractly execute a random prefix of
    the optimal order (objects jump to their oracle parks), then with prob
    `p_partial` leave the NEXT object part-way along its push (a failed /
    interrupted push), and move `start` to a free cell adjacent to the last
    handled object (where the robot would be). Returns a Scene whose oracle
    labels are computed downstream as usual; unsolvable outcomes fall back to
    the untouched base scene so the mix never loses a sample."""
    from clear.data.oracle import assign_goal_cells, solve
    for _ in range(max_tries):
        base = base_scene_fn(rng)
        orders, _ = solve(base, emb)
        if not orders or len(orders[0]) < 1:
            continue
        order = list(orders[0])
        work = Scene(base.terrain.copy(), base.start, base.goal,
                     [Obj(**vars(o)) for o in base.objects],
                     height=None if base.height is None else base.height.copy())
        assign_goal_cells(work, order, emb)
        k = int(rng.integers(0, len(order)))  # objects order[:k] already parked
        occupied = set()
        for i in order[:k]:
            work.objects[i].cell = work.objects[i].goal_cell
        last_cell = work.objects[order[k - 1]].cell if k > 0 else base.start
        if k < len(order) and rng.random() < p_partial:
            i = order[k]
            r0, c0 = work.objects[i].cell
            r1, c1 = work.objects[i].goal_cell
            u = float(rng.uniform(0.3, 0.8))
            cand = (int(round(r0 + u * (r1 - r0))), int(round(c0 + u * (c1 - c0))))
            taken = {o.cell for j, o in enumerate(work.objects) if j != i} | {work.goal}
            if work.in_bounds(cand) and int(work.terrain[cand]) != WALL and cand not in taken:
                work.objects[i].cell = cand
                last_cell = cand
        for o in work.objects:
            o.goal_cell = None
        # robot start: a free non-object cell adjacent to where the last push ended
        taken = {o.cell for o in work.objects} | {work.goal}
        nbrs = [(last_cell[0] + dr, last_cell[1] + dc) for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))]
        nbrs = [c for c in nbrs if work.in_bounds(c) and int(work.terrain[c]) != WALL and c not in taken]
        if nbrs:
            work.start = nbrs[int(rng.integers(0, len(nbrs)))]
        if len({o.cell for o in work.objects}) < len(work.objects):
            continue  # two objects rounded onto one cell -- redraw
        if solve(work, emb)[0]:
            return work
    return base_scene_fn(rng)


if __name__ == "__main__":
    _self_check_geometry_points()
