"""modes: modes.

modes: Traversal modes (CLEAR v5): the skill library as an abstraction.

A mode is one way a body crosses terrain. It is identified by a contact set, driven by one
frozen controller, and described to the model ONLY through public fields (MODE_DESC_DIM
numbers). Which terrain a (body, mode) pair can cross is never written here; it is measured by
probes (`probe_design`) and learned by the grounding layer.

Stages record which modes exist today:
  1  walk-only; objects become resources through terrain composition (composition.py)
  2  crouch / step_over on top of existing walkers (small adaptation)
  3  mantle (humanoid), rear_up (quadruped with arm), brace -- parkour-style RL skills
"""
from __future__ import annotations

# ---- modes ----
from dataclasses import dataclass, field

CONTACT_SETS = ("feet", "hands", "torso", "wheels")
MODE_DESC_DIM = 4 + 4        # contact one-hot (4) + [max_step_m, max_grade, cmd_speed, needs_arm]


@dataclass(frozen=True)
class Mode:
    mode_id: str
    contacts: tuple                     # subset of CONTACT_SETS
    controller_id: str
    stage: int
    needs_arm: bool = False
    descriptor: dict = field(default_factory=dict)   # max_step_m, max_grade, cmd_speed (controller training envelope)

    def vector(self) -> list:
        oh = [1.0 if c in self.contacts else 0.0 for c in CONTACT_SETS]
        d = self.descriptor
        return oh + [float(d.get("max_step_m", 0.0)), float(d.get("max_grade", 0.0)),
                     float(d.get("cmd_speed", 0.0)), 1.0 if self.needs_arm else 0.0]


# Per body family. Test bodies (go2, h1) get stage-1 walk only, from their own frozen walker.
MODES = {
    "g1": (
        Mode("walk", ("feet",), "g1_blind_stairs_arclip2", 1, descriptor=dict(max_step_m=0.15, max_grade=0.30, cmd_speed=0.3)),
        Mode("crouch", ("feet",), "g1_crouch_v1", 2, descriptor=dict(max_step_m=0.05, max_grade=0.20, cmd_speed=0.2)),
        Mode("mantle", ("feet", "hands"), "g1_mantle_v1", 3, needs_arm=True, descriptor=dict(max_step_m=0.80, max_grade=0.0, cmd_speed=0.1)),
        Mode("brace", ("feet", "hands"), "g1_brace_v1", 3, needs_arm=True, descriptor=dict(max_step_m=0.25, max_grade=0.50, cmd_speed=0.15)),
    ),
    "spot": (
        Mode("walk", ("feet",), "spot_stance_13200", 1, descriptor=dict(max_step_m=0.12, max_grade=0.30, cmd_speed=0.5)),
        Mode("crouch", ("feet",), "spot_crouch_v1", 2, descriptor=dict(max_step_m=0.06, max_grade=0.20, cmd_speed=0.3)),
    ),
    "spot_arm": (
        Mode("walk", ("feet",), "spot_stance_13200", 1, descriptor=dict(max_step_m=0.12, max_grade=0.30, cmd_speed=0.5)),
        Mode("crouch", ("feet",), "spot_crouch_v1", 2, descriptor=dict(max_step_m=0.06, max_grade=0.20, cmd_speed=0.3)),
        Mode("rear_up", ("feet", "hands"), "spot_rearup_v1", 3, needs_arm=True, descriptor=dict(max_step_m=0.40, max_grade=0.0, cmd_speed=0.1)),
    ),
    "go2": (Mode("walk", ("feet",), "go2_walker_v1", 1, descriptor=dict(max_step_m=0.10, max_grade=0.25, cmd_speed=0.5)),),
    # go1: frozen WP-3 walker (outputs/leap2026/WP-3/walkers.json), structurally unseen test body of roster r2
    "go1": (Mode("walk", ("feet",), "go1_walker_wp3", 1, descriptor=dict(max_step_m=0.10, max_grade=0.25, cmd_speed=0.5)),),
    "h1": (Mode("walk", ("feet",), "h1_walker_v1", 1, descriptor=dict(max_step_m=0.12, max_grade=0.30, cmd_speed=0.4)),),
}

# The purposes an object interaction can serve (plan skeleton vocabulary).
PURPOSES = ("clear", "step", "bridge", "brace")
PURPOSE_INDEX = {p: i for i, p in enumerate(PURPOSES)}


def modes_for(base_id: str, max_stage: int = 1):
    return [m for m in MODES[base_id] if m.stage <= max_stage]


def mode_vocab(max_stage: int = 1):
    """Global mode ids (union over bodies) so a mode index means the same thing for every body."""
    ids = []
    for ms in MODES.values():
        for m in ms:
            if m.stage <= max_stage and m.mode_id not in ids:
                ids.append(m.mode_id)
    return ids
