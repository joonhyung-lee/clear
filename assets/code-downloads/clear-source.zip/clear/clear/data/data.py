"""Scene generation -> solved oracle examples -> batched tensors.

An Example is one (scene, embodiment) pair the oracle could solve. The same
scene appears once per embodiment that can solve it, which is what makes the
rate head capability-conditional: identical pixels, different correct order.
"""

from dataclasses import dataclass

import numpy as np
import torch

from clear.data.capability import EMBODIMENTS, WALL, feature_vector
from clear.data.grid import Obj, Scene, cell_path, random_scene
from clear.data.oracle import assign_goal_cells, bfs_path, plan_success, reachable, solve
from clear.data.probes import N_PROBES, probe_set
from clear.util import oracle_progress, path_pose_velocity


def _line_of_sight(terrain, a, b, samples=12):
    """True if the straight line a->b (grid r,c) never crosses a WALL cell.
    Analytic, no MuJoCo -- same family as oracle.py's _path_clips_wall, but
    against the terrain array directly (this pipeline's synthetic scenes
    never call grid.attach_geometry_points, so there is no wall_points cloud
    here to check against). Used as an egocentric-visibility PROXY: whether a
    camera at the robot's start pose could plausibly see this object at all,
    without the cost of an actual render -- see obj_extra's own docstring on
    Example."""
    ar, ac = a
    br, bc = b
    for k in range(samples + 1):
        t = k / samples
        r, c = round(ar + t * (br - ar)), round(ac + t * (bc - ac))
        if int(terrain[r, c]) == WALL:
            return False
    return True


def _clearing_gain(scene: Scene, emb, idx: int) -> float:
    """CoINS's counterfactual interaction gain (arXiv 2601.03956 sec. III-C,
    'InterNav-VLM'): how much would clearing ONLY object `idx` shorten the
    robot's own start->goal route, everything else left exactly where it is?
    G = 1 - len(route with idx cleared) / len(route with idx still blocking);
    1.0 when idx is the difference between goal-reachable and not, 0.0 when
    clearing it alone doesn't move the needle (irrelevant object, or the goal
    is already reachable without touching anything). oracle.solve() finds the
    globally optimal FULL order (all objects jointly); this is a cheaper,
    order-independent PRIOR any single object can be scored against on its own
    -- see oracle.bfs_path, the same start->goal primitive plan_success uses to
    check the robot's own traversal, called here with one object's cell freed
    at a time instead of oracle's joint search."""
    others = {o.cell for j, o in enumerate(scene.objects) if j != idx}
    blocked = others | {scene.objects[idx].cell}
    len_blocked = bfs_path(scene, scene.start, scene.goal, blocked=blocked, emb=emb)
    len_cleared = bfs_path(scene, scene.start, scene.goal, blocked=others, emb=emb)
    if len_cleared is None:
        return 0.0  # unreachable even with idx cleared -- it isn't the gate
    if len_blocked is None:
        return 1.0  # currently unreachable, idx alone unlocks the goal
    if len(len_blocked) <= 0:
        return 0.0
    return float(np.clip(1.0 - len(len_cleared) / len(len_blocked), 0.0, 1.0))


@dataclass
class Example:
    grid: np.ndarray  # (C, H, W)
    x0: np.ndarray  # (N, 3) x, y, theta
    x1: np.ndarray  # (N, 3) parking pose for every object ANY oracle order moves;
    #                 == x0 otherwise. The effective target is order-conditioned:
    #                 collate() keeps x1 only for the sampled order's movers.
    mass: np.ndarray  # (N,)
    extent: np.ndarray  # (N,)
    movable: np.ndarray  # (N,) bool -- this embodiment could displace it
    reachable0: np.ndarray  # (N,) bool -- is object i's OWN cell reachable from
    #   scene.start with every OTHER object still sitting at its initial cell
    #   (oracle.reachable(..., cleared=set())). Missing signal diagnosed
    #   2026-08-20 (docs/PLAN_verification_and_sota_comparison.md §9.1): a
    #   sequential-gate maze (rooms) can seal a whole room behind a
    #   not-yet-cleared blocker, and object_features had nothing telling the
    #   model an object sits behind such a seal -- it could only infer this
    #   from terrain+all-object-positions attention, with near-zero training
    #   pressure to learn that on `mix` (rarely has this structure). This is
    #   the initial-state answer only (order-independent, computable once);
    #   it does NOT update as a plan clears blockers -- deliberately: PAMO
    #   predicts the whole order atomically at t=0, so "reachable BEFORE any
    #   push happens" is the one well-defined, order-independent version of
    #   this feature.
    orders: list  # list of MOVER-ONLY orders (tuples of length n_moved). Orders
    #               may move different object sets (cross-set multimodality).
    emb_feat: np.ndarray  # (FEATURE_DIM,)
    emb_name: str
    n_moved: int  # objects the plan actually displaces (equal across orders)
    paths: dict  # {obj_index: [(r,c), ...]} 8-dir, corner-safe cell path x0 -> x1, union movers only
    robot_paths: dict = None  # {order_tuple: [phase0_path, phase1_path, ...]} the
    #   ROBOT's own inter-phase route per oracle order -- from where it finished
    #   the previous push (that object's goal_cell) or scene.start for phase 0,
    #   to the next object's cell. Grid-native cell_path, the same primitive
    #   `paths` uses for OBJECT motion. Joint-planner (B) label; None on older
    #   examples / when not requested. See DESIGN below.
    height: np.ndarray | None = None  # (H, W) metres when the scene is metric.
    #   Carried explicitly because `grid` is the 3-class one-hot and cannot
    #   represent it -- example_scene would otherwise hand the planner a
    #   different world than the one the oracle solved.
    obj_extra: np.ndarray | None = None  # (N, D) -- COMPOSABLE per-object extra
    #   columns, D = 2*attach_obj_extra + attach_gain, in that column order.
    #   Each flag contributes its own columns independently so turning one on
    #   never changes what the other already means to an existing checkpoint:
    #
    #   attach_obj_extra=True appends 2: [line_of_sight(start, obj), dist/diag]
    #   -- an EGOCENTRIC-FLAVORED per-object feature (2026-08-21, egocentric
    #   pointcloud -> production-PAMO integration): whether the robot's start
    #   pose has an unoccluded straight line to this object, and how far. Real
    #   egocentric camera features (clear/data/waypoint_data.py's egocentric()
    #   MuJoCo render) are a SEPARATE track (1a, single-object approach-path
    #   prediction) that never touches this file's synthetic scene generator
    #   -- wiring an actual per-example MuJoCo render into THIS pipeline would
    #   mean rendering tens of thousands of scenes at data-gen time (~114ms/
    #   call measured elsewhere this session), a much bigger cost-and-pipeline
    #   change than this pass attempts. This analytic line-of-sight/distance
    #   proxy captures the ESSENTIAL thing an egocentric view adds that a
    #   privileged one doesn't -- partial observability from occlusion.
    #
    #   attach_gain=True appends 1: [_clearing_gain(scene, emb, i)] -- the
    #   CoINS-style (arXiv 2601.03956) counterfactual "how much would clearing
    #   ONLY this object shorten the robot's own route" score, see
    #   _clearing_gain's own docstring. Unlike reachable0 (own-cell
    #   reachability, binary) or PriorityHead's learned ordering, this is a
    #   GRADED, order-independent per-object prior computed directly from the
    #   grid the oracle already solves on -- a cheap geometric signal for
    #   "which object is actually gating the path" that nothing in
    #   object_features exposed before this.
    #
    #   Both False (default, every existing caller) keeps collate() from
    #   emitting the `obj_extra` batch key at all -- zero behavior change for
    #   every model/checkpoint that doesn't ask for this. Reaches the model via
    #   PAMO's ALREADY-EXISTING `obj_extra`/`obj_extra_dim` hook
    #   (clear/model/clear.py's object_features(): `batch.get('obj_extra')`
    #   concatenates onto the base per-object features at all 4 call sites if
    #   present -- that hook already existed, unused, before attach_obj_extra
    #   was added: see its own docstring on E4PAMO building an encoder and
    #   never routing data into it).
    emb: object | None = None  # the Embodiment this example was built for. Every scorer
    #   used to re-look it up as EMBODIMENTS[emb_name], which only works for bodies in that
    #   global table -- not for a body table passed to build_examples(bodies=), e.g.
    #   capability.tipping_variants(). Carried here so the scorer uses the SAME body the
    #   labels were built with. `embodiment_of(ex)` is the accessor; None falls back to the
    #   global table, so every existing pickle/checkpoint path still works.
    trav: np.ndarray | None = None  # (H, W) float32 -- can THIS body stand on / cross the cell:
    #   metric scene: height <= climb limit and not a wall; class scene: emb.can_traverse(class).
    #   Local capability, not reachability (no flood fill). Target of PriorityHead's traversability
    #   head (--trav_head), which gives the scene tokens a body-dependent target of their own.
    afford: np.ndarray | None = None  # (H, W) float32 -- THIS embodiment's per-cell
    #   reachability from scene.start with every object still at its initial cell
    #   (terrain.reachable_mask over height_field + occupancy_of). A GLOBAL,
    #   body-conditioned connectivity fact the 5-class grid does not contain and
    #   SceneEncoder's 2-conv (~5-cell receptive field) stack cannot compute:
    #   "is this cell behind a seal for this body". Added 2026-08-31 for the
    #   OOD-collapse work (docs/HANDOFF_ood_collapse_2026-08-31.md SS10) as the
    #   PRIVILEGED upper bound of the ego-affordance channel -- if the ground
    #   truth of what TraversalAffordanceHead predicts does not move chain-scene
    #   scene_success, rendering ego observations for chain scenes cannot either.
    #   None (default, every existing caller) keeps collate()'s batch dict
    #   byte-identical to before this field existed.
    probe_set: np.ndarray | None = None  # (P, 3) [probe_id, query, outcome] -- see data/probes.py.
    morph_rows: np.ndarray | None = None  # (L, N_MORPH_FEAT) per-link structure rows -- data/morphology.py.
    morph_mask: np.ndarray | None = None  # (L,) bool; padded rows are False.
    probe_mask: np.ndarray | None = None  # (P,) bool, True = probe observed. Read only by
    #   PAMO(capability_encoder='set'); the vector path keeps reading emb_feat.


def embodiment_of(ex):
    """The body an Example was built for -- its own, or the global table's entry
    for older examples that predate Example.emb."""
    return ex.emb if getattr(ex, "emb", None) is not None else EMBODIMENTS[ex.emb_name]


def _pose(obj: Obj, cell=None) -> np.ndarray:
    r, c = obj.cell if cell is None else cell
    return np.array([c, r, obj.theta], dtype=np.float32)


JITTER = 0.35  # < 0.5 so round() still recovers the oracle's cell


def _chaikin(pts, iters=2):
    """Corner-cutting smoothing. Every new point is a convex combination of
    two adjacent path points, so on a cardinal cell path it never leaves the
    free cells the oracle certified."""
    for _ in range(iters):
        out = [pts[0]]
        for a, b in zip(pts[:-1], pts[1:]):
            out.append((0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]))
            out.append((0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]))
        out.append(pts[-1])
        pts = out
    return pts


def build_examples(n_scenes, h=8, w=8, n_objects=4, seed=0, emb_names=None,
                   plan_fn=None, scene_fn=None, continuous=False, attach_obj_extra=False,
                   attach_gain=False, metric_labels=False, park_rule="nearest",
                   afford_channel=False, bodies=None, mode_labels=False):
    """plan_fn(scene, emb) -> (orders, cost) supplies the training orders.
    Default is the grid oracle; pass wam.make_plan_fn() to distill from the
    oracle-free search instead -- that swap IS the M2 supervision change.

    scene_fn(rng) -> Scene overrides the default generator -- e.g. the
    chain-depth family (grid.chain_scene) for the E1 depth-stress slice.

    continuous=True keeps the SAME grid-oracle ordering supervision but
    renders the world continuously: poses jittered off-lattice inside their
    cells, parking poses sampled inside the goal cell, paths Chaikin-smoothed
    curves instead of cardinal staircases. Cells still recover via round(),
    so every metric and the rejection checker work unchanged.

    attach_gain=True adds the CoINS-style per-object clearing-gain column --
    see Example.obj_extra's own docstring for what it is and how it composes
    with attach_obj_extra."""
    rng = np.random.default_rng(seed)
    # jitter draws come from their own stream so continuous=True/False with the
    # same seed produce the SAME scene sequence -- that pairing is what makes
    # the discrete-vs-continuous component comparison scene-for-scene fair
    jitter_rng = np.random.default_rng(seed + 777_777) if continuous else None
    # `bodies` swaps the embodiment TABLE (not just which names are used) --
    # capability.tipping_bodies() returns the same three bodies with contact
    # heights attached, which changes what can_move (and so the oracle's labels)
    # says. None = EMBODIMENTS, byte-identical to before this existed.
    bodies = bodies or EMBODIMENTS
    emb_names = emb_names or list(bodies)
    out = []
    for _ in range(n_scenes):
        scene = scene_fn(rng) if scene_fn is not None else random_scene(rng, h, w, n_objects)
        for name in emb_names:
            emb = bodies[name]
            ex = _make(scene, emb, name, rng, plan_fn=plan_fn or solve, jitter_rng=jitter_rng,
                      attach_obj_extra=attach_obj_extra, attach_gain=attach_gain,
                      metric_labels=metric_labels, park_rule=park_rule,
                      afford_channel=afford_channel, mode_labels=mode_labels)
            if ex is not None:
                out.append(ex)
    return out




PARK_SET_TOP_K = 8  # set-valued labels: nearest K validated parks form the label set


def _sample_park_assignment(work: Scene, union, emb, rng, rule, top_k=PARK_SET_TOP_K):
    """Set-valued Stage B labels (2026-08-25, PLAN sect78 item 1): instead of the
    oracle's single greedy nearest-validated park per object (`assign_goal_cells`,
    a heuristic POLICY the model would imitate -- the root of the deterministic,
    alternative-free placements of PLAN sect65), draw the park from the set of
    validated candidates, so the training distribution is the FEASIBLE SET
    (world-model fact) rather than one policy's pick. Sequential, same validity
    contract as assign_goal_cells (park_valid with the rest of `union` pending).
      rule = "set"           uniform over the nearest `top_k` validated candidates
      rule = "set_lookahead" softmax(-cost / T) over them, cost = look-ahead time proxy
                             of the remaining assignment completed greedily-nearest
    Mutates goal_cell in place; falls back to assign_goal_cells' own fallback when
    no validated candidate exists."""
    from clear.data.oracle import _nearest_free, park_candidates, park_valid, LOOKAHEAD_C_PUSH, LOOKAHEAD_C_WALK, _blocked_for_walk, _walk_cells, _standoff_cell
    positions = [o.cell for o in work.objects]
    robot = (float(work.start[0]), float(work.start[1]))
    for k, i in enumerate(union):
        pending = list(union[k + 1:])
        cands = []
        for cand in park_candidates(work, positions, i):
            if park_valid(work, emb, positions, i, pending, cand):
                cands.append(cand)
                if len(cands) >= top_k:
                    break
        if not cands:
            taken = {c for c in positions if c is not None} | {work.start, work.goal}
            cand = _nearest_free(work, positions[i], taken) or positions[i]
        elif rule == "set_lookahead":
            cur = positions[i]
            costs = []
            for cand in cands:
                push = ((cand[0] - cur[0]) ** 2 + (cand[1] - cur[1]) ** 2) ** 0.5
                pos2 = list(positions)
                pos2[i] = cand
                nxt = _standoff_cell(cand, cur)
                # transit to the next object (or the goal) from where this push leaves the robot
                if pending:
                    t = _blocked_for_walk(work, pos2, skip=(pending[0],))
                    walk = _walk_cells(work, t, nxt, pos2[pending[0]])
                else:
                    walk = _walk_cells(work, _blocked_for_walk(work, pos2), nxt, work.goal)
                costs.append(LOOKAHEAD_C_PUSH * push + LOOKAHEAD_C_WALK * walk)
            c = np.asarray(costs, dtype=float)
            w = np.exp(-(c - c.min()) / PARK_SET_TEMPERATURE_S)
            cand = cands[int(rng.choice(len(cands), p=w / w.sum()))]
        else:
            cand = cands[int(rng.integers(len(cands)))]
        work.objects[i].goal_cell = cand
        positions[i] = cand


PARK_SET_TEMPERATURE_S = 10.0  # seconds of time-proxy per e-fold of label weight (set_lookahead)


def mode_orders(scene, emb, n_moved, base_orders, cap=8):
    """Every order of `n_moved` pushes that ACTUALLY opens the goal, judged the
    way scene_success judges it (execute, then ask) rather than the way solve()
    ranks it.

    Why this exists (2026-08-31): solve() enumerates cost-tied optimal orders,
    but its cost is lexicographic (objects moved, then path length), and path
    length breaks nearly every tie -- measured, oracle labels are single-mode in
    100% of rooms_fork examples. The metric this repo scores on
    (eval.success_rate -> oracle.plan_success) does not look at path length at
    all: measured on the same examples, 33.6% have MORE than one order that
    opens the goal. So the supervision was discarding real modes that the
    metric accepts, and PriorityHead's sigma had nothing to represent.

    Cost: permutations of the movable set at the oracle's own depth (<= 4! at
    the standard config), each executed once. Off by default.
    """
    from itertools import permutations
    from clear.data.oracle import assign_goal_cells, order_executable, plan_success
    movable = [i for i, o in enumerate(scene.objects) if emb.can_move(o)]
    if not movable or n_moved == 0:
        return base_orders
    out = list(base_orders)
    seen = {tuple(o) for o in out}
    for perm in permutations(movable, n_moved):
        if perm in seen:
            continue
        work = Scene(scene.terrain.copy(), scene.start, scene.goal,
                     [Obj(**vars(o)) for o in scene.objects],
                     height=None if scene.height is None else scene.height.copy())
        if not order_executable(work, emb, list(perm)):
            continue
        assign_goal_cells(work, list(perm), emb)
        final = {i: work.objects[i].goal_cell for i in perm}
        if any(v is None for v in final.values()):
            continue
        if plan_success(scene, emb, list(perm), final):
            out.append(perm)
            seen.add(perm)
        if len(out) >= cap:
            break
    return out


def _make(scene: Scene, emb, name, rng, plan_fn=solve, jitter_rng=None, attach_obj_extra=False,
         attach_gain=False, metric_labels=False, park_rule="nearest", afford_channel=False,
         mode_labels=False):
    orders, _ = plan_fn(scene, emb)
    if not orders:
        return None

    movable = np.array([emb.can_move(o) for o in scene.objects], dtype=bool)
    if not movable.any():
        # solvable without touching anything; nothing for the rate head to order
        return None
    # BEFORE the parking block: the union that gets goal cells and paths has to
    # cover every mode, or collate() reads a path that was never built.
    if mode_labels:
        orders = mode_orders(scene, emb, len(orders[0]), orders)

    reachable0 = np.array([reachable(scene, emb, o.cell, set()) for o in scene.objects], dtype=bool)

    afford = None
    if afford_channel:
        from clear.data.terrain import height_field, occupancy_of, reachable_mask
        afford = reachable_mask(height_field(scene), emb, scene.start,
                                occupancy_of(scene)).astype(np.float32)

    obj_extra = None
    if attach_obj_extra or attach_gain:
        cols = []
        if attach_obj_extra:
            h, w = scene.terrain.shape
            diag = float(np.hypot(h, w))
            cols.append(np.array([
                [float(_line_of_sight(scene.terrain, scene.start, o.cell)),
                 float(np.hypot(o.cell[0] - scene.start[0], o.cell[1] - scene.start[1])) / diag]
                for o in scene.objects
            ], dtype=np.float32))
        if attach_gain:
            cols.append(np.array(
                [[_clearing_gain(scene, emb, i)] for i in range(len(scene.objects))],
                dtype=np.float32))
        obj_extra = np.concatenate(cols, axis=-1)

    # Park the UNION of movers across all oracle orders. Different orders may
    # move different object sets (e.g. "clear either gap"), so which x1 applies
    # is decided per sampled order in collate(), not here. Parking each union
    # member once keeps x1 well-defined for every order.
    # ponytail: one shared parking spot per object across orders; per-order
    # placement only if a parked spot turns out to block another order's path.
    union = sorted({i for o in orders for i in o})
    # The height comes along: assign_goal_cells parks via reach_positions, which
    # is body-dependent, so a `work` without it would place parking spots by
    # class rules and then be scored by metric ones.
    work = Scene(scene.terrain.copy(), scene.start, scene.goal,
                 [Obj(**vars(o)) for o in scene.objects],
                 height=None if scene.height is None else scene.height.copy())
    if park_rule == "nearest":
        assign_goal_cells(work, union, emb)
    else:
        _sample_park_assignment(work, union, emb, rng, park_rule)
    paths = {i: cell_path(work.terrain, work.objects[i].cell, work.objects[i].goal_cell) for i in union}

    x0 = np.stack([_pose(o) for o in work.objects])
    x1 = np.stack([_pose(o, o.goal_cell) for o in work.objects])

    # The label has to be reachable by the rule we score against. `solve` picks
    # the order under vanish semantics (a moved object stops existing) while
    # plan_success executes it with the parked object still occupying a cell,
    # so a minority of generated plans are unachievable as scored -- ~9% at
    # grid16/16, and a model trained on them can never do better than that
    # ceiling. Keep only scenes where at least one oracle order survives.
    keep = {i: work.objects[i].goal_cell for i in union}
    if not any(plan_success(scene, emb, list(o), keep) for o in orders):
        return None

    if jitter_rng is not None:
        x0[:, :2] += jitter_rng.uniform(-JITTER, JITTER, size=(len(x0), 2)).astype(np.float32)
        x1 = x0.copy()
        for i in union:
            r, c = work.objects[i].goal_cell
            x1[i, :2] = (c + jitter_rng.uniform(-JITTER, JITTER), r + jitter_rng.uniform(-JITTER, JITTER))
            x1[i, 2] = work.objects[i].theta
            # path in (r, c) like cell_path; endpoints follow the jittered poses
            pts = [(float(r_), float(c_)) for r_, c_ in paths[i]]
            pts[0] = (float(x0[i, 1]), float(x0[i, 0]))
            pts[-1] = (float(x1[i, 1]), float(x1[i, 0]))
            if len(pts) == 1:
                pts = [(float(x0[i, 1]), float(x0[i, 0])), pts[0]]
            paths[i] = _chaikin(pts)

    # robot_paths (joint-planner B label): the ROBOT's own inter-phase route.
    # For each oracle order, phase k sends the robot from where it finished the
    # previous push (object order[k-1]'s goal_cell, or scene.start for k=0) to
    # the next object order[k]'s current cell. Same grid cell_path primitive as
    # object motion; robot footprint treats other objects as passable (it walks
    # up TO the object, physical push handled elsewhere). Cheap: reuses solve's
    # own orders + the already-parked goal cells.
    robot_paths = {}
    for order in orders:
        phases = []
        prev = tuple(scene.start)
        for i in order:
            dst = tuple(work.objects[i].cell)
            try:
                rp = cell_path(work.terrain, prev, dst)
            except Exception:
                rp = [prev, dst]
            phases.append([(float(rr), float(cc)) for rr, cc in rp] or [prev, dst])
            gc = work.objects[i].goal_cell
            prev = tuple(gc) if gc is not None else dst
        robot_paths[tuple(order)] = phases

    return Example(
        grid=work.tensor(),
        x0=x0,
        x1=x1,
        mass=np.array([o.mass for o in work.objects], dtype=np.float32),
        extent=np.array([o.extent for o in work.objects], dtype=np.float32),
        movable=movable,
        reachable0=reachable0,
        orders=[tuple(o) for o in orders],
        emb_feat=np.array(feature_vector(emb), dtype=np.float32),
        emb_name=name,
        n_moved=len(orders[0]),
        paths=paths,
        robot_paths=robot_paths,
        height=work.height,
        obj_extra=obj_extra,
        emb=emb,
        afford=afford,
        probe_set=probe_set(emb),
        probe_mask=np.ones(len(probe_set(emb)), dtype=bool),   # 11 rows for a tipping body
        trav=_traversable(scene, emb),
        **_morph_fields(name),
    )


def _traversable(scene, emb):
    """(H, W) float32 in {0, 1}: can this body step onto the cell (local rule, see Example.trav)."""
    if scene.height is not None:
        from clear.data.terrain import climb_limit
        from clear.data.terrain import WALL_H
        h = np.asarray(scene.height, dtype=np.float32)
        return ((h <= float(climb_limit(emb)) + 1e-6) & (h < WALL_H - 1e-6)).astype(np.float32)
    t = np.asarray(scene.terrain)
    return np.vectorize(lambda c: float(emb.can_traverse(int(c))))(t).astype(np.float32)


def _morph_fields(emb_name):
    """(morph_rows, morph_mask) padded to morphology.MAX_LINKS, or empty when the
    body has no registered morphology -- a 'morph' run asserts presence at
    collate instead of silently reading a table."""
    try:
        from clear.data.morphology import MAX_LINKS, N_MORPH_FEAT, morph_rows
        r, m = morph_rows(emb_name)
    except Exception:
        return {}
    rows = np.zeros((MAX_LINKS, r.shape[1]), dtype=np.float32)
    mask = np.zeros(MAX_LINKS, dtype=bool)
    rows[:len(r)] = r
    mask[:len(r)] = m
    return {"morph_rows": rows, "morph_mask": mask}


def example_scene(ex: Example) -> Scene:
    """Rebuild the grid Scene from what the model already observes (the grid
    tensor + object states) -- used for planner-side order rejection, so it
    must not need anything the deployed system would lack."""
    terrain = ex.grid[:3].argmax(0).astype(np.int64)
    start = tuple(int(v) for v in np.argwhere(ex.grid[3])[0])
    goal = tuple(int(v) for v in np.argwhere(ex.grid[4])[0])
    objs = [
        Obj(
            cell=(int(round(float(ex.x0[i, 1]))), int(round(float(ex.x0[i, 0])))),
            mass=float(ex.mass[i]),
            extent=float(ex.extent[i]),
            theta=float(ex.x0[i, 2]),
        )
        for i in range(len(ex.x0))
    ]
    return Scene(terrain=terrain, start=start, goal=goal, objects=objs,
                 height=ex.height)


def with_afford(batch, channel=None):
    """Append the affordance channel as the LAST grid channel -- the same
    append-at-the-end contract grow_scene_channels/ego_project assume (class
    channels stay first). `channel` substitutes a different (b, h, w) map, which
    is how the zero / cross-scene-shuffle falsification controls are built.
    """
    ch = batch["afford"] if channel is None else channel
    return torch.cat([batch["grid"], ch.unsqueeze(1)], dim=1)


def collate(examples, rng, device="cpu", t=None, smoothness=False):
    """Sample a flow time and one valid order per example; return a batch dict.

    smoothness=True additionally samples one smoothness_j ~ Uniform(0, 1) PER
    EXAMPLE (same scalar for every mover in that example, mirroring emb_feat's
    own per-example-not-per-object scope) and blends pose/v_target toward a
    Chaikin-smoothed version of the same path by that amount -- the label side
    of a steerable smoothness conditioning input (see PAMO's own
    `condition_smoothness`). False (default) is BYTE-IDENTICAL to before this
    param existed: every other caller (train.py's FlowRateBaseline, rollout.py,
    eval_flax_importance.py) never passes it and must not see this at all.
    """
    ts = np.full(len(examples), t, dtype=np.float32) if t is not None else rng.random(len(examples)).astype(np.float32)
    n = len(examples[0].x0)

    s, target, ranks, x1_eff, pose, v_target, smooth_vals = [], [], [], [], [], [], []
    robot_pose_l, robot_v_l, robot_end_l, robot_start_l, robot_mask_l = [], [], [], [], []
    for ex, ti in zip(examples, ts):
        order = ex.orders[rng.integers(len(ex.orders))]  # mover-only
        movers = set(order)
        # movable non-movers trail as zero-displacement slots: they keep the
        # schedule's conservation semantics but their target stays x0.
        tail = tuple(i for i in np.flatnonzero(ex.movable) if i not in movers)
        full = tuple(order) + tail
        s_i, idx = oracle_progress(full, n, float(ti))
        s.append(s_i)
        target.append(idx)
        rk = np.full(n, n, dtype=np.int64)  # immovable -> sentinel rank n
        for pos, i in enumerate(full):
            rk[i] = pos
        ranks.append(rk)
        keep = np.array([i in movers for i in range(n)])
        x1_eff.append(np.where(keep[:, None], ex.x1, ex.x0))

        # Pose/velocity follow the object's actual cell-to-cell path (diagonal
        # allowed, never through a wall corner), not a straight Euclidean line
        # that can cut corners. Only this step's sampled movers actually move;
        # everyone else sits at their fixed x0 pose.
        pose_i = ex.x0.copy()
        v_i = np.zeros_like(ex.x0)
        smooth_j = float(rng.uniform(0., 1.)) if smoothness else 0.0
        smooth_vals.append(smooth_j)
        for j in movers:
            pose_raw, v_raw = path_pose_velocity(
                ex.paths[j], float(ex.x0[j, 2]), float(ex.x1[j, 2]), float(s_i[j])
            )
            # smooth_j > 0 and len(path) > 1 guard: a degenerate 1-cell (already-there)
            # path Chaikin-duplicates into identical points, and path_pose_velocity
            # divides by the path's total segment length -- 0/0 on that input.
            # Nothing to smooth for a zero-length path anyway (blending would be a no-op).
            if smooth_j > 0 and len(ex.paths[j]) > 1:
                smoothed = _chaikin(list(ex.paths[j]))
                pose_smooth, v_smooth = path_pose_velocity(
                    smoothed, float(ex.x0[j, 2]), float(ex.x1[j, 2]), float(s_i[j])
                )
                pose_i[j] = (1 - smooth_j) * pose_raw + smooth_j * pose_smooth
                v_i[j] = (1 - smooth_j) * v_raw + smooth_j * v_smooth
            else:
                pose_i[j], v_i[j] = pose_raw, v_raw
        pose.append(pose_i)
        v_target.append(v_i)

        # ROBOT path label (joint-planner B): PER-PHASE per-object. Phase k (the
        # robot's approach to order[k]) is the label for order[k]'s OWN token, so
        # every mover token carries its own approach leg -- not just rank 0. Each
        # phase is sampled at the flow's per-object schedule s_i[order[k]], so the
        # robot leg advances in lockstep with THAT object's placement. Shape:
        # (n, 3) per field, keyed by object index; non-movers stay zero.
        rps = getattr(ex, 'robot_paths', None)
        rv_o = np.zeros((n, 3), np.float32); rp_o = np.zeros((n, 3), np.float32)
        re_o = np.zeros((n, 3), np.float32); rs_o = np.zeros((n, 3), np.float32)
        rmask = np.zeros(n, bool)
        if rps is not None and tuple(order) in rps:
            phases = rps[tuple(order)]
            for k, oi in enumerate(order):
                poly = list(phases[k])
                if len(poly) < 2:
                    poly = poly + poly[-1:] if poly else [(float(ex.x0[oi,1]), float(ex.x0[oi,0]))]*2
                seg = sum(np.hypot(poly[q+1][0]-poly[q][0], poly[q+1][1]-poly[q][1])
                          for q in range(len(poly)-1))
                si = float(s_i[oi])
                if seg < 1e-6:
                    rp_o[oi] = [poly[0][1], poly[0][0], 0.]; rv_o[oi] = 0.
                else:
                    pp, vv = path_pose_velocity(poly, 0.0, 0.0, si)
                    rp_o[oi] = pp; rv_o[oi] = vv
                re_o[oi] = [poly[-1][1], poly[-1][0], 0.]
                rs_o[oi] = [poly[0][1], poly[0][0], 0.]
                rmask[oi] = True
        robot_pose_l.append(rp_o); robot_v_l.append(rv_o)
        robot_end_l.append(re_o); robot_start_l.append(rs_o); robot_mask_l.append(rmask)

    def cat(key, dtype=torch.float32):
        return torch.as_tensor(np.stack([getattr(e, key) for e in examples]), dtype=dtype, device=device)

    b = {
        "grid": cat("grid"),
        "x0": cat("x0"),
        # order-conditioned target: parking pose for the sampled order's movers,
        # x0 for everything else ("don't move" is a zero-velocity target, not a
        # discrete selection).
        "x1": torch.as_tensor(np.stack(x1_eff), dtype=torch.float32, device=device),
        "mass": cat("mass"),
        "extent": cat("extent"),
        "movable": cat("movable", torch.bool),
        "reachable0": cat("reachable0", torch.bool),
        "emb_feat": cat("emb_feat"),
        "s": torch.as_tensor(np.stack(s), device=device),
        "t": torch.as_tensor(ts, device=device),
        "target": torch.as_tensor(np.array(target), dtype=torch.long, device=device),
        "rank": torch.as_tensor(np.stack(ranks), device=device),
        "pose": torch.as_tensor(np.stack(pose), dtype=torch.float32, device=device),
        "v_target": torch.as_tensor(np.stack(v_target), dtype=torch.float32, device=device),
    }
    if smoothness:
        b["smoothness"] = torch.as_tensor(smooth_vals, dtype=torch.float32, device=device)
    st = lambda L, dt=torch.float32: torch.as_tensor(np.stack(L), dtype=dt, device=device)
    b["robot_pose"] = st(robot_pose_l)
    b["robot_v_target"] = st(robot_v_l)
    b["robot_endpoint_target"] = st(robot_end_l)
    b["robot_start_pose"] = st(robot_start_l)
    b["robot_mask"] = st(robot_mask_l, torch.bool)
    if examples[0].obj_extra is not None:
        # PAMO.object_features() concatenates this onto the base per-object
        # features when present -- see Example.obj_extra's own docstring.
        # Absent (default) means every existing model/checkpoint sees exactly
        # the same batch dict as before this field existed.
        b["obj_extra"] = cat("obj_extra")
    if examples[0].afford is not None:
        # kept as its OWN key, not concatenated onto "grid": the falsification
        # controls (zero / shuffle across scenes) need to substitute this
        # channel alone, and the training loop appends it in one place.
        b["afford"] = cat("afford")
    if examples[0].probe_set is not None:
        b["probe_set"] = cat("probe_set")
        b["probe_mask"] = cat("probe_mask", torch.bool)
    if examples[0].trav is not None:
        b["trav"] = cat("trav")
    if examples[0].morph_rows is not None:
        b["morph_rows"] = cat("morph_rows")
        b["morph_mask"] = cat("morph_mask", torch.bool)
    return b


def _self_check_obj_extra():
    """docs/PLAN_verification_and_sota_comparison.md -- egocentric->production
    integration, first pass. Smallest thing that fails if obj_extra's
    plumbing (Example -> collate -> PAMO.object_features -> PriorityHead/
    CausalVelocityField's obj_extra_dim) breaks, in either direction: the
    opt-out default must stay byte-identical, and opt-in must actually reach
    the model and change its output (same shape of check as
    causal_velocity_field.py's own condition_smoothness self-check)."""
    import torch

    from clear.model.clear import PAMO

    rng = np.random.default_rng(0)
    examples_off = build_examples(6, h=8, w=8, n_objects=3, seed=1, attach_obj_extra=False)
    assert examples_off, "no examples generated -- can't self-check"
    assert examples_off[0].obj_extra is None
    batch_off = collate(examples_off, rng)
    assert "obj_extra" not in batch_off, "attach_obj_extra=False must not emit the batch key at all"

    examples_on = build_examples(6, h=8, w=8, n_objects=3, seed=1, attach_obj_extra=True)
    assert examples_on, "no examples generated -- can't self-check"
    n = len(examples_on[0].x0)
    assert examples_on[0].obj_extra.shape == (n, 2)
    assert set(np.unique(examples_on[0].obj_extra[:, 0])) <= {0.0, 1.0}, "line-of-sight column must be 0/1"
    assert (examples_on[0].obj_extra[:, 1] >= 0).all(), "distance column must be non-negative"
    batch_on = collate(examples_on, rng)
    assert batch_on["obj_extra"].shape == (len(examples_on), n, 2)
    print(f"ok obj_extra plumbing: off->no batch key, on->{tuple(batch_on['obj_extra'].shape)}")

    # Same scenes (seed=1 both), so this isolates obj_extra_dim's effect, not
    # scene variance -- a model with obj_extra_dim=2 must produce a DIFFERENT
    # priority-head output when the batch's obj_extra values are perturbed,
    # and gradients must reach to_object_tokens's newly-widened input rows.
    torch.manual_seed(0)
    model = PAMO(grid_hw=(8, 8), dim=32, depth=2, heads=2, dim_head=16, obj_extra_dim=2)
    mu0, _ = model.priority_head(batch_on["grid"], model.object_features(
        batch_on, batch_on["x0"], torch.zeros_like(batch_on["s"]), 0., batch_on["movable"]),
        batch_on["emb_feat"])
    perturbed = dict(batch_on)
    perturbed["obj_extra"] = batch_on["obj_extra"] + 1.0
    mu1, _ = model.priority_head(perturbed["grid"], model.object_features(
        perturbed, perturbed["x0"], torch.zeros_like(perturbed["s"]), 0., perturbed["movable"]),
        perturbed["emb_feat"])
    assert not torch.allclose(mu0, mu1), "perturbing obj_extra didn't change PriorityHead's output at all"

    loss, _ = model(batch_on)
    loss.backward()
    assert model.priority_head.to_object_tokens.weight.grad is not None, "no gradient reached to_object_tokens"
    grad_on_extra_cols = model.priority_head.to_object_tokens.weight.grad[:, -2:]
    assert grad_on_extra_cols.abs().sum() > 0, "obj_extra's own input columns got zero gradient -- E4PAMO's exact failure mode (built the feature, nothing downstream ever used it)"
    print("ok obj_extra reaches PriorityHead's output and gets real gradient (not the E4PAMO dead-input bug)")

    # obj_extra_dim=0 (the default) must stay byte-for-byte the pre-existing
    # PAMO -- constructing it with an obj_extra-bearing batch must simply
    # ignore the extra columns rather than erroring or silently resizing.
    plain = PAMO(grid_hw=(8, 8), dim=32, depth=2, heads=2, dim_head=16)
    plain_loss, _ = plain(batch_off)
    assert torch.isfinite(plain_loss)
    print("ok obj_extra_dim=0 (default) trains fine on a batch with no obj_extra key at all")


def _self_check_clearing_gain():
    """attach_gain composes independently of attach_obj_extra (own column
    count, appended after attach_obj_extra's 2 rather than replacing them),
    and the gain values themselves are a real, bounded, non-constant signal --
    not a column of the same number repeated (E4PAMO's dead-input bug, one
    level up: a column that reaches the model but never actually varies is
    just as useless as one that never reaches it)."""
    rng = np.random.default_rng(0)

    gain_only = build_examples(10, h=8, w=8, n_objects=4, seed=2, attach_gain=True)
    assert gain_only, "no examples generated -- can't self-check"
    n = len(gain_only[0].x0)
    assert gain_only[0].obj_extra.shape == (n, 1), "attach_gain alone must add exactly 1 column"
    all_gains = np.concatenate([e.obj_extra[:, 0] for e in gain_only])
    assert ((all_gains >= 0.0) & (all_gains <= 1.0)).all(), "gain must be clipped to [0, 1]"
    assert all_gains.std() > 0, "gain is constant across a 10-scene batch -- not a real signal"

    both = build_examples(6, h=8, w=8, n_objects=3, seed=1, attach_obj_extra=True, attach_gain=True)
    assert both, "no examples generated -- can't self-check"
    n = len(both[0].x0)
    assert both[0].obj_extra.shape == (n, 3), "attach_obj_extra + attach_gain must stack to 3 columns"
    # the first 2 columns must be byte-identical to attach_obj_extra alone --
    # composing must not perturb what attach_obj_extra already means.
    obj_extra_only = build_examples(6, h=8, w=8, n_objects=3, seed=1, attach_obj_extra=True)
    np.testing.assert_array_equal(both[0].obj_extra[:, :2], obj_extra_only[0].obj_extra)
    batch_both = collate(both, rng)
    assert batch_both["obj_extra"].shape == (len(both), n, 3)
    print(f"ok attach_gain composes: gain-alone->{gain_only[0].obj_extra.shape}, "
          f"+attach_obj_extra->{tuple(batch_both['obj_extra'].shape)}, prefix columns unchanged")


if __name__ == "__main__":
    _self_check_obj_extra()
    _self_check_clearing_gain()
