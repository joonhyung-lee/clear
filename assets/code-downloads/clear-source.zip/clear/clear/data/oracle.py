"""Oracle: which objects must move, and in what order.

Dijkstra over (cell, frozenset_of_moved_objects) with lexicographic cost
(n_objects_moved, n_flanked_moved, path_length). The order objects are first
touched along an optimal path *is* the precedence order -- no separate
precedence graph needed, because a path that reaches the goal already visited
its blockers in a physically consistent order.

`n_flanked_moved` (2026-08-20, obj_1 investigation, docs/HANDOFF_pamo_push_maze.md):
a soft tie-breaker, not a feasibility gate. An object flanked by WALL on both
sides of an axis (see `_flanked`) is a body-clearance risk a 1-cell-coarse
grid can't actually certify -- it's a real body (clearance>=1.0, currently
just QUADRUPED) that has spent minutes stuck near such an object, so the
solver prefers routes that avoid moving it, but still uses it when it's the
only way to a solution rather than declaring the scene unsolvable (a hard
gate here was tried and reverted -- see capability.py's Embodiment.clearance).

Multiple distinct optimal orders are returned. They are the multimodal target:
training samples one per example, so the rate head learns the marginal over
valid orders instead of collapsing onto one arbitrary topological sort.

# ponytail: state space is 2^|objects| * cells. Fine to ~8 objects, which is
# every scene we plan to run. Above that, switch to a precedence-graph
# relaxation -- do not pre-emptively build one.
"""

import heapq
from collections import deque

import os

import numpy as np

from clear.data.capability import WALL, Embodiment
from clear.data.grid import MAX_PHYSICAL_EXTENT, Scene

NEIGHBORS = ((-1, 0), (1, 0), (0, -1), (0, 1))
MAX_ORDERS = 8


def _flanked_axes(scene, cell):
    """(row_flanked, col_flanked): WALL (or off-grid) directly on both
    opposite sides of the COLUMN axis (escape only possible by changing ROW)
    / the ROW axis (escape only possible by changing COLUMN), respectively."""
    r, c = cell
    h, w = scene.terrain.shape

    def wall(rc):
        rr, cc = rc
        return not (0 <= rr < h and 0 <= cc < w) or int(scene.terrain[rr, cc]) == WALL

    return wall((r, c - 1)) and wall((r, c + 1)), wall((r - 1, c)) and wall((r + 1, c))


def _flanked(scene, cell) -> bool:
    """True if `cell` is a 1-grid-cell-wide slot: WALL (or off-grid, which is
    just as impassable) directly on BOTH opposite sides of at least one axis.
    Deliberately coarse -- a floor on what a grid this size can express, not a
    precise footprint check. Read only as a soft search cost, see module
    docstring -- never a hard rejection."""
    return any(_flanked_axes(scene, cell))


PATH_CLEARANCE = 0.85  # grid cells -- see find_parking's own docstring for why this
# exists. Calibrated against the one confirmed real collision this session (seed=1001,
# rooms): the straight push line came within 0.45 cells of another object at closest
# approach. 0.85 catches that with margin (objects can be up to ~0.9*cell_size wide,
# i.e. ~0.45 cells of half-extent each -- two paths/objects need roughly that much
# separation to not touch at all) without being so wide it starts rejecting candidates
# that were never actually going to be a problem.


def _segment_min_dist(p0, p1, points, samples=20):
    """Min distance from the segment p0->p1 to any row of `points` (k, 2),
    sampling `samples` points along the segment. Shared primitive behind
    _path_clips_object's per-object check and _path_clips_wall below."""
    p0, p1 = np.asarray(p0, dtype=float), np.asarray(p1, dtype=float)
    best = np.inf
    for t in np.linspace(0.0, 1.0, samples):
        p = p0 + t * (p1 - p0)
        best = min(best, float(np.min(np.linalg.norm(points - p, axis=1))))
    return best


def _path_clips_object(cell0, cell1, other_cell, other_points=None, margin=PATH_CLEARANCE, samples=20):
    """True if the straight segment cell0->cell1 (grid coords) passes within
    `margin` cells of the other object at closest approach -- same
    sampled-line technique `spot_push_bridge.py`'s `_line_crosses_wall`
    already uses for walls. `park_candidates`/`find_parking` otherwise only
    reason about grid-CELL occupancy at the two endpoints, never the path
    between them -- this is what catches "the push itself would graze
    something on the way", not just "the destination is already taken".

    `other_points`: optional (k, 2) real footprint samples (grid.Obj.
    local_points, OFFSET from the object's own position -- see that field's
    docstring), checked individually instead of collapsing the object to
    `other_cell` alone. None (the default, and every scene that never called
    grid.attach_geometry_points) keeps exactly the original single-point
    circular-margin behavior -- rotation-blind, but that was always the
    contract here; this only adds precision when it's available, never
    removes the fallback."""
    targets = (np.asarray(other_cell, dtype=float) + other_points if other_points is not None
              else np.asarray(other_cell, dtype=float)[None, :])
    return _segment_min_dist(cell0, cell1, targets, samples) < margin


def _path_clips_wall(cell0, cell1, wall_points, margin=PATH_CLEARANCE, samples=20):
    """True if the straight segment cell0->cell1 passes within `margin` cells
    of any real wall-footprint sample (grid.Scene.wall_points, absolute --
    walls are static, no re-anchoring needed unlike _path_clips_object's
    other_points). None or empty (every scene that never called
    grid.attach_geometry_points) -> always False, i.e. no wall check at all --
    the ORIGINAL contract here, since nothing has ever checked the push path
    against walls (only `park_candidates`'s candidate-cell WALL exclusion and
    `reach_positions`'s BFS terrain check, neither of which sees the straight
    segment BETWEEN two non-adjacent cells). 2026-08-21: closes that gap --
    see docs/PLAN_verification_and_sota_comparison.md §21/§22 and the
    oracle-anatomy artifact's §6 (seed 1006's corner case, which
    `_flanked_axes`' cardinal-neighbor-only test also can't see)."""
    if wall_points is None or len(wall_points) == 0:
        return False
    return _segment_min_dist(cell0, cell1, wall_points, samples) < margin


def _neighbors(scene: Scene, emb: Embodiment, cell, moved: frozenset, occ: dict):
    """Yield (next_cell, next_moved, step_cost) for legal transitions."""
    r, c = cell
    for dr, dc in NEIGHBORS:
        nxt = (r + dr, c + dc)
        if not scene.in_bounds(nxt):
            continue
        if not scene.can_enter(emb, cell, nxt):
            continue
        idx = occ.get(nxt)
        if idx is None or idx in moved:
            yield nxt, moved, (0, 0, 1)
        elif emb.can_move(scene.objects[idx]):
            flanked = emb.clearance >= 1.0 and _flanked(scene, scene.objects[idx].cell)
            yield nxt, moved | {idx}, (1, int(flanked), 1)
        # else: blocked, this body cannot clear it


def solve(scene: Scene, emb: Embodiment):
    """Return (orders, cost). `orders` is a list of tuples of object indices in
    move order; empty list means unsolvable for this embodiment."""
    occ = scene.occupied()
    src = (scene.start, frozenset())
    if not scene.can_start(emb):
        return [], None

    dist = {src: (0, 0, 0)}
    parents = {src: []}
    pq = [((0, 0, 0), scene.start, frozenset())]

    while pq:
        cost, cell, moved = heapq.heappop(pq)
        state = (cell, moved)
        if cost > dist.get(state, cost):
            continue
        for nxt, nmoved, step in _neighbors(scene, emb, cell, moved, occ):
            ncost = (cost[0] + step[0], cost[1] + step[1], cost[2] + step[2])
            nstate = (nxt, nmoved)
            known = dist.get(nstate)
            if known is None or ncost < known:
                dist[nstate] = ncost
                parents[nstate] = [state]
                heapq.heappush(pq, (ncost, nxt, nmoved))
            elif ncost == known and state not in parents[nstate]:
                parents[nstate].append(state)

    goals = [s for s in dist if s[0] == scene.goal]
    if not goals:
        return [], None
    best = min(dist[s] for s in goals)
    goals = [s for s in goals if dist[s] == best]

    # Walk every optimal predecessor chain, recording move order. Memoized per
    # state: open grids have combinatorially many tied-cost cell paths through
    # the same (cell, moved) state, so an unmemoized DFS re-explores each one
    # in full even when they collapse to a handful of distinct orders -- this
    # was measured taking multi-second, scene-dependent blowups at grid16.
    memo = {}

    def orders_to(state):
        """Set of complete src -> state move orders (chronological)."""
        if state == src:
            return {()}
        cached = memo.get(state)
        if cached is not None:
            return cached
        _, moved = state
        out = set()
        for prev in parents.get(state, []):
            newly = moved - prev[1]
            for s in orders_to(prev):
                out.add(s + tuple(newly) if newly else s)
                if len(out) >= MAX_ORDERS:
                    break
            if len(out) >= MAX_ORDERS:
                break
        memo[state] = out
        return out

    orders = set()
    for g in goals:
        orders |= orders_to(g)
        if len(orders) >= MAX_ORDERS:
            break

    return sorted(orders)[:MAX_ORDERS], best


def reach_positions(scene: Scene, emb: Embodiment, positions, target) -> bool:
    """Single reachability primitive: BFS from start given CURRENT object
    positions (None = removed). Stepping INTO an occupied cell is allowed only
    when it is the target (that is the displacement move)."""
    occ = {c for c in positions if c is not None}
    if not scene.can_start(emb):
        return False
    seen, q = {scene.start}, deque([scene.start])
    while q:
        cell = q.popleft()
        if cell == target:
            return True
        r, c = cell
        for dr, dc in NEIGHBORS:
            nxt = (r + dr, c + dc)
            if (
                scene.in_bounds(nxt)
                and nxt not in seen
                and scene.can_enter(emb, cell, nxt)
                and (nxt not in occ or nxt == target)
            ):
                seen.add(nxt)
                q.append(nxt)
    return False


def reachable(scene: Scene, emb: Embodiment, target, cleared) -> bool:
    """reach_positions with the oracle's vanish semantics for `cleared`."""
    positions = [None if i in cleared else o.cell for i, o in enumerate(scene.objects)]
    return reach_positions(scene, emb, positions, target)


def reachable_count(scene: Scene, emb: Embodiment, cleared) -> int:
    """Same BFS/vanish semantics as reachable(), but counts ALL reachable
    cells instead of checking one target -- a continuous "how much of the
    scene opened up" signal (marginal counterfactual reachability, PLAN doc
    S58) rather than reachable()'s single-target bool. Used by the critic
    to score how much clearing a specific candidate object would help,
    which a single-target check mostly can't discriminate for pos==0-only
    (one object rarely fully opens scene.goal in `rooms` scenes -- see
    §9.1's sequential-gate finding)."""
    if not scene.can_start(emb):
        return 0
    occ = {c for i, c in enumerate(o.cell for o in scene.objects) if i not in cleared}
    seen, q = {scene.start}, deque([scene.start])
    while q:
        cell = q.popleft()
        r, c = cell
        for dr, dc in NEIGHBORS:
            nxt = (r + dr, c + dc)
            if (
                scene.in_bounds(nxt)
                and nxt not in seen
                and scene.can_enter(emb, cell, nxt)
                and nxt not in occ
            ):
                seen.add(nxt)
                q.append(nxt)
    return len(seen)


def order_executable(scene: Scene, emb: Embodiment, order) -> bool:
    """Planner-side validity of a sampled order, no solver needed: walking the
    order, every object must be movable and reachable when its turn comes,
    until the goal is reachable. The tail after the goal opens is irrelevant --
    execution stops there. This checks EXECUTABILITY, not optimality: an order
    that clears a useless-but-reachable object first still passes."""
    cleared = set()
    for i in order:
        if reachable(scene, emb, scene.goal, cleared):
            return True
        if not emb.can_move(scene.objects[i]):
            return False
        if not reachable(scene, emb, scene.objects[i].cell, cleared):
            return False
        cleared.add(i)
    return reachable(scene, emb, scene.goal, cleared)


def carry_path(scene: Scene, positions, i, park):
    """Cell path (inclusive) for moving object i from its cell to `park`,
    through non-WALL cells that no other object occupies. None if none exists.

    Endpoints alone were never enough: two cells can both be legal and still
    have no way between them that does not cross a wall or another object.
    Scoring endpoints only let objects teleport through walls, and the viewer
    drew the straight line between them, so the picture agreed with the score
    and both were wrong.

    The robot's start cell is NOT an obstacle: the robot is the thing doing
    the pushing, so it steps aside. Blocking it walled off the only route out
    of a one-wide corridor and made `_corridor` unsolvable.

    # ponytail: 4-connected BFS, no clearance/rotation. Objects are one cell.
    # Widen to swept-extent when extent stops being cosmetic.
    """
    blocked = {c for j, c in enumerate(positions) if c is not None and j != i}
    return bfs_path(scene, positions[i], park, blocked)


def bfs_path(scene: Scene, src, dst, blocked = (), emb: Embodiment = None):
    """Shortest 4-connected cell path src -> dst avoiding `blocked` and any
    terrain the traveller cannot cross -- WALL for a carried object, whatever
    `emb.can_traverse` rejects for the robot. Inclusive of both ends; `dst`
    itself may be blocked (you are moving into it). None when unreachable.

    The one path primitive: the carried object and the robot both walk on it,
    so what the scorer accepts and what the viewer draws cannot drift apart.
    """
    # Two travellers, two rules. The robot climbs, so its rule reads the EDGE
    # it is stepping across and needs the cell it steps from; a carried object
    # is body-independent and only refuses WALL.
    ok = ((lambda frm, to: scene.can_enter(emb, frm, to)) if emb is not None
          else (lambda frm, to: int(scene.terrain[to]) != WALL))
    if src == dst:
        return [src]
    blocked = set(blocked) - {dst}
    prev = {src: None}
    q = deque([src])
    while q:
        cell = q.popleft()
        if cell == dst:
            out = []
            while cell is not None:
                out.append(cell)
                cell = prev[cell]
            return out[::-1]
        r, c = cell
        for dr, dc in NEIGHBORS:
            nxt = (r + dr, c + dc)
            if scene.in_bounds(nxt) and nxt not in prev and nxt not in blocked and ok(cell, nxt):
                prev[nxt] = cell
                q.append(nxt)
    return None


def _neighbours(scene: Scene, cell):
    """In-bounds 4-neighbours of a cell, in the module's own NEIGHBORS order."""
    return [(cell[0] + dr, cell[1] + dc) for dr, dc in NEIGHBORS
            if scene.in_bounds((cell[0] + dr, cell[1] + dc))]


def execute_plan(scene: Scene, emb: Embodiment, order, final_cells, strict_push = False):
    """Replay the plan cell by cell and report whether the goal opened.

    Returns (frames, ok). Each frame is (robot_cell, object_cells_tuple, note)
    -- a full world snapshot, so the viewer just draws snapshots instead of
    re-deriving anything. plan_success is this function's verdict, which is
    the point: a picture that disagrees with the score is a bug we already
    shipped once.

    Semantics: the robot walks to each object in turn (the other objects block
    it), then pushes it along a carry path to the planner's parking cell (the
    other objects block that too). The goal check is made from wherever the
    robot currently stands. Objects that stay put cost nothing.

    `strict_push` (2026-09-01, opt-in, default off = every historical number is
    unchanged) closes a hole found while measuring the inference recipe: the
    approach walk targets the OBJECT'S OWN CELL with that object excluded from
    the obstacles, so a plan can park an object on the cell it already occupies,
    move nothing, and still relocate the ROBOT into a cell it could not
    otherwise stand in. Chaining such no-op pushes walks the robot across a
    blocker it never cleared -- measured on seed 29 of the rooms_fork family: a
    plan that moves NOTHING scores as opening a goal that is provably
    unreachable from the start with every object in place. With `strict_push`
    the robot must stop on a free neighbour cell of the object and push from
    there, which is also what the physical pusher does.
    """
    positions = [o.cell for o in scene.objects]
    robot = scene.start
    frames = [(robot, tuple(positions), 'start')]
    if not scene.can_start(emb):
        return frames, False

    def others(i):
        return {c for j, c in enumerate(positions) if c is not None and j != i}

    def goal_open():
        # From where the robot IS, not from where it started. It walked to each
        # object to push it and does not teleport home afterwards; asking from
        # scene.start marks a plan FAIL while the robot stands next to an open
        # goal, because the objects it just parked block the way back.
        return bfs_path(scene, robot, scene.goal,
                        {c for c in positions if c is not None}, emb) is not None

    for i in order:
        if goal_open():
            return frames, True                     # extras are harmless
        if not emb.can_move(scene.objects[i]):
            return frames, False
        walk = bfs_path(scene, robot, positions[i], others(i), emb)
        if walk is None:
            return frames, False
        if strict_push:
            # stand BESIDE the object, never on it, with every object blocking
            occ_all = {c for c in positions if c is not None}
            stands = [n for n in _neighbours(scene, positions[i])
                      if n not in occ_all and scene.can_enter(emb, n, positions[i])]
            walk = None
            for st in stands:
                cand = bfs_path(scene, robot, st, occ_all - {st}, emb)
                if cand is not None and (walk is None or len(cand) < len(walk)):
                    walk = cand
            if walk is None:
                return frames, False
        park = final_cells.get(i)
        if (
            park is None
            or not scene.in_bounds(park)
            or int(scene.terrain[park]) == WALL
            or park in others(i)
            or park in (scene.start, scene.goal)
        ):
            return frames, False
        carry = carry_path(scene, positions, i, park)
        if carry is None:
            return frames, False                    # legal ends, no way there

        for cell in walk[1:]:
            robot = cell
            frames.append((robot, tuple(positions), f'approach obj{i}'))
        for cell in carry[1:]:
            robot, positions[i] = positions[i], cell
            frames.append((robot, tuple(positions), f'push obj{i}'))

    ok = goal_open()
    if ok:
        walk = bfs_path(scene, robot, scene.goal, {c for c in positions if c is not None}, emb)
        for cell in (walk or [])[1:]:
            frames.append((cell, tuple(positions), 'to goal'))
    return frames, ok


def plan_success(scene: Scene, emb: Embodiment, order, final_cells) -> bool:
    """Scene-level success: execute the plan with the PLANNER'S OWN parking
    cells (not the oracle's) and check the goal actually opens. This is the
    oracle-free scoring rule -- it needs no solver and judges cross-set modes
    fairly: any executable plan that opens the path counts.

    order: object indices in execution sequence
    final_cells: {obj_idx: cell} target cells for the moved objects
    """
    return execute_plan(scene, emb, order, final_cells)[1]


def park_candidates(scene: Scene, positions, i, with_depth=False):
    """Free, non-wall, non-start/goal cells in BFS order from object i's cell,
    goal-ward-preferred within each BFS ring (same distance -> the one that
    moves the object further toward scene.goal comes first).

    Expansion is non-WALL only and deliberately NOT occupancy-aware: making it
    so starves plan_search(park=True), which passes every remaining movable
    object as `pending`. The carry check lives in plan_success instead, and
    _make drops the labels that fail it -- see MEASURED_LABEL_LOSS below.

    The goal-ward tiebreak (2026-08-20, rooms physical-stall investigation):
    a `_flanked` object's two axis-neighbors sit at the SAME BFS depth, so
    plain traversal order (NEIGHBORS tuple order) decided which side it got
    parked on -- found to land the object BACKWARD (robot's arrival side, not
    past the gate) in ~95% of solvable rooms scenes, purely by accident of
    that order. Harmless when there's lateral room to walk around (still
    reachable, `find_parking` just validates it), fatal when the object sits
    in a genuine 1-wide throat: the physical executor then has no way to
    reach the correct push face and stalls the full phase budget (never a
    planning-search failure -- `find_parking`'s own reachability check
    passes, since clearing the throat reopens it from either direction
    abstractly). Sorting each ring goal-ward keeps the exact same
    nearest-first/reachability-validated contract -- only same-distance tie
    order changes.
    """
    occupied = {c for j, c in enumerate(positions) if c is not None and j != i}
    blocked = occupied | {scene.start, scene.goal}
    start_cell = positions[i]
    goal_vec = (scene.goal[0] - start_cell[0], scene.goal[1] - start_cell[1])

    def goalward(cell):
        return (cell[0] - start_cell[0]) * goal_vec[0] + (cell[1] - start_cell[1]) * goal_vec[1]

    seen, frontier = {start_cell}, [start_cell]
    depth = 0
    while frontier:
        ring = [c for c in frontier if c not in blocked and int(scene.terrain[c]) != WALL and c != start_cell]
        ring.sort(key=goalward, reverse=True)
        if with_depth:  # PLAN 141: lets find_parking re-rank WITHIN a ring without touching ring order
            yield from ((depth, c) for c in ring)
        else:
            yield from ring
        depth += 1
        next_frontier = []
        for cell in frontier:
            r, c = cell
            for dr, dc in NEIGHBORS:
                nxt = (r + dr, c + dc)
                if scene.in_bounds(nxt) and nxt not in seen and int(scene.terrain[nxt]) != WALL:
                    seen.add(nxt)
                    next_frontier.append(nxt)
        frontier = next_frontier


def park_valid(scene: Scene, emb: Embodiment, positions, i, pending, cand) -> bool:
    """Can object i park at `cand` without stranding the rest of the plan?
    Extracted 2026-08-24 from find_parking's inner `valid` closure, byte-
    identical logic (verified against git HEAD across the full eval seed
    range before trusting it) -- exposed as a module function because it IS
    an embodiment-conditioned per-cell feasibility oracle, exactly the dense
    label source the affordance-map work needs (experiments/
    stageb_clearance_signal/RESULTS.md sect22): (scene, emb, object, cell)
    -> bool, with reach_positions carrying the terrain x embodiment
    dependence and the path-clip checks carrying real footprint geometry.

    Checks: with i at cand (already-parked objects staying put), every
    pending object stays reachable in sequence (optimistically vanishing
    after its own move), the goal opens at the end, and the straight-line
    push path from i's current cell to cand clips neither a wall's real
    footprint nor another object's."""
    pos2 = list(positions)
    pos2[i] = cand
    for j in pending:
        if not reach_positions(scene, emb, pos2, pos2[j]):
            return False
        pos2[j] = None  # optimistic: j will be parked somewhere workable
    if not reach_positions(scene, emb, pos2, scene.goal):
        return False
    # margin = object i's OWN half-extent only, not PATH_CLEARANCE (~two
    # half-extents summed -- see that constant's docstring). Both targets
    # here are real-footprint point clouds (wall_points traces the wall's
    # own unit square, other_points traces object j's own perimeter), so
    # the far side's half-extent is already spent in the point positions
    # themselves; adding PATH_CLEARANCE on top double-counts it. Bug found
    # 2026-08-21 (geometry_points_n150): with PATH_CLEARANCE, this tripped
    # for 37/47 objects at their OWN resting cell, zero movement --
    # cell-to-cell pitch is 1.0 and _wall_cell_points jitters across a
    # wall's full unit square, so any wall-adjacent object (i.e. nearly
    # every object in a corridor/gate/room scene, the entire case this
    # exists for) has a wall point ~0.5 cells away, comfortably inside
    # 0.85 -- valid() rejected almost every candidate, forcing systematic
    # _nearest_free fallback (zero validation by design) and collapsing
    # oracle's physical success 0.65->0.185 on N=150 (the N=60
    # abstract-only smoke test never caught it: plan_success replays a
    # fixed order+cells, it never re-derives candidates via find_parking).
    own_half = min(scene.objects[i].extent, MAX_PHYSICAL_EXTENT) / 2.0
    if _path_clips_wall(positions[i], cand, scene.wall_points, margin=own_half):
        return False
    return not any(j != i and positions[j] is not None
                   and _path_clips_object(positions[i], cand, positions[j],
                                          other_points=scene.objects[j].local_points,
                                          margin=own_half)
                   for j in range(len(positions)))


def prune_unpushable(scene: Scene, order, emb: Embodiment):
    """Pusher-feasible plan from a solve() order (PLAN 132): walk the order with the robot's cell tracked
    (start -> the cell the object left last); an object with no pushable park from where the robot stands
    is DROPPED from the plan (rooms 1009: after the first doorway blocker is pushed one cell into the
    corridor, the robot cannot get behind the second one). Sets goal_cell for the kept objects (pushable
    park, find_parking tiers 1-2) and returns the kept order. Dropped objects keep goal_cell None and count
    as untouched for the strict metric -- if the walk shoves them, that shows up as disturbance."""
    from clear.maze.world import pushable_route
    positions = [o.cell for o in scene.objects]
    robot_cell = tuple(scene.start)
    kept = []
    routes = {}
    can_drag = getattr(emb, "can_drag", False)
    for k, i in enumerate(order):
        pending = [x for x in order[k + 1:]]
        cand = find_parking(scene, emb, positions, i, pending, robot_cell=robot_cell)
        blocked = {c for j, c in enumerate(positions) if c is not None and j != i}
        route = pushable_route(scene, positions[i], cand, blocked, robot_cell=robot_cell, can_drag=can_drag) if cand is not None else None
        if route is None:
            scene.objects[i].goal_cell = None
            continue
        cells, modes = route
        scene.objects[i].goal_cell = cand
        positions[i] = cand
        if len(cells) > 1:
            d = (cells[-1][0] - cells[-2][0], cells[-1][1] - cells[-2][1])
            robot_cell = tuple(cells[-2]) if modes[-1] == "push" else (cells[-1][0] + d[0], cells[-1][1] + d[1])
        routes[int(i)] = {"cells": [list(c) for c in cells], "modes": modes}
        kept.append(i)
    LAST_ROUTES.clear(); LAST_ROUTES.update(routes)
    return kept


LAST_ROUTES = {}   # object idx -> {"cells", "modes"} of the last prune_unpushable call (executors read the modes)


# PLAN 141 (2026-08-29, rooms 1018): a park cell 4-adjacent to a big bystander leaves the two box
# footprints ~0.3 m apart (obj_0 half 0.42 m + obj_2 half 0.66 m in a 1.475 m cell); the physical
# push overshoots into it (0.20 m 'untouched object disturbed'). Opt-in re-ranking: within each BFS
# ring of park_candidates (nearest-first contract untouched -- the 2026-08-20/21 attempts that reached
# FARTHER for a 'nicer' park regressed N=150 physical), candidates whose footprint gap to any other
# object is below PAMO_PARK_CLEARANCE_M go last. Cell size mirrors mj_util.batch_physical_eval.NATIVE_CELL
# (not imported: mj_util imports this module); half-extents mirror the bridge's min(extent, 0.9)/2 rule.
PARK_CLEARANCE_M = float(os.environ.get("PAMO_PARK_CLEARANCE_M", "0"))
_PARK_CELL_M = float(os.environ.get("PAMO_PARK_CELL_M", "1.475"))


def _park_tight(scene: Scene, positions, i, cand, margin_m) -> bool:
    """True if object i parked at `cand` would sit closer than `margin_m` (box face to box face,
    separated along at least one axis counts as clear) to any other object at its current cell."""
    h_i = min(float(scene.objects[i].extent), 0.9) * _PARK_CELL_M / 2
    for j, cj in enumerate(positions):
        if j == i or cj is None:
            continue
        h_j = min(float(scene.objects[j].extent), 0.9) * _PARK_CELL_M / 2
        gap = max(abs(cand[0] - cj[0]) * _PARK_CELL_M - h_i - h_j,
                  abs(cand[1] - cj[1]) * _PARK_CELL_M - h_i - h_j)
        if gap < margin_m:
            return True
    return False


def find_parking(scene: Scene, emb: Embodiment, positions, i, pending, robot_cell=None):
    """Nearest parking cell for object i that does not strand the rest of the
    plan: with i parked there (already-parked objects staying put), every
    pending object must remain reachable in sequence -- optimistically
    vanishing after its own move -- and the goal must open at the end.

    Discovered the hard way: plain nearest-free parking put an object in the
    corridor the robot needed next (plan_success caught it). Vanish-semantics
    solvers cannot see this failure; parked-occupies scoring can.

    3rd pass tried and reverted (2026-08-21, corner fix): within the
    axis-forward tier, additionally preferred a candidate that wasn't in a
    WALL-on-two-perpendicular-sides corner (seed 1006's actual failure --
    `_flanked_axes` only sees opposite-side flanking, never a corner). Abstract
    check looked strictly better (seed 1006 fixed, solvable-scene count
    unchanged). N=150 physical caught what the abstract check couldn't: this
    is a SEQUENTIAL per-object search (`assign_goal_cells` calls this once per
    object, positions accumulate), so steering object i away from a corner
    that happened to be conveniently out of everyone else's way cost more,
    later, than it gained -- same 130-scene oracle set (n_unsolvable/n_errored
    both identical) went 0.692->0.615, and all 3 PAMO seeds dropped together
    on the exact matching solvable-scene subset (0.610/0.648/0.667 ->
    0.571/0.629/0.648). It also made `build_examples`'s own consistency check
    stricter, silently shrinking the PAMO arms' n_used by 7/150 (45 vs 38
    unsolvable) -- a cost the abstract check never measures since it never
    runs that downstream check. Reverted in full; seed 1006's corner case
    stays an open, ~1-in-150 unfixed edge case. See plan doc for the numbers.

    First attempt at axis-forward-first reverted, 2nd attempt below (2026-08-20,
    rooms physical-stall investigation): for a flanked object, only accept a
    candidate on the goal side of its one escape axis, searching arbitrarily
    farther before falling back to the unrestricted (possibly wrong-side)
    search. Abstract metric loved it (eliminated the row-flanked+backward
    pattern 100%, was 20.7% of solvable rooms scenes after `park_candidates`'
    own tiebreak). 1st attempt was physically net zero on a 50-seed batch:
    fixed 2 genuine freeze-stalls, but a 3rd seed (1001) that used to succeed
    regressed -- traced: pushing the object the NOW-much-longer distance to
    the nearer-in-abstract-terms-but-actually-farther forward cell sent it
    within 0.45 grid cells of obj_2 (not in this order) at closest approach,
    which then moved 1.26m despite not being touched on purpose --
    `park_candidates`/`find_parking` only reasoned about grid-CELL occupancy,
    never the straight-line push PATH between two cells. `valid()` below adds
    exactly that check (`_path_clips_object`, same sampled-line technique
    spot_push_bridge.py's `_line_crosses_wall` already uses for walls) --
    with it, the axis-forward pass can search as far as it needs to without
    silently routing a push through another object's footprint.
    """
    def valid(cand):
        if not park_valid(scene, emb, positions, i, pending, cand):
            return False
        return True

    row_fl, col_fl = _flanked_axes(scene, positions[i])
    row_dir = 1 if scene.goal[0] >= positions[i][0] else -1
    col_dir = 1 if scene.goal[1] >= positions[i][1] else -1

    def axis_forward(cand):
        if row_fl and (cand[0] - positions[i][0]) * row_dir <= 0:
            return False
        if col_fl and (cand[1] - positions[i][1]) * col_dir <= 0:
            return False
        return True

    if PARK_CLEARANCE_M > 0:  # PLAN 141 (opt-in): same nearest-first rings, tight-fit candidates last within a ring
        _dc = list(park_candidates(scene, positions, i, with_depth=True))
        _dc.sort(key=lambda t: (t[0], _park_tight(scene, positions, i, t[1], PARK_CLEARANCE_M)))
        candidates = [c for _, c in _dc]
    else:
        candidates = list(park_candidates(scene, positions, i))
    if row_fl or col_fl:
        for cand in candidates:
            if axis_forward(cand) and valid(cand):
                return cand
    for cand in candidates:
        if valid(cand):
            return cand
    return None


def assign_goal_cells(scene: Scene, order, emb: Embodiment) -> None:
    """Park each moved object, in plan order, at the nearest cell that keeps
    the remaining plan executable (find_parking). Mutates goal_cell in place;
    untouched objects stay put. Falls back to plain nearest-free if no
    validated spot exists (the plan is then doomed anyway and plan_success
    will say so).

    # ponytail: still no clearance/stability modeling -- that matters only
    # once the velocity head is collision-limited rather than data-limited.
    """
    positions = [o.cell for o in scene.objects]
    robot_cell = None
    for k, i in enumerate(order):
        cand = find_parking(scene, emb, positions, i, list(order[k + 1:]), robot_cell=robot_cell)
        if cand is None:
            taken = {c for c in positions if c is not None} | {scene.start, scene.goal}
            cand = _nearest_free(scene, positions[i], taken) or positions[i]
        scene.objects[i].goal_cell = cand
        positions[i] = cand


def _nearest_free(scene: Scene, start, taken):
    """Last-resort park, same non-WALL expansion as park_candidates."""
    seen, q = {start}, deque([start])
    while q:
        cell = q.popleft()
        if cell not in taken and int(scene.terrain[cell]) != WALL:
            return cell
        r, c = cell
        for dr, dc in NEIGHBORS:
            nxt = (r + dr, c + dc)
            if scene.in_bounds(nxt) and nxt not in seen and int(scene.terrain[nxt]) != WALL:
                seen.add(nxt)
                q.append(nxt)
    return None


def _self_check_path_clips():
    """docs/PLAN_verification_and_sota_comparison.md §21/§22 -- smallest thing
    that fails if the real-geometry path-clip checks regress. oracle.py had no
    self-check convention before this; scoped to just the 3 new/changed
    functions, not a full find_parking scenario."""
    # _path_clips_object: None other_points must be BYTE-IDENTICAL to the
    # original single-point behavior -- the whole backward-compat promise.
    assert _path_clips_object((0.0, 0.0), (0.0, 10.0), (0.0, 5.0)) is True   # dead center of the segment
    assert _path_clips_object((0.0, 0.0), (0.0, 10.0), (5.0, 5.0)) is False  # PATH_CLEARANCE=0.85 away

    # other_points shifts the check to real footprint samples, anchored at
    # other_cell -- a point sitting ON the segment (even far from other_cell
    # itself) must now register as a clip.
    far_offset = np.array([[0.0, 4.9]])  # other_cell=(0,0) + this = (0, 4.9), on the segment
    assert _path_clips_object((0.0, 0.0), (0.0, 10.0), (0.0, 0.0), other_points=far_offset) is True
    safe_offset = np.array([[10.0, 0.0]])  # (10, 0), nowhere near the segment
    assert _path_clips_object((0.0, 0.0), (0.0, 10.0), (0.0, 0.0), other_points=safe_offset) is False

    # _path_clips_wall: None/empty must be a permanent no-op (the "nothing
    # ever checked this before" contract).
    assert _path_clips_wall((0.0, 0.0), (0.0, 10.0), None) is False
    assert _path_clips_wall((0.0, 0.0), (0.0, 10.0), np.zeros((0, 2))) is False
    # a real wall point sitting on the segment must clip it.
    assert _path_clips_wall((0.0, 0.0), (0.0, 10.0), np.array([[0.0, 5.0]])) is True
    assert _path_clips_wall((0.0, 0.0), (0.0, 10.0), np.array([[5.0, 5.0]])) is False

    # find_parking's own-half-extent margin (2026-08-21 fix, see valid()'s
    # comment): a wall point 0.5 cells off the segment -- the common
    # wall-adjacent-resting-cell distance that made PATH_CLEARANCE=0.85 trip
    # on 37/47 objects at zero movement -- must NOT clip at a real object's
    # capped half-extent (<=0.45), only at the old flat margin.
    adjacent_wall = np.array([[0.5, 5.0]])
    assert _path_clips_wall((0.0, 0.0), (0.0, 10.0), adjacent_wall) is True  # old flat 0.85: false positive
    assert _path_clips_wall((0.0, 0.0), (0.0, 10.0), adjacent_wall, margin=0.45) is False  # fixed

    print("ok _path_clips_object/_path_clips_wall: fallback byte-identical to the "
         "original single-point behavior, real-geometry mode correctly anchored, "
         "own-half-extent margin fix confirmed")


if __name__ == "__main__":
    _self_check_path_clips()


# ---------------------------------------------------------------------------
# look-ahead parking (2026-08-25, PLAN sect77; user: "다음 object interaction까지
# look-ahead해서 어디로 밀어야 적절할지 cost -- minimum total distance / time /
# number of interactions"). `assign_goal_cells` parks each object at the NEAREST
# validated cell, greedily, one object at a time -- it never asks where the robot
# has to walk next. This variant searches the joint assignment over the whole
# order (top-k validated candidates per object, sequential park_valid exactly as
# before) and picks the one minimizing an execution-time proxy:
#   cost = sum_i  c_push * push_dist_i                 (object i: its cell -> park)
#        + sum_i  c_walk * transit_dist_i              (robot: after park_{i-1} -> standoff_i)
#        + c_walk * final_walk_dist                    (robot: after park_k -> scene.goal)
# distances in cells along walls+parked-objects-avoiding BFS paths (cell_path on a
# blocked terrain), robot proxy after a push = behind the park along the push
# axis. c_push/c_walk mirror the executor budgets (15 s/m push, ~4 s/m walk).
# "number of interactions" is the order length, already minimal in `solve`.
LOOKAHEAD_TOP_K = 6
LOOKAHEAD_C_PUSH = 15.0 / 1.475  # s per cell of push
LOOKAHEAD_C_WALK = 4.0 / 1.475   # s per cell of walking
LOOKAHEAD_STANDOFF_CELLS = 0.9   # robot proxy behind a park, in cells


def _blocked_for_walk(scene: Scene, positions, skip=()):
    t = scene.terrain.copy()
    for j, c in enumerate(positions):
        if c is not None and j not in skip:
            t[c] = WALL
    return t


def _walk_cells(scene: Scene, terrain, src, dst):
    """BFS path length in cells on `terrain` (WALL blocked), or a large penalty
    if disconnected / src or dst out of grid. src may be a fractional (r, c)
    robot proxy -- rounded to the nearest in-bounds cell."""
    from clear.data.grid import cell_path
    h, w = scene.terrain.shape
    s = (int(min(max(round(src[0]), 0), h - 1)), int(min(max(round(src[1]), 0), w - 1)))
    d = (int(dst[0]), int(dst[1]))
    if s == d:
        return 0.0
    try:
        p = cell_path(terrain, s, d)
    except KeyError:
        return 50.0
    return float(len(p) - 1) if p else 50.0


def _standoff_cell(park, origin, dist=LOOKAHEAD_STANDOFF_CELLS):
    """fractional (r, c) `dist` cells from `park` back toward `origin` (where the
    robot stands after pushing origin -> park; where it must stand BEFORE pushing
    an object at `park` toward... -- same geometry, used for both)."""
    dr, dc = origin[0] - park[0], origin[1] - park[1]
    n = (dr * dr + dc * dc) ** 0.5
    if n < 1e-9:
        return (float(park[0]), float(park[1]))
    return (park[0] + dr / n * dist, park[1] + dc / n * dist)


def assign_goal_cells_lookahead(scene: Scene, order, emb: Embodiment, top_k=LOOKAHEAD_TOP_K,
                                c_push=LOOKAHEAD_C_PUSH, c_walk=LOOKAHEAD_C_WALK, robot_cell=None):
    """Joint park assignment minimizing push + transit + final-walk time proxy
    (module comment above). Same validity contract as assign_goal_cells
    (sequential park_valid with the remaining order pending); falls back to
    assign_goal_cells when no full valid assignment exists among the top-k
    candidates. Mutates goal_cell in place. Returns (cost, n_combos_evaluated)."""
    order = list(order)
    if not order:
        return 0.0, 0
    robot0 = tuple(scene.start) if robot_cell is None else tuple(robot_cell)
    positions0 = [o.cell for o in scene.objects]
    best = {"cost": float("inf"), "parks": None, "n": 0}

    def rec(k, positions, robot, cost):
        if cost >= best["cost"]:
            return
        if k == len(order):
            terrain = _blocked_for_walk(scene, positions)
            total = cost + c_walk * _walk_cells(scene, terrain, robot, scene.goal)
            best["n"] += 1
            if total < best["cost"]:
                best["cost"], best["parks"] = total, [positions[i] for i in order]
            return
        i = order[k]
        pending = order[k + 1:]
        cur = positions[i]
        # robot walks from `robot` to the push standoff behind object i (its far side from
        # the park is unknown before choosing the park -> use the object's cell as the
        # transit target, minus the object itself; the standoff is ~1 cell around it)
        terrain_walk = _blocked_for_walk(scene, positions, skip=(i,))
        walk = _walk_cells(scene, terrain_walk, robot, cur)
        n_valid = 0
        for cand in park_candidates(scene, positions, i):
            if not park_valid(scene, emb, positions, i, pending, cand):
                continue
            n_valid += 1
            push = ((cand[0] - cur[0]) ** 2 + (cand[1] - cur[1]) ** 2) ** 0.5
            pos2 = list(positions)
            pos2[i] = cand
            rec(k + 1, pos2, _standoff_cell(cand, cur), cost + c_walk * walk + c_push * push)
            if n_valid >= top_k:
                break

    rec(0, list(positions0), (float(robot0[0]), float(robot0[1])), 0.0)
    if best["parks"] is None:
        assign_goal_cells(scene, order, emb)
        return float("nan"), best["n"]
    for i, cand in zip(order, best["parks"]):
        scene.objects[i].goal_cell = cand
    return best["cost"], best["n"]
