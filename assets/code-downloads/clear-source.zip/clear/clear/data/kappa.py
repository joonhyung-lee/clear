"""kappa(r) -- the measured capability probe vector, and its cache.

docs/PAPER_FREEZE_2026-08-24.md section 2: kappa(r) in R^9 = push mass curve
(5 buckets) ++ step-height pass rate (3 heights) ++ arm reach. Values are
MEASURED (or honestly derived) off the roster assets by the scripts in
experiments/kappa_measure/, which write the cache this module loads. Nothing
here measures anything -- this is the definition and the loader.

Every component carries a provenance tag, because the components are NOT all
the same kind of number (raw traction was tried and is not comparable across
the roster -- see mj_util/embodiment.py's traction() docstring):

  measured-dynamic    a real closed-loop physical rollout (spot push via the
                      third-party/sumo executor; google_robot ledge drive)
  measured-kinematic  a kinematic ceiling off the asset (FK max reach,
                      foot-lift ceiling) -- an upper bound, not a controller
  asset-derived       computed from asset constants only (mass-ratio push
                      proxy for robots with no push executor; reach 0.0 for
                      a robot with no arm)

    python3 -m clear.data.kappa      # self-check against the cache, if built
"""
import json
import os

import numpy as np

MASS_BUCKETS = (2.0, 5.0, 10.0, 15.0, 25.0)   # kg -- spans grid.py's 0.5-25 log-uniform
STEP_HEIGHTS = (0.05, 0.15, 0.30)             # m  -- classify_terrain's FLAT_MAX/WALL_MIN band

COMPONENTS = tuple(
    [f"push_kg_{int(m)}" for m in MASS_BUCKETS]
    + [f"step_m_{int(h * 100):03d}" for h in STEP_HEIGHTS]
    + ["arm_reach_m"]
)  # 5 + 3 + 1 = 9

ROSTER = ("husky", "spot", "spot_w_arm", "g1_wo_wrist")

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CACHE_PATH = os.path.join(_ROOT, "runs", "kappa_cache", "kappa_v1.json")


def load_entry(robot_name, cache_path=None):
    """Full cache record for one robot: {values, provenance, meta}."""
    path = cache_path or CACHE_PATH
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"kappa cache not found at {path} -- build it with the scripts in "
            f"experiments/kappa_measure/ (measure_reach.py, measure_step.py, "
            f"measure_push.py --robot spot, derive_push_proxy.py)")
    with open(path) as f:
        cache = json.load(f)
    if robot_name not in cache["robots"]:
        raise KeyError(f"no kappa entry for {robot_name!r} in {path}; "
                       f"have {sorted(cache['robots'])}")
    return cache["robots"][robot_name]


def load_kappa(robot_name, cache_path=None):
    """-> np.ndarray (9,) float32, ordered as COMPONENTS. Raises if the cache
    or any component is missing -- a partial vector is worse than an error."""
    entry = load_entry(robot_name, cache_path)
    missing = [c for c in COMPONENTS if c not in entry["values"]]
    if missing:
        raise KeyError(f"kappa cache entry for {robot_name!r} is missing "
                       f"{missing} -- rerun the matching measure script")
    return np.array([entry["values"][c] for c in COMPONENTS], dtype=np.float32)


def update_cache(robot_name, values, provenance, meta, cache_path=None):
    """Merge one robot's partial measurement into the cache (read-modify-write).
    `values`: {component_name: float} -- a subset of COMPONENTS.
    `provenance`: {component_name: tag} for the same keys.
    `meta`: free-form dict describing this measurement run (script, seeds, N...),
    stored under the series name so later runs of OTHER series don't clobber it."""
    path = cache_path or CACHE_PATH
    unknown = set(values) - set(COMPONENTS)
    assert not unknown, f"unknown kappa components: {unknown}"
    tags = {"measured-dynamic", "measured-kinematic", "asset-derived"}
    bad = {c: p for c, p in provenance.items() if p not in tags}
    assert not bad, f"unknown provenance tags: {bad}"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cache = {"version": "kappa_v1", "components": list(COMPONENTS),
             "mass_buckets": list(MASS_BUCKETS), "step_heights": list(STEP_HEIGHTS),
             "robots": {}}
    if os.path.exists(path):
        with open(path) as f:
            cache = json.load(f)
    entry = cache["robots"].setdefault(
        robot_name, {"values": {}, "provenance": {}, "meta": {}})
    entry["values"].update({c: float(v) for c, v in values.items()})
    entry["provenance"].update(provenance)
    entry["meta"][meta.get("series", "misc")] = meta
    with open(path, "w") as f:
        json.dump(cache, f, indent=2, sort_keys=True)
    return path


def _self_check():
    assert len(COMPONENTS) == 9, COMPONENTS
    assert len(set(COMPONENTS)) == 9
    if not os.path.exists(CACHE_PATH):
        print(f"ok (definition only): 9 components; cache not built yet at {CACHE_PATH}")
        return
    for name in ROSTER:
        k = load_kappa(name)
        assert k.shape == (9,) and np.isfinite(k).all(), (name, k)
        assert (k[:8] >= 0).all() and (k[:8] <= 1).all(), (name, "rates must be in [0,1]", k)
        assert 0.0 <= k[8] < 3.0, (name, "arm reach out of sane range", k[8])
        prov = load_entry(name)["provenance"]
        print(f"{name:14} kappa={np.round(k, 3).tolist()}  "
              f"prov={{push:{prov[COMPONENTS[0]]}, step:{prov[COMPONENTS[5]]}, "
              f"reach:{prov['arm_reach_m']}}}")
    ks = {n: load_kappa(n) for n in ROSTER}
    assert any((ks[a] != ks[b]).any() for a in ROSTER for b in ROSTER if a < b), \
        "all kappa vectors identical -- the probe separates nothing"
    print("ok: 4 robots, 9 components each, vectors separate")


if __name__ == "__main__":
    _self_check()
