"""Morphology rows: the body's OWN structure as the capability input.

kappa, third framing (2026-09-02, after the spec sheet was retired and the
experience-log variant was rejected): the planner should read the BODY, not a
table about the body. Each embodiment is a set of per-link rows extracted from
its MJCF -- mass, inertia, geometry, the incoming joint's type/range, the
actuator driving it -- and a set encoder turns those rows into the one kappa
token. Nothing behavioural is handed over: no mass limit, no climb limit, no
probe outcome. Whatever "capability" means, the model has to read it off the
structure, the way it already reads movability off mass + shape when
`can_move` is withheld.

Zero-shot is the point: a NEW body needs no calibration run and no table entry
-- parse its MJCF, encode, plan. The calibration instruments in
experiments/kappa_measure/ are demoted to label generation and validation.

Training diversity comes from MJCF-consistent VARIANTS of the three roster
bodies: `scaled_variant` scales the model's masses / actuator gears / geometry
by explicit factors and scales the paired oracle Embodiment limits by the SAME
factors (documented scaling laws below). The encoder input and the label
source are two views of one intervention, so the mapping morphology ->
capability is learnable and never leaks the limits themselves.

Scaling laws (crude on purpose -- they only need to be CONSISTENT between the
MJCF edit and the label edit, not exact physics):
  gear_f   actuator force scale        -> max_mass x gear_f
  size_f   geometry / limb length      -> climb x size_f (set explicitly on the
                                          variant: Embodiment.climb is authoritative
                                          when non-None), max_extent x size_f,
                                          push_height x size_f
  mass_f   body masses                 -> no label change (a heavier body pushes
                                          no less here; it shows the encoder a
                                          correlated-but-not-causal axis)

    python -m clear.data.morphology     # self-check
"""
import os
from dataclasses import replace

import mujoco
import numpy as np

from clear.data.capability import EMBODIMENTS, PUSH_HEIGHTS, Embodiment

ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                      'asset')

# the three class bodies' physical stand-ins (same mapping ego_render uses)
BODY_XML = {
    'wheel': 'husky/husky_wo_plate.xml',
    'quadruped': 'spot_w_arm/spot_arm_pos_native.xml',
    'humanoid': 'g1/g1_pos_native.xml',
}

N_MORPH_FEAT = 18
N_MORPH_FEAT_V2 = 41       # v1 + joint-frame pose + parent-id bits + actuator + geom type
N_MORPH_FEAT_V3 = 20       # v1 + the two leg-geometry magnitudes (metres), nothing else
PARENT_BITS = 6
MAX_LINKS = 64          # collate pads to this; g1 has ~40 bodies

# Which row set the DATA layer emits. Process-global on purpose: rows are
# attached example-by-example inside build_examples workers, and a per-call
# argument would have to thread through six layers that otherwise do not know
# morphology exists. train_pamo sets it from --morph_rows_v2 BEFORE
# variant_grid(); eval_ood.load_model sets it from the checkpoint args.
ROWS_VERSION = 1


def set_rows_version(v):
    global ROWS_VERSION
    assert v in (1, 2, 3), v
    ROWS_VERSION = int(v)


def feat_dim(version = None):
    v = version or ROWS_VERSION
    return {1: N_MORPH_FEAT, 2: N_MORPH_FEAT_V2, 3: N_MORPH_FEAT_V3}[v]


def _rows_fn():
    return {1: link_rows_from_model, 2: link_rows_v2_from_model,
            3: link_rows_v3_from_model}[ROWS_VERSION]

_JNT_ONEHOT = {mujoco.mjtJoint.mjJNT_FREE: 0, mujoco.mjtJoint.mjJNT_BALL: 1,
               mujoco.mjtJoint.mjJNT_HINGE: 2, mujoco.mjtJoint.mjJNT_SLIDE: 3}


def link_rows_from_model(model):
    """MjModel -> (L, N_MORPH_FEAT) float32 rows, one per non-world body.

    Row layout (normalised where noted):
      0     log1p(body mass)
      1-3   log1p(diagonal inertia)
      4     max geom half-size on this body (m)
      5     n geoms on this body / 4
      6     tree depth / 10
      7     is leaf (no children)
      8-11  incoming joint type one-hot (free, ball, hinge, slide); all 0 = welded
      12-14 |joint axis| (hinge/slide; else 0)
      15    joint range span / (2 pi)
      16    log1p(|actuator gear| driving this joint); 0 = passive
      17    log1p(joint damping)
    """
    nb = model.nbody
    children = {b: [] for b in range(nb)}
    for b in range(1, nb):
        children[int(model.body_parentid[b])].append(b)
    depth = np.zeros(nb)
    for b in range(1, nb):
        d, p = 0, b
        while p > 0:
            p = int(model.body_parentid[p]); d += 1
        depth[b] = d
    gear_by_jnt = {}
    for a in range(model.nu):
        if model.actuator_trntype[a] == mujoco.mjtTrn.mjTRN_JOINT:
            j = int(model.actuator_trnid[a, 0])
            gear_by_jnt[j] = max(gear_by_jnt.get(j, 0.0), abs(float(model.actuator_gear[a, 0])))
    rows = []
    for b in range(1, nb):
        r = np.zeros(N_MORPH_FEAT, dtype = np.float32)
        r[0] = np.log1p(float(model.body_mass[b]))
        r[1:4] = np.log1p(np.abs(model.body_inertia[b]))
        gadr, gnum = int(model.body_geomadr[b]), int(model.body_geomnum[b])
        if gnum:
            r[4] = float(model.geom_size[gadr:gadr + gnum].max())
        r[5] = gnum / 4.0
        r[6] = depth[b] / 10.0
        r[7] = float(not children[b])
        jadr, jnum = int(model.body_jntadr[b]), int(model.body_jntnum[b])
        if jnum:
            j = jadr                                  # first joint into this body
            r[8 + _JNT_ONEHOT[mujoco.mjtJoint(int(model.jnt_type[j]))]] = 1.0
            if model.jnt_type[j] in (mujoco.mjtJoint.mjJNT_HINGE, mujoco.mjtJoint.mjJNT_SLIDE):
                r[12:15] = np.abs(model.jnt_axis[j])
            lo, hi = model.jnt_range[j]
            r[15] = float(hi - lo) / (2 * np.pi) if hi > lo else 0.0
            r[16] = np.log1p(gear_by_jnt.get(j, 0.0))
            dadr = int(model.jnt_dofadr[j])
            r[17] = np.log1p(float(model.dof_damping[dadr]))
        rows.append(r)
    return np.stack(rows).astype(np.float32)


def link_rows_v2_from_model(model):
    """v1 rows + what T2's robot tokenization carries that v1 dropped
    (references/Transformer-Transformer.pdf; t2/robotok/token.py):

      18-20  body frame pos in PARENT frame (the actual kinematics -- leg
             length lives here, not in inertia proxies)
      21-24  body frame quat (wxyz) in parent frame
      25-30  parent link id as a 6-bit binary code (T2's BinaryEncoding trick:
             explicit tree topology without a GNN)
      31     kp, 32 kv (log1p)  -- position/velocity servo gains
      33     |ctrl range| span, 34 log1p(|force range| span)
      35-39  geom type one-hot (box, sphere, cylinder, capsule, mesh/other)
      40     n joints into this body / 4  (multi-dof flag)

    Scale-spanning quantities stay log-encoded, same reason as T2's
    LogEncoding on mass/diaginertia ("span many orders of magnitude").
    """
    base = link_rows_from_model(model)
    nb = model.nbody
    import mujoco as mj
    gear_kp_kv = {}
    for a in range(model.nu):
        if model.actuator_trntype[a] == mj.mjtTrn.mjTRN_JOINT:
            j = int(model.actuator_trnid[a, 0])
            kp = float(model.actuator_gainprm[a, 0])
            kv = float(-model.actuator_biasprm[a, 2]) if model.actuator_biasprm.shape[1] > 2 else 0.
            cr = float(model.actuator_ctrlrange[a, 1] - model.actuator_ctrlrange[a, 0])
            fr = float(model.actuator_forcerange[a, 1] - model.actuator_forcerange[a, 0])
            old = gear_kp_kv.get(j, (0., 0., 0., 0.))
            gear_kp_kv[j] = (max(old[0], kp), max(old[1], kv), max(old[2], cr), max(old[3], fr))
    GEOM_OH = {mj.mjtGeom.mjGEOM_BOX: 0, mj.mjtGeom.mjGEOM_SPHERE: 1,
               mj.mjtGeom.mjGEOM_CYLINDER: 2, mj.mjtGeom.mjGEOM_CAPSULE: 3}
    ext = np.zeros((nb - 1, N_MORPH_FEAT_V2 - N_MORPH_FEAT), dtype = np.float32)
    for b in range(1, nb):
        r = ext[b - 1]
        r[0:3] = model.body_pos[b]
        r[3:7] = model.body_quat[b]
        parent = int(model.body_parentid[b])
        for k in range(PARENT_BITS):
            r[7 + k] = (parent >> k) & 1
        jadr, jnum = int(model.body_jntadr[b]), int(model.body_jntnum[b])
        if jnum:
            kp, kv, cr, fr = gear_kp_kv.get(jadr, (0., 0., 0., 0.))
            r[13] = np.log1p(kp); r[14] = np.log1p(kv)
            r[15] = min(cr, 20.) / 20.; r[16] = np.log1p(fr)
        gadr, gnum = int(model.body_geomadr[b]), int(model.body_geomnum[b])
        if gnum:
            gt = int(model.geom_type[gadr])
            r[17 + GEOM_OH.get(mj.mjtGeom(gt), 4)] = 1.0
        r[22] = jnum / 4.0
    return np.concatenate([base, ext], axis = 1)


def link_rows_v3_from_model(model):
    """v1 rows + ONLY the kinematic magnitudes that carry limb scale
    (learned-CCOR K-calibration fork, EXPERIMENT_learned_ccor_2026-09-02.md:
    the v1 encoder's implied climb edge sat at ~0.45 across every training
    grid because v1's sole absolute geometric magnitude is geom half-size --
    leg LENGTH was only indirectly present; v2 fixed that but drowned it in 23
    extra columns and planned worse):

      18  ||body_pos||  parent-frame offset length (m) -- the chain segment
      19  xpos_z        absolute frame height at qpos0 (m), via FK -- a
                        standing body's hips are high and feet are near 0, so
                        this column IS the leg-length distribution

    Both raw metres, no normalisation -- scaled_variant scales body/geom pos
    by size_f, so these move exactly with the climb label."""
    base = link_rows_from_model(model)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    nb = model.nbody
    ext = np.zeros((nb - 1, N_MORPH_FEAT_V3 - N_MORPH_FEAT), dtype = np.float32)
    for b in range(1, nb):
        ext[b - 1, 0] = float(np.linalg.norm(model.body_pos[b]))
        ext[b - 1, 1] = float(data.xpos[b][2])
    return np.concatenate([base, ext], axis = 1)


def _spec_for(base_name):
    return mujoco.MjSpec.from_file(os.path.join(ASSETS, BODY_XML[base_name]))


def scaled_variant(base_name, mass_f = 1.0, gear_f = 1.0, size_f = 1.0):
    """-> (Embodiment, link_rows) for a scaled copy of a roster body.

    ONE intervention, two views: the MJCF (what the encoder reads) and the
    Embodiment limits (what the oracle labels with) are scaled by the same
    factors -- see the module docstring's scaling laws.
    """
    spec = _spec_for(base_name)
    for b in spec.bodies:
        if b.mass and b.mass > 0:
            b.mass = float(b.mass) * mass_f
        if hasattr(b, 'ipos') and b.inertia is not None and len(b.inertia) == 3:
            b.inertia = [float(v) * mass_f * size_f ** 2 for v in b.inertia]
    for g in spec.geoms:
        g.size = [float(v) * size_f for v in g.size]
        g.pos = [float(v) * size_f for v in g.pos]
    for bd in spec.bodies:
        bd.pos = [float(v) * size_f for v in bd.pos]
    for a in spec.actuators:
        a.gear = [float(a.gear[0]) * gear_f] + [float(v) for v in a.gear[1:]]
    model = spec.compile()
    rows = _rows_fn()(model)

    base = EMBODIMENTS[base_name]
    from clear.data.terrain import climb_limit
    name = f'{base_name}_m{mass_f:g}_g{gear_f:g}_s{size_f:g}'.replace('.', 'p')
    emb = replace(base, name = name,
                  max_mass = base.max_mass * gear_f,
                  max_extent = base.max_extent * size_f,
                  # climb scales with limb length; setting it makes the variant's
                  # limit authoritative (Embodiment.climb docstring). On class
                  # terrain this is label-neutral while the scaled value stays on
                  # the base's side of the 0.15/1.0 class edges; on metric terrain
                  # (gp_height / the primitive family) it changes reachable sets.
                  climb = climb_limit(base) * size_f,
                  push_height = (base.push_height or PUSH_HEIGHTS.get(base_name, 0.0)) * size_f)
    return emb, rows


_ROWS_CACHE = {}


def morph_rows(emb_name):
    """(rows (L, F) float32, mask (L,) bool) for a registered embodiment name.

    Base class-body names resolve through BODY_XML; variant names must have
    been registered by `register_variant`. Raises for unknown bodies -- a
    morphology run must never silently fall back to a table.
    """
    key = (ROWS_VERSION, emb_name)
    if key in _ROWS_CACHE:
        rows = _ROWS_CACHE[key]
    elif emb_name in BODY_XML:
        model = mujoco.MjModel.from_xml_path(os.path.join(ASSETS, BODY_XML[emb_name]))
        rows = _rows_fn()(model)
        _ROWS_CACHE[key] = rows
    else:
        raise KeyError(f'no morphology registered for {emb_name!r} (rows v{ROWS_VERSION})')
    return rows, np.ones(len(rows), dtype = bool)


def register_variant(emb, rows):
    _ROWS_CACHE[(ROWS_VERSION, emb.name)] = rows
    return emb


def variant_grid(bases = ('wheel', 'quadruped', 'humanoid'),
                 gear_fs = (0.5, 1.0, 2.0), size_fs = (0.8, 1.0, 1.25)):
    """The training roster: |bases| x |gear_fs| x |size_fs| scaled bodies,
    registered so morph_rows() resolves them. -> [Embodiment]."""
    out = []
    for b in bases:
        for gf in gear_fs:
            for sf in size_fs:
                emb, rows = scaled_variant(b, gear_f = gf, size_f = sf)
                out.append(register_variant(emb, rows))
    return out


def _self_check():
    import itertools
    rows = {n: morph_rows(n)[0] for n in BODY_XML}
    for n, r in rows.items():
        assert r.shape[1] == N_MORPH_FEAT and 2 <= len(r) <= MAX_LINKS, (n, r.shape)
        assert np.isfinite(r).all(), n
    # bodies must be distinguishable as SETS (order-free): compare sorted row hashes
    def sig(r):
        return np.sort(r.round(4).sum(axis = 1))
    for a, b in itertools.combinations(BODY_XML, 2):
        sa, sb = sig(rows[a]), sig(rows[b])
        m = min(len(sa), len(sb))
        assert len(sa) != len(sb) or not np.allclose(sa[:m], sb[:m]), (a, b)
    # a scaled variant must (1) differ from its base in rows, (2) scale limits
    emb, r2 = scaled_variant('quadruped', gear_f = 2.0)
    assert emb.max_mass == EMBODIMENTS['quadruped'].max_mass * 2.0
    base_rows = rows['quadruped']
    assert r2.shape == base_rows.shape and not np.allclose(r2, base_rows)
    # gear scaling shows up ONLY in the gear column (16) and inertia-free cols
    diff_cols = np.where(np.abs(r2 - base_rows).max(axis = 0) > 1e-6)[0]
    assert 16 in diff_cols, diff_cols
    # size variant moves geometry columns
    emb_s, r3 = scaled_variant('quadruped', size_f = 1.25)
    assert 4 in np.where(np.abs(r3 - base_rows).max(axis = 0) > 1e-6)[0]
    assert emb_s.max_extent > EMBODIMENTS['quadruped'].max_extent
    grid = variant_grid(bases = ('quadruped',), gear_fs = (0.5, 1.0), size_fs = (1.0,))
    assert len(grid) == 2 and morph_rows(grid[0].name)[0] is not None
    print(f'ok morphology: rows {[rows[n].shape for n in BODY_XML]}, sets distinct, '
          f'variants scale rows and limits consistently')


if __name__ == '__main__':
    _self_check()
