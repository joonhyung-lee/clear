"""terrain: terrain, terrain_primitives.

terrain: Continuous terrain: metric height fields, and per-EDGE traversability.

Why this exists. The grid pipeline hands the network a 3-class terrain
(FLAT/STEP/WALL) produced by two global thresholds in project.classify_terrain.
Two things are lost there and both matter for a real maze:

  1. The height itself. A 0.06 m lip and a 0.29 m ledge are both STEP, and a
     0.31 m ledge is WALL -- a 2 cm difference flips a binary the network
     cannot see behind. Feeding metres instead lets the model place the
     boundary where the body actually places it.

  2. That climbing is an EDGE property. `can_traverse(cell)` asks whether a
     cell is passable in isolation, but a body climbs the *difference* between
     where it stands and where it steps. Standing on a 0.15 m platform, a
     0.30 m ledge is a 0.15 m step up. The cell-class abstraction calls it WALL
     regardless of where you are standing.

The height field is authored from the same grid Scene the oracle uses, so the
two views cannot disagree; `clear.util.project` is the inverse (heights -> grid)
and tests/test_terrain.py checks the round trip.

# ponytail: heights are per-cell constants (flat-topped blocks), which is what
# scene_to_mjcf actually builds. Real slopes want a finer sample grid; add it
# when the maze stops being extruded blocks.

terrain_primitives: Canonical terrain primitives: the six-way taxonomy, as a metric scene family.

gp_height's GP surface is expressive but unreadable -- no single cell has a
name. This family builds the board from SIX NAMED primitives instead (the
taxonomy this project's terrain claims will be stated in):

  flat      0 m ground
  wall      1.0 m, impassable for every body
  stairs    a run of uniform risers (rise r per cell, n treads): passable iff
            climb >= r -- the CUMULATIVE height is irrelevant, the riser is
            the test, which is what separates stairs from a bump. Every raised
            band keeps ONE flat gap column, so a body that cannot climb still
            has a route -- the divergence the family exists to create is
            "climbers go over, the wheel detours", not "the wheel is stuck"
  ramp      linear slope to the same total height: per-cell step = total/len,
            so a body that fails the stairs' riser may still pass the ramp --
            the pair (stairs, ramp) is the taxonomy's built-in capability probe
  curb      a single raised strip (둔턱): one step up of height b, one step
            down; passable iff climb >= b
  blocker   passage geometry is FINE but a movable object sits in it -- the
            terrain says yes, the plan must say "move it first". This is the
            primitive that hands the ordering problem its cases.

Each generated scene records WHICH primitive occupies which band
(`Scene`'s terrain/height as usual + the `bands` list returned alongside), so
an eval can score per-primitive: "this body fails exactly on stairs with
r > its climb" is a sentence the gp surface can never support.

Layout: horizontal bands between start (top row) and goal (bottom row), one
primitive per band, at least one guaranteed crossing point per band (a gap for
wall bands, the primitive itself otherwise). Heights are continuous knobs, so
the same generator serves class bodies (thresholded view) and metric ones.

    python -m clear.data.terrain_primitives     # self-check + ASCII preview
"""

# ---- terrain ----
import numpy as np

from clear.data.capability import FLAT, STEP, WALL, Embodiment
from clear.data.grid import Scene

# Metric heights of the three terrain classes, matching mj_util.mj_maze's
# extrusion (CELL 0.8 m cells, STEP platforms 0.15 m, wall slabs 1.0 m).
# One source of truth: mj_maze imports these rather than redeclaring them.
CLASS_HEIGHT = {FLAT: 0.0, STEP: 0.15, WALL: 1.0}

# 4-neighbourhood, in the (row, col) convention used everywhere else.
# Index order is fixed and is the channel order of every per-edge tensor here.
EDGES = ((-1, 0), (1, 0), (0, -1), (0, 1))   # up, down, left, right

# Height reported for an off-grid neighbour: an unclimbable step for any body.
# THE one definition -- the torch mirror in model/perception_encoder.py imports
# it. They were briefly 10.0 here and 15.0 there, which made the model's input
# and its training label disagree by exactly 5 m on every boundary cell.
OFF_GRID_STEP = 10.0


def height_field(scene: Scene, jitter = 0.0, rng = None) -> np.ndarray:
    """(H, W) float32 metric top height per cell.

    `jitter` (metres, uniform +-) roughens the surface so the perception
    encoder cannot pass by memorising three exact constants. Ground truth is
    recomputed from the jittered heights, never from the class grid, so the
    labels stay consistent with what the model sees.
    """
    # A metric scene carries the real surface; the class lookup is the
    # fallback for the three-height world, not the definition.
    h = (scene.height.astype(np.float32) if scene.height is not None
         else np.vectorize(CLASS_HEIGHT.get)(scene.terrain).astype(np.float32))
    if jitter:
        rng = rng if rng is not None else np.random.default_rng(0)
        h = h + rng.uniform(-jitter, jitter, size = h.shape).astype(np.float32)
        h = np.maximum(h, 0.0)
    return h


def climb_limit(emb: Embodiment) -> float:
    """Metres of step-up this body can climb, derived from the class table it
    was declared with rather than introduced as a new tunable.

    A body that accepts STEP must clear STEP's 0.15 m; one that refuses it must
    not. A body that refuses WALL must not clear 1.0 m. The limit therefore
    sits in the open interval between the highest class it accepts and the
    lowest it refuses, and the midpoint is the only choice that does not
    silently favour one side.

    A metrically-defined body (`synthetic_embodiment`) carries its limit
    directly and that value wins: its class table was derived from the limit,
    so re-deriving a midpoint here would hand the model a number the oracle
    never planned with.
    """
    if getattr(emb, 'climb', None) is not None:
        return float(emb.climb)
    ok = [CLASS_HEIGHT[c] for c in (FLAT, STEP, WALL) if emb.can_traverse(c)]
    no = [CLASS_HEIGHT[c] for c in (FLAT, STEP, WALL) if not emb.can_traverse(c)]
    lo = max(ok) if ok else 0.0
    hi = min(no) if no else max(CLASS_HEIGHT.values()) * 2.0
    return float((lo + hi) / 2.0)


def synthetic_embodiment(name, climb, max_mass, max_extent, n_arms, register = True):
    """A body defined by a metric climb limit, with its class table derived
    from that limit -- the inverse of the three hardcoded bodies.

    This exists because the end-to-end run has two supervision signals about
    the same capability. The auxiliary edge head is trained on the metric limit
    in the descriptor; the ordering and flow heads are trained on oracle plans
    built from `can_traverse`. Sampling the descriptor limit independently of
    the body (which is what the first version did) makes those two disagree on
    a third of examples, and leaves `[mass, extent, arms]` identifying the body
    exactly -- so the cheapest way to fit the plan heads is to ignore the climb
    channel and look the body up, which is the failure the metric path exists
    to remove. Deriving `traversable` FROM the sampled limit removes the
    disagreement; sampling mass/extent/arms independently removes the lookup.

    Registered in EMBODIMENTS by default because every consumer resolves a body
    as `EMBODIMENTS[ex.emb_name]` -- oracle, rollout, plan_success, viz. Adding
    the entry is what lets synthetic bodies flow through all of them unchanged.
    """
    trav = frozenset(c for c in (FLAT, STEP, WALL) if CLASS_HEIGHT[c] <= climb + 1e-9)
    emb = Embodiment(name, trav, max_mass = float(max_mass),
                     max_extent = float(max_extent), n_arms = int(n_arms),
                     climb = float(climb))
    if register:
        from clear.data.capability import EMBODIMENTS
        EMBODIMENTS[name] = emb
    return emb


def edge_deltas(heights: np.ndarray) -> np.ndarray:
    """(4, H, W) signed step-up height from each cell to each 4-neighbour.

    Off-grid neighbours are +inf-like (a large positive), i.e. an infinite step
    up: the boundary is not climbable, which is the same thing in_bounds says.
    """
    h, w = heights.shape
    out = np.empty((len(EDGES), h, w), dtype = np.float32)
    big = OFF_GRID_STEP
    for k, (dr, dc) in enumerate(EDGES):
        nb = np.full_like(heights, big)
        r0, r1 = max(0, -dr), h - max(0, dr)
        c0, c1 = max(0, -dc), w - max(0, dc)
        nb[r0:r1, c0:c1] = heights[r0 + dr:r1 + dr, c0 + dc:c1 + dc]
        out[k] = nb - heights
    return out


def edge_traversable(heights: np.ndarray, emb: Embodiment,
                     occupancy: np.ndarray = None) -> np.ndarray:
    """(4, H, W) bool: can this body step from each cell to each neighbour.

    Pure geometry against the body's climb limit -- a step UP beyond the limit
    is blocked, a step DOWN is not (falling is allowed; nothing here models
    damage). `occupancy` (H, W bool) additionally blocks stepping INTO an
    occupied cell, which is how objects enter perception.
    """
    ok = edge_deltas(heights) <= climb_limit(emb) + 1e-6
    if occupancy is not None:
        h, w = heights.shape
        for k, (dr, dc) in enumerate(EDGES):
            blocked = np.ones((h, w), dtype = bool)
            r0, r1 = max(0, -dr), h - max(0, dr)
            c0, c1 = max(0, -dc), w - max(0, dc)
            blocked[r0:r1, c0:c1] = occupancy[r0 + dr:r1 + dr, c0 + dc:c1 + dc]
            ok[k] &= ~blocked
    return ok


def reachable_mask(heights: np.ndarray, emb: Embodiment, start,
                   occupancy: np.ndarray = None) -> np.ndarray:
    """(H, W) bool: cells reachable from `start` under edge traversability.

    This is the quantity the planner actually needs, and the one the auxiliary
    head is scored against at the scene level -- per-edge accuracy can look
    excellent while a single wrong edge seals a corridor.
    """
    from collections import deque

    ok = edge_traversable(heights, emb, occupancy)
    h, w = heights.shape
    seen = np.zeros((h, w), dtype = bool)
    seen[start] = True
    q = deque([start])
    while q:
        r, c = q.popleft()
        for k, (dr, dc) in enumerate(EDGES):
            nr, nc = r + dr, c + dc
            if 0 <= nr < h and 0 <= nc < w and not seen[nr, nc] and ok[k, r, c]:
                seen[nr, nc] = True
                q.append((nr, nc))
    return seen


def occupancy_of(scene: Scene) -> np.ndarray:
    """(H, W) bool of cells holding a movable object."""
    occ = np.zeros(scene.shape, dtype = bool)
    for o in scene.objects:
        occ[o.cell] = True
    return occ


# ---- terrain_primitives ----
from dataclasses import dataclass


from clear.data.grid import Obj, height_to_terrain

PRIMITIVES = ('flat', 'wall', 'stairs', 'ramp', 'curb', 'blocker')
WALL_H = 1.0


@dataclass
class Band:
    kind: str
    rows: tuple          # (r0, r1) inclusive band rows
    param: float = 0.0   # riser (stairs) / total rise (ramp) / curb height
    gap_col: int = -1    # walls & blockers: the crossing column


def primitive_scene(rng: np.random.Generator, h = 8, w = 8, n_objects = 4,
                    kinds = None, riser_range = (0.10, 0.45), curb_range = (0.10, 0.55),
                    ramp_total_range = (0.3, 0.9), plug_gap_p = 0.0):
    """-> (Scene, [Band]). Scene.height is metric; terrain is the class view.

    plug_gap_p: probability that a stairs/curb band's detour gap column gets a
    movable object (drawn from the n_objects budget). With the default 0.0 the
    gap is always free, so a non-climber detours at zero object cost and climb
    moves the PATH but almost never the ORDER (oracle mid-band CCOR ~0.035).
    Plugging the gap is the blocker primitive's mechanism extended to the
    capability-gated bands: climbers step over the band and ignore the plug,
    non-climbers must move it first -- the coupling that makes climb reach the
    ordering decision (learned-CCOR second-family gate, prereg Addendum 6)."""
    for _ in range(64):
        height = np.zeros((h, w), dtype = np.float32)
        start = (0, int(rng.integers(0, w)))
        goal = (h - 1, int(rng.integers(0, w)))
        n_bands = max(2, (h - 2) // 3)
        edges = np.linspace(1, h - 1, n_bands + 1).astype(int)
        pool = list(kinds or ('wall', 'stairs', 'ramp', 'curb', 'blocker'))
        bands, blocker_cells = [], []
        for lo, hi in zip(edges[:-1], edges[1:]):
            r0 = int(rng.integers(lo, max(lo + 1, hi)))
            kind = pool[int(rng.integers(len(pool)))]
            if kind == 'wall':
                gap = int(rng.integers(0, w))
                height[r0, :] = WALL_H
                height[r0, gap] = 0.0
                bands.append(Band('wall', (r0, r0), WALL_H, gap))
            elif kind == 'stairs':
                riser = float(rng.uniform(*riser_range))
                n_tread = min(3, h - 1 - r0)
                # cap the summit under WALL_H: the class view must never close the
                # band into a full wall (riser is the test, not the summit)
                while riser * n_tread >= 0.9 * WALL_H and n_tread > 1:
                    n_tread -= 1
                riser = min(riser, 0.9 * WALL_H / n_tread)
                gap = int(rng.integers(0, w))
                for k in range(n_tread):
                    height[r0 + k, :] = np.maximum(height[r0 + k, :], riser * (k + 1))
                    height[r0 + k, gap] = 0.0     # the detour column (see docstring)
                # descend on the far side is implicit: bands below overwrite with
                # their own profile; the TEST is the riser on the way up
                if rng.random() < plug_gap_p:
                    blocker_cells.append((r0, gap))
                bands.append(Band('stairs', (r0, r0 + n_tread - 1), riser, gap))
            elif kind == 'ramp':
                total = float(rng.uniform(*ramp_total_range))
                n_run = min(4, h - 1 - r0)
                gap = int(rng.integers(0, w))
                for k in range(n_run):
                    height[r0 + k, :] = np.maximum(height[r0 + k, :],
                                                   total * (k + 1) / n_run)
                    height[r0 + k, gap] = 0.0
                bands.append(Band('ramp', (r0, r0 + n_run - 1), total / n_run, gap))
            elif kind == 'curb':
                b = float(rng.uniform(*curb_range))
                gap = int(rng.integers(0, w))
                height[r0, :] = np.maximum(height[r0, :], b)
                height[r0, gap] = 0.0
                if rng.random() < plug_gap_p:
                    blocker_cells.append((r0, gap))
                bands.append(Band('curb', (r0, r0), b, gap))
            else:                                    # blocker: flat terrain + a plug
                gap = int(rng.integers(0, w))
                height[r0, :] = WALL_H
                height[r0, gap] = 0.0
                blocker_cells.append((r0, gap))
                bands.append(Band('blocker', (r0, r0), 0.0, gap))
        height[start] = 0.0
        height[goal] = 0.0
        terrain = height_to_terrain(height)
        occupied = {start, goal}
        objects = []
        for cell in blocker_cells:
            if cell in occupied:
                continue
            objects.append(Obj(cell = cell,
                               mass = float(np.exp(rng.uniform(np.log(0.5), np.log(18.0)))),
                               extent = float(rng.uniform(0.3, 1.2)),
                               theta = float(rng.uniform(-np.pi, np.pi))))
            occupied.add(cell)
        free = [(r, c) for r in range(h) for c in range(w)
                if height[r, c] < WALL_H and (r, c) not in occupied]
        rng.shuffle(free)
        while len(objects) < n_objects and free:
            cell = free.pop()
            objects.append(Obj(cell = cell,
                               mass = float(np.exp(rng.uniform(np.log(0.5), np.log(25.0)))),
                               extent = float(rng.uniform(0.3, 1.2)),
                               theta = float(rng.uniform(-np.pi, np.pi))))
            occupied.add(cell)
        if not any(b.kind == 'blocker' for b in bands) and n_objects == 0:
            continue
        scene = Scene(terrain = terrain, start = start, goal = goal, objects = objects,
                      height = height)
        return scene, bands
    raise RuntimeError('primitive_scene: no valid layout in 64 resamples')


def scene_fn(kinds = None):
    """build_examples-compatible: fn(rng) -> Scene (bands dropped)."""
    return lambda rng: primitive_scene(rng, 8, 8, 4, kinds = kinds)[0]


def _self_check():
    rng = np.random.default_rng(0)
    seen = set()
    for s in range(60):
        scene, bands = primitive_scene(np.random.default_rng(s))
        seen.update(b.kind for b in bands)
        assert scene.height is not None and scene.height.shape == scene.terrain.shape
        assert float(scene.height[scene.start]) == 0.0 == float(scene.height[scene.goal])
        for b in bands:
            if b.kind == 'wall':
                assert float(scene.height[b.rows[0], b.gap_col]) == 0.0
            if b.kind == 'stairs':
                assert 0 < b.param <= 0.45
                top = b.param * (b.rows[1] - b.rows[0] + 1)
                assert top < WALL_H, (b, top)
            if b.kind == 'blocker':
                assert any(o.cell == (b.rows[0], b.gap_col) for o in scene.objects) or \
                    (b.rows[0], b.gap_col) in (scene.start, scene.goal)
    assert seen >= {'wall', 'stairs', 'ramp', 'curb', 'blocker'}, seen
    scene, bands = primitive_scene(np.random.default_rng(3))
    chars = {0: '.', 1: '^', 2: '#'}
    print('primitives seen over 60 seeds:', sorted(seen))
    print('seed 3 bands:', [(b.kind, b.rows, round(b.param, 2)) for b in bands])
    for r in range(scene.terrain.shape[0]):
        print(''.join('S' if (r, c) == scene.start else 'G' if (r, c) == scene.goal
                      else 'o' if any(o.cell == (r, c) for o in scene.objects)
                      else chars[int(scene.terrain[r, c])]
                      for c in range(scene.terrain.shape[1])))
    print('ok terrain_primitives')
