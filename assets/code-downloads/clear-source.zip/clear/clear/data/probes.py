"""kappa as a PROBE SET: (probe_id, query, outcome) rows instead of a fixed
6-number descriptor (capability.feature_vector).

PROBES = kappa.COMPONENTS (5 push masses, 3 step heights, arm reach) plus
`extent_cells` (largest pushable bbox axis) -- 10 probes. For a class-table /
synthetic body the outcome is what the oracle's own predicates say
(can_move: mass <= max_mass; can_traverse: height <= climb_limit), so the token
the model reads and the plan it is supervised on cannot disagree. For the 4
real robots `probe_set_from_kappa` reads the MEASURED cache instead.

Query values are normalised: mass/25, height/0.3, reach/1.2, extent/1.5.

    python -m clear.data.probes     # self-check
"""
import numpy as np

from clear.data.capability import EMBODIMENTS, Embodiment
from clear.data.kappa import COMPONENTS, MASS_BUCKETS, STEP_HEIGHTS, load_kappa

PROBES = tuple(COMPONENTS) + ("extent_cells",)
N_PROBES = len(PROBES)  # 10
# One extra row, emitted only for a body that HAS a contact height
# (capability.tipping_bodies): "how high does this body push", which with the
# object's own extent decides tipping. Opt-in precisely because it changes the
# row count, and every existing kappa-set checkpoint (setK_seed0 included) was
# trained at 10.
PROBES_TIP = PROBES + ("push_height_m",)
N_PROBES_TIP = len(PROBES_TIP)  # 11
NOMINAL_ARM_REACH = 0.6  # metres, a body with n_arms > 0 (class-table bodies have no measured reach)
_SCALE = dict(mass=25.0, height=0.3, reach=1.2, extent=1.5, push=1.0)


def _queries():
    """Normalised query value per probe, in PROBES order."""
    q = [m / _SCALE["mass"] for m in MASS_BUCKETS] + [h / _SCALE["height"] for h in STEP_HEIGHTS]
    return q + [1.0, 1.0]  # arm_reach_m / extent_cells: the outcome IS the value


def probe_set(emb: Embodiment) -> np.ndarray:
    """-> (N_PROBES, 3) float32 rows [probe_index, query, outcome]."""
    from clear.data.terrain import climb_limit  # local: terrain imports capability
    climb = climb_limit(emb)
    out = [float(m <= emb.max_mass) for m in MASS_BUCKETS]
    out += [float(h <= climb + 1e-9) for h in STEP_HEIGHTS]
    out += [(NOMINAL_ARM_REACH if emb.n_arms > 0 else 0.0) / _SCALE["reach"],
            emb.max_extent / _SCALE["extent"]]
    queries = _queries()
    if emb.push_height > 0.0:
        queries = queries + [1.0]                       # the outcome IS the value
        out = out + [emb.push_height / _SCALE["push"]]
    n = len(out)
    return np.stack([np.arange(n, dtype=np.float32), np.array(queries, np.float32),
                     np.array(out, np.float32)], axis=1)


def probe_set_from_kappa(robot_name, cache_path=None):
    """-> (probe_set (N_PROBES, 3), probe_mask (N_PROBES,) bool) from the measured
    cache. `extent_cells` has no measured value for the real roster, so that
    row is masked out -- the encoder accepts a missing probe."""
    k = load_kappa(robot_name, cache_path)  # ordered as COMPONENTS
    out = list(k[:8]) + [k[8] / _SCALE["reach"], 0.0]
    ps = np.stack([np.arange(N_PROBES, dtype=np.float32), np.array(_queries(), np.float32),
                   np.array(out, np.float32)], axis=1)
    mask = np.ones(N_PROBES, dtype=bool)
    mask[PROBES.index("extent_cells")] = False
    return ps, mask


# Training bodies whose probe outcomes vary continuously in mass and climb.
# (name, climb m, max_mass kg, max_extent cells, n_arms)
SYNTHETIC_TRAIN = (
    ("syn_c00_m08", 0.00, 8.0, 1.0, 0),
    ("syn_c10_m03", 0.10, 3.0, 0.8, 0),
    ("syn_c10_m18", 0.10, 18.0, 1.2, 1),
    ("syn_c20_m12", 0.20, 12.0, 1.0, 1),
    ("syn_c35_m03", 0.35, 3.0, 0.8, 0),
    ("syn_c35_m12", 0.35, 12.0, 1.2, 2),
)
HELDOUT = ("syn_c12_m10_heldout", 0.12, 10.0, 1.0, 1)  # unseen kappa: never registered for training


def rooms_fork_scene(rng, h, w, n_objects):
    """50/50 walled_room_scene / two_route_scene(passage_len=2) with log-uniform
    plug masses in [0.5, 20] kg so both the climb and the mass probes decide
    which plug a body's plan moves."""
    from clear.data.grid import two_route_scene, walled_room_scene
    if rng.random() < 0.5:
        return walled_room_scene(rng, h, w, n_objects=n_objects)
    plug_mass = tuple(float(np.exp(rng.uniform(np.log(0.5), np.log(20.0)))) for _ in range(2))
    return two_route_scene(rng, h, w, n_objects=n_objects, plug_mass=plug_mass, passage_len=2)


def register_synthetic(bodies=SYNTHETIC_TRAIN):
    """Register the continuum training bodies in EMBODIMENTS (idempotent)."""
    from clear.data.terrain import synthetic_embodiment
    return [synthetic_embodiment(*b) for b in bodies]


def register_heldout():
    from clear.data.terrain import synthetic_embodiment
    return synthetic_embodiment(*HELDOUT)


def _self_check():
    assert N_PROBES == 10 and len(set(PROBES)) == 10
    ps = {n: probe_set(e) for n, e in EMBODIMENTS.items()}
    for n, p in ps.items():
        assert p.shape == (N_PROBES, 3) and np.isfinite(p).all(), n
        assert (p[:, 0] == np.arange(N_PROBES)).all()
    # oracle-consistent outcomes: wheel lifts <= 2 kg, no step; humanoid everything but 25 kg
    w, h = ps["wheel"][:, 2], ps["humanoid"][:, 2]
    assert w[:5].tolist() == [1, 0, 0, 0, 0] and w[5:8].tolist() == [1, 0, 0], w
    assert h[:5].tolist() == [1, 1, 1, 1, 0] and h[5:8].tolist() == [1, 1, 1], h
    assert w[8] == 0.0 and h[8] > 0
    syn = register_synthetic()
    p = probe_set(syn[1])  # climb 0.10, mass 3
    assert p[5:8, 2].tolist() == [1, 0, 0] and p[:5, 2].tolist() == [1, 0, 0, 0, 0], p
    outs = np.stack([probe_set(e)[:, 2] for e in EMBODIMENTS.values()])
    assert len({tuple(o) for o in outs}) == len(EMBODIMENTS), "two bodies share a probe set"
    try:
        for r in ("husky", "spot", "spot_w_arm", "g1_wo_wrist"):
            pk, m = probe_set_from_kappa(r)
            assert pk.shape == (N_PROBES, 3) and m.sum() == 9 and not m[-1], r
        print("ok: kappa cache -> probe sets for 4 real robots (extent masked)")
    except FileNotFoundError as e:
        print(f"skip real-robot check: {e}")
    print(f"ok: {N_PROBES} probes, {len(EMBODIMENTS)} bodies all distinct; wheel={w.tolist()}")


if __name__ == "__main__":
    _self_check()
