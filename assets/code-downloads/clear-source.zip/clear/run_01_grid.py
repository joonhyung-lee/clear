"""Grid (exp1): train the models, or evaluate CLEAR / an ordering baseline (--method clear | clear_ro | clear_ho | autoregressive | gumbel_sinkhorn | polynet)."""
from utils.tools.run import main

main({
    'train': ('experiments.common.dispatch', 'train', '--experiment', 'grid2d'),
    'evaluate': ('experiments.exp1.evaluate',),
})
