![CLEAR](https://anonymous-hf.com/api/a/p5icltdspejh/resolve/assets/teaser.png?v=4)

*Capability-aware interaction planning across robot embodiments.*

> **TL;DR**
>
> Source code and 129 pretrained checkpoints of the CLEAR planner. Download with `get.py`, install with `uv sync`, run one script per experiment.

## 0. Download

```bash
curl -LO https://anonymous-hf.com/api/a/p5icltdspejh/resolve/utils/tools/get.py
python3 get.py clear && cd clear
```

## 1. Install

```bash
uv sync                                           # Python 3.11, CPU torch (pyproject.toml has the CUDA note)
uv sync --extra manipulation                     # adds MuJoCo for 02
```

## 2. Run experiments

```bash
# 01 grid. --method clear | clear_ro | clear_ho | autoregressive | gumbel_sinkhorn | polynet
uv run run_01_grid.py evaluate --method clear --out outputs/grid/clear
uv run run_01_grid.py evaluate --method polynet --out outputs/grid/polynet
uv run run_01_grid.py train --method clear

# 02 ordered manipulation. --arm clear | bc | plan_bc | bc_shared | ar_bc | clear_nocausal | clear_regression | clear_noaffordance
uv run run_02_manipulation.py train --arm clear --data experiments/exp2/data/paper --seed 0 --out outputs/manipulation/clear.pt

# 03 maze. plan one scene (window, or --video demo.mp4); train with --config .../{clear | noemb | no_affordance | robot_id | get_encoder | cdgs | clear_nocausal | specialist_g1 | specialist_spot_arm}.json
uv run run_03_maze.py plan --input experiments/exp3/data/example_g1.json --video demo.mp4
D=experiments/exp3/data/primary_prepared_local_edges
uv run run_03_maze.py train --data $D/shared_teachers.jsonl --probes $D/shared_probes.jsonl --config utils/training/exp3/configs/seed0/clear.json --seed 0 --out outputs/maze/clear

# 04 long horizon planning. adapt the maze planner for replanning
T=utils/training/exp4
uv run run_04_replanning.py train --data $T/data/adapt_teachers.jsonl --probes $T/data/adapt_probes.jsonl --config $T/config.json --init-checkpoint ckpts/maze/reference/seed0/clear.pt --steps 500 --allow-geometric-teacher --out outputs/replanning/clear
```

`<stage> --help` lists every argument. Every command above runs on CPU from the released data and checkpoints.
Executing plans on the simulated robots (the paper's physical-success numbers) needs the controller runtime, which
is not part of this distribution; the planners, their training and the grid evaluation are.

## Layout

- `clear/` → planner
  - `model/` → `clear.py`, `ordernet.py`, `causalflownet.py`, `affordancenet.py`, `encoders.py`, `morphology_encoder.py`, `quantizers.py`
  - `data/` → grid scenes, oracle, terrain, capability, probes
  - `maze/` → `world.py` (scenes, routes, abstract controller), `robots.py` (bodies, structure)
  - `util.py` → projection, schedule, ranking, CEM
- `experiments/` → one folder per experiment
  - `exp1/` → grid
  - `exp2/` → manipulation
  - `exp3/` → maze
  - `exp4/` → replanning
- `ckpts/` → pretrained checkpoints
  - `grid/`
  - `maze/`
  - `locomotion/`
  - `paths.json` → where each checkpoint is linked for the code
- `models/` → ordering baselines
- `assets/` → robot models (`g1/`, `spot/`, `spot_w_arm/`, `husky/`) and the README figures
- `utils/` → helpers
  - `tools/` → download, fetch and render
  - `tests/` → unit tests (`uv run pytest utils/tests`)
  - `training/` → per-experiment training configs and teacher data
  - `viz/` → figure scripts

## Experiments

| (a) 2D Grid | (b) Ordered Manipulation | (c) Maze Navigation | (d) Long Horizon Planning |
|---|---|---|---|
| ![](https://anonymous-hf.com/api/a/p5icltdspejh/resolve/assets/a_grid.png) | ![](https://anonymous-hf.com/api/a/p5icltdspejh/resolve/assets/b_ordered_manipulation.png) | ![](https://anonymous-hf.com/api/a/p5icltdspejh/resolve/assets/c_maze_navigation.png) | ![](https://anonymous-hf.com/api/a/p5icltdspejh/resolve/assets/d_long_horizon_planning.png) |
| Relocate obstacles to open a path. | Order interactions to keep access. | Plan per body around terrain and objects. | Replan when placement or access changes. |

## Licensing

The CLEAR code is released under the MIT License. Third-party assets keep their own licenses and notices:

- `assets/spot/`, `assets/spot_w_arm/` → `assets/spot/LICENSE`, `assets/spot/README.md`
- `assets/g1/` → `assets/g1/README_upstream.md`
- `assets/husky/` → `assets/husky/README.md` (provenance recorded; the bundle has no standalone redistribution license)
- `clear/model/quantizers.py` → `clear/model/QUANTIZERS_LICENSE` (MIT)
