"""Ordered manipulation (exp2): train the comparison arms, refine the flow checkpoints."""
from utils.tools.run import main

main({
    'train': ('experiments.exp2.train_comparison',),
    'refine': ('experiments.exp2.refine_flow_comparison',),
})
