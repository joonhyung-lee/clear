# G1 29-DOF (no hand) — standalone MuJoCo asset

Self-contained. No external package/repo/dependency beyond MuJoCo itself.

```
scene.xml                 # entry point (floor + light + include)
g1_29dof_nohand.xml       # robot: 29 actuators, IDL joint order, motor (torque) actuators
meshes/*.STL              # 33 referenced meshes only
```

Load:
```python
import mujoco
m = mujoco.MjModel.from_xml_path("scene.xml")
```

Notes:
- Actuators are `<motor>` (ctrl = joint torque), order matches Unitree G1 29-DOF IDL table.
- Sensors: per-joint pos/vel/actuatorfrc (×29), then IMU `imu_quat`+gyro+accel+`frame_pos`+`frame_vel` on pelvis site `imu`, plus secondary IMU on torso site `secondary_imu`.
- No hands (rubber_hand removed). Keyframe `stand` provided.
- Built from mujoco_menagerie unitree_g1 (g1.xml), adapted for torque control + full sensor suite.
