# Husky source and execution

Conversion-source attribution is withheld in this anonymous working copy.

The XML and five STL meshes are preserved. No standalone license was present
in that local source root or the conversion repository's selected tree covering
these files; no new license is assigned here. The upstream ROS Husky description
has a [BSD-3-Clause notice](https://github.com/husky/husky/blob/noetic-devel/LICENSE),
but these converted meshes did not match its current blobs. The complete
conversion/asset redistribution grant remains unresolved.

The current native mjlab execution contract 5 implements the requested
velocity differential kinematics: x_dot = v cos(theta), y_dot = v sin(theta),
theta_dot = omega. The controller integrates the exact SE(2) arc at each 0.005 s
physics step. The base is prescribed through a mocap body; wheel joints and
actuators are removed from this effective model. Boxes remain dynamic under
mujoco-warp contact. Contact forces do not feed back into the prescribed base.
Wall and step contact is rejected by the executor.

The older contract 4 applied finite horizontal forces and yaw torque to a free
base with passive wheels. Its saved results remain historical and are not
labeled differential-kinematic execution.

Source and effective model hashes, dynamics contract and resolved settings are
logged. This is a simulation model, not a hardware dynamics calibration.
