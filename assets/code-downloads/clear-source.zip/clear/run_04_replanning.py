"""Replanning (exp4): train the adaptation."""
from utils.tools.run import main

main({
    'train': ('experiments.exp4.sprint6h.train_adapt', 'train'),
})
