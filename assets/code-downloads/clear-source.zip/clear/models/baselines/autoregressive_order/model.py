"""Autoregressive Transformer ordering baseline (spec 6.2; Kool et al. attention-learn-to-route
style decoder adapted to object selection).

Same scene / object / embodiment encoders as CLEAR (clear.model.scene_encoder.SceneEncoder,
scene_encoder.object_features with can_move withheld, capability_encoder.CapabilityEncoder on
the structural descriptor) and the same AffordanceTransformer trunk width/depth. What differs
is ONLY the order representation:

  order      decoded one object id at a time with a learned STOP token; already-selected
             objects are masked (and marked with a learned "placed" offset, as the legacy
             pointer head in clear.model.ordering_ablation_heads does); trained by teacher
             forcing on one stored optimal plan per scene per step (scene-balanced);
             greedy decoding at inference.
  targets    a second trunk of the same capacity as CLEAR's CausalVelocityField, under the
             same rank-causal mask, regresses each selected object's displacement to its
             target cell directly (no flow).

The legacy `pointer` head was checked first: it has no STOP token, fixes the mover set from
the capability table, and has no target head, so it could not serve as this baseline.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from clear.model.affordancenet import AffordanceTransformer
from clear.model.encoders import CapabilityEncoder
from clear.model.causalflownet import causal_mask
from clear.model.encoders import SCENE_CHANS, SceneEncoder, obj_feat_dim, object_features


class AutoregressiveOrderModel(nn.Module):
    def __init__(self, grid_hw=(8, 8), dim=128, depth=4, heads=4, dim_head=32,
                 drop_obj=("can_move",), max_steps=16, scene_channels=SCENE_CHANS,
                 push_reachability=False):
        super().__init__()
        self.grid_hw = tuple(grid_hw)
        self.drop_obj = tuple(drop_obj)
        self.max_steps = int(max_steps)
        # LEAP 2026 WP-1: the 4-D observation-only `push_reachability` channel CLEAR receives
        # (experiments/exp1/dataset.py push_reachability_rows), concatenated to the object
        # features of BOTH trunks. False is byte-identical to the paper baselines.
        self.push_reachability = bool(push_reachability)
        fdim = obj_feat_dim(self.drop_obj) + 4 * self.push_reachability
        # order decoder (encoder capacity == PriorityHead)
        self.to_object_tokens = nn.Linear(fdim, dim)
        self.capability_encoder = CapabilityEncoder(dim)
        self.scene_encoder = SceneEncoder(dim, grid_hw, channels=scene_channels)
        self.transformer = AffordanceTransformer(dim, depth=depth, heads=heads, dim_head=dim_head)
        self.stop_token = nn.Parameter(torch.randn(dim) * 0.02)
        self.step_embed = nn.Embedding(self.max_steps + 1, dim)
        self.placed_embed = nn.Parameter(torch.zeros(dim))
        self.to_logit = nn.Linear(dim, 1)
        # target decoder (capacity == CausalVelocityField trunk + head)
        self.tgt_object_tokens = nn.Linear(fdim, dim)
        self.tgt_capability_encoder = CapabilityEncoder(dim)
        self.tgt_scene_encoder = SceneEncoder(dim, grid_hw, channels=scene_channels)
        self.tgt_transformer = AffordanceTransformer(dim, depth=depth, heads=heads, dim_head=dim_head)
        self.to_target = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, 2))

    # -- shared encoders ------------------------------------------------------------------
    def features(self, batch):
        x0 = batch["x0"]
        s = torch.zeros_like(x0[..., 0])
        movable = torch.ones_like(s, dtype=torch.bool)  # withheld column anyway (drop can_move)
        feat = object_features(x0, batch["mass"], batch["extent"], s, 0.0, movable, self.grid_hw,
                               drop=self.drop_obj)
        if self.push_reachability:
            feat = torch.cat([feat, batch["push_reachability"].to(feat.dtype)], dim=-1)
        return feat

    def step_logits(self, feat, cap, scene, placed, step):
        """-> (b, n + 1) logits; index n is STOP. `placed` (b, n) bool, `step` (b,) long."""
        objects = self.to_object_tokens(feat) + placed[..., None].to(feat.dtype) * self.placed_embed
        stop = (self.stop_token + self.step_embed(step))[:, None, :]
        tokens = torch.cat([cap, objects, scene, stop], dim=1)
        out = self.transformer(tokens)
        n = objects.shape[1]
        obj_logits = self.to_logit(out[:, 1:1 + n]).squeeze(-1)
        stop_logit = self.to_logit(out[:, -1]).squeeze(-1)
        logits = torch.cat([obj_logits, stop_logit[:, None]], dim=-1)
        return logits.masked_fill(torch.cat([placed, torch.zeros_like(placed[:, :1])], 1), -1e9)

    # -- training --------------------------------------------------------------------------
    def order_loss(self, batch, orders):
        feat = self.features(batch)
        cap = self.capability_encoder(batch["emb_feat"])
        scene = self.scene_encoder(batch["grid"])
        b, n = feat.shape[:2]
        T = max(len(o) for o in orders) + 1
        placed = torch.zeros(T, b, n, dtype=torch.bool, device=feat.device)
        target = torch.full((T, b), n, dtype=torch.long, device=feat.device)  # STOP by default
        valid = torch.zeros(T, b, dtype=torch.bool, device=feat.device)
        for i, o in enumerate(orders):
            for t in range(len(o) + 1):
                valid[t, i] = True
                for j in o[:t]:
                    placed[t, i, j] = True
                if t < len(o):
                    target[t, i] = o[t]
        rep = lambda x: x[None].expand(T, *x.shape).reshape(T * b, *x.shape[1:])
        steps = torch.arange(T, device=feat.device).clamp(max=self.max_steps)[:, None].expand(T, b).reshape(-1)
        logits = self.step_logits(rep(feat), rep(cap), rep(scene), placed.reshape(T * b, n), steps)
        ce = F.cross_entropy(logits, target.reshape(-1), reduction="none").view(T, b)
        return ce[valid].mean()

    def _rank(self, orders, n, device):
        rank = torch.full((len(orders), n), n, dtype=torch.long, device=device)
        movable = torch.zeros(len(orders), n, dtype=torch.bool, device=device)
        for i, o in enumerate(orders):
            for pos, j in enumerate(o):
                rank[i, j] = pos
                movable[i, j] = True
        return rank, movable

    def target_delta(self, batch, orders):
        feat = self.features(batch)
        b, n = feat.shape[:2]
        rank, movable = self._rank(orders, n, feat.device)
        cap = self.tgt_capability_encoder(batch["emb_feat"])
        scene = self.tgt_scene_encoder(batch["grid"])
        tokens = torch.cat([cap, self.tgt_object_tokens(feat), scene], dim=1)
        mask = causal_mask(rank, movable, scene.shape[1], causal=True)
        out = self.tgt_transformer(tokens, mask=mask)
        return self.to_target(out[:, 1:1 + n]), movable

    def target_loss(self, batch, orders):
        delta, movable = self.target_delta(batch, orders)
        if not movable.any():
            return delta.sum() * 0.0
        true = (batch["x1"] - batch["x0"])[..., :2]
        return F.mse_loss(delta[movable], true[movable])

    def forward(self, batch, orders):
        lo = self.order_loss(batch, orders)
        lt = self.target_loss(batch, orders)
        return lo + lt, {"order_ce": lo.item(), "target_mse": lt.item()}

    # -- inference -------------------------------------------------------------------------
    @torch.no_grad()
    def greedy_decode(self, batch, code=None):
        feat = self.features(batch)
        cap = self.capability_encoder(batch["emb_feat"])
        scene = self.scene_encoder(batch["grid"])
        b, n = feat.shape[:2]
        placed = torch.zeros(b, n, dtype=torch.bool, device=feat.device)
        done = torch.zeros(b, dtype=torch.bool, device=feat.device)
        orders = [[] for _ in range(b)]
        for step in range(min(n, self.max_steps)):
            st = torch.full((b,), step, dtype=torch.long, device=feat.device)
            pick = self._logits(feat, cap, scene, placed, st, code).argmax(-1)
            for i in range(b):
                if done[i]:
                    continue
                if int(pick[i]) == n:
                    done[i] = True
                else:
                    orders[i].append(int(pick[i]))
                    placed[i, pick[i]] = True
            if bool(done.all()):
                break
        return [tuple(o) for o in orders]

    @torch.no_grad()
    def sample_decode(self, batch, generator=None, temperature: float = 1.0, code=None):
        """One categorical draw per step from the masked STOP decoder -- the stochastic
        counterpart of `greedy_decode`, so Coverage@32 draws 32 distinct plans instead of
        repeating the greedy one. Already-selected objects are masked (-1e9), so no object
        repeats; decoding ends at STOP or after `max_steps`. `code` is ignored here and used
        by the PolyNet-style subclass."""
        feat = self.features(batch)
        cap = self.capability_encoder(batch["emb_feat"])
        scene = self.scene_encoder(batch["grid"])
        b, n = feat.shape[:2]
        placed = torch.zeros(b, n, dtype=torch.bool, device=feat.device)
        done = torch.zeros(b, dtype=torch.bool, device=feat.device)
        orders = [[] for _ in range(b)]
        for step in range(min(n, self.max_steps)):
            st = torch.full((b,), step, dtype=torch.long, device=feat.device)
            logits = self._logits(feat, cap, scene, placed, st, code)
            probs = F.softmax(logits / max(float(temperature), 1e-6), dim=-1)
            pick = torch.multinomial(probs, 1, generator=generator).squeeze(-1)
            for i in range(b):
                if done[i]:
                    continue
                if int(pick[i]) == n:
                    done[i] = True
                else:
                    orders[i].append(int(pick[i]))
                    placed[i, pick[i]] = True
            if bool(done.all()):
                break
        return [tuple(o) for o in orders]

    def _logits(self, feat, cap, scene, placed, step, code=None):
        """Indirection so a subclass can condition the decoder (PolyNet-style codes)."""
        return self.step_logits(feat, cap, scene, placed, step)

    @torch.no_grad()
    def predict_targets(self, batch, orders):
        """-> (b, n, 2) predicted [x, y] (col, row) in canvas cells."""
        delta, _ = self.target_delta(batch, orders)
        return (batch["x0"][..., :2] + delta).cpu().numpy()
