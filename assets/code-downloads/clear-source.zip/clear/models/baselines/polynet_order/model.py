"""PolyNet-style Multi-Strategy AR (spec: exp_v2/01_grid2d_baseline_extension_instruction.md §6).

The existing STOP-based masked autoregressive decoder, conditioned on a binary strategy
vector z through a two-layer residual MLP applied to the decoder's attention output -- the
architectural role of PolyNet's `poly_layer_1` / `poly_layer_2` (ahottung/PolyNet @ 4e9cb874,
MIT; design reference only, see third-party/LOCK_grid2d.md). Four strategies (z_dim = 2, all
binary codes), pre-registered because BRANCH scenes have two or four optimal orders.

Training is a supervised analogue of PolyNet's best-of-K update: teacher-force the sampled
oracle order under every code, and backpropagate the order NLL only through the lowest-NLL
code for that example. No diversity penalty, no forced first move. The shared target
regression is computed once, for the sampled order.

Inference: point prediction = greedy decoding under ONE fixed code per training seed, chosen
on validation Task Success (tie-break Order Hit) and stored in the checkpoint; coverage cycles
the four codes equally, eight categorical draws each. This is an adaptation, not a port:
PolyNet uses policy-gradient rewards on complete routing tours. Call it "PolyNet-style".
"""
from __future__ import annotations

import itertools

import torch
import torch.nn.functional as F
from torch import nn

from baselines.autoregressive_order.model import AutoregressiveOrderModel


class PolyNetOrderModel(AutoregressiveOrderModel):
    def __init__(self, *args, z_dim: int = 2, poly_hidden: int | None = None, **kw):
        super().__init__(*args, **kw)
        dim = self.to_object_tokens.out_features
        self.z_dim = int(z_dim)
        codes = list(itertools.product((0.0, 1.0), repeat=self.z_dim))
        self.register_buffer("codes", torch.tensor(codes, dtype=torch.float32))   # (K, z_dim)
        h = int(poly_hidden or dim)
        self.poly_layer_1 = nn.Linear(dim + self.z_dim, h)
        self.poly_layer_2 = nn.Linear(h, dim)
        nn.init.zeros_(self.poly_layer_2.weight); nn.init.zeros_(self.poly_layer_2.bias)  # start as plain AR
        self.point_code: int = 0          # selected on validation per training seed; frozen in the checkpoint

    @property
    def n_codes(self) -> int:
        return int(self.codes.shape[0])

    # -- conditioned decoder ----------------------------------------------------------------
    def step_logits(self, feat, cap, scene, placed, step, code=None):
        """AR decoder with the strategy residual. `code`: int, (b,) long, or None (= point_code)."""
        objects = self.to_object_tokens(feat) + placed[..., None].to(feat.dtype) * self.placed_embed
        stop = (self.stop_token + self.step_embed(step))[:, None, :]
        tokens = torch.cat([cap, objects, scene, stop], dim=1)
        out = self.transformer(tokens)
        b = out.shape[0]
        if code is None:
            code = self.point_code
        idx = torch.as_tensor(code, device=out.device, dtype=torch.long).expand(b) if torch.as_tensor(code).ndim == 0 \
            else torch.as_tensor(code, device=out.device, dtype=torch.long)
        z = self.codes[idx]                                              # (b, z_dim)
        zt = z[:, None, :].expand(b, out.shape[1], self.z_dim)
        out = out + self.poly_layer_2(F.relu(self.poly_layer_1(torch.cat([out, zt], dim=-1))))
        n = objects.shape[1]
        obj_logits = self.to_logit(out[:, 1:1 + n]).squeeze(-1)
        stop_logit = self.to_logit(out[:, -1]).squeeze(-1)
        logits = torch.cat([obj_logits, stop_logit[:, None]], dim=-1)
        return logits.masked_fill(torch.cat([placed, torch.zeros_like(placed[:, :1])], 1), -1e9)

    def _logits(self, feat, cap, scene, placed, step, code=None):
        return self.step_logits(feat, cap, scene, placed, step, code)

    # -- training: best-code supervised update ---------------------------------------------
    def order_nll_per_code(self, batch, orders):
        """-> (K, b) summed order NLL of each example under each strategy code."""
        feat = self.features(batch)
        cap = self.capability_encoder(batch["emb_feat"])
        scene = self.scene_encoder(batch["grid"])
        b, n = feat.shape[:2]
        T = max(len(o) for o in orders) + 1
        placed = torch.zeros(T, b, n, dtype=torch.bool, device=feat.device)
        target = torch.full((T, b), n, dtype=torch.long, device=feat.device)
        valid = torch.zeros(T, b, dtype=torch.bool, device=feat.device)
        for i, o in enumerate(orders):
            for t in range(len(o) + 1):
                valid[t, i] = True
                for j in o[:t]:
                    placed[t, i, j] = True
                if t < len(o):
                    target[t, i] = o[t]
        K = self.n_codes
        rep = lambda x: x[None].expand(T * K, *x.shape).reshape(T * K * b, *x.shape[1:])
        steps = torch.arange(T, device=feat.device).clamp(max=self.max_steps)
        steps = steps[:, None, None].expand(T, K, b).reshape(-1)
        code = torch.arange(K, device=feat.device)[None, :, None].expand(T, K, b).reshape(-1)
        pl = placed[:, None].expand(T, K, b, n).reshape(T * K * b, n)
        logits = self.step_logits(rep(feat), rep(cap), rep(scene), pl, steps, code)
        tgt = target[:, None].expand(T, K, b).reshape(-1)
        ce = F.cross_entropy(logits, tgt, reduction="none").view(T, K, b)
        ce = ce * valid[:, None, :].to(ce.dtype)
        return ce.sum(dim=0)                                             # (K, b)

    def order_loss(self, batch, orders):
        nll = self.order_nll_per_code(batch, orders)                     # (K, b)
        best = nll.detach().argmin(dim=0)                                # (b,)
        chosen = nll.gather(0, best[None, :]).squeeze(0)                 # gradient only through the best code
        lengths = torch.tensor([len(o) + 1 for o in orders], device=nll.device, dtype=nll.dtype)
        return (chosen / lengths).mean()                                 # per-step NLL, comparable to AR's CE

    def forward(self, batch, orders):
        lo = self.order_loss(batch, orders)
        lt = self.target_loss(batch, orders)
        return lo + lt, {"order_ce": lo.item(), "target_mse": lt.item()}

    # -- inference --------------------------------------------------------------------------
    @torch.no_grad()
    def greedy_decode(self, batch, code=None):
        return super().greedy_decode(batch, code=self.point_code if code is None else code)

    @torch.no_grad()
    def sample_decode(self, batch, generator=None, temperature: float = 1.0, code=None):
        return super().sample_decode(batch, generator=generator, temperature=temperature,
                                     code=self.point_code if code is None else code)

    # -- inference, PolyNet's own rule: decode under every strategy, keep the best ------------
    @torch.no_grad()
    def decode_by_likelihood(self, batch):
        """Point prediction without a frozen code: greedy-decode under each of the K codes and
        return, per scene, the sequence with the lowest per-step NLL under its own code.

        This is the supervised analogue of PolyNet's test-time rule (roll out every strategy,
        keep the best by the objective) -- the objective here is the model's own likelihood,
        because the oracle is not available at test time. Motivation (validation, 2026-09-07):
        the best-of-K update hands the K* = 0 examples to ONE code, so any single frozen code
        either always STOPs or never does; only a per-scene choice can combine them."""
        b = batch["x0"].shape[0]
        cands = [self.greedy_decode(batch, code=c) for c in range(self.n_codes)]      # K x b orders
        nll = torch.zeros(self.n_codes, b, device=batch["x0"].device)
        for c in range(self.n_codes):
            per_code = self.order_nll_per_code(batch, [list(o) for o in cands[c]])   # (K, b)
            lengths = torch.tensor([len(o) + 1 for o in cands[c]], device=nll.device, dtype=nll.dtype)
            nll[c] = per_code[c] / lengths
        best = nll.argmin(dim=0).tolist()
        return [cands[best[i]][i] for i in range(b)]
