"""PolyNet-style Multi-Strategy AR baseline (experiment 01). See model.py."""
from baselines.polynet_order.model import PolyNetOrderModel  # noqa: F401
