"""Gumbel-Sinkhorn operator in PyTorch (Mena et al., ICLR 2018).

Written against the authors' archived TensorFlow-1 reference (google/gumbel_sinkhorn @
312c73f6, Apache-2.0; see third-party/LOCK_grid2d.md) -- the algorithm, not the code:
log-space alternating row/column normalisation, Gumbel perturbation, and hard rounding by a
linear-assignment solve. The reference rounds with SciPy's Hungarian; this project does not
depend on SciPy, so a small exact O(n^3) Hungarian solver is implemented here for the
(n + 1) <= 16 items this experiment ever sees, and is tested to return a true permutation.
"""
from __future__ import annotations

import torch


def sample_gumbel(shape, generator=None, device=None, dtype=torch.float32, eps: float = 1e-20):
    """Standard Gumbel(0, 1): -log(-log(U))."""
    u = torch.rand(shape, generator=generator, device=device, dtype=dtype)
    return -torch.log(-torch.log(u + eps) + eps)


def log_sinkhorn(log_alpha: torch.Tensor, n_iters: int = 20) -> torch.Tensor:
    """Incomplete Sinkhorn normalisation in log space. `log_alpha` (..., N, N) -> log of an
    (approximately) doubly-stochastic matrix. Alternates row and column log-sum-exp
    subtraction, as the reference does; entries are never exponentiated inside the loop."""
    for _ in range(int(n_iters)):
        log_alpha = log_alpha - torch.logsumexp(log_alpha, dim=-1, keepdim=True)
        log_alpha = log_alpha - torch.logsumexp(log_alpha, dim=-2, keepdim=True)
    return log_alpha


def gumbel_sinkhorn(log_alpha: torch.Tensor, tau: float = 1.0, noise_factor: float = 1.0,
                    n_iters: int = 20, generator=None) -> torch.Tensor:
    """log of a random doubly-stochastic matrix: sinkhorn((log_alpha + g * noise) / tau).
    `noise_factor = 0` gives the deterministic relaxation whose tau -> 0 limit is the
    maximum-weight matching of `log_alpha`."""
    if noise_factor > 0:
        log_alpha = log_alpha + noise_factor * sample_gumbel(
            log_alpha.shape, generator=generator, device=log_alpha.device, dtype=log_alpha.dtype)
    return log_sinkhorn(log_alpha / max(float(tau), 1e-6), n_iters)


def hungarian_max(score: torch.Tensor) -> list[int]:
    """Maximum-weight perfect matching of a square (N, N) score matrix.

    Returns `assign` with `assign[i] = j`: row (item) i goes to column (position) j, a true
    permutation of range(N). Exact Hungarian (Kuhn-Munkres, potentials form), O(N^3); N here
    is at most objects + 1 <= 16, so a Python loop is fine and deterministic. Ties are broken
    by the fixed scan order, so equal inputs give equal outputs.
    """
    a = score.detach().to(torch.float64).cpu()
    n = a.shape[0]
    assert a.shape == (n, n), f"square matrix required, got {tuple(a.shape)}"
    cost = (-a).tolist()                        # minimise negative score
    INF = float("inf")
    u = [0.0] * (n + 1); v = [0.0] * (n + 1); p = [0] * (n + 1); way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [INF] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta, j1 = INF, 0
            for j in range(1, n + 1):
                if not used[j]:
                    cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta; v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    assign = [0] * n
    for j in range(1, n + 1):
        if p[j]:
            assign[p[j] - 1] = j - 1
    return assign


def prefix_from_assignment(assign: list[int], stop_item: int) -> tuple[int, ...]:
    """Items ordered by assigned position, cut at STOP's position. Items placed after STOP
    are unselected. `assign[i]` is item i's position; `stop_item` is the STOP row index."""
    stop_pos = assign[stop_item]
    items = [i for i in range(len(assign)) if i != stop_item and assign[i] < stop_pos]
    return tuple(sorted(items, key=lambda i: assign[i]))
