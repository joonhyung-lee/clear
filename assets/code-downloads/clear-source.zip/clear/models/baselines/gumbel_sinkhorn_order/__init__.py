"""Gumbel-Sinkhorn ordering baseline (experiment 01). See model.py and ops.py."""
from baselines.gumbel_sinkhorn_order.model import GumbelSinkhornOrderModel  # noqa: F401
