"""Gumbel-Sinkhorn Ordering baseline (spec: exp_v2/01_grid2d_baseline_extension_instruction.md §5).

One-shot stochastic PARTIAL permutation: the n object tokens plus one learned STOP token are
n + 1 items, scored against n + 1 positions. A permutation orders all items; the predicted
interaction sequence is the prefix before STOP. Selection and order are therefore one joint
object, with no independent per-object Bernoulli mover head.

Everything except the order representation is the Autoregressive Transformer's: the same
public scene / capability / object encoders, the same transformer trunk, and the same
rank-causal direct target-regression head (`AutoregressiveOrderModel.target_loss` /
`predict_targets`). Only `order_loss` and the decoders differ.

Training: Gumbel perturbation + log-Sinkhorn at temperature tau (scheduled tau_start -> tau_end
by the trainer via `set_tau`), supervised only on the prefix (item o_t at position t) and STOP
at position K; suffix positions of unselected objects carry no target.
Inference: point = maximum-weight matching of log_alpha with no noise; coverage = matching of
log_alpha + Gumbel noise, one independently seeded draw per sample.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn

from baselines.autoregressive_order.model import AutoregressiveOrderModel

from baselines.gumbel_sinkhorn_order.ops import gumbel_sinkhorn, hungarian_max, log_sinkhorn, prefix_from_assignment, sample_gumbel


class GumbelSinkhornOrderModel(AutoregressiveOrderModel):
    def __init__(self, *args, sinkhorn_iters: int = 20, tau_start: float = 1.0, tau_end: float = 0.1,
                 noise_factor: float = 1.0, **kw):
        super().__init__(*args, **kw)
        dim = self.to_object_tokens.out_features
        self.sinkhorn_iters = int(sinkhorn_iters)
        self.tau_start, self.tau_end = float(tau_start), float(tau_end)
        self.noise_factor = float(noise_factor)
        # Inference-only knob (default off): scale the coverage-draw Gumbel noise to the score
        # matrix, `noise = noise_std_mult * std(log_alpha)` per scene. Motivation (validation,
        # 2026-09-07): the trained scores have per-row top-1/top-2 margins of 10-15 nats, so
        # unit Gumbel noise flips almost no assignment and 32 draws hold ~3-4 distinct orders.
        self.noise_std_mult = 0.0
        self.tau = float(tau_start)
        # item -> position score: bilinear between item embeddings and learned position embeddings.
        # max_steps + 1 positions covers objects + STOP for every bucket size this experiment uses.
        self.to_item = nn.Linear(dim, dim)
        self.pos_embed = nn.Embedding(self.max_steps + 2, dim)
        # the AR step/placed machinery is unused by this decoder; kept so checkpoints share a schema
        self.hparams = dict(sinkhorn_iters=self.sinkhorn_iters, tau_start=self.tau_start,
                            tau_end=self.tau_end, noise_factor=self.noise_factor)

    def set_tau(self, tau: float) -> None:
        self.tau = float(tau)

    # -- scores -----------------------------------------------------------------------------
    def log_alpha(self, batch):
        """-> (b, n + 1, n + 1) item-to-position scores; row n is STOP."""
        feat = self.features(batch)
        cap = self.capability_encoder(batch["emb_feat"])
        scene = self.scene_encoder(batch["grid"])
        b, n = feat.shape[:2]
        st = torch.zeros(b, dtype=torch.long, device=feat.device)
        stop = (self.stop_token + self.step_embed(st))[:, None, :]
        tokens = torch.cat([cap, self.to_object_tokens(feat), scene, stop], dim=1)
        out = self.transformer(tokens)
        items = torch.cat([out[:, 1:1 + n], out[:, -1:]], dim=1)          # (b, n+1, d)
        pos = self.pos_embed(torch.arange(n + 1, device=feat.device))       # (n+1, d)
        return torch.einsum("bid,pd->bip", self.to_item(items), pos) / (items.shape[-1] ** 0.5)

    # -- training ---------------------------------------------------------------------------
    def order_loss(self, batch, orders, generator=None):
        la = self.log_alpha(batch)
        b, m, _ = la.shape
        n = m - 1
        logP = gumbel_sinkhorn(la, tau=self.tau, noise_factor=self.noise_factor,
                               n_iters=self.sinkhorn_iters, generator=generator)
        # supervise item o_t at position t for t < K, and STOP (row n) at position K. Nothing
        # else: the suffix order of unselected objects is not an oracle quantity.
        rows, cols, bidx = [], [], []
        for i, o in enumerate(orders):
            for t, j in enumerate(o):
                bidx.append(i); rows.append(int(j)); cols.append(t)
            bidx.append(i); rows.append(n); cols.append(len(o))
        bidx = torch.tensor(bidx, device=la.device); rows = torch.tensor(rows, device=la.device)
        cols = torch.tensor(cols, device=la.device)
        return -logP[bidx, rows, cols].mean()

    def forward(self, batch, orders, generator=None):
        lo = self.order_loss(batch, orders, generator)
        lt = self.target_loss(batch, orders)
        return lo + lt, {"order_nll": lo.item(), "target_mse": lt.item(), "tau": self.tau}

    # -- inference --------------------------------------------------------------------------
    @torch.no_grad()
    def _decode(self, la_row):
        n = la_row.shape[0] - 1
        assign = hungarian_max(la_row)
        return prefix_from_assignment(assign, stop_item=n)

    @torch.no_grad()
    def greedy_decode(self, batch, code=None):
        """Point prediction: maximum-weight matching of the noiseless scores."""
        return [self._decode(row) for row in self.log_alpha(batch)]

    @torch.no_grad()
    def sample_decode(self, batch, generator=None, temperature: float = 1.0, code=None):
        """One Gumbel-perturbed matching per scene; each coverage draw reseeds `generator`."""
        la = self.log_alpha(batch)
        g = sample_gumbel(la.shape, generator=generator, device=la.device, dtype=la.dtype)
        scale = self.noise_factor
        if self.noise_std_mult > 0:
            scale = self.noise_std_mult * la.std(dim=(-2, -1), keepdim=True)
        return [self._decode(row) for row in la + scale * g]

    @torch.no_grad()
    def doubly_stochastic(self, batch, tau: float | None = None):
        """Diagnostic: the noiseless relaxation at `tau` (default tau_end)."""
        return log_sinkhorn(self.log_alpha(batch) / (self.tau_end if tau is None else tau),
                            self.sinkhorn_iters).exp()
