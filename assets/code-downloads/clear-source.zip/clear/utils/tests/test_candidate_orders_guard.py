"""candidate_orders' enumeration guard.

At full depth (depth == n) the beam must reproduce plackett_luce_logp's own
top slice exactly; at truncated depth it must match the proper top-d PL
marginal (denominator over everything unplaced), computed here by brute force.
"""
import numpy as np
import torch

from clear.model.clear import _beam_orders
from clear.util import plackett_luce_logp


def _proper_topd_logp(scores, order, idx):
    lp, rest = 0.0, list(idx)
    for j in order:
        lp += scores[j] - float(np.logaddexp.reduce([scores[q] for q in rest]))
        rest.remove(j)
    return lp


def test_beam_matches_enumeration_full_depth():
    rng = np.random.default_rng(0)
    n, width = 6, 40
    scores = rng.normal(0, 2, n)
    idx = list(range(n))
    from itertools import permutations
    cands = list(permutations(idx, n))                            # 720
    t = torch.tensor(scores, dtype = torch.float32)[None]
    mov = torch.ones(1, n, dtype = torch.bool)
    lp = plackett_luce_logp(t.expand(len(cands), -1).contiguous(), cands,
                            mov.expand(len(cands), -1)).numpy()
    top = [c for _, c in sorted(zip(lp, cands), key = lambda x: -x[0])][:width]
    assert _beam_orders(scores, idx, n, width) == top


def test_beam_matches_proper_marginal_truncated():
    rng = np.random.default_rng(0)
    n, depth, width = 7, 5, 40
    scores = rng.normal(0, 2, n)
    idx = list(range(n))
    from itertools import permutations
    cands = list(permutations(idx, depth))                        # 2520
    lp = [_proper_topd_logp(scores, c, idx) for c in cands]
    top = [c for _, c in sorted(zip(lp, cands), key = lambda x: -x[0])][:width]
    assert _beam_orders(scores, idx, depth, width) == top


def test_beam_shape_and_greedy_head():
    rng = np.random.default_rng(1)
    scores = rng.normal(0, 1, 5)
    beam = _beam_orders(scores, list(range(5)), 5, 10)
    assert len(beam) == 10 and all(len(b) == 5 and len(set(b)) == 5 for b in beam)
    assert beam[0] == tuple(np.argsort(-scores))
