"""The flow trace hook records the generator's own intermediates, and changes nothing.

Runs the flow twice from one seed -- once plain, once with a trace -- and checks
that the endpoint is bit-identical and that the trace holds n_steps + 1 states
whose last entry is that endpoint.
"""
import torch

from clear.model.causalflownet import RankCausalTargetFlow

def test_flow_trace_records_intermediates_without_changing_the_result():
  torch.manual_seed(0)
  B, N, D, DIM = 2, 3, 16, 12
  flow = RankCausalTargetFlow(dim=D, target_dim=DIM, depth=2, heads=2).eval()
  static = torch.randn(B, N, D)
  context = torch.randn(B, 1, D)      # one embodiment token
  scene = torch.randn(B, 4, D)        # a few scene tokens
  rank = torch.tensor([[0, 1, 2], [0, 1, 2]])
  selected = torch.tensor([[True, True, False], [True, False, False]])
  STEPS = 8

  with torch.no_grad():
    g1 = torch.Generator().manual_seed(7)
    plain = flow.sample(static, context, scene, rank, selected, n_steps=STEPS, generator=g1)
    g2 = torch.Generator().manual_seed(7)
    trace = []
    traced = flow.sample(static, context, scene, rank, selected, n_steps=STEPS, generator=g2, trace=trace)

  assert torch.equal(plain, traced), "tracing changed the result"
  assert len(trace) == STEPS + 1, f"expected {STEPS + 1} states, got {len(trace)}"
  ts = [t for t, _ in trace]
  assert ts[0] == 0.0 and ts[-1] == 1.0, ts
  assert all(b > a for a, b in zip(ts, ts[1:])), "flow time must increase"
  assert torch.equal(trace[-1][1], traced), "last trace state must be the returned code"
  assert not torch.equal(trace[0][1], trace[-1][1]), "the flow must actually move"
  # unselected slots stay exactly zero at every step, as the sampler guarantees
  for t, g in trace:
    assert torch.count_nonzero(g[~selected]) == 0, f"unselected slot moved at t={t}"
  print(f"flow trace OK: {len(trace)} states, t={ts[0]} .. {ts[-1]}, endpoint identical")
