from types import SimpleNamespace
import numpy as np
from experiments.exp1.ordering_ablation import permute, permutation_seed

def scene():
 return SimpleNamespace(start=(3,3),objects=[SimpleNamespace(cell=(5,3),object_id=9),SimpleNamespace(cell=(3,1),object_id=7),SimpleNamespace(cell=(3,4),object_id=2)])

def test_heuristic_is_static_with_declared_ties():
 assert permute([0,2,1],scene(),'x',0,'point',-1,'heuristic')==(2,1,0)

def test_random_uses_canonical_subset_and_separate_deterministic_seed():
 state=np.random.get_state()
 a=permute([2,1,0],scene(),'x',0,'point',-1,'random')
 b=permute([0,2,1],scene(),'x',0,'point',-1,'random')
 assert a==b and sorted(a)==[0,1,2]
 after=np.random.get_state();assert all(np.array_equal(x,y) for x,y in zip(state,after))
 assert permutation_seed('x',0,'point',-1)!=permutation_seed('x',0,'distribution',0)
 assert permutation_seed('x',0,'point',-1)==4556703558053137929

def test_empty_singleton_and_native_are_preserved():
 for mode in ['native','random','heuristic']:
  assert permute([],scene(),'x',0,'point',-1,mode)==()
  assert permute([2],scene(),'x',0,'point',-1,mode)==(2,)
 assert permute([2,0,1],scene(),'x',0,'point',-1,'native')==(2,0,1)
