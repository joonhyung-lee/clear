"""Specialist exposure can match each shared body's exact sample count."""
from collections import Counter
import torch
import pytest
from experiments.exp3.trajectory_v3.shared_cli import sample_training_indices


def test_balancing_is_exact_even_with_unequal_teacher_counts_and_resumes():
    rows=[{'body_id':'g1'}]*19+[{'body_id':'spot_arm'}]
    generator=torch.Generator().manual_seed(0)
    for _ in range(3):
        indices=sample_training_indices(rows,16,generator,True)
        assert Counter(rows[i]['body_id'] for i in indices)=={'g1':8,'spot_arm':8}
    saved=generator.get_state()
    first=sample_training_indices(rows,16,generator,True)
    generator.set_state(saved)
    assert sample_training_indices(rows,16,generator,True)==first
    with pytest.raises(ValueError):sample_training_indices(rows,3,generator,True)
