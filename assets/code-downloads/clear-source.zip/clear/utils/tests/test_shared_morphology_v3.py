"""Shared weights, gradient ownership, context freshness, and executable CLI contracts."""
from copy import deepcopy
import json

import numpy as np
import pytest
import torch

from clear.model.encoders import StructureEncoder
from experiments.exp3.trajectory_v3.calibration import digest
from experiments.exp3.trajectory_v3.contracts import ObjectMotionPlan, ObjectPath, SCHEMA
from experiments.exp3.trajectory_v3.data import collate
from experiments.exp3.trajectory_v3.navigation import EDGE_FIELDS, TerrainNavigator
from experiments.exp3.trajectory_v3.shared_cli import main, validate_training_data
from experiments.exp3.trajectory_v3.shared_morphology import SHARED_SCHEMA, SharedMorphologyModel, SharedTraversalPredictor, SharedObjectProposer, checkpoint_record, collate_probes, embodiment_from_row, load_shared_checkpoint, load_shared_planner, refresh_navigation_rows
from experiments.exp3.trajectory_v3.traversability import TRAVERSAL_SCHEMA, TraversabilityModel


@pytest.fixture(autouse=True)
def deterministic():
    torch.manual_seed(4)
    torch.set_num_threads(1)


def row(split="train"):
    offset = {"train": 0., "val": .05, "test": .1}[split]
    scene = dict(world_size=[3, 3], walls=[], terrain=[], start=[.6 + offset, .6, 0], goal=[2.2, 2.2, 0],
                 layout_group_id="plan-" + split,
                 objects=[dict(object_id=0, pose=[1.5, 1.5, 0], size=[.2, .2, .2], mass_kg=1, friction=.5)])
    path = ObjectPath(0, ((1.5, 1.5, 0), (2., 1.5, 0)))
    return dict(scene=scene, structure_rows=[[.1] * 20, [.2] * 20], body_id="test_fixture",
                split=split, footprint_radius_m=.1, controller_hash="a" * 64,
                plan=ObjectMotionPlan((path,)).to_dict(),
                teacher=dict(source="planner_object_path", validation="geometric", evidence_hash=digest(scene)))


def probe(split="train"):
    r = row(split)
    return dict(schema=TRAVERSAL_SCHEMA, backend="dynamic_simulation", structure_rows=r["structure_rows"],
                structure_hash=digest(r["structure_rows"]), controller_hash=r["controller_hash"],
                scene_hash=digest(r["scene"]), evidence_hash="f" * 64,
                edge_fields=list(EDGE_FIELDS), edge_features=[0, 0, 0, 0, 0, .5, 1, 0, .1, .5, .8],
                success=True, collision=False, fell=False, execution_seed=0,
                split=split, layout_group_id="probe-" + split)


def config():
    return dict(model=dict(dim=16, depth=2, heads=2, waypoints=4, traversal_dim=8, navigation_features=4),
                navigation=dict(resolution=.5, threshold=.8),
                train=dict(steps=2, batch_size=1, probe_batch_size=1, eval_every=1,
                           lr=.001, affordance_weight=1.), holdout_structure_hashes=[])


def model():
    return SharedMorphologyModel(**config()["model"])


def predictor(m):
    r = row()
    return SharedTraversalPredictor(m, {digest(r["structure_rows"]): r["controller_hash"]})


def random_batch():
    return dict(object_features=torch.randn(1, 3, 9), object_mask=torch.ones(1, 3, dtype=torch.bool),
                scene_features=torch.randn(1, 2, 9), scene_mask=torch.ones(1, 2, dtype=torch.bool),
                structure=torch.randn(1, 2, 20), structure_mask=torch.ones(1, 2, dtype=torch.bool),
                navigation_features=torch.rand(1, 3, 4), rank=torch.tensor([[0, 1, -1]]),
                path_code=torch.randn(1, 3, 12))


def test_flow_prior_scale_matches_training_sampling_and_checkpoint(tmp_path,monkeypatch):
    m=SharedMorphologyModel(**config()['model'],flow_noise_std=.1)
    batch=random_batch();batch['target_code']=batch['path_code'];h=m._encode(batch)
    generator=torch.Generator().manual_seed(42)
    noise=torch.randn(batch['target_code'].shape,generator=generator)*.1
    t=torch.rand(1,generator=generator);selected=batch['rank']>=0
    target=torch.where(selected[...,None],batch['target_code'],0.)
    expected=(1-t[:,None,None])*noise+t[:,None,None]*target
    def velocity(static,context,scene,mixed,time,rank,active,**kw):
        torch.testing.assert_close(mixed,expected)
        return target-noise
    monkeypatch.setattr(m.flow,'forward',velocity)
    assert m.flow_loss(h,batch,torch.Generator().manual_seed(42)).item()==0
    monkeypatch.setattr(m.flow,'forward',lambda static,context,scene,g,*args,**kw:torch.zeros_like(g))
    actual=m.flow.sample(h['objects'],h['embodiment'],h['scene'],batch['rank'],selected,
                         n_steps=2,generator=torch.Generator().manual_seed(42))
    torch.testing.assert_close(actual,torch.where(selected[...,None],noise,0.))
    p=tmp_path/'model.pt';torch.save(checkpoint_record(m,{},dict(resolution=.1,threshold=.8)),p)
    loaded,_=load_shared_checkpoint(p);assert loaded.flow.noise_std==.1
    assert 'flow_noise_std' not in model().config
    for invalid in (0.,-1.,float('nan'),float('inf')):
        with pytest.raises(ValueError):SharedMorphologyModel(**config()['model'],flow_noise_std=invalid)


def test_one_registered_morphology_and_all_three_gradient_paths():
    m, batch = model(), random_batch()
    assert m.morphology_encoder is m.encoder.structure_in
    assert [name for name, module in m.named_modules() if isinstance(module, StructureEncoder)] == ["encoder.structure_in"]
    for task in ("affordance", "ordering", "flow"):
        m.zero_grad(set_to_none=True)
        if task == "affordance":
            loss = m.traversal_loss(collate_probes([probe()]))
        else:
            h = m._encode(batch)
            if task == "ordering":
                loss = m.ordering.loss(h["selection"], h["mu"], h["sigma"], batch["rank"], batch["object_mask"])["order"]
            else:
                loss = m.flow_loss(h, dict(batch, target_code=batch["path_code"]))
        loss.backward()
        assert sum(p.grad.abs().sum() for p in m.morphology_encoder.parameters() if p.grad is not None) > 0, task
        if task == "affordance":
            assert all(p.grad is None for p in m.ordering.parameters())
        else:
            assert all(p.grad is None for p in m.traversal_affordance.parameters())
    m.zero_grad(set_to_none=True)
    total, terms = m.joint_loss(batch, collate_probes([probe()]))
    total.backward()
    assert torch.isfinite(total)
    assert set(terms) == {"selection", "order", "kl", "flow", "affordance"}
    assert all(p.grad is not None for p in m.traversal_affordance.parameters())


def test_pool_is_permutation_and_padding_invariant_and_legacy_keys_load():
    encoder = StructureEncoder(20, 16)
    old = torch.nn.Sequential(torch.nn.Linear(20, 16), torch.nn.GELU(), torch.nn.Linear(16, 16))
    encoder.load_state_dict(old.state_dict(), strict=True)
    rows = torch.randn(2, 3, 20)
    mask = torch.tensor([[True, True, False], [True, True, False]])
    expected = old(rows)[:, :2].mean(1)
    changed = rows.clone()
    changed[:, 2] = 1000
    torch.testing.assert_close(encoder.pool(changed, mask), expected)
    torch.testing.assert_close(encoder.pool(rows[:, [1, 0, 2]], mask), expected)
    legacy = TraversabilityModel(dim=16)
    legacy.structure.load_state_dict(old.state_dict(), strict=True)
    torch.testing.assert_close(legacy.structure.pool(rows, mask), expected)


def test_no_embodiment_disables_shared_body_and_footprint_conditioning():
    m = SharedMorphologyModel(**config()["model"], no_embodiment=True)
    p = collate_probes([probe()])
    a = m.traversal_logits(p["features"], p["structure"], p["structure_mask"])
    changed = p["features"].clone()
    changed[:, 8] = 100
    b = m.traversal_logits(changed, p["structure"] * 100, p["structure_mask"])
    torch.testing.assert_close(a, b, rtol=0, atol=0)


def test_navigation_changes_with_shared_head_and_rejects_stale_views_and_contexts():
    m = model().eval()
    last = m.traversal_affordance.classifier[-1]
    with torch.no_grad():
        last.weight.zero_()
        last.bias.fill_(30)
    first = predictor(m)
    fresh = refresh_navigation_rows([row()], TerrainNavigator(first, resolution=.5))
    assert fresh[0]["navigation_context"]["object_features"][0][2] == 1
    with torch.no_grad():
        last.bias.fill_(-30)
    with pytest.raises(RuntimeError, match="rebuild"):
        first.predict(np.zeros((1, 11)), embodiment_from_row(row()))
    second = predictor(m)
    assert second.identity != first._identity
    blocked = refresh_navigation_rows(fresh, TerrainNavigator(second, resolution=.5))
    assert blocked[0]["navigation_context"]["object_features"][0][2] == 0
    proposer = SharedObjectProposer(m, second, candidates=1, flow_steps=2)
    with pytest.raises(ValueError, match="snapshot"):
        list(proposer(row()["scene"], embodiment_from_row(row()), fresh[0]["navigation_context"]))


def test_optimizer_update_invalidates_shared_predictor():
    m = model()
    p = predictor(m)
    optimizer = torch.optim.AdamW(m.parameters(), lr=.001)
    m.traversal_loss(collate_probes([probe()])).backward()
    optimizer.step()
    with pytest.raises(RuntimeError, match="rebuild"):
        _ = p.identity


def test_checkpoint_restores_single_model_and_seeded_predictions(tmp_path):
    m = model().eval()
    p = predictor(m)
    fresh = refresh_navigation_rows([row()], TerrainNavigator(p, resolution=.5))
    batch = collate(fresh, 4)
    encoded = m.encode(batch)["context"][:, 0]
    torch.testing.assert_close(encoded, p._embeddings[digest(row()["structure_rows"])], rtol=0, atol=0)
    a = m.sample(batch, steps=2, generator=torch.Generator().manual_seed(7))
    path = tmp_path / "shared.pt"
    torch.save(checkpoint_record(m, p.profiles, config()["navigation"]), path)
    restored, _ = load_shared_checkpoint(path)
    b = restored.sample(batch, steps=2, generator=torch.Generator().manual_seed(7))
    for key in a:
        torch.testing.assert_close(a[key], b[key], rtol=0, atol=0)
    assert predictor(restored).identity == p.identity
    planner = load_shared_planner(path, candidates=1, flow_steps=2)
    assert planner.navigator.predictor.model is planner.proposer.model
    assert planner.proposer.model.morphology_encoder is planner.proposer.model.encoder.structure_in
    with pytest.raises(ValueError, match="same model"):
        SharedObjectProposer(model(), planner.navigator.predictor)
    torch.save(dict(schema=SCHEMA), tmp_path / "legacy.pt")
    with pytest.raises(ValueError, match="not automatically merged"):
        load_shared_checkpoint(tmp_path / "legacy.pt")


@pytest.mark.parametrize("failure", ["split", "holdout", "controller", "structure_profile"])
def test_joint_dataset_gates(failure):
    rows = [row(), row("val")]
    probes = [probe(), probe("val")]
    cfg = config()
    if failure == "split":
        probes[1]["layout_group_id"] = rows[0]["scene"]["layout_group_id"]
    elif failure == "holdout":
        cfg["holdout_structure_hashes"] = [digest(rows[0]["structure_rows"])]
    elif failure == "structure_profile":
        for p in probes:
            p['structure_rows']=[[.3]*20]
            p['structure_hash']=digest(p['structure_rows'])
    else:
        rows[1]["controller_hash"] = "b" * 64
    match = {"split": "leaks across", "holdout": "held-out", "controller": "one frozen controller",
             "structure_profile": "structure-controller pairs"}[failure]
    with pytest.raises(ValueError, match=match):
        validate_training_data(rows, probes, cfg)


@pytest.mark.parametrize("selection,variant", [("total","clear"),("flow","clear"),
                                               ("flow","robot_id"),("flow","no_affordance")])
def test_joint_training_and_single_checkpoint_cli_smoke(tmp_path, selection, variant):
    rows = [row(), row("val"), row("test")]
    probes = [probe(), probe("val"), probe("test")]
    for name, values in (("data.jsonl", rows), ("probes.jsonl", probes)):
        (tmp_path / name).write_text("".join(json.dumps(r) + "\n" for r in values))
    cfg=config()
    if variant == "robot_id":
        cfg['model']['robot_id_structures']=[rows[0]['structure_rows']]
    elif variant == "no_affordance":
        cfg['model']['affordance_guidance']=False
    (tmp_path / "config.json").write_text(json.dumps(cfg))
    main(["train", "--data", str(tmp_path / "data.jsonl"), "--probes", str(tmp_path / "probes.jsonl"),
          "--config", str(tmp_path / "config.json"), "--out", str(tmp_path / "run"), "--allow-geometric-teacher",
          "--select", selection])
    checkpoint = tmp_path / "run" / "last.pt"
    record = torch.load(checkpoint, weights_only=True)
    assert record["schema"] == SHARED_SCHEMA and record["step"] == 2
    assert record["training_mode"] == "joint_with_online_navigation"
    terms = json.loads((tmp_path / "run" / "loss.json").read_text())
    assert all("affordance" in t["train_terms"] and "flow" in t["train_terms"] for t in terms)
    assert all("affordance" in t["validation_terms"] and "flow" in t["validation_terms"]["components"] for t in terms)
    best = torch.load(tmp_path / "run" / "best.pt", weights_only=True)
    score = lambda t: t["validation_terms"]["components"]["flow"] if selection == "flow" else t["validation_loss"]
    assert best["step"] == min(terms, key=score)["step"]
    assert best["selection_metric"] == selection
    assert best["selection_score"] == min(map(score, terms))
    (tmp_path / "observation.json").write_text(json.dumps(rows[2]))
    main(["plan", "--checkpoint", str(checkpoint), "--input", str(tmp_path / "observation.json"),
          "--out", str(tmp_path / "plan.json"), "--candidates", "1", "--flow-steps", "2"])
    result = json.loads((tmp_path / "plan.json").read_text())
    assert result["architecture"] == "shared_morphology"
    assert result["physical_execution_performed"] is False


def test_fine_tuning_starts_from_shared_weights_with_fresh_run_identity(tmp_path):
    from experiments.exp3.trajectory_v3.training_state import file_hash
    initial=model();r=row()
    source=tmp_path/'initial.pt'
    torch.save(checkpoint_record(initial,{digest(r['structure_rows']):r['controller_hash']},config()['navigation'],step=37),source)
    for name,values in (('data',[row(),row('val')]),('probes',[probe(),probe('val')])):
        (tmp_path/f'{name}.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in values))
    cfg=config();cfg['train'].update(steps=1,lr=1e-12)
    (tmp_path/'config.json').write_text(json.dumps(cfg))
    main(['train','--data',str(tmp_path/'data.jsonl'),'--probes',str(tmp_path/'probes.jsonl'),
          '--config',str(tmp_path/'config.json'),'--out',str(tmp_path/'run'),
          '--init-checkpoint',str(source),'--seed','77','--allow-geometric-teacher'])
    trained,record=load_shared_checkpoint(tmp_path/'run/last.pt')
    for name,value in initial.state_dict().items():
        torch.testing.assert_close(trained.state_dict()[name],value,atol=5e-11,rtol=0.)
    identity=record['training_state']['identity']
    assert identity['seed']==77 and record['step']==1
    assert identity['initialization']['checkpoint_sha256']==file_hash(source)
    assert identity['initialization']['step']==37
    assert identity['initialization']['optimizer']=='fresh'


def test_paired_bodies_share_proposal_noise_but_have_separate_execution_streams():
    from experiments.exp3.trajectory_v3.evaluate_shared import proposal_seed, episode_seed
    a=row();b=deepcopy(a);b['body_id']='other_body';b['structure_rows']=[[.3]*20]
    assert proposal_seed(a,0)==proposal_seed(b,0)
    assert proposal_seed(a,0)!=proposal_seed(a,1)
    assert episode_seed(a,0)!=episode_seed(b,0)


@pytest.mark.parametrize("logit", [-10., 10.])
def test_shared_checkpoint_runs_exp4_evaluation(tmp_path, monkeypatch, logit):
    from experiments.exp3.trajectory_v3.evaluate_v3 import main as evaluate_main
    r, m = row("test"), model()
    r["scene"]["base_scene_id"] = "shared-evaluation-fixture"
    r["teacher"]["k_star"] = 0
    with torch.no_grad():
        m.traversal_affordance.classifier[-1].weight.zero_()
        m.traversal_affordance.classifier[-1].bias.fill_(logit)
    profiles = {digest(r["structure_rows"]): r["controller_hash"]}
    checkpoint = tmp_path / "shared.pt"
    torch.save(checkpoint_record(m, profiles, config()["navigation"]), checkpoint)
    summary = dict(structure_hash=digest(r["structure_rows"]), controller_hash=r["controller_hash"],
                   footprint_radius_m=r["footprint_radius_m"],
                   conditions=[dict(condition=dict(kind="flat", magnitude=0., friction=.5), success_rate=1.)])
    (tmp_path / "probe.json").write_text(json.dumps(summary))
    (tmp_path / "push.json").write_text(json.dumps(dict(conditions=[
        dict(condition=dict(mass_kg=1., friction=.5), success_rate=1.)])))
    (tmp_path / "test.jsonl").write_text(json.dumps(r) + "\n")
    calls = []
    original = SharedObjectProposer.__call__

    def checked(self, scene, embodiment, context):
        assert self.model is self.predictor.model
        assert context["predictor_hash"] == self.predictor.identity
        calls.append(context["predictor_hash"])
        yield from original(self, scene, embodiment, context)

    monkeypatch.setattr(SharedObjectProposer, "__call__", checked)
    override = ["--threshold", "0.95"] if logit > 0 else []
    evaluate_main(["--data", str(tmp_path / "test.jsonl"), "--shared-checkpoint", str(checkpoint),
                   "--probe-summaries", f"test_fixture={tmp_path / 'probe.json'}",
                   "--push-summaries", f"test_fixture={tmp_path / 'push.json'}",
                   "--out", str(tmp_path / "eval"), "--mode", "exp4", "--methods", "clear",
                   "--seeds", "0", "--candidates", "1", *override])
    report = json.loads((tmp_path / "eval" / "aggregate_metrics.json").read_text())
    assert report["config"]["architecture"] == "shared_morphology"
    assert report["config"]["checkpoint_schema"] == SHARED_SCHEMA
    expected_navigation = dict(config()["navigation"])
    if override:
        expected_navigation["threshold"] = .95
    assert report["config"]["navigation"] == expected_navigation
    import hashlib
    assert report["config"]["shared_checkpoint_sha256"] == hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    assert len(report["groups"]) == 6
    assert all(g["episodes"] == 1 for g in report["groups"].values())
    assert bool(calls) == (logit < 0)
    assert all(g["task_success"]["mean"] == float(logit > 0) for g in report["groups"].values())


@pytest.mark.parametrize("legacy", ["checkpoint", "noemb_checkpoint", "traversability_checkpoint"])
def test_shared_evaluation_rejects_mixed_checkpoints(tmp_path, legacy):
    from experiments.exp3.trajectory_v3.evaluate_v3 import evaluate
    with pytest.raises(ValueError, match="cannot be combined"):
        evaluate([], tmp_path, "exp3", {}, shared_checkpoint="shared.pt", **{legacy: "legacy.pt"})


def test_geometry_cache_preserves_routes_and_invalidates_updated_scene_and_weights():
    from experiments.exp3.trajectory_v3.navigation_cache import CachedTerrainNavigator, GeometryCache
    m, r = model().eval(), row()
    with torch.no_grad():
        m.traversal_affordance.classifier[-1].weight.zero_()
        m.traversal_affordance.classifier[-1].bias.fill_(30)
    p, emb, cache = predictor(m), embodiment_from_row(r), GeometryCache(2)
    cached = CachedTerrainNavigator(p, resolution=.5, geometry_cache=cache)
    original = TerrainNavigator(p, resolution=.5).analyze(r["scene"], emb)
    analysis = cached.analyze(r["scene"], emb)
    assert analysis.goal_route == original.goal_route
    assert analysis.model_context() == original.model_context()
    assert cached.analyze(r["scene"], emb) is analysis
    r["scene"]["goal"] = [.7, .7, 0.]
    changed = cached.analyze(r["scene"], emb)
    assert changed is not analysis and analysis.scene["goal"] == [2.2, 2.2, 0.]
    with torch.no_grad():
        m.traversal_affordance.classifier[-1].bias.fill_(-30)
    with pytest.raises(RuntimeError, match="rebuild"):
        cached.analyze(r["scene"], emb)
    refreshed = CachedTerrainNavigator(predictor(m), resolution=.5, geometry_cache=cache)
    assert refreshed.analyze(r["scene"], emb).goal_route is None
    assert len(cache.values) <= 2


def test_resume_replays_optimizer_schedule_and_random_streams(tmp_path):
    cfg = config()
    cfg["train"].update(steps=4, eval_every=2, affordance_warmup_steps=2, schedule="cosine",
                        lr_warmup_steps=1, min_lr_ratio=.1)
    for name, values in (("data.jsonl", [row(), row("val")]), ("probes.jsonl", [probe(), probe("val")])):
        (tmp_path / name).write_text("".join(json.dumps(r) + "\n" for r in values))
    (tmp_path / "config.json").write_text(json.dumps(cfg))
    common = ["train", "--data", str(tmp_path / "data.jsonl"), "--probes", str(tmp_path / "probes.jsonl"),
              "--config", str(tmp_path / "config.json"), "--allow-geometric-teacher", "--seed", "2"]
    main([*common, "--out", str(tmp_path / "full")])
    main([*common, "--out", str(tmp_path / "resumed"), "--stop-after", "2"])
    main([*common, "--out", str(tmp_path / "resumed"), "--resume"])
    full = torch.load(tmp_path / "full/last.pt", weights_only=True)
    resumed = torch.load(tmp_path / "resumed/last.pt", weights_only=True)
    for key, tensor in full["state_dict"].items():
        torch.testing.assert_close(tensor, resumed["state_dict"][key], rtol=0, atol=0)
    assert full["validation_loss"] == resumed["validation_loss"]
    assert full["training_state"]["history"][-1]["lr"] == resumed["training_state"]["history"][-1]["lr"]
    cfg["train"]["steps"] = 6
    (tmp_path / "config.json").write_text(json.dumps(cfg))
    with pytest.raises(ValueError, match="same shared schema"):
        main([*common, "--out", str(tmp_path / "resumed"), "--resume"])


def test_manifest_rejects_changed_inputs(tmp_path):
    from experiments.exp3.trajectory_v3.exp3_protocol import PROTOCOL_SCHEMA, file_record, load_prepared
    data = tmp_path / "input.jsonl"
    data.write_text("original\n")
    (tmp_path / "manifest.json").write_text(json.dumps(dict(schema=PROTOCOL_SCHEMA, files=dict(data=file_record(data)))))
    load_prepared(tmp_path)
    data.write_text("changed\n")
    with pytest.raises(ValueError, match="input changed"):
        load_prepared(tmp_path)


def test_shared_evaluation_keeps_denominators_and_reproducible_sampling(tmp_path):
    from experiments.exp3.trajectory_v3.evaluate_shared import evaluate as evaluate_task, episode_seed, main as eval_main
    from experiments.exp3.trajectory_v3.summarize_shared import summarize_runs
    r = row("val")
    r["scene"]["base_scene_id"] = "fixture"
    r["teacher"]["k_star"] = 0
    # Exact fixture probabilities exercise contracts; these are not measured performance results.
    summary = dict(structure_hash=digest(r["structure_rows"]), footprint_radius_m=.1, controller_hash="a" * 64,
                   conditions=[dict(condition=dict(kind="flat", magnitude=0, friction=.8), success_rate=1.)])
    (tmp_path / "traversal.json").write_text(json.dumps(summary))
    (tmp_path / "push.json").write_text(json.dumps(dict(conditions=[dict(condition=dict(mass_kg=1, friction=.5), success_rate=1.)])))
    m = model().eval()
    with torch.no_grad():
        m.traversal_affordance.classifier[-1].weight.zero_()
        m.traversal_affordance.classifier[-1].bias.fill_(30)
    p = predictor(m)
    checkpoint = tmp_path / "model.pt"
    torch.save(checkpoint_record(m, p.profiles, config()["navigation"], seed=0), checkpoint)
    unresolved = deepcopy(r)
    unresolved["teacher"]["k_star"] = None
    unresolved["scene"]["base_scene_id"] = "unresolved_fixture"
    assert episode_seed(r, 0) == episode_seed(deepcopy(r), 0)
    assert episode_seed(r, 0) != episode_seed(r, 1)
    result = evaluate_task([r, unresolved], checkpoint, tmp_path / "eval", {"test_fixture": tmp_path / "traversal.json"},
                           {"test_fixture": tmp_path / "push.json"}, rollout_seeds=[0], candidates=1, flow_steps=2,
                           probe_rows=[probe("val"), dict(probe("val"), success=False)])
    groups = result["groups"]["clear_shared"]
    assert groups["all"]["episodes"] == 2
    assert groups["reference_solved"]["episodes"] == 1
    assert groups["reference_unresolved"]["episodes"] == 1
    assert groups["all"]["task_success"]["mean"] == 1
    from experiments.exp3.trajectory_v3.parallel_shared_eval import evaluate_parallel
    parallel = evaluate_parallel([r, unresolved], checkpoint, tmp_path / "parallel_eval",
                                 {"test_fixture": tmp_path / "traversal.json"},
                                 {"test_fixture": tmp_path / "push.json"}, rollout_seeds=[0],
                                 candidates=1, flow_steps=2, workers=2)
    assert parallel["groups"] == result["groups"]
    serial_episodes = [json.loads(s) for s in (tmp_path / "eval/episodes.jsonl").read_text().splitlines()]
    parallel_episodes = [json.loads(s) for s in (tmp_path / "parallel_eval/episodes.jsonl").read_text().splitlines()]
    for episodes in (serial_episodes, parallel_episodes):
        for episode in episodes:
            episode.pop("wall_s")
        episodes.sort(key=lambda e: (e["scene_id"], e["body_id"]))
    assert serial_episodes == parallel_episodes
    evaluate_task([r], checkpoint, tmp_path / "untriggered_event",
                  {"test_fixture": tmp_path / "traversal.json"}, {"test_fixture": tmp_path / "push.json"},
                  rollout_seeds=[0], candidates=1, flow_steps=2, mode="exp4", perturbation="placement_shift")
    untriggered = json.loads((tmp_path / "untriggered_event/episodes.jsonl").read_text())
    assert untriggered["task_success"] and untriggered["attempted_interactions"] == 0
    assert not untriggered["perturbation_applied"]  # The declared event never reached its trigger.
    diagnostics = json.loads((tmp_path / "eval/probe_metrics.json").read_text())
    assert diagnostics["all"]["negatives"] == 1 and diagnostics["all"]["false_positive_rate"] == 1
    path = tmp_path / "eval/metrics.json"
    assert summarize_runs([path])["metrics"]["all"]["task_success"]["sd"] is None
    with pytest.raises(ValueError, match="distinct training seed"):
        summarize_runs([path, path])
    with pytest.raises(SystemExit):
        eval_main(["--prepared", "unused", "--checkpoint", "unused", "--out", "unused", "--split", "test"])


def test_teacher_differing_switch_uses_its_own_denominator():
    from experiments.exp3.trajectory_v3.evaluate_shared import summarize
    episodes = []
    for scene, teachers, predictions, successes in (
        ('same', ([0], [0]), ([0], [0]), (True, True)),
        ('different_success', ([0], [1]), ([0], [1]), (True, True)),
        ('different_failure', ([0], [1]), ([0], [1]), (True, False)),
    ):
        for i, body in enumerate(('spot', 'g1')):
            episodes.append(dict(scene_id=scene, layout_group_id=scene, body_id=body, method='clear_shared',
                                 rollout_seed=0, status='goal_reached' if successes[i] else 'no_valid_plan_found',
                                 task_success=successes[i], k_star=1, minimum_interaction_success=successes[i],
                                 plan_valid=True, attempted_interactions=1, decision='interact',
                                 plan=dict(paths=[dict(object_id=o) for o in predictions[i]]),
                                 decision_objects=predictions[i], reference_objects=teachers[i]))
    metrics = summarize(episodes)['clear_shared']
    assert metrics['body_paired_unordered_set_change_with_success_rate']['n'] == 3
    assert metrics['body_paired_unordered_set_change_with_success_rate']['mean'] == pytest.approx(1 / 3)
    assert metrics['teacher_differing_order_change_with_success_rate']['n'] == 2
    assert metrics['teacher_differing_order_change_with_success_rate']['mean'] == .5
    assert metrics['review_v2']['plan_switch_accuracy']['mean'] is None


def test_exp4_summary_pairs_events_and_keeps_conditional_denominators(tmp_path):
    from itertools import product
    from experiments.exp3.trajectory_v3.summarize_shared_exp4 import summarize_seed, POLICIES, EVENTS
    for policy, event in product(POLICIES, EVENTS):
        folder = tmp_path / f"eval_val_{policy}_{event}"
        folder.mkdir()
        cfg = dict(mode="exp4", policy=policy, perturbation=event, provenance=dict(split="val"),
                   checkpoint_sha256="same-checkpoint", rows=2, rollout_seeds=[0])
        (folder / "metrics.json").write_text(json.dumps(dict(status="evaluation_completed", config=cfg)))
        rows = []
        for i in range(2):
            success = i == 0 and (event != "access_shift" or policy == "replan_after_interaction")
            rows.append(dict(scene_id=str(i), body_id="spot", rollout_seed=0, rng_seed=i,
                             method="clear_shared", task_success=success, horizon=2, backend_events=[]))
        (folder / "episodes.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    report = summarize_seed(tmp_path, "val")["metrics"]
    assert report["access_shift|paired_success_gain"] == dict(n=2, mean=.5)
    assert report["access_shift|recovery_after_frozen_failure"] == dict(n=1, mean=1.)
    assert report["nominal|recovery_after_frozen_failure"] == dict(n=0, mean=None)
    path = tmp_path / "eval_val_replan_after_interaction_access_shift/episodes.jsonl"
    rows = [json.loads(s) for s in path.read_text().splitlines()]
    rows[0]["rng_seed"] = 999
    path.write_text("".join(json.dumps(r) + "\n" for r in rows))
    with pytest.raises(ValueError, match="common episode random seeds"):
        summarize_seed(tmp_path, "val")


def test_noflow_regression_keeps_whole_waypoint_space_and_shared_gradients():
    cfg=config()['model'];m=SharedMorphologyModel(**cfg,trajectory_objective='regression')
    batch=random_batch()
    assert sum(p.numel() for p in m.parameters())==sum(p.numel() for p in model().parameters())
    loss,terms=m.joint_loss(batch,collate_probes([probe()]))
    loss.backward()
    assert torch.isfinite(loss)
    assert any(p.grad is not None and p.grad.abs().sum()>0 for p in m.morphology_encoder.parameters())
    with torch.no_grad():m.ordering.priority.bias[0]=10.
    calls=[]
    hook=m.flow.register_forward_hook(lambda *_:calls.append(1))
    a=m.sample(batch,steps=1,generator=torch.Generator().manual_seed(42))
    b=m.sample(batch,steps=30,generator=torch.Generator().manual_seed(42))
    hook.remove()
    assert len(calls)==2  # one full-waypoint regression call per proposal batch
    assert a['path_code'].shape==(1,3,12)
    torch.testing.assert_close(a['path_code'],b['path_code'])
    assert m.config['trajectory_objective']=='regression'
    restored=SharedMorphologyModel(**m.config);restored.load_state_dict(m.state_dict())
    torch.testing.assert_close(restored.sample(batch,1,torch.Generator().manual_seed(42))['path_code'],a['path_code'])


def test_no_affordance_guidance_disconnects_both_routes_and_context_but_keeps_loss():
    m = SharedMorphologyModel(**config()['model'], affordance_guidance=False).eval()
    profiles = {digest(row()['structure_rows']): row()['controller_hash']}
    last = m.traversal_affordance.classifier[-1]
    with torch.no_grad():
        last.weight.zero_()
        last.bias.fill_(30)
    before = refresh_navigation_rows([row()], TerrainNavigator(SharedTraversalPredictor(m, profiles), resolution=.5))
    with torch.no_grad():
        last.bias.fill_(-30)
    after = refresh_navigation_rows([row()], TerrainNavigator(SharedTraversalPredictor(m, profiles), resolution=.5))
    assert before[0]['navigation_context']['object_features'] == after[0]['navigation_context']['object_features']
    assert after[0]['navigation_context']['object_features'][0][2] == 1
    from experiments.exp3.trajectory_v3.data import validate_navigation_context
    assert validate_navigation_context(after[0]).shape == (1, 4)
    m.traversal_loss(collate_probes([probe()])).backward()
    assert last.bias.grad.abs().sum() > 0
    restored = SharedMorphologyModel(**m.config)
    restored.load_state_dict(m.state_dict(), strict=True)
    assert not restored.affordance_guidance


def test_robot_id_replaces_structure_encoding_in_every_head_and_rejects_unknown():
    structures = [row()['structure_rows'], [[.3]*20]]
    m = SharedMorphologyModel(**config()['model'], robot_id_structures=structures)
    batch = random_batch()
    batch['structure'] = torch.tensor([structures[0]])
    expected = m.encoder.structure_in.embedding.weight[:1]
    torch.testing.assert_close(m.encode_morphology(batch['structure'], batch['structure_mask']), expected)
    torch.testing.assert_close(m._encode(batch)['embodiment'][:, 0], expected)
    loss, _ = m.joint_loss(batch, collate_probes([probe()]))
    loss.backward()
    assert m.encoder.structure_in.embedding.weight.grad[0].abs().sum() > 0
    assert list(m.morphology_encoder.named_parameters())[0][0] == 'embedding.weight'
    with pytest.raises(ValueError, match='unknown'):
        m.encode_morphology(batch['structure']+1, batch['structure_mask'])
    restored = SharedMorphologyModel(**m.config)
    restored.load_state_dict(m.state_dict(), strict=True)
    torch.testing.assert_close(restored.encode_morphology(batch['structure'], batch['structure_mask']), expected)
