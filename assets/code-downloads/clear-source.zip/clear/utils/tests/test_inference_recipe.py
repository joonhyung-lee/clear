"""Self-checks for the inference-side recipe (docs/EXPERIMENT_inference_recipe_2026-09-01.md).

Three things that would silently rot:
  1. projection never returns a wall / unreachable / doubled-up cell
  2. jitter = 0 leaves the rollout byte-identical to the deterministic one
  3. sample_verified returns a plan that passes its own check when one exists

Run: PYTHONPATH=. .venv/bin/python tests/test_inference_recipe.py
"""
import sys
from pathlib import Path

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from clear.data import build_examples, collate  # noqa: E402
from clear.data.capability import WALL  # noqa: E402
from clear.data.data import embodiment_of, example_scene  # noqa: E402
from clear.data.oracle import plan_success  # noqa: E402
from clear.data.terrain import height_field, reachable_mask  # noqa: E402
from clear.model import PAMO  # noqa: E402
from clear.util import NoFeasiblePlacement, final_cells, snap
from clear.util import ShiftScorer


def _fixture(n = 24):
    ex = [e for e in build_examples(n, 8, 8, 4, seed = 3, attach_gain = False) if e.n_moved > 0]
    assert ex, 'no solvable example'
    model = PAMO(grid_hw = (8, 8), dim = 32, depth = 2, heads = 2, dim_head = 16)
    batch = collate(ex, np.random.default_rng(0), 'cpu', t = 0.)
    return model.eval(), ex, batch


def test_snap_is_feasible_and_sequential():
    """snap() must land every object on a cell the body can occupy AND leave the
    rest of the plan executable -- the second half is what oracle.find_parking
    guarantees for us, and the reason this module is 20 lines instead of 120."""
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(5)
        model, ex, batch = _fixture()
    gen = torch.Generator().manual_seed(0)
    plan = model.sample(batch, generator = gen)
    checked = 0
    rejected = 0
    for i, e in enumerate(ex):
        scene, emb, order = example_scene(e), embodiment_of(e), list(plan['orders'][i])
        try:
            final = snap(scene, emb, order, final_cells(plan, i, order))
        except NoFeasiblePlacement:
            rejected += 1
            continue
        reach = reachable_mask(height_field(scene), emb, scene.start)
        assert len(set(final.values())) == len(final), 'two objects snapped onto one cell'
        for j, (r, c) in final.items():
            assert scene.terrain[r, c] != WALL, f'snapped into a wall: {(r, c)}'
            assert reach[r, c], f'snapped somewhere this body cannot reach: {(r, c)}'
            checked += 1
    assert checked, 'nothing was projected'
    assert rejected, 'the seed-5 infeasible order must be rejected'
    print(f'snap ok ({checked} cells)')


def test_jitter_zero_is_identical():
    model, ex, batch = _fixture()
    a = model.sample(batch, generator = torch.Generator().manual_seed(0))
    b = model.sample(batch, generator = torch.Generator().manual_seed(0), jitter = 0.0)
    assert torch.equal(a['x'], b['x']), 'jitter=0 changed the deterministic rollout'
    c = model.sample(batch, generator = torch.Generator().manual_seed(0), jitter = 0.4)
    assert not torch.equal(a['x'], c['x']), 'jitter>0 did nothing'
    print('jitter ok (0 is a no-op, >0 moves the rollout)')


@pytest.mark.parametrize('project', [False, True])
def test_verified_returns_a_passing_plan(project):
    model, ex, batch = _fixture()
    plan = model.sample_verified(batch, ex, k = 4, generator = torch.Generator().manual_seed(0),
                                 jitter = 0.3, snap_placement=project)
    assert plan['tries'].max() <= 4 and plan['verified'].dtype == torch.bool
    for i, e in enumerate(ex):
        if not bool(plan['verified'][i]):
            continue
        scene, emb, order = example_scene(e), embodiment_of(e), list(plan['orders'][i])
        final = final_cells(plan, i, order)
        assert plan_success(scene, emb, order, final), 'plan marked verified does not pass'
    print(f'sample_verified ok ({int(plan["verified"].sum())}/{len(ex)} verified, '
          f'mean tries {plan["tries"].float().mean():.2f})')


def test_shift_scorer_orders_families():
    from clear.data.grid import gp_scene, random_scene
    from clear.data.probes import rooms_fork_scene

    def scene_fn_for(name, g, n_obj):
        if name == 'rooms_fork':
            return lambda r: rooms_fork_scene(r, g, g, n_obj)
        return lambda r: gp_scene(r, g, g, n_obj) if r.random() < 0.7 else random_scene(r, g, g, n_obj)
    model = PAMO(grid_hw = (8, 8), dim = 32, depth = 2, heads = 2, dim_head = 16).eval()
    def b(fam, seed):
        e = [x for x in build_examples(40, 8, 8, 4, seed = seed, scene_fn = scene_fn_for(fam, 8, 4),
                                       attach_gain = False) if x.n_moved > 0]
        return collate(e, np.random.default_rng(0), 'cpu', t = 0.)
    sc = ShiftScorer.fit(model, [b('rooms_fork', 11)])
    d_in = sc.score(model, b('rooms_fork', 22)).median().item()
    d_out = sc.score(model, b('mix', 22)).median().item()
    assert d_out > d_in, f'detector does not separate families: in {d_in:.2f} out {d_out:.2f}'
    assert float(sc.temperature(torch.tensor([sc.d_ref * 0.5]))[0]) == 1.0, 'in-family T must be 1'
    print(f'shift scorer ok (in-family {d_in:.1f} < out {d_out:.1f})')


if __name__ == '__main__':
    test_snap_is_feasible_and_sequential()
    test_jitter_zero_is_identical()
    test_verified_returns_a_passing_plan(False)
    test_verified_returns_a_passing_plan(True)
    test_shift_scorer_orders_families()
