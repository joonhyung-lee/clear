"""THE scene palette (imagination_grid.gif) -- single source of truth for
every renderer: training-time viz figures, the rollout viewer, and any page
figures. If a scene render looks off-brand, it stopped importing from here.
"""

from collections import deque

import numpy as np
from matplotlib import colors as mcolors

WALL_C = '#282c39'
STEP_C = '#f0d090'
OBJ_C = '#f4715c'    # movable objects
FIX_C = '#9aa0a6'    # immovable obstacles
GOAL_C = '#18a06d'
ROBOT_C = '#5b4be0'  # init ring + robot
REACH_C = '#ddd8f6'  # reachable-from-init tint
VEL_C = '#18a06d'    # velocity target arrows


def reachable(terrain, cell, wall_value, blocked = (), impassable = None):
    """Cells reachable from `cell`.

    Two things this must not forget, because forgetting either makes the tint
    claim a route the scorer rejects -- which is exactly how a FAIL ends up
    drawn on top of an apparently open path:
      `blocked`    the object cells. Without them the tint answers "reachable
                   if the objects were not there", i.e. almost everything.
      `impassable` terrain classes THIS body cannot cross (a quadruped stopped
                   by a step). Defaults to walls only, which is the right
                   answer only for a body that can climb anything.
    """
    bad = {wall_value} if impassable is None else set(impassable)
    blocked = set(blocked) - {cell}
    seen, q = {cell}, deque([cell])
    h, w = terrain.shape
    while q:
        r, c = q.popleft()
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nx = (r + dr, c + dc)
            if (0 <= nx[0] < h and 0 <= nx[1] < w and nx not in seen
                    and terrain[nx] not in bad and nx not in blocked):
                seen.add(nx)
                q.append(nx)
    return seen


def terrain_rgb(terrain, step_value, wall_value, tint_from = None, blocked = (),
                impassable = None):
    """(H, W) class grid -> RGB image in the unified palette; optional
    lavender tint over cells reachable from `tint_from` with `blocked`
    (object cells) treated as obstacles."""
    img = np.ones((*terrain.shape, 3))
    if tint_from is not None:
        tint = np.array(mcolors.to_rgb(REACH_C))
        for r, c in reachable(terrain, tint_from, wall_value, blocked, impassable):
            img[r, c] = tint
    img[terrain == step_value] = mcolors.to_rgb(STEP_C)
    img[terrain == wall_value] = mcolors.to_rgb(WALL_C)
    return img


def draw_markers(ax, start, goal):
    """init ring (violet) + goal square (green), (r, c) tuples."""
    ax.scatter(goal[1], goal[0], s = 220, c = GOAL_C, marker = 's',
               edgecolors = 'white', linewidths = 1.3, zorder = 5)
    ax.scatter(start[1], start[0], s = 220, facecolors = 'none',
               edgecolors = ROBOT_C, linewidths = 2.4, zorder = 6)
