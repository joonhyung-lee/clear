"""Training-time introspection for PAMO components. Read-only diagnostics:
capture attention, project tokens, render plans -- nothing feeds back into
the model.

Figures answer the questions the aggregate metrics can't:
  scene_plan_figure            -- what did the sampled plan DO in this scene
  attention_figure             -- who attends whom across [cap | objects | scene]
  tau_figure                   -- is the priority head's tau distribution
                                  separating ranks / covering modes
  token_pca_figure             -- how the token space organizes by type
  capability_counterfactual    -- same pixels, swapped body: does the
                                  predicted order actually change
  velocity_quiver_figure       -- predicted vs target velocity along path time
  order_acc_by                 -- metric slices (per-embodiment, per-depth)

Every figure function returns a matplotlib Figure; the caller logs it
(wandb.Image) or saves it. `python -m clear.viz` writes a full smoke set.

ein notation:
  b - batch,  n - objects,  h - heads,  t - tokens (1 cap + n obj + s scene)
"""

import numpy as np
import torch

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors

from clear.model.affordancenet import Attention
from clear.data.capability import EMBODIMENTS, FLAT, STEP, WALL, feature_vector
from clear.model.encoders import object_features
from viz.model.style import FIX_C, GOAL_C, OBJ_C, REACH_C, ROBOT_C, STEP_C, VEL_C, WALL_C, draw_markers, terrain_rgb

OBJ_COLORS = plt.cm.tab10.colors  # per-object identity, diagnostics only (tau curves)

# helpers


def run_with_attention(module, fn):
    """Flag every Attention inside `module`, call fn(), return (result,
    [per-layer (b, h, t, t)] in forward order)."""
    layers = [m for m in module.modules() if isinstance(m, Attention)]
    for m in layers:
        m.store_attn = True
    try:
        out = fn()
    finally:
        for m in layers:
            m.store_attn = False
    return out, [m.attn.cpu() for m in layers]


def single_batch(ex, device = 'cpu', t = 0.):
    """One-example batch at a fixed flow time."""
    from clear.data.data import collate
    return collate([ex], np.random.default_rng(0), device, t = t)


def _with_obj_extra(feat, batch):
    """Concat batch.get('obj_extra') onto a viz-built feature tensor, same as
    PAMO.object_features()'s own bound method -- every viz.py figure function
    below builds `feat` via the free scene_encoder.object_features() directly
    (not model.object_features()) because it needs a t/s the bound method
    doesn't expose, which also means each one independently missed obj_extra
    (2026-08-21, same failure class _feat0's own docstring already
    documents: a new column reaches three call sites and misses a fourth --
    this repo now has six, hence a shared helper instead of another inline
    copy)."""
    extra = batch.get('obj_extra')
    return feat if extra is None else torch.cat([feat, extra.to(feat.dtype)], dim = -1)


def _feat0(batch, grid_hw, drop = (), reachable0 = None):
    """`drop`/`reachable0` must match the model's own PAMO.drop_obj/use_reachable
    -- object_features()'s own defaults ((), None) silently rebuild the
    FULL, undropped/un-augmented feature tensor regardless of what the model
    was actually trained on, which only ever mattered once a checkpoint with
    a non-empty drop_obj (or use_reachable=True) existed (2026-08-20,
    docs/PLAN_verification_and_sota_comparison.md's infer_movable=True run --
    every call site below used to omit `drop`, and PriorityHead.to_object_tokens
    -- sized off obj_feat_dim(drop_obj) -- broke on the first mismatched shape
    it saw, at that run's first viz_every checkpoint; reachable0 is the same
    bug class, found while adding the reachable0 feature itself, §9.1)."""
    feat = object_features(
        batch['x0'], batch['mass'], batch['extent'],
        torch.zeros_like(batch['s']), 0., batch['movable'], grid_hw, drop = drop,
        reachable0 = reachable0,
    )
    # same missed-4th-call-site bug class this docstring already warns about
    # (drop/reachable0, 2026-08-20) -- PAMO.object_features() concats
    # batch.get('obj_extra') when the model has obj_extra_dim>0; this
    # standalone viz reimplementation didn't, so any --attach_obj_extra
    # checkpoint shape-mismatched at its first viz_every (2026-08-21).
    extra = batch.get('obj_extra')
    if extra is not None:
        feat = torch.cat([feat, extra.to(feat.dtype)], dim = -1)
    return feat


def _draw_terrain(ax, ex, tint = False):
    terrain = ex.grid[:3].argmax(0)
    st = tuple(int(v) for v in np.argwhere(ex.grid[3])[0])
    gl = tuple(int(v) for v in np.argwhere(ex.grid[4])[0])
    h, w = terrain.shape
    ax.imshow(terrain_rgb(terrain, STEP, WALL, tint_from = st if tint else None),
              origin = 'upper', extent = (-0.5, w - 0.5, h - 0.5, -0.5))
    draw_markers(ax, st, gl)
    ax.set_xticks([])
    ax.set_yticks([])


def _pca2(x):
    x = x - x.mean(0, keepdims = True)
    _, _, vt = np.linalg.svd(x, full_matrices = False)
    return x @ vt[:2].T

# scene + plan


def _draw_scene_plan(ax, ex, order = None, x_final = None):
    """Terrain + supervision paths + objects on one axis. Paths are drawn
    as-is, so the discrete arm shows cardinal staircases and the continuous
    arm shows smoothed curves."""
    _draw_terrain(ax, ex, tint = True)

    for j, path in ex.paths.items():
        rs, cs = zip(*path)
        ax.plot(cs, rs, '-', color = OBJ_C, lw = 1.6, alpha = 0.65, zorder = 2)

    for j in range(len(ex.x0)):
        x, y = ex.x0[j, 0], ex.x0[j, 1]
        color = OBJ_C if ex.movable[j] else FIX_C
        ax.scatter(x, y, s = 300 * ex.extent[j] + 60, c = [color], edgecolors = 'white',
                   linewidths = 1.4, zorder = 3)
        label = f'#{order.index(j) + 1}' if (order is not None and j in order) else ''
        ax.annotate(label, (x, y), ha = 'center', va = 'center', fontsize = 7.5,
                    color = 'white', fontweight = 'bold', zorder = 4)
        if x_final is not None and order is not None and j in order:
            fx, fy = float(x_final[j, 0]), float(x_final[j, 1])
            ax.annotate('', (fx, fy), (x, y), zorder = 2,
                        arrowprops = dict(arrowstyle = '->', color = OBJ_C, lw = 2))


def scene_plan_figure(ex, order = None, x_final = None, title = None):
    fig, ax = plt.subplots(figsize = (5, 5))
    _draw_scene_plan(ax, ex, order = order, x_final = x_final)
    oracle = ' | '.join('-'.join(map(str, o)) for o in ex.orders[:4])
    ax.set_title(title or f'{ex.emb_name}  n_moved={ex.n_moved}  oracle: {oracle}', fontsize = 9)
    fig.tight_layout()
    return fig


def world_comparison_figure(ex_discrete, ex_continuous):
    """The same (scene, embodiment) rendered in both worlds -- built from
    paired build_examples(seed = s) / build_examples(seed = s,
    continuous = True) calls, which share the scene sequence by construction."""
    fig, axes = plt.subplots(1, 2, figsize = (10, 5))
    for ax, ex, name in zip(axes, (ex_discrete, ex_continuous), ('discrete', 'continuous')):
        _draw_scene_plan(ax, ex)
        ax.set_title(f'{name} -- {ex.emb_name}, oracle '
                     + ' | '.join('-'.join(map(str, o)) for o in ex.orders[:3]), fontsize = 9)
    fig.suptitle('same scene, same oracle orders -- two world renderings', fontsize = 10)
    fig.tight_layout()
    return fig

# attention


def attention_figure(attns, ex, grid_hw, mask = None, title = ''):
    """attns: [per-layer (1, h, t, t)]. Top row: head-mean token-token matrix
    at first / last layer (+ mask if given). Bottom rows: each object's
    last-layer attention over scene tokens, painted back onto the grid."""
    n = len(ex.x0)
    h, w = grid_hw
    h2, w2 = (h + 1) // 2, (w + 1) // 2
    first, last = attns[0][0].mean(0).numpy(), attns[-1][0].mean(0).numpy()

    n_cols = max(3, n)
    fig, axes = plt.subplots(2, n_cols, figsize = (2.6 * n_cols, 5.6))

    for ax, mat, name in ((axes[0, 0], first, 'layer 0'), (axes[0, 1], last, f'layer {len(attns) - 1}')):
        ax.imshow(mat, cmap = 'viridis')
        for pos in (0.5, n + 0.5):  # cap | objects | scene boundaries
            ax.axhline(pos, color = 'w', lw = 0.7)
            ax.axvline(pos, color = 'w', lw = 0.7)
        ax.set_title(f'{name} attn (head mean)', fontsize = 8)
        ax.set_xticks([])
        ax.set_yticks([])

    ax = axes[0, 2]
    if mask is not None:
        ax.imshow(mask[0].numpy(), cmap = 'gray_r')
        ax.set_title('mask (black = blocked)', fontsize = 8)
    else:
        ax.imshow(last[1:1 + n, 1:1 + n], cmap = 'viridis')
        ax.set_title('obj x obj (last layer)', fontsize = 8)
    ax.set_xticks([])
    ax.set_yticks([])
    for k in range(3, n_cols):
        axes[0, k].axis('off')

    for j in range(n_cols):
        ax = axes[1, j]
        if j >= n:
            ax.axis('off')
            continue
        _draw_terrain(ax, ex)
        scene_attn = last[1 + j, 1 + n:].reshape(h2, w2)
        up = np.kron(scene_attn, np.ones((2, 2)))[:h, :w]
        ax.imshow(up, cmap = 'magma', alpha = 0.6, origin = 'upper')
        ax.plot(ex.x0[j, 0], ex.x0[j, 1], 'o', color = 'cyan', ms = 6)
        cap_in = last[1 + j, 0]
        ax.set_title(f'obj {j} -> scene   (->cap {cap_in:.2f})', fontsize = 8)

    fig.suptitle(title, fontsize = 10)
    fig.tight_layout()
    return fig


def priority_attention_figure(model, ex, device = 'cpu'):
    batch = single_batch(ex, device)
    feat0 = _feat0(batch, model.grid_hw, drop = model.drop_obj, reachable0 = batch['reachable0'] if model.use_reachable else None)
    _, attns = run_with_attention(
        model.priority_head,
        lambda: model.priority_head(batch['grid'], feat0, batch['emb_feat']),
    )
    return attention_figure(attns, ex, model.grid_hw,
                            title = f'PriorityHead attention -- {ex.emb_name}')


def velocity_attention_figure(model, ex, device = 'cpu', t = 0.5):
    from clear.model.causalflownet import causal_mask
    batch = single_batch(ex, device, t = t)
    feat = object_features(batch['pose'], batch['mass'], batch['extent'],
                           batch['s'], batch['t'], batch['movable'], model.grid_hw,
                           drop = model.drop_obj,
                           reachable0 = batch['reachable0'] if model.use_reachable else None)
    feat = _with_obj_extra(feat, batch)
    _, attns = run_with_attention(
        model.velocity_field,
        lambda: model.velocity_field(batch['grid'], feat, batch['emb_feat'],
                                     batch['rank'], batch['movable']),
    )
    mask = causal_mask(batch['rank'], batch['movable'],
                       model.velocity_field.scene_encoder.num_tokens).cpu()
    return attention_figure(attns, ex, model.grid_hw, mask = mask,
                            title = f'CausalVelocityField attention -- {ex.emb_name}, t={t}')

# tau distribution


def tau_figure(model, ex, device = 'cpu', k = 32, generator = None):
    """Left: mu +/- sigma per object (color = oracle rank). Right: frequency
    of k sampled orderings, oracle-valid ones in green."""
    batch = single_batch(ex, device)
    feat0 = _feat0(batch, model.grid_hw, drop = model.drop_obj, reachable0 = batch['reachable0'] if model.use_reachable else None)
    with torch.no_grad():
        mu, sigma = model.priority_head(batch['grid'], feat0, batch['emb_feat'])
    mu, sigma = mu[0].cpu().numpy(), sigma[0].cpu().numpy()

    first_order = ex.orders[0]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize = (10, 4))
    n = len(mu)
    for j in range(n):
        if not ex.movable[j]:
            color = 'lightgray'
        elif j in first_order:
            color = plt.cm.viridis(first_order.index(j) / max(1, len(first_order)))
        else:
            color = 'tan'
        ax1.errorbar(j, mu[j], yerr = sigma[j], fmt = 'o', color = color, capsize = 4, ms = 8)
    ax1.set_xlabel('object')
    ax1.set_ylabel('activation logit u (low moves first)')
    ax1.set_title(f'tau distribution -- oracle #1: {"-".join(map(str, first_order))}', fontsize = 9)
    ax1.grid(alpha = 0.3)

    samples = model.sample_orders(batch, k = k, generator = generator)
    counts = {}
    for s in samples:
        key = '-'.join(map(str, s[0][:ex.n_moved]))
        counts[key] = counts.get(key, 0) + 1
    prefixes = {'-'.join(map(str, o[:ex.n_moved])) for o in ex.orders}
    keys = sorted(counts, key = counts.get, reverse = True)
    bar_colors = ['#4caf50' if key in prefixes else '#e57373' for key in keys]
    ax2.bar(range(len(keys)), [counts[key] for key in keys], color = bar_colors)
    ax2.set_xticks(range(len(keys)))
    ax2.set_xticklabels(keys, rotation = 45, ha = 'right', fontsize = 7)
    ax2.set_ylabel(f'count / {k} samples')
    ax2.set_title(f'sampled order modes (green = oracle-valid, {len(ex.orders)} oracle modes)',
                  fontsize = 9)
    fig.tight_layout()
    return fig

# token space


def token_pca_figure(model, examples, device = 'cpu'):
    """PriorityHead output tokens from up to 24 examples, PCA to 2D. Left:
    all tokens by type. Right: capability-token cosine similarity across the
    three embodiments (does the model separate bodies at all?)."""
    from clear.data.data import collate
    rng = np.random.default_rng(0)
    head = model.priority_head

    all_tokens, types = [], []
    cap_by_emb = {}
    with torch.no_grad():
        for ex in examples[:24]:
            batch = collate([ex], rng, device, t = 0.)
            feat0 = _feat0(batch, model.grid_hw, drop = model.drop_obj, reachable0 = batch['reachable0'] if model.use_reachable else None)
            objects = head.to_object_tokens(feat0)
            tokens = torch.cat([
                head.capability_encoder(batch['emb_feat']),
                objects,
                head.scene_encoder(batch['grid']),
            ], dim = 1)
            out = head.transformer(tokens)[0].cpu().numpy()
            n = objects.shape[1]
            all_tokens.append(out)
            types += ['cap'] + ['obj_mov' if m else 'obj_fix' for m in ex.movable] + ['scene'] * (len(out) - 1 - n)
            cap_by_emb.setdefault(ex.emb_name, []).append(out[0])

    pts = _pca2(np.concatenate(all_tokens))
    types = np.array(types)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize = (11, 4.5))
    style = dict(cap = ('red', 60, '*'), obj_mov = ('#2e7d32', 22, 'o'),
                 obj_fix = ('#9e9e9e', 22, 'o'), scene = ('#90caf9', 4, '.'))
    for name, (c, s, m) in style.items():
        sel = types == name
        ax1.scatter(pts[sel, 0], pts[sel, 1], c = c, s = s, marker = m, label = name, alpha = 0.7)
    ax1.legend(fontsize = 8)
    ax1.set_title('PriorityHead output tokens, PCA', fontsize = 9)

    names = [n for n in EMBODIMENTS if n in cap_by_emb]
    caps = np.stack([np.mean(cap_by_emb[n], axis = 0) for n in names])
    caps_n = caps / np.linalg.norm(caps, axis = 1, keepdims = True)
    sim = caps_n @ caps_n.T
    im = ax2.imshow(sim, cmap = 'RdBu_r', vmin = -1, vmax = 1)
    ax2.set_xticks(range(len(names)), names)
    ax2.set_yticks(range(len(names)), names)
    for i in range(len(names)):
        for j in range(len(names)):
            ax2.annotate(f'{sim[i, j]:.2f}', (j, i), ha = 'center', va = 'center', fontsize = 9)
    fig.colorbar(im, ax = ax2, shrink = 0.8)
    ax2.set_title('capability token cosine sim (post-transformer mean)', fontsize = 9)
    fig.tight_layout()
    return fig

# capability counterfactual


def capability_counterfactual_figure(model, ex, device = 'cpu'):
    """Same scene tensor, three embodiment tokens (+ their movable masks):
    the predicted ordering should differ exactly where capability says it
    must. THE conditioning diagnostic."""
    names = list(EMBODIMENTS)
    n = len(ex.x0)

    grid = torch.as_tensor(ex.grid, device = device)[None].repeat(len(names), 1, 1, 1).float()
    x0 = torch.as_tensor(ex.x0, device = device)[None].repeat(len(names), 1, 1)
    mass = torch.as_tensor(ex.mass, device = device)[None].repeat(len(names), 1)
    extent = torch.as_tensor(ex.extent, device = device)[None].repeat(len(names), 1)
    movable = torch.stack([
        torch.tensor([EMBODIMENTS[nm].can_move(_ObjView(ex.mass[j], ex.extent[j])) for j in range(n)],
                     device = device)
        for nm in names
    ])
    emb_feat = torch.tensor([feature_vector(EMBODIMENTS[nm]) for nm in names],
                            dtype = torch.float32, device = device)

    reachable0 = None
    if model.use_reachable:
        # reachability is embodiment-dependent (can_traverse/climb differ per
        # body) -- ex.reachable0 was only ever computed for ex.emb_name, so
        # it can't be reused across the OTHER swapped-body columns here.
        # Recompute fresh per synthetic embodiment instead of passing None
        # (which would crash: to_object_tokens is sized for this column once
        # use_reachable=True, same bug class as the drop_obj miss above).
        from clear.data.data import example_scene
        from clear.data.oracle import reachable as _reachable
        scene = example_scene(ex)
        reachable0 = torch.tensor(
            [[_reachable(scene, EMBODIMENTS[nm], scene.objects[j].cell, set()) for j in range(n)]
             for nm in names],
            dtype = torch.bool, device = device,
        )

    feat0 = object_features(x0, mass, extent, torch.zeros(len(names), n, device = device),
                            0., movable, model.grid_hw, drop = model.drop_obj,
                            reachable0 = reachable0)
    if ex.obj_extra is not None:
        # scene-derived (line-of-sight/distance from the same start pose), not
        # embodiment-derived -- same value repeats across every swapped-body
        # column here, unlike reachable0 above which genuinely differs per body.
        extra = torch.as_tensor(ex.obj_extra, device = device)[None].repeat(len(names), 1, 1)
        feat0 = torch.cat([feat0, extra.to(feat0.dtype)], dim = -1)
    with torch.no_grad():
        mu, _ = model.priority_head(grid, feat0, emb_feat)
    mu = mu.cpu().numpy()

    fig, axes = plt.subplots(1, len(names), figsize = (4.2 * len(names), 4.4))
    for i, (nm, ax) in enumerate(zip(names, axes)):
        _draw_terrain(ax, ex)
        mov = np.flatnonzero(movable[i].cpu().numpy())
        order = mov[np.argsort(mu[i, mov])]
        for j in range(n):
            color = OBJ_C if j in mov else FIX_C
            ax.scatter(ex.x0[j, 0], ex.x0[j, 1], s = 300 * ex.extent[j] + 60, c = [color],
                       edgecolors = 'white', linewidths = 1.4, zorder = 3)
            label = f'#{list(order).index(j) + 1}' if j in order else 'X'
            ax.annotate(label, (ex.x0[j, 0], ex.x0[j, 1]), ha = 'center', va = 'center',
                        fontsize = 7.5, color = 'white', fontweight = 'bold', zorder = 4)
        ax.set_title(f'{nm}: mu-order {"-".join(map(str, order))}'
                     + ('   <- data emb' if nm == ex.emb_name else ''), fontsize = 9)
    fig.suptitle('capability counterfactual: same scene, swapped body (X = cannot move)',
                 fontsize = 10)
    fig.tight_layout()
    return fig


class _ObjView:
    def __init__(self, mass, extent):
        self.mass, self.extent = float(mass), float(extent)

# velocity field


def velocity_quiver_figure(model, ex, device = 'cpu', ts = (0.15, 0.5, 0.85)):
    """Predicted (blue) vs target (green) velocity at each mover's pose,
    across flow times, under the oracle order's mask."""
    fig, axes = plt.subplots(1, len(ts), figsize = (4.2 * len(ts), 4.4))
    for t, ax in zip(ts, np.atleast_1d(axes)):
        batch = single_batch(ex, device, t = float(t))
        feat = object_features(batch['pose'], batch['mass'], batch['extent'],
                               batch['s'], batch['t'], batch['movable'], model.grid_hw,
                               drop = model.drop_obj,
                               reachable0 = batch['reachable0'] if model.use_reachable else None)
        feat = _with_obj_extra(feat, batch)
        with torch.no_grad():
            v, _ = model.velocity_field(batch['grid'], feat, batch['emb_feat'],
                                        batch['rank'], batch['movable'])
        v = v[0].cpu().numpy()
        vt = batch['v_target'][0].cpu().numpy()
        pose = batch['pose'][0].cpu().numpy()
        s = batch['s'][0].cpu().numpy()

        _draw_terrain(ax, ex)
        movers = set(ex.orders[0])
        for j in range(len(ex.x0)):
            x, y = pose[j, 0], pose[j, 1]
            ax.scatter(x, y, s = 120, c = [OBJ_C if ex.movable[j] else FIX_C],
                       edgecolors = 'white', linewidths = 1.2, zorder = 3)
            if j in movers:
                ax.annotate('', (x + vt[j, 0] * .3, y + vt[j, 1] * .3), (x, y),
                            arrowprops = dict(arrowstyle = '->', color = VEL_C, lw = 2.5), zorder = 4)
            if ex.movable[j]:
                ax.annotate('', (x + v[j, 0] * .3, y + v[j, 1] * .3), (x, y),
                            arrowprops = dict(arrowstyle = '->', color = 'blue', lw = 1.5), zorder = 5)
        ax.set_title(f't={t}   s={np.array2string(s, precision = 2)}', fontsize = 8)
    fig.suptitle('velocity: predicted (blue) vs target (green), oracle order mask', fontsize = 10)
    fig.tight_layout()
    return fig

# metric slices live in clear/eval.py (no matplotlib needed there); re-exported
# so `from viz.model import order_acc_by` keeps working

from clear.eval import order_acc_by  # noqa: E402, F401

# one-call bundle for the train loop


def training_figures(model, examples, device = 'cpu', generator = None):
    """Pick the most informative val examples and return {name: Figure}.
    Selection: one multimodal scene, one deep scene, one per embodiment."""
    def pick(pred):
        return next((ex for ex in examples if pred(ex)), None)

    multi = pick(lambda ex: len(ex.orders) > 1 and ex.n_moved > 0)
    deep = pick(lambda ex: ex.n_moved >= 3) or pick(lambda ex: ex.n_moved == 2)
    per_emb = {nm: pick(lambda ex, nm = nm: ex.emb_name == nm and ex.n_moved > 0)
               for nm in EMBODIMENTS}

    figs = {}
    anchor = multi or deep or next(ex for ex in examples if ex.n_moved > 0)
    figs['attn/priority'] = priority_attention_figure(model, anchor, device)
    figs['attn/velocity'] = velocity_attention_figure(model, anchor, device)
    figs['tokens/pca_capsim'] = token_pca_figure(model, examples, device)
    figs['capability/counterfactual'] = capability_counterfactual_figure(model, anchor, device)
    figs['flow/velocity_quiver'] = velocity_quiver_figure(model, deep or anchor, device)
    if multi is not None:
        figs['tau/multimodal'] = tau_figure(model, multi, device, generator = generator)
    if deep is not None and deep is not multi:
        figs['tau/deep'] = tau_figure(model, deep, device, generator = generator)
    for nm, ex in per_emb.items():
        if ex is not None:
            batch = single_batch(ex, device)
            order = model.sample_orders(batch, generator = generator)[0][0]
            plan = model.sample(batch, generator = generator)
            figs[f'plan/{nm}'] = scene_plan_figure(ex, order = list(order),
                                                   x_final = plan['x'][0].cpu().numpy())
    return figs
