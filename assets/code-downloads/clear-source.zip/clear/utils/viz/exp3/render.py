"""Qualitative figures (spec 11).  matplotlib only -- `mujoco.Renderer` needs EGL/OSMesa,
which this host does not have, so no RGB panel is produced here (see REPORT, risk R1).

  paired_scene_figure   spec 11.1: one row per base scene, one column per embodiment.
                        Each panel draws the terrain (height as greyscale, ramps hatched,
                        narrow gates marked), the executed route, the selected objects with
                        their interaction number and displacement arrow, the selected body
                        part, and the trial's success/failure.  Scenes are chosen by the
                        spec's fixed rule: one STAIR_VS_FLAT, one ARM_GATE and one
                        MULTI_GATE base scene whose oracle signature sets are disjoint.
  traversability_figure spec 11.2: for one scene, the counterfactual-occlusion attribution
                        map per body with that body's predicted route overlaid.
"""
from __future__ import annotations

import json
import os

import numpy as np

from experiments.common.interfaces import read_trials
from experiments.common.manifests import read_manifests
from clear.maze import robots as R
from experiments.exp3.scene_io import manifest_path, scene_from_manifest

FIG_FAMILIES = ("STAIR_VS_FLAT", "ARM_GATE", "MULTI_GATE")


def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt


def _draw_scene(ax, scene):
    h, w = scene.shape
    hgt = np.asarray(scene.height, float)
    ax.imshow(np.clip(hgt / max(scene.wall_h, 1e-6), 0, 1), cmap="Greys", vmin=0, vmax=1,
              origin="upper", interpolation="nearest")
    for r in range(h):
        for c in range(w):
            if scene.slope_deg[r, c] > 0:
                ax.add_patch(_rect(r, c, facecolor="none", edgecolor="#3b6ea5", hatch="///", lw=0.0))
            if scene.passage_width[r, c] < scene.cell_m - 1e-6:
                ax.add_patch(_rect(r, c, facecolor="none", edgecolor="#b8860b", lw=1.6))
    ax.plot(scene.start[1], scene.start[0], marker="s", color="#3b76d9", ms=7, zorder=5)
    ax.plot(scene.goal[1], scene.goal[0], marker="*", color="#d94040", ms=13, zorder=5)
    ax.set_xticks([]); ax.set_yticks([])
    ax.set_xlim(-0.5, w - 0.5); ax.set_ylim(h - 0.5, -0.5)


def _rect(r, c, **kw):
    from matplotlib.patches import Rectangle
    return Rectangle((c - 0.5, r - 0.5), 1, 1, **kw)


def _panel(ax, scene, record, colour):
    _draw_scene(ax, scene)
    traj = [tuple(t) for t in record.extra.get("trajectory", [])]
    if len(traj) > 1:
        ax.plot([c for _, c in traj], [r for r, _ in traj], "-", color=colour, lw=2.0, alpha=0.9, zorder=4)
    order = record.extra.get("attempted_objects", [])
    pred = list(record.predicted_order)
    parts = list(record.extra.get("body_parts", []))
    for o in scene.objects:
        r, c = o.cell
        sel = int(o.object_id) in pred
        ax.add_patch(_rect(r, c, facecolor="#c98a4b" if sel else "#9aa0a6",
                           edgecolor="k", lw=0.6, alpha=0.95 if sel else 0.55, zorder=3))
        ax.text(c, r, f"{o.mass:.0f}", ha="center", va="center", fontsize=5.5, color="w", zorder=4)
        if sel:
            k = pred.index(int(o.object_id))
            tgt = record.extra.get("final_object_cells", {}).get(str(o.object_id))
            ax.text(c - 0.42, r - 0.42, str(k + 1), fontsize=7, color="#111", weight="bold", zorder=6)
            if tgt:
                ax.annotate("", xy=(tgt[1], tgt[0]), xytext=(c, r), zorder=6,
                            arrowprops=dict(arrowstyle="->", color="#7a3b00", lw=1.3))
    ok = bool(record.task_success)
    lbl = "OK" if ok else (record.failure_type or "FAIL")
    part_s = "/".join(sorted(set(parts))) if parts else "-"
    ax.set_title(f"{record.embodiment_id}\n{record.extra.get('route_class', '?')} | {part_s} | {lbl}",
                 fontsize=6.5, color="#0a7d29" if ok else "#a11",
                 pad=3)


def paired_scene_figure(records, manifests, out_path, bodies=None, families=FIG_FAMILIES,
                        method=None) -> str | None:
    plt = _mpl()
    by_id = {m.scene_id: m for m in manifests}
    bodies = list(bodies or R.MAIN_BODIES)
    recs = [r for r in records if method is None or r.method == method]
    by_base = {}
    for r in recs:
        by_base.setdefault(r.extra.get("base_scene_id"), {})[r.embodiment_id] = r
    chosen = []
    for fam in families:
        for base, bodymap in sorted(by_base.items()):
            if base in [c[0] for c in chosen] or not base:
                continue
            m = by_id.get(next(iter(bodymap.values())).scene_id)
            if m is None or m.scene_family != fam:
                continue
            if not all(b in bodymap for b in bodies):
                continue
            if not m.extra.get("switch_pairs_strict"):
                continue
            chosen.append((base, bodymap))
            break
    if not chosen:
        return None
    fig, axes = plt.subplots(len(chosen), len(bodies), figsize=(2.05 * len(bodies), 2.35 * len(chosen)),
                             squeeze=False)
    for i, (base, bodymap) in enumerate(chosen):
        for j, b in enumerate(bodies):
            rec = bodymap[b]
            scene = scene_from_manifest(by_id[rec.scene_id])
            _panel(axes[i][j], scene, rec, R.get(b).color)
        axes[i][0].set_ylabel(f"{by_id[bodymap[bodies[0]].scene_id].scene_family}\n{base[-10:]}",
                              fontsize=6)
    fig.suptitle(f"Paired scenes, one row per base scene, one column per embodiment"
                 f"{'' if method is None else f'  --  {method}'}", fontsize=8)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    fig.savefig(out_path, dpi=170)
    plt.close(fig)
    return out_path


def traversability_figure(model, examples, out_path, bodies=None) -> str | None:
    """spec 11.2: same scene, phi_B swapped, occlusion attribution + predicted route."""
    from experiments.exp3.attribution import occlusion_map
    from clear.maze.robots import padded_rows, structure_for
    plt = _mpl()
    bodies = list(bodies or R.MAIN_BODIES)
    ex = examples[0]
    fig, axes = plt.subplots(1, len(bodies), figsize=(2.2 * len(bodies), 2.5), squeeze=False)
    maps = [occlusion_map(model, ex, padded_rows(structure_for(b).rows)) for b in bodies]
    vmax = max(1e-9, max(float(m.max()) for m in maps))
    for j, (b, m) in enumerate(zip(bodies, maps)):
        ax = axes[0][j]
        ax.imshow(m / vmax, cmap="magma", vmin=0, vmax=1, origin="upper", interpolation="nearest")
        ax.set_title(b, fontsize=7)
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle(f"phi_B-conditioned occlusion attribution -- same scene ({ex.scene_id.rsplit('__', 1)[0]}), "
                 f"only the structural description changes", fontsize=7)
    fig.tight_layout(rect=(0, 0, 1, 0.9))
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    fig.savefig(out_path, dpi=170)
    plt.close(fig)
    return out_path


def render_all(run_dir, split, data_root, method=None, attribution=False, config=None,
               runs_root=None, training_seed=0) -> list:
    records = read_trials(os.path.join(run_dir, "trial_metrics.jsonl"))
    manifests = read_manifests(manifest_path(split, data_root))
    figs = os.path.join(run_dir, "figures")
    out = []
    methods = [method] if method else sorted({r.method for r in records})
    for m in methods:
        p = paired_scene_figure(records, manifests, os.path.join(figs, f"paired_scenes_{m}.png"), method=m)
        if p:
            out.append(p)
    if attribution:
        from experiments.exp3.model import load_examples
        from experiments.exp3.train import load_checkpoint
        ck = os.path.join(runs_root or os.path.dirname(run_dir), f"clear_seed{training_seed}", "checkpoint.pt")
        if os.path.exists(ck):
            model, _ = load_checkpoint(ck)
            ex = load_examples(os.path.join(data_root, split, "examples.npz"))
            p = traversability_figure(model, ex, os.path.join(figs, "traversability_phiB.png"))
            if p:
                out.append(p)
    return out
